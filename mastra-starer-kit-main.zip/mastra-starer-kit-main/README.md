# Mastra AIエージェント with チャットUI

このプロジェクトは、[assistant-ui](https://www.assistant-ui.com/)と[Mastra](https://mastra.ai/)を使用して構築された、チャットUI付きのAIエージェントアプリケーションです。

このプロジェクトは以下の記事を参考に作成されています：
- [Mastraを使ってAIエージェントを作ろう！ - 基礎編(2) -](https://zenn.dev/tokium_dev/articles/mastra-ai-agent-handson-basic-2)

## 機能

- **チャットUI**: ChatGPTのようなインターフェースでAIエージェントと対話
- **天気エージェント**: 指定した場所の天気情報を取得するAIエージェント
- **Mastra統合**: Mastraフレームワークを使用したエージェント実装
- **Vercel対応**: 簡単にVercelにデプロイ可能

## 必要な環境

- **Node.js**: v20.0以上
- **npm/yarn/pnpm**: パッケージマネージャー
- **OpenAI APIキー**: サポート対象のモデルプロバイダーのAPIキー（本プロジェクトではOpenAIを使用）

## セットアップ手順

### 1. 依存関係のインストール

```bash
npm install
# または
pnpm install
```

### 2. 環境変数の設定

プロジェクトルートに `.env.local` ファイルを作成し、以下の環境変数を設定してください：

```bash
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 3. ローカル開発サーバーの起動

```bash
npm run dev
# または
pnpm dev
```

開発サーバーが起動したら、ブラウザで [http://localhost:3000](http://localhost:3000) にアクセスしてください。

### 4. Mastra Playgroundの起動（オプション）

Mastraの開発用Playgroundを起動する場合：

```bash
npm run mastra:dev
```

## プロジェクト構造

```
├── app/
│   ├── api/
│   │   └── chat/
│   │       └── route.ts          # APIルート（チャットエンドポイント）
│   ├── assistant.tsx             # assistant-ui設定
│   ├── page.tsx                  # メインページ
│   └── ...
├── components/
│   ├── assistant-ui/            # assistant-uiコンポーネント
│   └── ui/                      # UIコンポーネント
├── mastra/
│   ├── agents/
│   │   └── weather-agent.ts     # 天気エージェントの定義
│   ├── tools/
│   │   └── weather-tool.ts      # 天気情報取得ツール
│   ├── workflows/
│   │   └── weather-workflow.ts  # 天気ワークフロー
│   └── index.ts                 # Mastra設定
└── ...
```

## 主な実装内容

### APIルート (`app/api/chat/route.ts`)

チャットUIからのリクエストを受け取り、Mastraエージェントを実行するAPIエンドポイントです。

```typescript
import { mastra } from "@/mastra";
import { toAISdkFormat } from "@mastra/ai-sdk";
import { createUIMessageStreamResponse, UIMessage } from "ai";

export const maxDuration = 30;

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();
  const agent = mastra.getAgent("weatherAgent");
  const result = await agent.stream(messages);

  return createUIMessageStreamResponse({
    stream: toAISdkFormat(
      result,
      { from: "agent" },
    ),
  });
}
```

### Mastra設定 (`mastra/index.ts`)

Mastraの初期化設定とエージェント・ワークフローの登録を行います。

### 天気エージェント (`mastra/agents/weather-agent.ts`)

天気情報を取得するためのエージェント定義です。OpenAI GPT-4o-miniモデルを使用し、天気ツールを利用できます。

## 利用可能なコマンド

```bash
# 開発サーバーの起動
npm run dev

# プロダクションビルド
npm run build

# プロダクションサーバーの起動
npm start

# リンターの実行
npm run lint

# Prettierのチェック
npm run prettier

# Prettierの自動修正
npm run prettier:fix

# Mastra Playgroundの起動
npm run mastra:dev
```

## 参考リンク

- [assistant-ui公式ドキュメント](https://www.assistant-ui.com/)
- [Mastra公式ドキュメント](https://mastra.ai/docs)
- [Mastra > Full-Stack Integration](https://mastra.ai/docs)
- [参考記事: Mastraを使ってAIエージェントを作ろう！ - 基礎編(2) -](https://zenn.dev/tokium_dev/articles/mastra-ai-agent-handson-basic-2)

## ライセンス

このプロジェクトは参考記事の内容に基づいて作成されています。
