import argparse
import asyncio
import datetime

from agent_utils import build_agent, load_env
from strands import Agent, tool
from strands.models.openai import OpenAIModel
from strands.tools.mcp import MCPClient
from strands_tools import calculator, current_time, shell
from mcp import stdio_client, StdioServerParameters


def build_model() -> OpenAIModel:
    # agent_utils.pyの共通設定からモデルを構築
    config = load_env()
    base_agent = build_agent(config)
    return base_agent.model


def showtime(label: str) -> None:
    # 目視しやすいタイムスタンプを出力
    now = datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f")[:-3]
    print(f"{now} : {label}")


def run_basic_agent(model: OpenAIModel) -> None:
    # 最小構成のエージェント実行
    agent = Agent(model=model)
    agent("AWS Bedrockって何？")


@tool
def counter(word: str, letter: str) -> int:
    return word.lower().count(letter.lower())


def run_tool_agent(model: OpenAIModel) -> None:
    # shellツールは強力なので、学習用途のみで利用してください。
    agent = Agent(
        model=model,
        tools=[counter, current_time, calculator, shell],
    )
    agent("straberryの中にrはいくつある？")
    agent("今の時間を教えて")
    agent("2 + 2 を計算して")


async def stream_once(agent: Agent, prompt: str) -> None:
    # ストリーミング結果を逐次表示
    agent_stream = agent.stream_async(prompt)
    async for event in agent_stream:
        if "result" in event:
            result = event.get("result")
            print(result)


def run_streaming(model: OpenAIModel) -> None:
    # ストリーミング実行の例
    agent = Agent(model=model, tools=[calculator, current_time])
    showtime("START")
    asyncio.run(stream_once(agent, "2+2"))
    showtime("END")

    showtime("START")
    asyncio.run(stream_once(agent, "今何時?"))
    showtime("END")


def run_mcp(model: OpenAIModel) -> None:
    # MCPサーバーからツールを読み込んで実行
    mcp = MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["strands-agents-mcp-server"],
            )
        )
    )
    with mcp:
        agent = Agent(
            model=model,
            tools=mcp.list_tools_sync(),
        )
        agent("StrandsでA2Aサーバーの最小サンプルコードを書いて！")


def run_multi_agent(model: OpenAIModel) -> None:
    # サブエージェントをツールとして呼び出す例
    @tool
    def math_agent(query: str) -> str:
        agent = Agent(
            model=model,
            system_prompt="ツールを使って計算を行ってください",
            tools=[calculator],
        )
        return str(agent(query))

    @tool
    def haiku_agent(query: str) -> str:
        agent = Agent(
            model=model,
            system_prompt="与えられたお題で五・七・五の俳句を詠んで",
        )
        return str(agent(query))

    orchestrator = Agent(
        model=model,
        system_prompt="与えられた問題を計算して、答えを俳句として詠んで",
        tools=[math_agent, haiku_agent],
    )
    orchestrator("十円持っている太郎くんが二十円もらいました。今いくら？")


def parse_args() -> argparse.Namespace:
    # 実行モードを選択
    parser = argparse.ArgumentParser(description="Strands初学者向けサンプル集")
    parser.add_argument(
        "sample",
        nargs="?",
        default="basic",
        choices=["basic", "tools", "stream", "mcp", "multi", "all"],
        help="実行するサンプルを選択",
    )
    return parser.parse_args()


def main() -> None:
    # モデルを構築してサンプルを切り替え実行
    model = build_model()
    args = parse_args()

    if args.sample == "basic":
        run_basic_agent(model)
        return
    if args.sample == "tools":
        run_tool_agent(model)
        return
    if args.sample == "stream":
        run_streaming(model)
        return
    if args.sample == "mcp":
        run_mcp(model)
        return
    if args.sample == "multi":
        run_multi_agent(model)
        return

    run_basic_agent(model)
    run_tool_agent(model)
    run_streaming(model)
    run_mcp(model)
    run_multi_agent(model)


if __name__ == "__main__":
    main()
