import os

from dotenv import load_dotenv
from strands import Agent
from strands.models.openai import OpenAIModel


def load_env() -> dict:
    load_dotenv()
    config = {
        "api_key": os.getenv("OPENAI_API_KEY"),
        "base_url": os.getenv("OPENAI_BASE_URL"),
        "model_id": os.getenv("OPENAI_MODEL_ID"),
        "temperature": os.getenv("OPENAI_TEMPERATURE"),
        "max_tokens": os.getenv("OPENAI_MAX_TOKENS"),
        "timeout": os.getenv("OPENAI_TIMEOUT"),
        "max_retries": os.getenv("OPENAI_MAX_RETRIES"),
    }
    missing = [key for key, value in config.items() if key in {"api_key", "model_id"} and not value]
    if missing:
        raise RuntimeError(
            "Missing required env vars: "
            + ", ".join([f"OPENAI_{key.upper()}" for key in missing])
        )
    return config


def build_agent(config: dict) -> Agent:
    client_args: dict = {"api_key": config["api_key"]}
    if config["base_url"]:
        client_args["base_url"] = config["base_url"]
    if config["timeout"]:
        client_args["timeout"] = float(config["timeout"])
    if config["max_retries"]:
        client_args["max_retries"] = int(config["max_retries"])

    params = {}
    if config["temperature"]:
        params["temperature"] = float(config["temperature"])
    if config["max_tokens"]:
        params["max_tokens"] = int(config["max_tokens"])

    model = OpenAIModel(
        client_args=client_args,
        model_id=config["model_id"],
        params=params,
    )
    return Agent(model=model)
