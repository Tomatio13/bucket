# Strands Agents 初学者向けサンプル

このフォルダには、Strands Agents の基本的な使い方を学ぶためのサンプルを
1ファイルにまとめています。

## セットアップ

`env.example` を `.env` としてコピーし、値を設定してください。

```bash
cp env.example .env
```

`.env` に以下の環境変数を設定してください。

- `OPENAI_API_KEY` (必須)
- `OPENAI_MODEL_ID` (必須)
- `OPENAI_BASE_URL` (任意)
- `OPENAI_TEMPERATURE` (任意)
- `OPENAI_MAX_TOKENS` (任意)
- `OPENAI_TIMEOUT` (任意)
- `OPENAI_MAX_RETRIES` (任意)


仮想環境を用意し、必要なライブラリをインストールしてください。
```bash
uv venv
source .venv/bin/activate
uv pip install -r requirements.txt
```

## 使い方

### 各サンプルの説明

- `basic`: 最小構成のエージェント
- `tools`: ツール利用（counter / current_time / calculator / shell）
- `stream`: ストリーミング応答の例
- `mcp`: MCPツールの読み込み
- `multi`: ツール化したサブエージェントの協調
- `all`: すべてのサンプルを順番に実行

### コマンドイメージ
```bash
python all_in_one.py basic
python all_in_one.py tools
python all_in_one.py stream
python all_in_one.py mcp
python all_in_one.py multi
python all_in_one.py all
```

### 流れ（ざっくり）

1. `agent_utils.py` を使って `.env` から設定を読み込む  
2. 読み込んだ設定でモデルを作成する  
3. 引数に応じて、該当するサンプル関数を実行する  

## プログラムの概要

### 主要コンポーネント

- `Agent`: 会話の司令塔。モデルとツールを束ねる
- `Model`: LLM本体。ここでは `OpenAIModel` を使用
- `Tool`: エージェントが呼び出せる関数（例: 計算、時刻取得）
- `MCPClient`: 外部サーバーからツールを取得する仕組み
- `agent_utils.py`: 環境変数を読み込み、モデル作成の共通処理を提供

### データフロー（簡略）

1. `.env` から設定を読み込む  
2. モデルを構築する  
3. `Agent` を作成し、必要なツールを登録する  
4. ユーザー入力を `Agent` に渡す  
5. 必要ならツールを呼び出して結果を返す  

### Basic（最小構成）の位置づけ

Basic は「モデルを使って1回だけ質問する」最小構成です。
まずはここで、Agentの動きに慣れます。

#### サンプルコード（Basic）

```python
agent = Agent(model=model)
agent("AWS Bedrockって何？")
```

### MCP（Model Context Protocol）の位置づけ

Strands Agents では、MCP を使うと「外部ツール群をまとめて取り込む」ことができます。
通常のツールは Python 内で関数として定義しますが、MCP は別プロセスで動くツールサーバー
から動的にツール一覧を取得します。

#### MCPの流れ（概念）

1. MCPサーバーを起動（このサンプルでは `uvx strands-agents-mcp-server`）  
2. `MCPClient` がサーバーに接続  
3. `mcp.list_tools_sync()` でツール一覧を取得  
4. `Agent` にツールを登録して利用  

#### 使いどころ

- **外部連携の切り替え**: サーバー側でツールを差し替えるだけで機能を変更できる  
- **チーム共有**: 同じMCPサーバーを使えば、全員が共通ツールを利用できる  
- **拡張性**: 新しいツール追加がサーバー側で完結する  

#### 注意点

- MCPツールは「どんな機能を持つか」を理解した上で使うこと  
- 強力なツール（ファイル操作など）は本番環境での利用範囲を明確にすること  

#### サンプルコード（MCP）

```python
mcp = MCPClient(
    lambda: stdio_client(
        StdioServerParameters(
            command="uvx",
            args=["strands-agents-mcp-server"],
        )
    )
)
```

### Tools（ツール）の位置づけ

Strands Agents では、ツールは「エージェントが実行できる関数」です。
モデルは会話の中で「この処理はツールに任せるべき」と判断すると、登録済みのツールを呼びます。

#### Toolsの流れ（概念）

1. `@tool` で関数をツール化  
2. `Agent` に `tools=[...]` として登録  
3. エージェントが必要に応じてツールを呼ぶ  
4. ツールの戻り値を使って最終回答を作る  

#### 使いどころ

- **決まった処理の再利用**: 計算、日時取得などの定型処理  
- **信頼性**: LLMの推測ではなく、確定処理で答えたい場合  
- **拡張性**: ツールを追加するだけで機能を増やせる  

#### 注意点

- ツールは「入力と出力が明確な小さな関数」にする  
- `shell` のような強力なツールは権限や用途を明確にする  

#### サンプルコード（Tools）

```python
@tool
def counter(word: str, letter: str) -> int:
    return word.lower().count(letter.lower())

agent = Agent(
    model=model,
    tools=[counter, current_time, calculator, shell],
)
agent("straberryの中にrはいくつある？")
```

### Streaming（ストリーミング）の位置づけ

ストリーミングは「応答が生成される途中経過を逐次受け取る」仕組みです。
長文回答や処理の進行を、待たずに表示できるのが利点です。

#### Streamingの流れ（概念）

1. `agent.stream_async()` を呼ぶ  
2. `async for` でイベントを順次受け取る  
3. `result` イベントを表示する  

#### 使いどころ

- **待ち時間の短縮**: 長い回答を早く見せたい  
- **進行状況の可視化**: ユーザーに処理中を伝える  

#### 注意点

- 非同期処理なので `asyncio.run` などの実行方法を合わせる  
- 逐次表示が不要なら通常の呼び出しで十分  

#### サンプルコード（Streaming）

```python
async def stream_once(agent: Agent, prompt: str) -> None:
    agent_stream = agent.stream_async(prompt)
    async for event in agent_stream:
        if "result" in event:
            print(event.get("result"))
```

### Multi-Agent（サブエージェント連携）の位置づけ

Multi-Agent は「専門エージェントをツール化して分業する」構成です。
1つのエージェントが全部やるのではなく、役割を分けて協調させます。

#### Multi-Agentの流れ（概念）

1. サブエージェントを `@tool` で包む  
2. 監督（orchestrator）エージェントにツールとして登録  
3. 監督エージェントが必要に応じてサブエージェントを呼ぶ  
4. まとめて最終回答を返す  

#### 使いどころ

- **役割分担**: 計算担当、文章担当などを分けたい  
- **品質向上**: 専門プロンプトを使い分けたい  
- **スケール**: 大きなタスクを小さく分けたい  

#### 注意点

- サブエージェントの入出力をシンプルにする  
- 監督エージェントの指示（system_prompt）で役割を明確化する  

#### サンプルコード（Multi-Agent）

```python
@tool
def math_agent(query: str) -> str:
    agent = Agent(model=model, tools=[calculator])
    return str(agent(query))

orchestrator = Agent(
    model=model,
    tools=[math_agent],
)
```

