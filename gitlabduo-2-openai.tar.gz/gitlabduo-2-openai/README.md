<h1 align="center">gitlabduo-2-openai</h1>

<p align="center">
  GitLab Duo GraphQL を OpenAI 互換 API として公開する軽量 proxy
</p>

<p align="center">
  主用途は通常の chat completion で、必要な場合にだけ tool calling を扱います。
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-stdlib%20only-3776AB?logo=python&logoColor=white" alt="Python stdlib only">
  <img src="https://img.shields.io/badge/API-OpenAI%20compatible-10A37F" alt="OpenAI compatible API">
  <img src="https://img.shields.io/badge/Backend-GitLab%20Duo-FCA121" alt="GitLab Duo GraphQL backend">
</p>

## 🚀 Quick Start

### Prerequisites

- Python 3.11 以降
- GitLab Duo が有効な GitLab 環境
- GraphQL 呼び出しに使う GitLab token

### Minimal Setup

```bash
# edit run.sh first
./run.sh
```

### Smoke Check

```bash
curl -s http://127.0.0.1:8000/healthz
```

## 📝 Overview

このプロジェクトは、OpenAI 互換クライアントから GitLab Duo を使えるようにするための変換層です。

まずできること:

- 通常のチャット
- streaming チャット
- assistant からの `tool_calls`
- クライアントが保持する `messages` を前提にした会話継続
- クライアントが実行した tool 結果の round-trip

設計の中心はあくまで chat completion です。  
tool は、その上に載る追加機能として扱っています。

## 🎯 Primary Use Case

最も基本的な使い方は、OpenAI 互換クライアントから普通の chat API として呼ぶことです。

1. クライアントが `/v1/chat/completions` を呼ぶ
2. proxy が GitLab Duo に問い合わせる
3. assistant の自然文応答を OpenAI 互換形式で返す

tools を使わないチャットだけでも動作します。

## ✨ Features

- `GET /healthz`
- `GET /v1/models`
- `POST /v1/chat/completions`
- non-stream / stream の両対応
- OpenAI 互換 `tool_calls` の返却
- `role:"tool"` の受理
- `tool_call_id` と tool 名の整合性チェック
- Python 標準ライブラリのみで動作

## ✅ What Works Today

### 1. Standard Chat

- tools なしの通常チャット
- assistant の自然文応答
- OpenAI 互換 `chat.completion` レスポンス

### 2. Streaming Chat

- `stream=true`
- OpenAI 互換の data-only SSE
- `chat.completion.chunk`
- `data: [DONE]`

### 3. Tool Calling

- assistant からの `tool_calls`
- クライアント側の local tool 実行
- `role:"tool"` を返して tool round-trip を継続

## 🚫 Non-Goals

- proxy 自身が Bash や filesystem tool を実行すること
- GitLab GraphQL operation registry を proxy 側で実行すること
- OpenAI Responses API 互換
- Action Cable を使った native subscription client
- 完全な JSON Schema validator

## 🔌 API Surface

### `GET /healthz`

疎通確認用 endpoint です。

### `GET /v1/models`

OpenAI 互換の model list を返します。

### `POST /v1/chat/completions`

現在主に対応している入力:

- `model`
- `messages`
- `stream`
- `tools`
- `metadata`

未対応パラメータ:

- `audio`
- `logprobs`
- `prediction`
- `service_tier`
- `store`

これらは明示的に 400 を返します。

## 🔄 Chat Flow

### Normal Chat

1. クライアントが `messages` を送る
2. proxy が `messages` を GitLab Duo 向け prompt に変換する
3. proxy が `aiAction(chat)` を呼ぶ
4. proxy が `aiMessages(threadId)` を polling する
5. assistant text を OpenAI 互換形式で返す

### Chat With Tools

1. クライアントが `messages + tools` を送る
2. proxy が tools の説明を Duo 向け preamble に埋め込む
3. Duo が tool envelope を返す
4. proxy が `tool_calls` に変換して返す
5. クライアントがローカルで tool を実行する
6. クライアントが `role:"tool"` を返す
7. proxy がその結果を Duo に渡して tool round-trip を継続する

## 🧩 Message Compatibility

`messages[*].content` は次を受け入れます。

- string
- object
- array
- number
- boolean
- null

このため、通常の chat message だけでなく、構造化された tool 結果も取り込めます。

## 🛠️ Tool Model

この proxy は client-executed tools を前提にしています。

- proxy は `tool_calls` を返す
- 実際の tool 実行はクライアントが行う
- 通常会話の継続性はクライアントが `messages` 履歴で担保する
- proxy は tool result を GitLab Duo に橋渡しする

整合性ルール:

- `tool_call_id` が未知なら reject
- `tool_call_id` と `name` が不一致なら reject
- `name` が無ければ `tool_call_id` だけで解決可能

## 🏗️ Architecture

詳細は [docs/architecture.md](docs/architecture.md) を参照してください。

主要コンポーネント:

- [src/server.py](src/server.py)
  - HTTP サーバ起動
- [src/router.py](src/router.py)
  - endpoint 振り分け
- [src/openai_handlers.py](src/openai_handlers.py)
  - OpenAI 互換 request / response 整形
- [src/chat_bridge.py](src/chat_bridge.py)
  - GitLab Duo 会話変換、tool round-trip、polling 制御
- [src/duo_client.py](src/duo_client.py)
  - GraphQL 呼び出し
- [src/state_store.py](src/state_store.py)
  - `sqlite3` による最小 state / audit 保存
- [src/tool_emulator.py](src/tool_emulator.py)
  - incoming tools の preamble 化と tool envelope parse

## ⚙️ Configuration

主な環境変数:

```text
┌──────────────────────────────┬────────┬───────────────────────┬────────────────────────────────────────────┐
│ 変数名                       │ 必須   │ default               │ 意味                                       │
├──────────────────────────────┼────────┼───────────────────────┼────────────────────────────────────────────┤
│ WRAPPER_API_KEY              │ 必須   │ `dev-proxy-key`       │ クライアントが proxy を呼ぶための API key  │
│ GITLAB_BASE_URL              │ 必須   │ `https://gitlab.exa…` │ GitLab のベース URL                        │
│ GITLAB_TOKEN                 │ 必須   │ なし                  │ GitLab GraphQL 呼び出し用 token            │
│ PROXY_HOST                   │ 任意   │ `127.0.0.1`           │ proxy の listen host                       │
│ PROXY_PORT                   │ 任意   │ `8000`                │ proxy の listen port                       │
│ REQUEST_TIMEOUT_SECONDS      │ 任意   │ `30`                  │ GitLab への 1 リクエスト timeout 秒数      │
│ POLLING_INTERVAL_SECONDS     │ 任意   │ `1`                   │ `aiMessages` polling 間隔                  │
│ POLLING_TIMEOUT_SECONDS      │ 任意   │ `30`                  │ polling 全体の timeout 秒数                │
│ ENABLE_ACTION_CABLE_STREAM… │ 任意   │ `false`               │ 将来の Action Cable 経路の feature flag    │
└──────────────────────────────┴────────┴───────────────────────┴────────────────────────────────────────────┘
```

現在の実装では、`WRAPPER_API_KEY`、`GITLAB_BASE_URL`、`GITLAB_TOKEN` を最低限入れておけば動かせます。

## ▶️ Run

起動:

```bash
./run.sh
```

疎通確認:

```bash
curl -s http://127.0.0.1:8000/healthz
```

通常チャット例:

```bash
curl -s http://127.0.0.1:8000/v1/chat/completions \
  -H "Authorization: Bearer test-key" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gitlab-duo-chat",
    "messages": [
      {"role": "user", "content": "Hello"}
    ]
  }'
```

## 🧪 Testing

通常テスト:

```bash
python -m unittest discover -s tests -v
```

live 統合テスト:

```bash
python -m unittest tests.test_integration_live -v
```

### Live Integration Test

[tests/test_integration_live.py](tests/test_integration_live.py) は、環境変数が設定されたときだけ動きます。

最低限必要:

```text
┌──────────────────────────┬────────┬─────────┬──────────────────────────────────────┐
│ 変数名                   │ 必須   │ default │ 意味                                 │
├──────────────────────────┼────────┼─────────┼──────────────────────────────────────┤
│ LIVE_GITLAB_BASE_URL     │ 必須   │ なし    │ live 統合テスト用 GitLab base URL    │
│ LIVE_GITLAB_TOKEN        │ 必須   │ なし    │ live 統合テスト用 GitLab token       │
│ LIVE_DUO_TEST_PROMPT     │ 任意   │ なし    │ chat bridge smoke test 用 prompt     │
│ LIVE_DUO_TEST_MODEL      │ 任意   │ なし    │ chat bridge smoke test 用 model      │
└──────────────────────────┴────────┴─────────┴──────────────────────────────────────┘
```

## 📌 Operational Notes

- proxy はローカル tool 実行をしません
- tool 実行主体は OpenAI 互換クライアントです
- 通常会話の継続性はクライアントが `messages` を再送することで担保します
- proxy の state は主に `tool_call_id` と GitLab Duo `thread_id` の対応保持に使います
- `proxy_state.sqlite3` に最小 state を保存します

## ⚠️ Limitations

- OpenAI Responses API には未対応です
- native GitLab subscription transport は未対応です
- usage token は概算または省略になる場合があります
- 高度な observability は未整備です
- 本番運用向けの HA 構成は未整備です

## 📚 Design Docs

- [docs/architecture.md](docs/architecture.md)
