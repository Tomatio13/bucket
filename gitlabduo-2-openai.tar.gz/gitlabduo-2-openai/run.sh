#!/usr/bin/env sh

set -eu

export WRAPPER_API_KEY="test-key"
export GITLAB_BASE_URL="https://gitlab.example.com"
export GITLAB_TOKEN="glpat-..."

if [ "$GITLAB_BASE_URL" = "https://gitlab.example.com" ] || [ "$GITLAB_TOKEN" = "glpat-..." ]; then
  echo "error: edit run.sh and set real GitLab credentials first" >&2
  exit 1
fi

exec python -m src.server
