# Architecture

## Overview

このリポジトリは、GitLab Duo GraphQL を OpenAI 互換の Chat Completions API として公開する軽量 proxy です。

現行実装の中心は `POST /v1/chat/completions` です。  
`tools` が指定された場合だけ、GitLab Duo の最終応答を JSON envelope として解釈し、OpenAI 互換の `tool_calls` に変換します。

設計上の基本方針:

- proxy 自身はローカル Bash や filesystem tool を実行しない
- tool 実行主体は常にクライアント側に置く
- Python 標準ライブラリだけで完結する
- GitLab Duo とのやり取りは GraphQL mutation/query と polling で行う

## Sequence Diagram

```mermaid
sequenceDiagram
    participant Client as OpenAI互換クライアント
    participant Proxy as gitlabduo-2-openai proxy
    participant Duo as GitLab Duo

    Client->>Proxy: POST /v1/chat/completions<br/>messages, tools?, stream?
    Proxy->>Proxy: OpenAI互換requestを検証
    Proxy->>Proxy: messagesをDuo向けpromptへ変換
    Proxy->>Duo: aiAction(chat)
    loop polling
        Proxy->>Duo: aiMessages(threadId)
        Duo-->>Proxy: assistant message chunks / final message
    end

    alt toolsなし
        Proxy-->>Client: chat.completion / SSE chunk
    else toolsあり かつ tool_calls envelope
        Proxy->>Proxy: tool_callsへ変換して保存
        Proxy-->>Client: assistant.tool_calls
        Client->>Client: ローカルtool実行
        Client->>Proxy: POST /v1/chat/completions<br/>messages + role:"tool"
        Proxy->>Proxy: tool_call_idを検証
        Proxy->>Duo: aiAction(chat with tool result)
        loop polling
            Proxy->>Duo: aiMessages(threadId)
            Duo-->>Proxy: final assistant message
        end
        Proxy-->>Client: chat.completion / SSE chunk
    end
```

## Scope

### In Scope

- `GET /healthz`
- `GET /v1/models`
- `POST /v1/chat/completions`
- 非 stream / `stream=true` の両方
- assistant 応答の `tool_calls` 変換
- `role:"tool"` メッセージの受理
- `tool_call_id` と tool 名の整合チェック
- `sqlite3` による会話 state と監査ログの保存

### Out Of Scope

- proxy 側での tool 実行
- OpenAI Responses API 互換
- GitLab Action Cable を使った native streaming
- 完全な JSON Schema validator
- 高度な observability や HA 構成

## Runtime Components

### [src/server.py](../src/server.py)

- `ThreadingHTTPServer` を起動します
- `Settings` を読み、`Router` を組み立てます
- state DB は `proxy_state.sqlite3` を使います

### [src/router.py](../src/router.py)

- ルーティングと HTTP レスポンス送出を担当します
- `GET /healthz` だけは認証なしです
- それ以外の公開 endpoint は `Authorization: Bearer ...` を必須にします
- `stream=true` のときは SSE 形式で返します

### [src/openai_handlers.py](../src/openai_handlers.py)

- OpenAI 互換 request の検証を担当します
- `/v1/models` と `/v1/chat/completions` のレスポンス整形を行います
- unsupported parameter は明示的に 400 で reject します
- `stream=true` でも、内部的には通常応答を作った後に SSE chunk へ包み直します

### [src/chat_bridge.py](../src/chat_bridge.py)

- OpenAI `messages` を GitLab Duo 向けの単一 prompt に変換します
- `aiAction` を発行し、`aiMessages` を polling して最終 assistant 応答を待ちます
- `tools` 指定時だけ assistant 応答を JSON として解析し、`tool_calls` を組み立てます
- `role:"tool"` メッセージを会話に再投入します
- 通常会話はクライアントが再送する `messages` を前提に扱います
- tool round-trip では `conversation_id` または `tool_call_id` から `thread_id` を復元します

### [src/duo_client.py](../src/duo_client.py)

- `urllib.request` で GitLab GraphQL API を呼びます
- `/api/graphql` に POST します
- `aiAction`、`aiMessages`、`availableModels` を呼び出します
- HTTP / GraphQL エラーを proxy 内の `ProxyError` 系へ変換します

### [src/tool_emulator.py](../src/tool_emulator.py)

- `tools` を GitLab Duo 向け developer preamble に圧縮します
- assistant 応答を `{"tool_calls":[...]}` 形式として parse します
- tool envelope として解釈できない応答は `ProxyError` になります
- ただし `ChatBridge` 側では parse 失敗を握り、通常テキスト応答として扱います

### [src/state_store.py](../src/state_store.py)

- `sqlite3` で最小限の bridge state を持ちます
- conversation と thread の対応を保存します
- 発行済み `tool_call_id` と元の tool 名、thread を保存します
- 監査用の最小 audit log を保存します

## Request Lifecycle

### Health Check

1. クライアントが `GET /healthz` を呼ぶ
2. proxy は認証なしで `{"status":"ok"}` を返す

### Model List

1. クライアントが `GET /v1/models` を呼ぶ
2. proxy は Bearer token を検証する
3. `availableModels` を取りに行く
4. upstream モデル取得に失敗した場合は `gitlab-duo-chat` を fallback として返す

### Non-Tool Chat

1. クライアントが `/v1/chat/completions` を呼ぶ
2. handler が request を検証する
3. クライアントが保持している `messages` 履歴を proxy がそのまま受け取る
4. bridge が OpenAI `messages` を 1 本の prompt に直列化する
5. `aiAction` を呼ぶ
6. `aiMessages(threadId)` を polling する
7. 最終 assistant text を OpenAI 互換 JSON として返す

### Tool Chat

1. クライアントが `tools` 付きで `/v1/chat/completions` を呼ぶ
2. proxy が tools 情報を developer preamble に埋め込む
3. GitLab Duo が plain text か JSON envelope を返す
4. JSON envelope が `{"tool_calls":[...]}` 形式なら `tool_calls` に変換する
5. proxy が `tool_call_id` と tool 名を state に記録する
6. クライアントがローカルで tool を実行する
7. クライアントが `role:"tool"` と結果を再送する
8. proxy がその内容を prompt に埋め込み、GitLab Duo へ継続送信する

## Prompt Construction

`ChatBridge` は OpenAI 互換 request を GitLab Duo 向けの単一文字列 prompt に変換します。

- 通常 message は `[role] content` 形式に直列化します
- `tools` がある場合だけ、先頭に developer preamble を追加します
- `role:"tool"` は `[tool:<name>] {"client_result": ...}` 形式へ変換します

この設計は単純ですが、OpenAI ネイティブな message 構造を GitLab Duo にそのまま転送しているわけではありません。

## Tool Handling Model

### Why Client-Executed Tools

この proxy は、OpenAI 互換クライアントがローカル tool を実行するモデルを前提にしています。

- proxy は `tool_calls` を返すだけです
- 実際の tool 実行はクライアントが担当します
- 通常会話の継続性はクライアントが `messages` 履歴を再送して担保します
- proxy は tool 実行結果を GitLab Duo に再投入するだけです

これにより、proxy がローカル shell やファイルシステムの権限を持たずに済みます。

### Tool Call Detection

assistant 応答は、`tools` が渡された request のときだけ tool envelope として解釈されます。

期待する形式:

```json
{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}
```

注意点:

- `name` は string である必要があります
- `arguments` は object である必要があります
- `tool_call_id` は upstream の値ではなく proxy が新規採番します
- JSON parse に失敗した場合、現行実装では単に通常テキスト応答へ fallback します

### Tool Result Messages

`role:"tool"` メッセージは次のどちらかで解決されます。

- `tool_call_id` があり、過去の tool call と照合できる
- `name` が明示されている

`tool_call_id` が存在する場合の整合性ルール:

- 未知の `tool_call_id` は reject
- 別 `conversation_id` に属する `tool_call_id` は reject
- `name` を併記した場合、保存済み tool 名と一致しないと reject

### Accepted Tool Result Content

`messages[*].content` は次を受け入れます。

- string
- object
- array
- number
- boolean
- null

list の場合は、`type:"text"` の item は text として連結し、それ以外は JSON 化して埋め込みます。

## Conversation State

通常会話の継続性は、OpenAI 互換クライアントが `messages` 履歴を毎回再送することで担保されます。

- proxy は一般会話のために独自 session key を必須にはしません
- `metadata.conversation_id` を送れるクライアントでは、それを GitLab Duo `thread_id` 再利用の補助キーとして使えます
- `metadata.conversation_id` が無い場合でも、tool 実行結果に含まれる `tool_call_id` から `thread_id` を復元できます
- つまり、一般的な OpenAI 互換クライアントのように `messages` と `tool_call_id` しか送れなくても、tool 呼び出しを含む継続会話は成立します

response の `metadata` には、元の metadata に加えて次を追記します。

- `gitlab_thread_id`
- `gitlab_request_id`
- `gitlab_client_subscription_id`

`metadata.conversation_id` は任意の補助情報です。送れないクライアントでは、proxy は `tool_call_id` ベースで tool round-trip に必要な最小限の継続性だけを補助します。

## Data Model

### conversations

- `conversation_id`
- `thread_id`
- `request_id`
- `client_subscription_id`
- `metadata_json`
- `updated_at`

### tool_calls

- `tool_call_id`
- `conversation_id`
- `thread_id`
- `tool_name`
- `arguments_json`
- `created_at`

### audit_logs

- `id`
- `request_id`
- `event_type`
- `payload_json`
- `created_at`

## Validation Rules

`OpenAIHandlers` は最低限の request validation を行います。

- `model` は必須 string
- `messages` は必須かつ non-empty array
- 各 message は object
- `role` は `developer | system | user | assistant | tool`
- `tools` は array のみ受理

明示的に未対応として reject する parameter:

- `audio`
- `logprobs`
- `prediction`
- `service_tier`
- `store`

## Streaming Design

現行の `stream=true` は native streaming ではありません。

- まず通常の chat completion を最後まで作ります
- その結果を OpenAI 互換 SSE chunk に分解して返します
- `data: [DONE]` で終了します

つまり、クライアントから見ると SSE ですが、upstream から token 単位で逐次中継しているわけではありません。

## Error Model

proxy は内部例外を OpenAI 風の error payload に変換します。

主な対応:

- 401 → `invalid_api_key`
- 403 → `permission_denied`
- 404 → `not_found`
- 429 → `rate_limit_exceeded`
- upstream 5xx / GraphQL 異常 → `server_error`

注意点:

- request validation は主に `invalid_request_error`
- upstream timeout は 504 `server_error`
- ルーター上の 404 も OpenAI 風 error で返します

## Configuration Notes

主要な設定は環境変数から読みます。

- `WRAPPER_API_KEY`
- `GITLAB_BASE_URL`
- `GITLAB_TOKEN`
- `PROXY_HOST`
- `PROXY_PORT`
- `REQUEST_TIMEOUT_SECONDS`
- `POLLING_INTERVAL_SECONDS`
- `POLLING_TIMEOUT_SECONDS`
- `ENABLE_ACTION_CABLE_STREAMING`
- `TOOL_PREAMBLE_MAX_CHARS`

`ENABLE_ACTION_CABLE_STREAMING` は現時点では予約された flag で、実装では使っていません。

## Verification

通常テスト:

```bash
python -m unittest discover -s tests -v
```

live 統合テスト:

```bash
python -m unittest tests.test_integration_live -v
```

## Future Work

- GitLab native streaming への接続
- tool envelope の厳密性向上
- request 制限値の実運用向け enforcement
- observability と運用メトリクスの追加
