# GitLab DuoのGraphQL APIをOpenAI互換APIとしてラップする実装方式の調査報告

## エグゼクティブサマリ

GitLab Duo まわりで公開ドキュメントから確認できる API 面は、専用の別エンドポイントではなく GitLab の versionless な GraphQL API (`/api/graphql`) 上に載っており、Duo Chat は `aiAction` mutation、`aiMessages` query、`aiCompletionResponse` subscription を中心に構成されています。認証は OAuth 2.0 token、Personal Access Token、Project/Group Access Token、または session cookie で行い、GraphQL query には `read_api`、mutation には `api` scope が必要です。さらに Duo 側の AI リクエストはバックグラウンドジョブで処理され、HTTP を開きっぱなしにせず subscription で結果を受け取る設計です。citeturn28view1turn10view0turn11search1turn25search0turn26search0

一方で、OpenAI 互換の Chat Completions は、呼び出し側が `tools` に JSON Schema を渡し、`tool_choice` や `parallel_tool_calls` を指定し、戻り値として `tool_calls` を受け取り、次ターンで `role:"tool"` を返すプロトコルです。公開 GitLab Duo GraphQL 仕様では、`aiAction` に caller-supplied な任意 function schema を渡す public contract は確認できず、GitLab Duo Chat の docs でも「GitLab 側で定義された prompts / tools を zero-shot agent が使う」と説明されています。そのため、OpenAI 互換の Function Calling は **GitLab 側のネイティブ機能としては扱えず、ラッパー側でプロトコルをエミュレートする** 前提で設計するのが現実的です。citeturn31view3turn17view6turn17view5turn17view4turn34search0turn1view2turn10view0

推奨アプローチは次の三段階です。第一に、`/v1/chat/completions` と `/v1/models` を先に作り、通常のチャット応答を安定化させます。第二に、Function Calling は「GraphQL 全面開放」ではなく、**whitelist した GraphQL operation registry を OpenAI function schema にコンパイルする方式**に限定します。第三に、`stream:true` は GitLab の `aiCompletionResponse` を優先利用し、Action Cable 実装が重い場合は `aiMessages` polling を fallback として持たせます。これは OpenAI 側の SSE ストリーミング仕様と GitLab 側の subscription / polling 両方に整合しやすい構成です。citeturn16view2turn35search0turn29view0turn11search1turn33view0turn21view0turn39view1

結論だけ先に言うと、**最も堅い実装は「チャット翻訳層」と「GraphQL operation から JSON Schema / 実行器を生成するツール層」を分離した二層構成**です。純粋な薄いプロキシでも text-only チャットは作れますが、Function Calling、ストリーミング、監査、トランザクション整合性まで含めると、サーバー単体より「プロキシ + operation registry / executor SDK」の組み合わせのほうが障害面でも保守面でも有利です。これは後述する設計パターン、OSS、そして GitLab 側の非同期・実験的 API の性質から見ても妥当です。citeturn28view0turn26search0turn25search0turn21view1turn22view0

## 前提と確認できた仕様

本報告では、**「GitLab DuoのGraphQL API」= 公開 docs で確認できる GitLab GraphQL 上の Duo 関連要素**として扱います。具体的には `aiAction`、`aiMessages`、`aiCompletionResponse`、および Duo Agentic Chat 向け `availableModels` 相当の参照を対象にしています。もし意図している対象が GitLab Duo Agent Platform の未公開内部 API や、IDE 拡張・CLI 専用の別経路であれば、追加の discovery が必要です。citeturn26search0turn25search0turn36search0

GitLab GraphQL API の基本仕様は比較的明確です。エンドポイントは `/api/graphql`、GitLab Self-Managed の GraphQL explorer は `/-/graphql-explorer` です。認証は Bearer token または query parameter での token 指定、もしくは `_gitlab_session` cookie がサポートされます。authorization failure の挙動も GraphQL query と mutation で異なり、query 側では権限不足時に `null` が返る一方、mutation 側では top-level `errors` にエラーが出ます。OpenAI 互換ラッパーを作るときは、この差分をそのまま外に漏らさず、OpenAI 風の 401/403/404/429/5xx に正規化する必要があります。citeturn28view1

スキーマ運用の観点では、GitLab GraphQL は versionless ですが、参照ドキュメントは current schema から自動生成され、deprecated 項目は introspection query にも現れます。さらに GraphQL overview では、experiment 扱いの schema item は deprecation process の対象外で、いつでも変更・削除され得ると明記されています。検索スニペット上でも `Mutation.aiAction` は experiment、`aiMessages` も experiment と出ており、運用前提では **schema snapshot と drift 検知** が必須です。citeturn0search4turn28view0turn26search0turn25search0

制限値も重要です。GitLab GraphQL の一般制約として、最大 page size は通常 100、query complexity は unauthenticated 200 / authenticated 250、query or mutation size は 10,000 文字、request timeout は 30 秒、blob 系の data limit は複数 blob 指定時に合計 20 MB です。加えて Self-Managed / Dedicated 向け rate limit docs では、GraphQL `aiAction` mutation に **認証ユーザーあたり 8 時間で 160 回**という専用制限があります。GitLab.com 固有の上限値は overview から直接は確定できなかったため、**GitLab.com は別管理・Self-Managed/Dedicated は明示値あり**として扱うのが安全です。citeturn29view0turn3search0

サブスクリプションについては、「ある」と答えてよい一方で、**第三者向け stable public contract として十分に仕様化されているとは言いにくい**、というのが実態です。Duo Chat docs では `aiCompletionResponse` subscription が明示され、complete message は `userId + aiAction:"CHAT"`、streaming chunk は `clientSubscriptionId` を識別子にして配信されると説明されています。また GitLab の real-time docs では、GraphQL subscription は Action Cable を土台にし、`/-/cable` の WebSocket と Redis PubSub を使う内部実装として説明されています。しかし GraphQL API overview 自体は、この transport を外部利用の安定 API として明示していません。したがって、**subscription capability は存在するが、transport contract は内部寄り**とみなし、ラッパーでは polling fallback を用意すべきです。citeturn11search1turn33view0turn28view1

Duo 系の query / mutation には会話継続に役立つ ID もあります。docs の例では、`aiAction(input: { chat: ... })` が `requestId`、`threadId`、`errors` を返し、`aiMessages(threadId: ...)` で thread 単位のメッセージ列を取得できます。また `clientSubscriptionId` は streaming や同一画面上の複数機能の衝突回避のため UUID 推奨です。ラッパー側では、これらを OpenAI 互換レスポンスの裏側に保持し、`metadata` や内部 state として紐づけるのが自然です。citeturn10view0turn11search1

モデル列挙については、generated reference の検索結果に「Duo Agentic Chat で利用可能なモデルを取得する query」があり、戻りは `AvailableModels` です。ただし search snippet では引数名が `namespaceId` と出るケースと `rootNamespaceId` と出るケースがあり、公開 docs の見え方にズレがあります。GitLab GraphQL が versionless で reference も自動生成であることを踏まえると、`/v1/models` をこの query に依存させる場合は **対象インスタンスに対する introspection / 起動時検証を必須**にするべきです。citeturn24search0turn36search0turn28view0

## OpenAI互換仕様として満たすべき面

OpenAI 互換でまず押さえるべき最小セットは、`POST /v1/chat/completions` と `GET /v1/models` です。OpenAI docs では Chat Completions API は会話メッセージ列から応答を生成するエンドポイントとして定義されており、developer/system/user/assistant/tool の各 role を扱います。新規プロジェクトには Responses API が推奨されていますが、既存の coding agent やエコシステム互換の観点では、`/v1/chat/completions` のサポートが依然として重要です。citeturn16view1turn19search0turn35search0

Function Calling では、`tools` に function definition を載せます。各 function は `name`、`description`、`parameters` を持ち、`parameters` は JSON Schema です。`tool_choice` は `none` / `auto` / `required` / 特定 function 強制 / `allowed_tools` に対応し、`parallel_tool_calls` で並列 function call の可否を制御できます。さらに `strict: true` を使うと schema 準拠をより強く要求できますが、Chat Completions では strict はデフォルトではなく、schema が制約を満たさないと request 自体が reject されます。したがって GraphQL から function schema を生成するなら、**read-only の bounded operation だけ strict:true にする**のが実装しやすいです。citeturn31view3turn17view6turn17view5turn17view4

呼び出しフローも OpenAI 側は明確です。公式ガイドでは、モデルへ tools を渡す、モデルが tool call を返す、アプリ側で tool を実行する、結果を `role:"tool"` と `tool_call_id` 付きで返す、最後に model が最終応答を返す、という multi-step conversation になっています。戻り値の chat completion object では `choices[].message.tool_calls[]` に function 名と JSON arguments が入り、`finish_reason` は `tool_calls` になります。また docs では、モデルが生成する function arguments は必ずしも valid JSON でも schema 準拠でもないので、**実行前に必ず validation する**べきだと明記されています。citeturn16view0turn32view0turn41view2turn34search1turn34search0

ストリーミングは Chat Completions では `stream=true` により data-only SSE として返されます。各 chunk は `chat.completion.chunk` で、`choices[].delta` に role や content の差分が入ります。`/v1/models` は単純な一覧 API で、`id`、`created`、`owned_by` などを返します。`metadata` は最大 16 個の key-value を持てる構造化フィールドです。エラーは少なくとも 401、403、429、500、503 が公式 docs にあり、rate limit は organization / project 単位かつ RPM / TPM / RPD / TPD / IPM で計測されます。ラッパーはこの仕様に合わせて、GitLab 側の auth / rate limit / timeout / upstream failure を OpenAI 風の HTTP / JSON に正規化する必要があります。citeturn16view2turn41view1turn35search0turn31view1turn38view1turn16view4

実装範囲としては、v1 では `messages`、`model`、`stream`、`tools`、`tool_choice`、`parallel_tool_calls`、`metadata` を優先対応し、`audio`、`logprobs`、`prediction`、`service_tier`、`store` など GitLab Duo に直接対応する経路がないものは、**明示的に未対応として 400 を返す**か、少なくとも documentation 上で no-op と宣言すべきです。暗黙に無視すると agent 側の挙動が壊れやすくなります。citeturn19search0turn31view0turn31view2

## 設計パターン

設計パターンは大きく三つに分けられます。ひとつ目は **Thin Chat Adapter** で、OpenAI 風の request / response だけ変換し、Duo Chat の text response を返す方式です。これは最短で作れますが、Function Calling や write 系オペレーションには弱いです。ふたつ目は **Curated Operation Registry** で、選別した GraphQL query / mutation を operation ごとに JSON Schema 化し、OpenAI function definition と executor に変換する方式です。みっつ目は **Generic GraphQL Executor** で、実質 `graphql_execute(document, variables)` のような万能関数をモデルに見せる方式です。GitLab GraphQL の experimental 項目、complexity / query size 制限、権限差分を考えると、実運用で推奨できるのは二つ目だけです。citeturn29view0turn28view0turn26search0turn25search0

技術的な自動生成自体は十分可能です。GraphQL 側では current schema からの introspection と generated reference があり、OSS でも GraphQL schema / query を OpenAPI に変換する `graphql-to-openapi`、GraphQL introspection を JSON Schema に変換する `graphql-2-json-schema`、OpenAI function schema を生成する helper 群が存在します。また entity["company","Zuplo","api gateway company"] の GraphQL MCP docs は、GraphQL endpoint から introspection tool と execute tool を自動生成する実運用パターンを示しています。つまり「GraphQL schema から LLM 向け tool surface を生成する」という発想自体は現実的です。ただし GitLab のように巨大で versionless な schema に対して、**全スキーマ自動公開**をそのままやるのは危険です。citeturn21view0turn39view1turn21view1turn22view0

したがって、推奨は **「スキーマ全体」ではなく「whitelist した named operation 群」を生成単位にする**ことです。つまり `project(fullPath)`、`issueSetLocked(projectPath, iid, locked)`、`aiAction(chat)` のような、使わせたい operation document を明示的に管理し、その variable 定義だけを JSON Schema に変換します。custom scalar は手動 scalar map に逃がし、union / interface は tool の入出力では flatten するか、レスポンスを text/json string として返すのが堅いです。citeturn28view1turn29view0turn39view1

以下は、推奨する「GraphQL operation registry → OpenAI function schema」変換の概念図です。GitLab の introspection と named operation 群を入力にし、OpenAI tool で必要な JSON Schema と executor stub を生成します。GitLab は deprecation / experiment / remove_deprecated 検証があるため、生成は **build-time + startup validation** の二段にするのが安全です。citeturn28view0turn29view0

```mermaid
flowchart TD
    A[GitLab introspection schema] --> B[Operation registry<br/>named .graphql documents]
    B --> C[Variable type analyzer]
    A --> C
    C --> D[JSON Schema generator]
    D --> E[OpenAI tools definitions]
    D --> F[Typed executor stubs]
    E --> G[OpenAI-compatible client or agent]
    F --> H[GitLab GraphQL caller]
```

サンプルの GraphQL → function マッピングは次のようになります。これは **提案ベースのサンプル表**であり、実際には operation document を固定し、tool 名、description、required 引数、read/write 属性を registry 化して扱う想定です。公式 docs にある `aiAction(chat)`、`aiMessages`、`availableModels`、`project(fullPath)`、`issueSetLocked` などを材料に組み立てています。citeturn11search1turn24search0turn36search0turn28view1

| OpenAI関数名 | 対応するGraphQL operation | 種別 | 主な引数 | 主な返り値 | 用途 |
|---|---|---|---|---|---|
| `gitlab_duo_chat_send` | `mutation aiAction(input:{ chat: ... })` | internal | `content`, `threadId?`, `conversationType?`, `clientSubscriptionId?` | `requestId`, `threadId`, `errors` | OpenAI chat request を Duo Chat に橋渡しする内部関数 |
| `gitlab_duo_chat_messages` | `query aiMessages(threadId: ...)` | internal/read | `threadId`, `roles?` | `nodes[].requestId/content/role/timestamp/chunkId/errors` | polling fallback、履歴取得 |
| `gitlab_duo_available_models` | `query availableModels(...)` | read | `namespaceId` または `rootNamespaceId` | `AvailableModels` | `/v1/models` の背後候補 |
| `gitlab_project_get` | `query project(fullPath: ...)` | read | `fullPath` | `id`, `fullPath`, `visibility` など | 代表的な read-only tool |
| `gitlab_issue_set_locked` | `mutation issueSetLocked(...)` | write | `projectPath`, `iid`, `locked` | `issue { id, iid }` | 代表的な mutation tool |
| `gitlab_graphql_execute` | 任意 query / mutation | internal only | `document`, `variables` | 任意 | 信頼できる内部用途のみ。一般 agent には非推奨 |

関連 OSS としては、entity["company","GitHub","software hosting company"] 上の `graphql-to-openapi`、`graphql-2-json-schema`、`openai-function-calling`、`copilot-openai-api` のようなプロジェクトが、スキーマ変換、function schema 生成、OpenAI 互換 proxy の各ピースを実装可能な部品として示しています。直接そのまま使うより、**実装方針の参考にする**位置づけが妥当です。citeturn21view0turn39view1turn21view1turn21view2

## 推奨アーキテクチャ

推奨アーキテクチャは、**OpenAI互換フロントドア**、**Duo Chat adapter**、**GraphQL tool registry / executor**、**state / audit store** の四層です。フロントドアは `/v1/chat/completions` と `/v1/models` を提供し、request normalization、OpenAI 風レスポンス整形、SSE streaming を担当します。Duo Chat adapter は `aiAction(chat)` の発行、`requestId` / `threadId` / `clientSubscriptionId` の管理、`aiCompletionResponse` または `aiMessages` からの応答回収を担当します。tool registry は whitelisted operation を JSON Schema tool に変換し、executor は GraphQL query / mutation 実行、validation、read/write 制御を持ちます。citeturn10view0turn11search1turn16view2

以下は、OpenAI 互換クライアントから GitLab Duo までの推奨フローです。GitLab 側は AI リクエストを background job に載せ、OpenAI 側は SSE を要求しうるため、ラッパーがその間で protocol translation と session state を持つ構造になります。citeturn10view0turn16view2turn33view0

```mermaid
flowchart LR
    C[OpenAI-compatible client] --> P[/Wrapper API<br/>v1/chat/completions/]
    P --> N[Normalizer<br/>messages tools metadata]
    N --> T[Tool-call emulator<br/>or final-answer mode]
    T --> D[GitLab Duo adapter<br/>aiAction(chat)]
    D --> S[aiCompletionResponse<br/>Action Cable]
    D --> Q[aiMessages polling<br/>fallback]
    S --> P
    Q --> P
    P -->|JSON or SSE| C
    R[Operation registry] --> N
    R --> X[GraphQL executor]
```

認証連携は分けて考える必要があります。**外向きの wrapper 認証**は OpenAI 風の API key でよく、`Authorization: Bearer sk-...` を受ければ十分です。**内向きの GitLab 認証**は、GitLab GraphQL docs にある OAuth 2.0 token や各種 access token を使います。ただし、coding agent が「ユーザー本人の権限で GitLab を触る」ことが重要なら、Project/Group token より **user-delegated OAuth か PAT** を優先すべきです。session cookie は docs 上存在しますが、サーバー間統合には secret 管理・期限管理・CSRF などの面で扱いづらいため、ラッパー実装では通常は候補から外してよいでしょう。citeturn28view1

セキュリティ上は、token を wrapper DB に平文保存せず KMS / secret manager に入れること、GraphQL parameter ではなく header 認証を優先すること、mutation 系 tool は read-only tool と分離して監査ログを強制することが重要です。GitLab GraphQL には spam detection や CAPTCHA 応答、権限不足時の `null` / top-level `errors`、query complexity 制限、DoS 関連の過去脆弱性があるため、wrapper 側でも **input validation、op whitelist、query size guard、write audit** を入れるべきです。citeturn29view0turn37search5

スケーリングでは、read query は tenant / subject / operation / normalized variables を key に短 TTL cache してよい一方、chat turn、subscription、mutation は原則 non-cache にすべきです。ストリーミングは接続数に比例して負荷が増えるため、まずは `aiMessages` polling fallback で MVP を出し、必要になったら Action Cable client を載せるのが堅実です。GitLab docs 自体も Action Cable / GraphQL subscriptions は active development 中の work-in-progress としており、ここは feature flag 管理を前提に進める領域です。citeturn33view0turn11search1

OpenAI 互換の `metadata` は wrapper 内部 state に非常に有用です。例えば `gitlab_thread_id`、`gitlab_request_id`、`gitlab_client_subscription_id`、`tenant_id`、`tool_registry_version` を内部保存し、必要なら OpenAI 互換 object の metadata に反映できます。metadata には key / value サイズ制限があるので、長い GraphQL document 全文ではなく correlation ID のみを入れるのがよいです。citeturn31view1

## エージェント実行設計

coding agent が Function Calling を使う場面では、会話制御をかなり慎重に設計する必要があります。OpenAI 側の正式フローは「tools 定義 → model が `tool_calls` を返す → アプリが tool 実行 → `role:"tool"` で戻す → 最終応答」という手順です。GitLab Duo GraphQL 側には caller-supplied tools がないため、ラッパーは **Duo に tool catalog を prompt として埋め込み、JSON-only の envelope を要求して parse する**か、あるいは Function Calling 付きセッションだけ別 planner を使う必要があります。公開 docs から見た現実解は前者です。citeturn16view0turn34search1turn31view3turn1view2turn10view0

推奨フローは次のとおりです。  
1. 受信した `tools` を operation registry で検証し、許可された tool だけを残します。  
2. Duo へ送る developer preamble に「利用可能な関数一覧」「arguments の JSON Schema 要約」「tool が必要なら JSON のみ返す」という規約を埋め込みます。  
3. Duo の応答を strict parser で読み、tool envelope なら OpenAI 互換の `tool_calls` に変換して返します。  
4. 次ターンで `role:"tool"` の結果が来たら、それを machine-readable block として Duo に渡し、最終応答生成を続けます。  
5. parse 不能、schema 不一致、複数 write mutation、危険な generic executor 要求が来たら、tool call を拒否して text answer へフォールバックします。citeturn34search0turn41view2turn17view4turn17view5

リトライ戦略は、**read と write で分離**するべきです。read query は 429 / 503 / timeout に対して exponential backoff を許容できますが、mutation は idempotency が保証されない限り自動再送しないほうが安全です。OpenAI 側も 429 / 503 に backoff を推奨しており、GitLab 側も `aiAction` 専用制限、30 秒 timeout、streaming failure / generic AI error code を持っています。したがって wrapper では、read には自動再試行、write には manual retry token または operator-confirmed replay を採用するのがよいです。citeturn38view5turn38view7turn29view0turn3search0turn1view3

部分実行と整合性の観点では、tool を **read-only**, **safe write**, **unsafe write** の三段階に分けるのが実務的です。`parallel_tool_calls` は OpenAI 仕様としては可能ですが、GitLab mutation の side effect、権限検査、監査、順序依存を考えると、write tool が含まれるセッションでは wrapper 側で `parallel_tool_calls=false` に落とすか、明示的に拒否したほうがよいです。とくに project / issue / MR 更新系は confirm/apply の二段階にし、第一ターンで変更計画、第二ターンで実適用に分けると安全です。citeturn17view5turn17view6

会話 state は `threadId` で持ちます。新規セッションでは `threadId` を省略して新しい Duo conversation を作り、wrapper 側で OpenAI 互換 session と紐づけます。以後は `threadId` を再利用し、`requestId` と `clientSubscriptionId` を request ごとに発番して correlation を取ります。こうしておくと、SSE 再接続、途中中断、tool round-trip、監査トレースのどれにも対応しやすくなります。citeturn11search1turn10view0

## テストと運用

ユニットテストでは、`messages` 正規化、developer/system/user/tool role の flatten、tool schema validation、GraphQL scalar→JSON Schema 変換、OpenAI 互換 error mapping、`tool_calls` envelope parser を個別に固定値で潰すべきです。ここでは GitLab 実サーバーを使わず、GraphQL success / top-level errors / null authorization / rate-limit / timeout / spam extension などの fixture を持つのが効率的です。GitLab GraphQL docs には top-level errors や CAPTCHA 関連の返り値例があり、これを fixture のベースにできます。citeturn28view1turn29view0

統合テストでは、最低でも `aiAction(chat)`、`aiMessages(threadId)`、invalid token、scope 不足、権限不足、rate limit、長文 prompt、timeout のケースを本物の GitLab 環境に against して回す必要があります。GitLab docs では Duo の応答取得が background job + subscription であること、Chat 用 subscription が user-centric で complete message と chunk の扱いが分かれること、Action Cable が work-in-progress であることが示されているため、**streaming 統合テスト**は text-only 応答より優先度を上げてよい領域です。citeturn10view0turn11search1turn33view0

エンドツーエンドでは、実際の OpenAI 互換 client から `stream:false` / `stream:true`、tools なし / tools あり、single-turn / multi-turn を通します。とくに tools あり E2E では、「モデルが tool を呼ぶ」「tool 実行結果を返す」「最終自然文応答に戻る」という OpenAI flow が再現できていることを確認する必要があります。ここは prompt-based emulation なので、golden test だけでなく **parser robustness test** と **adversarial prompt test** が重要です。citeturn16view0turn34search1turn34search0

負荷試験は、chat turn / polling / SSE fan-out を分けて実施すべきです。GitLab 側には GraphQL complexity 制限、30 秒 timeout、`aiAction` 専用 rate limit があるため、単に RPS を上げるだけではなく、prompt 長、thread 長、stream 同時接続数、polling 間隔、mutation 混在率を変えて測る必要があります。特に polling fallback は `aiMessages` の読取頻度で簡単に上流負荷を増やすため、streaming beta の前に dashboard と circuit breaker を必ず入れるべきです。citeturn29view0turn3search0

セキュリティテストでは、query size 超過、complexity 超過、権限境界の read / write、秘密情報のログ流出、tool injection、generic executor の乱用、token rotation、そして self-managed GitLab の patch level を確認します。GitLab は 2025 年 12 月に GraphQL endpoint の DoS と情報露出に関する修正を出しているため、self-managed 前提なら **パッチ済み系列を前提条件にする**べきです。また deprecation / experiment の性質上、CI では `remove_deprecated=true` を使った schema compatibility check を定期実行するのが有効です。citeturn37search5turn28view0turn29view0

## 実装例と概算見積り

以下は、Node.js / TypeScript での最小構成サンプルです。意図は「`aiAction(chat)` を叩く」「`aiMessages` を polling して最終 assistant message を拾う」「tool envelope を OpenAI 互換 `tool_calls` に変換する」という骨格を示すことにあります。GitLab docs が public/stable な subscription client contract を十分には定義していないため、サンプルは polling fallback で書いています。運用版では、ここに Action Cable client と strict schema validation、監査、retry policy を足します。citeturn11search1turn33view0turn16view2

```ts
// Node.js 22+ / TypeScript
type Json = Record<string, unknown>;

type OpenAITool = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Json;
    strict?: boolean;
  };
};

type GitLabCtx = {
  baseUrl: string;
  token: string;
};

type AiActionResponse = {
  aiAction: {
    requestId?: string;
    threadId?: string;
    errors?: string[];
  };
};

type AiMessagesResponse = {
  aiMessages: {
    nodes: Array<{
      requestId?: string;
      content?: string;
      role?: string;
      chunkId?: string;
      timestamp?: string;
      errors?: string[];
    }>;
  };
};

class UpstreamError extends Error {
  constructor(
    message: string,
    readonly status: number = 502,
    readonly code: string = "upstream_error",
    readonly details?: unknown,
  ) {
    super(message);
  }
}

async function gitlabGraphql<T>(
  ctx: GitLabCtx,
  query: string,
  variables: Json = {},
): Promise<T> {
  const url = `${ctx.baseUrl.replace(/\/$/, "")}/api/graphql`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${ctx.token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query, variables }),
  });

  const payload = (await res.json()) as {
    data?: T;
    errors?: Array<{ message: string; extensions?: Json }>;
  };

  if (res.status === 401) {
    throw new UpstreamError("Invalid GitLab token", 401, "invalid_api_key", payload.errors);
  }
  if (!res.ok || payload.errors?.length) {
    const message =
      payload.errors?.map((e) => e.message).join("; ") || `GitLab HTTP ${res.status}`;
    throw new UpstreamError(message, res.status || 502, "gitlab_graphql_error", payload.errors);
  }
  if (!payload.data) {
    throw new UpstreamError("Empty GraphQL data", 502, "empty_upstream_response");
  }
  return payload.data;
}

const DUO_CHAT_MUTATION = `
mutation DuoChat(
  $content: String!,
  $threadId: AiConversationThreadID,
  $clientSubscriptionId: String
) {
  aiAction(input: {
    chat: { content: $content }
    conversationType: DUO_CHAT
    threadId: $threadId
    clientSubscriptionId: $clientSubscriptionId
  }) {
    requestId
    threadId
    errors
  }
}
`;

const AI_MESSAGES_QUERY = `
query DuoMessages($threadId: AiConversationThreadID!) {
  aiMessages(threadId: $threadId) {
    nodes {
      requestId
      content
      role
      timestamp
      chunkId
      errors
    }
  }
}
`;

function buildToolPreamble(tools: OpenAITool[]): string {
  if (!tools.length) return "";
  const lines = tools.map((tool) => {
    return JSON.stringify({
      name: tool.function.name,
      description: tool.function.description ?? "",
      parameters: tool.function.parameters ?? { type: "object", properties: {} },
      strict: tool.function.strict ?? false,
    });
  });

  return [
    "You are an OpenAI-compatible assistant.",
    "If a tool is needed, reply with JSON only in this exact shape:",
    `{"tool_calls":[{"name":"<function_name>","arguments":{}}]}`,
    "Do not add markdown fences.",
    "Available tools:",
    ...lines,
  ].join("\n");
}

function tryParseToolEnvelope(text: string): Array<{ name: string; arguments: Json }> | null {
  try {
    const parsed = JSON.parse(text) as {
      tool_calls?: Array<{ name?: string; arguments?: Json }>;
    };
    if (!parsed.tool_calls?.length) return null;
    return parsed.tool_calls
      .filter((x) => x.name && x.arguments && typeof x.arguments === "object")
      .map((x) => ({ name: x.name!, arguments: x.arguments! }));
  } catch {
    return null;
  }
}

async function startDuoTurn(
  ctx: GitLabCtx,
  content: string,
  threadId?: string,
  clientSubscriptionId?: string,
) {
  const data = await gitlabGraphql<AiActionResponse>(ctx, DUO_CHAT_MUTATION, {
    content,
    threadId: threadId ?? null,
    clientSubscriptionId: clientSubscriptionId ?? null,
  });

  const action = data.aiAction;
  if (action.errors?.length) {
    throw new UpstreamError(
      action.errors.join("; "),
      502,
      "gitlab_duo_action_error",
      action.errors,
    );
  }
  if (!action.threadId) {
    throw new UpstreamError("Missing threadId from aiAction", 502, "missing_thread_id");
  }
  return action;
}

async function waitForAssistantMessage(
  ctx: GitLabCtx,
  threadId: string,
  requestId?: string,
  timeoutMs = 25_000,
): Promise<string> {
  const started = Date.now();
  let seenChunkIds = new Set<string>();

  while (Date.now() - started < timeoutMs) {
    const data = await gitlabGraphql<AiMessagesResponse>(ctx, AI_MESSAGES_QUERY, { threadId });
    const nodes = data.aiMessages.nodes.filter((n) => n.role === "assistant");

    const hits = nodes.filter((n) => !requestId || n.requestId === requestId);
    for (const node of hits) {
      if (node.chunkId) seenChunkIds.add(node.chunkId);
      if (node.content && !node.chunkId) return node.content; // complete message
    }

    await new Promise((r) => setTimeout(r, 400));
  }

  throw new UpstreamError("Timed out waiting for Duo assistant message", 504, "upstream_timeout");
}

function mapUpstreamError(err: unknown) {
  if (err instanceof UpstreamError) {
    const type =
      err.status === 401
        ? "invalid_request_error"
        : err.status === 429
          ? "rate_limit_error"
          : "api_error";

    return {
      status: err.status,
      body: {
        error: {
          message: err.message,
          type,
          code: err.code,
          param: null,
        },
      },
    };
  }
  return {
    status: 500,
    body: {
      error: {
        message: "Internal proxy error",
        type: "api_error",
        code: "internal_error",
        param: null,
      },
    },
  };
}

// 例: /v1/chat/completions の核心部分
export async function createChatCompletion(params: {
  gitlab: GitLabCtx;
  model: string;
  messages: Array<{ role: string; content?: string }>;
  tools?: OpenAITool[];
  metadata?: Record<string, string>;
}) {
  const lastUser = [...params.messages].reverse().find((m) => m.role === "user")?.content ?? "";
  const preamble = buildToolPreamble(params.tools ?? []);
  const prompt = preamble ? `${preamble}\n\nUser request:\n${lastUser}` : lastUser;

  const turn = await startDuoTurn(
    params.gitlab,
    prompt,
    params.metadata?.gitlab_thread_id,
    crypto.randomUUID(),
  );

  const assistantText = await waitForAssistantMessage(
    params.gitlab,
    turn.threadId!,
    turn.requestId,
  );

  const toolCalls = tryParseToolEnvelope(assistantText);
  const id = `chatcmpl_${crypto.randomUUID()}`;
  const created = Math.floor(Date.now() / 1000);

  if (toolCalls?.length) {
    return {
      id,
      object: "chat.completion",
      created,
      model: params.model,
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: null,
            tool_calls: toolCalls.map((tc) => ({
              id: `call_${crypto.randomUUID()}`,
              type: "function",
              function: {
                name: tc.name,
                arguments: JSON.stringify(tc.arguments),
              },
            })),
          },
          finish_reason: "tool_calls",
        },
      ],
      metadata: {
        gitlab_request_id: turn.requestId ?? "",
        gitlab_thread_id: turn.threadId ?? "",
      },
    };
  }

  return {
    id,
    object: "chat.completion",
    created,
    model: params.model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: assistantText,
        },
        finish_reason: "stop",
      },
    ],
    metadata: {
      gitlab_request_id: turn.requestId ?? "",
      gitlab_thread_id: turn.threadId ?? "",
    },
  };
}
```

開発工数は、前提を **単一 GitLab インスタンス、10〜20 個の whitelisted tools、Node.js/TypeScript、マルチモーダル非対応、専用 UI なし** と置くと、概ね次のレンジです。これは公開仕様とサンプル構成を前提にした概算です。  

| 範囲 | 概算工数 | 備考 |
|---|---:|---|
| text-only `/v1/chat/completions` MVP | 1.5〜2.5 人週 | 非ストリーミング、thread 管理、基本エラー変換 |
| `/v1/models` と metadata / correlation | 0.5〜1 人週 | static models なら短い、`availableModels` 動的対応なら増える |
| `aiMessages` polling による `stream:true` 対応 | 1〜1.5 人週 | 擬似トークン streaming、SSE 化、タイムアウト制御 |
| whitelist tool registry 生成 | 1.5〜2.5 人週 | operation registry、JSON Schema 変換、validator |
| prompt-based Function Calling emulation | 2〜3 人週 | tool prompt、JSON parser、tool round-trip |
| OAuth / KMS / audit / observability / rate-limit hardening | 2〜3 人週 | 本番運用に必須 |
| Action Cable native streaming beta | 1.5〜2.5 人週 | transport 実装の不確実性が高い |

最大のリスクは五つあります。**第一に**、caller-supplied Function Calling を GitLab Duo GraphQL がネイティブに受けない点です。これは whitelist + JSON envelope + strict parser + no-tools fallback で緩和できます。**第二に**、`aiAction` / `aiMessages` が experimental で schema drift を起こし得る点です。これは startup introspection、`remove_deprecated=true` CI、operation registry の version pinning で緩和します。**第三に**、subscription transport が Action Cable 依存で外部 contract が薄い点です。これは `aiMessages` polling fallback で吸収します。**第四に**、write mutation の並列実行・自動 retry が整合性事故を起こしうる点です。これは read/write 分離、confirm/apply、idempotency key、`parallel_tool_calls=false` で抑えます。**第五に**、GraphQL endpoint 自体の DoS / 情報露出リスクです。self-managed なら patch level を必須前提にし、wrapper 側でも query whitelist とサイズ制限を入れるべきです。citeturn28view0turn29view0turn17view5turn37search5

総合すると、**最初から「完全な OpenAI 互換 Function Calling」を目指すより、`text chat → bounded tools → streaming hardening` の順で段階導入する**のが最も成功率が高いです。text-only チャット互換は十分実装可能で、bounded tool registry も GraphQL introspection / JSON Schema 変換の技術要素から現実的です。難所は「caller-supplied tool schema を GitLab 側が知らない」点なので、ここをラッパー内の protocol emulation と明示的な運用制約で吸収する、という割り切りが本件の最適解です。citeturn10view0turn31view3turn16view0turn21view0turn39view1