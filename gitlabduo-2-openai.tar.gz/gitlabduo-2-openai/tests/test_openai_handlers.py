from __future__ import annotations

import unittest

from src.errors import AuthenticationError, ProxyError
from src.openai_handlers import OpenAIHandlers


class FakeChatBridge:
    def __init__(self, response: dict):
        self.response = response
        self.last_payload = None

    def complete(self, payload: dict) -> dict:
        self.last_payload = payload
        return self.response


class OpenAIHandlersTest(unittest.TestCase):
    def setUp(self) -> None:
        self.chat_bridge = FakeChatBridge(
            {
                "content": "hello",
                "tool_calls": [],
                "finish_reason": "stop",
                "metadata": {"gitlab_thread_id": "thread-1"},
            }
        )
        self.handlers = OpenAIHandlers(
            api_key="secret",
            chat_bridge=self.chat_bridge,
            fetch_models=lambda: [{"id": "claude-sonnet-4-5", "name": "Claude Sonnet 4.5"}],
        )

    def test_authorize_accepts_matching_bearer_token(self) -> None:
        self.handlers.authorize("Bearer secret")

    def test_authorize_rejects_invalid_token(self) -> None:
        with self.assertRaises(AuthenticationError):
            self.handlers.authorize("Bearer nope")

    def test_chat_completion_rejects_unsupported_field(self) -> None:
        with self.assertRaises(ProxyError) as ctx:
            self.handlers.handle_chat_completion(
                {
                    "model": "gitlab-duo-chat",
                    "messages": [{"role": "user", "content": "hi"}],
                    "audio": {},
                }
            )
        self.assertEqual("unsupported_parameter", ctx.exception.code)

    def test_chat_completion_returns_openai_shape(self) -> None:
        response = self.handlers.handle_chat_completion(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "hi"}],
            }
        )
        self.assertEqual("chat.completion", response["object"])
        self.assertEqual("assistant", response["choices"][0]["message"]["role"])
        self.assertEqual("hello", response["choices"][0]["message"]["content"])

    def test_stream_chat_completion_emits_done(self) -> None:
        chunks = self.handlers.stream_chat_completion(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            }
        )
        self.assertTrue(chunks[-1].startswith("data: [DONE]"))

    def test_list_models_uses_upstream_models_when_available(self) -> None:
        payload = self.handlers.list_models()
        self.assertEqual("claude-sonnet-4-5", payload["data"][0]["id"])

    def test_chat_completion_accepts_tool_message_object_content(self) -> None:
        response = self.handlers.handle_chat_completion(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "use local tool"},
                    {
                        "role": "tool",
                        "name": "bash.run",
                        "content": {"stdout": "ok", "stderr": "", "exit_code": 0},
                    },
                ],
            }
        )
        self.assertEqual("chat.completion", response["object"])


if __name__ == "__main__":
    unittest.main()
