from __future__ import annotations

import unittest

from src.errors import ProxyError
from src.tool_emulator import ToolEmulator


class ToolEmulatorTest(unittest.TestCase):
    def setUp(self) -> None:
        self.emulator = ToolEmulator(max_preamble_chars=4000)

    def test_parse_tool_calls_accepts_valid_payload(self) -> None:
        tool_calls = self.emulator.parse_tool_calls(
            '{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}'
        )
        self.assertEqual(1, len(tool_calls))
        self.assertEqual("Bash", tool_calls[0].name)

    def test_parse_tool_calls_rejects_invalid_json(self) -> None:
        with self.assertRaises(ProxyError):
            self.emulator.parse_tool_calls("not-json")


if __name__ == "__main__":
    unittest.main()
