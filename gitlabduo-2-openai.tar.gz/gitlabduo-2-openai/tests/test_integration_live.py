from __future__ import annotations

import os
import tempfile
import unittest

from src.chat_bridge import ChatBridge
from src.config import Settings
from src.duo_client import DuoClient
from src.state_store import StateStore
from src.tool_emulator import ToolEmulator


def _read_required_env(name: str) -> str | None:
    value = os.getenv(name)
    if value is None or not value.strip():
        return None
    return value.strip()


@unittest.skipUnless(
    _read_required_env("LIVE_GITLAB_BASE_URL") and _read_required_env("LIVE_GITLAB_TOKEN"),
    "live GitLab credentials are not configured",
)
class LiveGitLabIntegrationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        base_url = _read_required_env("LIVE_GITLAB_BASE_URL")
        token = _read_required_env("LIVE_GITLAB_TOKEN")
        assert base_url is not None
        assert token is not None

        cls.settings = Settings(
            gitlab_base_url=base_url,
            gitlab_token=token,
            request_timeout_seconds=float(os.getenv("LIVE_GITLAB_TIMEOUT_SECONDS", "30")),
            polling_interval_seconds=0.5,
            polling_timeout_seconds=float(os.getenv("LIVE_GITLAB_POLL_TIMEOUT_SECONDS", "30")),
        )
        cls.duo_client = DuoClient(
            base_url=cls.settings.gitlab_base_url,
            token=cls.settings.gitlab_token,
            timeout_seconds=cls.settings.request_timeout_seconds,
        )

    def test_graphql_smoke_query_succeeds(self) -> None:
        payload = self.duo_client.graphql("query CurrentUser { currentUser { id username } }", {})
        self.assertIn("currentUser", payload)
        self.assertIsInstance(payload["currentUser"], dict | type(None))

    def test_live_chat_bridge_when_duo_is_configured(self) -> None:
        prompt = _read_required_env("LIVE_DUO_TEST_PROMPT")
        model = _read_required_env("LIVE_DUO_TEST_MODEL")
        if prompt is None or model is None:
            self.skipTest("LIVE_DUO_TEST_PROMPT or LIVE_DUO_TEST_MODEL is not configured")

        with tempfile.TemporaryDirectory() as tmpdir:
            bridge = ChatBridge(
                duo_client=self.duo_client,
                state_store=StateStore(f"{tmpdir}/state.sqlite3"),
                tool_emulator=ToolEmulator(max_preamble_chars=4000),
                polling_interval_seconds=self.settings.polling_interval_seconds,
                polling_timeout_seconds=self.settings.polling_timeout_seconds,
            )
            result = bridge.complete(
                {
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "metadata": {"conversation_id": "live-integration"},
                }
            )

        self.assertIn(result["finish_reason"], {"stop", "tool_calls"})
        if result["finish_reason"] == "stop":
            self.assertIsInstance(result["content"], str)


if __name__ == "__main__":
    unittest.main()
