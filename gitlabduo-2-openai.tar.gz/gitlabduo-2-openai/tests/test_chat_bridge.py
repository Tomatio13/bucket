from __future__ import annotations

import tempfile
import unittest

from src.chat_bridge import ChatBridge
from src.state_store import StateStore
from src.tool_emulator import ToolEmulator


class FakeDuoClient:
    def __init__(self, *, assistant_content: str) -> None:
        self.assistant_content = assistant_content
        self.sent_payloads = []

    def send_chat(self, *, content: str, thread_id: str | None, client_subscription_id: str) -> dict:
        self.sent_payloads.append(
            {
                "content": content,
                "thread_id": thread_id,
                "client_subscription_id": client_subscription_id,
            }
        )
        return {"requestId": "req-1", "threadId": "thread-1", "errors": []}

    def fetch_messages(self, *, thread_id: str) -> list[dict]:
        return [{"role": "assistant", "content": self.assistant_content, "chunkId": None}]


class ChatBridgeTest(unittest.TestCase):
    def _build_bridge(self, *, assistant_content: str) -> ChatBridge:
        duo_client = FakeDuoClient(assistant_content=assistant_content)
        return ChatBridge(
            duo_client=duo_client,
            state_store=StateStore(f"{self.tmpdir}/state.sqlite3"),
            tool_emulator=ToolEmulator(max_preamble_chars=4000),
            polling_interval_seconds=0.01,
            polling_timeout_seconds=0.1,
        )

    def setUp(self) -> None:
        self._tempdir = tempfile.TemporaryDirectory()
        self.tmpdir = self._tempdir.name

    def tearDown(self) -> None:
        self._tempdir.cleanup()

    def test_complete_returns_plain_text(self) -> None:
        bridge = self._build_bridge(assistant_content="hello from duo")
        result = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "hi"}],
                "metadata": {"conversation_id": "conv-1"},
            }
        )
        self.assertEqual("hello from duo", result["content"])
        self.assertEqual("stop", result["finish_reason"])

    def test_complete_returns_tool_calls_when_json_envelope_arrives(self) -> None:
        bridge = self._build_bridge(
            assistant_content='{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}'
        )
        result = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "inspect"}],
                "tools": [{"type": "function", "function": {"name": "Bash", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}}],
                "metadata": {"conversation_id": "conv-2"},
            }
        )
        self.assertEqual("tool_calls", result["finish_reason"])
        self.assertEqual("Bash", result["tool_calls"][0]["function"]["name"])
        stored = bridge._state_store.get_tool_call(result["tool_calls"][0]["id"])
        self.assertIsNotNone(stored)
        self.assertEqual("Bash", stored["tool_name"])

    def test_complete_accepts_client_executed_tool_message_with_name(self) -> None:
        bridge = self._build_bridge(assistant_content="tool result summarized")
        result = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "project info"},
                    {
                        "role": "tool",
                        "name": "Bash",
                        "content": '{"stdout":"ok","stderr":"","exit_code":0}',
                    },
                ],
                "metadata": {"conversation_id": "conv-3"},
            }
        )
        self.assertEqual("tool result summarized", result["content"])

    def test_complete_executes_tool_message_by_tool_call_id(self) -> None:
        bridge = self._build_bridge(
            assistant_content='{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}'
        )
        first = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "inspect"}],
                "tools": [{"type": "function", "function": {"name": "Bash", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}}],
                "metadata": {"conversation_id": "conv-5"},
            }
        )
        tool_call_id = first["tool_calls"][0]["id"]

        bridge._duo_client.assistant_content = "project loaded"
        second = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "inspect"},
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": {"stdout": "/tmp/project", "stderr": "", "exit_code": 0},
                    },
                ],
                "metadata": {"conversation_id": "conv-5"},
            }
        )
        self.assertEqual("project loaded", second["content"])
        sent_prompt = bridge._duo_client.sent_payloads[-1]["content"]
        self.assertIn("[tool:Bash]", sent_prompt)
        self.assertIn("\"stdout\":\"/tmp/project\"", sent_prompt)
        self.assertEqual("thread-1", bridge._duo_client.sent_payloads[-1]["thread_id"])

    def test_complete_reuses_thread_by_tool_call_id_without_metadata(self) -> None:
        bridge = self._build_bridge(
            assistant_content='{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}'
        )
        first = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "inspect"}],
                "tools": [{"type": "function", "function": {"name": "Bash", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}}],
            }
        )
        tool_call_id = first["tool_calls"][0]["id"]

        bridge._duo_client.assistant_content = "project loaded"
        second = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "inspect"},
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": {"stdout": "/tmp/project", "stderr": "", "exit_code": 0},
                    },
                ],
            }
        )
        self.assertEqual("project loaded", second["content"])
        self.assertEqual("thread-1", bridge._duo_client.sent_payloads[-1]["thread_id"])

    def test_complete_rejects_unknown_tool_call_id(self) -> None:
        bridge = self._build_bridge(assistant_content="unused")
        with self.assertRaises(Exception):
            bridge.complete(
                {
                    "model": "gitlab-duo-chat",
                    "messages": [
                        {"role": "user", "content": "inspect"},
                        {
                            "role": "tool",
                            "tool_call_id": "call_missing",
                            "content": '{"proxy_execute":true,"arguments":{"fullPath":"group/proj"}}',
                        },
                    ],
                    "metadata": {"conversation_id": "conv-6"},
                }
            )

    def test_complete_rejects_mismatched_tool_name_for_tool_call_id(self) -> None:
        bridge = self._build_bridge(
            assistant_content='{"tool_calls":[{"name":"Bash","arguments":{"command":"pwd"}}]}'
        )
        first = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [{"role": "user", "content": "inspect"}],
                "tools": [{"type": "function", "function": {"name": "Bash", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}}}}],
                "metadata": {"conversation_id": "conv-8"},
            }
        )
        tool_call_id = first["tool_calls"][0]["id"]

        with self.assertRaises(Exception):
            bridge.complete(
                {
                    "model": "gitlab-duo-chat",
                    "messages": [
                        {"role": "user", "content": "inspect"},
                        {
                            "role": "tool",
                            "name": "Read",
                            "tool_call_id": tool_call_id,
                            "content": "output",
                        },
                    ],
                    "metadata": {"conversation_id": "conv-8"},
                }
            )

    def test_complete_accepts_client_executed_tool_result_as_object_content(self) -> None:
        bridge = self._build_bridge(assistant_content="summary from duo")
        result = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "summarize local command result"},
                    {
                        "role": "tool",
                        "name": "bash.run",
                        "content": {"stdout": "hello", "stderr": "", "exit_code": 0},
                    },
                ],
                "metadata": {"conversation_id": "conv-9"},
            }
        )
        self.assertEqual("summary from duo", result["content"])
        sent_prompt = bridge._duo_client.sent_payloads[-1]["content"]
        self.assertIn("[tool:bash.run]", sent_prompt)
        self.assertIn("\"stdout\":\"hello\"", sent_prompt)

    def test_complete_accepts_client_executed_tool_result_as_content_parts(self) -> None:
        bridge = self._build_bridge(assistant_content="summary from content parts")
        result = bridge.complete(
            {
                "model": "gitlab-duo-chat",
                "messages": [
                    {"role": "user", "content": "summarize file read"},
                    {
                        "role": "tool",
                        "name": "file.read",
                        "content": [
                            {"type": "text", "text": "first line"},
                            {"type": "text", "text": "second line"},
                        ],
                    },
                ],
                "metadata": {"conversation_id": "conv-10"},
            }
        )
        self.assertEqual("summary from content parts", result["content"])
        sent_prompt = bridge._duo_client.sent_payloads[-1]["content"]
        self.assertIn("first line", sent_prompt)
        self.assertIn("second line", sent_prompt)


if __name__ == "__main__":
    unittest.main()
