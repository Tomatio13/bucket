"""GitLab Duo GraphQL client using urllib."""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.request
from typing import Any

from .errors import UpstreamServiceError, map_gitlab_error


class DuoClient:
    def __init__(self, *, base_url: str, token: str, timeout_seconds: float) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout_seconds = timeout_seconds

    def graphql(self, query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
        body = json.dumps({"query": query, "variables": variables or {}}).encode("utf-8")
        request = urllib.request.Request(
            url=f"{self._base_url}/api/graphql",
            method="POST",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._token}",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self._timeout_seconds) as response:
                http_status = response.getcode()
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                payload = json.loads(exc.read().decode("utf-8"))
            except Exception:
                payload = {}
            raise map_gitlab_error(
                http_status=exc.code,
                graphql_errors=payload.get("errors"),
            ) from exc
        except (urllib.error.URLError, socket.timeout) as exc:
            raise UpstreamServiceError(message="Failed to reach GitLab", status_code=503) from exc

        if payload.get("errors"):
            raise map_gitlab_error(http_status=http_status, graphql_errors=payload.get("errors"))
        if "data" not in payload or payload["data"] is None:
            raise map_gitlab_error(http_status=http_status, empty_data=True)
        return payload["data"]

    def send_chat(
        self,
        *,
        content: str,
        thread_id: str | None,
        client_subscription_id: str,
    ) -> dict[str, Any]:
        query = """
        mutation DuoChat($content: String!, $threadId: String, $clientSubscriptionId: String!) {
          aiAction(input: {
            chat: {
              content: $content,
              threadId: $threadId,
              clientSubscriptionId: $clientSubscriptionId
            }
          }) {
            requestId
            threadId
            errors
          }
        }
        """
        data = self.graphql(
            query=query,
            variables={
                "content": content,
                "threadId": thread_id,
                "clientSubscriptionId": client_subscription_id,
            },
        )
        return data["aiAction"]

    def fetch_messages(self, *, thread_id: str) -> list[dict[str, Any]]:
        query = """
        query DuoMessages($threadId: String!) {
          aiMessages(threadId: $threadId) {
            nodes {
              requestId
              content
              role
              timestamp
              errors
              chunkId
            }
          }
        }
        """
        data = self.graphql(query=query, variables={"threadId": thread_id})
        return data["aiMessages"]["nodes"]

    def fetch_models(self) -> list[dict[str, Any]]:
        query = """
        query DuoAvailableModels {
          availableModels {
            nodes {
              id
              name
            }
          }
        }
        """
        data = self.graphql(query=query, variables={})
        available_models = data.get("availableModels") or {}
        return list(available_models.get("nodes") or [])
