"""Configuration helpers for the proxy."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _read_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    host: str = "127.0.0.1"
    port: int = 8000
    gitlab_base_url: str = "https://gitlab.example.com"
    wrapper_api_key: str = "dev-proxy-key"
    gitlab_token: str = ""
    request_timeout_seconds: float = 30.0
    polling_interval_seconds: float = 1.0
    polling_timeout_seconds: float = 30.0
    enable_action_cable_streaming: bool = False
    tool_preamble_max_chars: int = 4000
    max_tools: int = 32
    max_messages: int = 200

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            host=os.getenv("PROXY_HOST", "127.0.0.1"),
            port=int(os.getenv("PROXY_PORT", "8000")),
            gitlab_base_url=os.getenv("GITLAB_BASE_URL", "https://gitlab.example.com"),
            wrapper_api_key=os.getenv("WRAPPER_API_KEY", "dev-proxy-key"),
            gitlab_token=os.getenv("GITLAB_TOKEN", ""),
            request_timeout_seconds=float(os.getenv("REQUEST_TIMEOUT_SECONDS", "30")),
            polling_interval_seconds=float(os.getenv("POLLING_INTERVAL_SECONDS", "1")),
            polling_timeout_seconds=float(os.getenv("POLLING_TIMEOUT_SECONDS", "30")),
            enable_action_cable_streaming=_read_bool("ENABLE_ACTION_CABLE_STREAMING", False),
            tool_preamble_max_chars=int(os.getenv("TOOL_PREAMBLE_MAX_CHARS", "4000")),
            max_tools=int(os.getenv("MAX_TOOLS", "32")),
            max_messages=int(os.getenv("MAX_MESSAGES", "200")),
        )
