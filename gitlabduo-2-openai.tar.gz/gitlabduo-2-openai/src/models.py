"""Dataclasses shared across modules."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ToolCall:
    tool_call_id: str
    name: str
    arguments: dict[str, object]
