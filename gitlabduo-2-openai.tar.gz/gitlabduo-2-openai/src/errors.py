"""Error types and OpenAI-style error conversion."""

from __future__ import annotations

from dataclasses import dataclass
from http import HTTPStatus
from typing import Any


@dataclass
class ProxyError(Exception):
    message: str
    status_code: int
    code: str
    param: str | None = None
    error_type: str = "invalid_request_error"
    details: Any = None

    def to_openai_error(self) -> dict[str, Any]:
        payload = {
            "message": self.message,
            "type": self.error_type,
            "param": self.param,
            "code": self.code,
        }
        return {"error": payload}


class AuthenticationError(ProxyError):
    def __init__(self, message: str = "Invalid authentication credentials") -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.UNAUTHORIZED,
            code="invalid_api_key",
            error_type="invalid_request_error",
        )


class PermissionError(ProxyError):
    def __init__(self, message: str = "Permission denied") -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.FORBIDDEN,
            code="permission_denied",
            error_type="invalid_request_error",
        )


class NotFoundError(ProxyError):
    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.NOT_FOUND,
            code="not_found",
            error_type="invalid_request_error",
        )


class RateLimitError(ProxyError):
    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.TOO_MANY_REQUESTS,
            code="rate_limit_exceeded",
            error_type="rate_limit_error",
        )


class UpstreamServiceError(ProxyError):
    def __init__(self, message: str = "Upstream service error", status_code: int = 502, details: Any = None) -> None:
        super().__init__(
            message=message,
            status_code=status_code,
            code="upstream_error",
            error_type="server_error",
            details=details,
        )


def map_gitlab_error(
    *,
    http_status: int,
    graphql_errors: list[dict[str, Any]] | None = None,
    empty_data: bool = False,
) -> ProxyError:
    if http_status == HTTPStatus.UNAUTHORIZED:
        return AuthenticationError("Invalid GitLab token")
    if http_status == HTTPStatus.FORBIDDEN:
        return PermissionError("GitLab access forbidden")
    if http_status == HTTPStatus.NOT_FOUND:
        return NotFoundError("GitLab resource not found")
    if http_status == HTTPStatus.TOO_MANY_REQUESTS:
        return RateLimitError("GitLab rate limit exceeded")
    if graphql_errors:
        message = "; ".join(error.get("message", "GraphQL error") for error in graphql_errors)
        return UpstreamServiceError(message=message, status_code=502, details=graphql_errors)
    if empty_data:
        return UpstreamServiceError(message="GitLab returned empty data", status_code=502)
    if http_status >= 500:
        return UpstreamServiceError(message="GitLab upstream failure", status_code=503)
    return UpstreamServiceError(message="Unexpected GitLab response", status_code=502)
