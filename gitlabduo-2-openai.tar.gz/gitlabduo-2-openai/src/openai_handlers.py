"""OpenAI-compatible request handlers."""

from __future__ import annotations

import json
import time
import uuid
from collections.abc import Callable
from typing import Any

from .chat_bridge import ChatBridge
from .errors import AuthenticationError, ProxyError, ProxyError as BaseProxyError


class OpenAIHandlers:
    def __init__(
        self,
        *,
        api_key: str,
        chat_bridge: ChatBridge,
        fetch_models: Callable[[], list[dict[str, Any]]] | None = None,
    ) -> None:
        self._api_key = api_key
        self._chat_bridge = chat_bridge
        self._fetch_models = fetch_models

    def authorize(self, authorization_header: str | None) -> None:
        if not authorization_header or not authorization_header.startswith("Bearer "):
            raise AuthenticationError()
        token = authorization_header.split(" ", 1)[1]
        if token != self._api_key:
            raise AuthenticationError()

    def health(self) -> dict[str, Any]:
        return {"status": "ok"}

    def list_models(self) -> dict[str, Any]:
        created = int(time.time())
        items = []
        models = self._resolve_models()
        for model in models:
            items.append(
                {
                    "id": model["id"],
                    "object": "model",
                    "created": created,
                    "owned_by": model.get("owned_by", "gitlab"),
                }
            )
        return {"object": "list", "data": items}

    def handle_chat_completion(self, payload: dict[str, Any]) -> dict[str, Any]:
        self._validate_chat_request(payload)
        bridge_result = self._chat_bridge.complete(payload)
        response_id = f"chatcmpl-{uuid.uuid4().hex}"
        created = int(time.time())
        assistant_message: dict[str, Any] = {
            "role": "assistant",
            "content": bridge_result["content"],
        }
        if bridge_result["tool_calls"]:
            assistant_message["tool_calls"] = bridge_result["tool_calls"]
        return {
            "id": response_id,
            "object": "chat.completion",
            "created": created,
            "model": payload["model"],
            "choices": [
                {
                    "index": 0,
                    "message": assistant_message,
                    "finish_reason": bridge_result["finish_reason"],
                }
            ],
            "metadata": bridge_result["metadata"],
        }

    def stream_chat_completion(self, payload: dict[str, Any]) -> list[str]:
        response = self.handle_chat_completion(payload)
        choice = response["choices"][0]
        deltas: list[dict[str, Any]] = [{"role": "assistant"}]
        if choice["message"].get("content"):
            deltas.append({"content": choice["message"]["content"]})
        elif choice["message"].get("tool_calls"):
            deltas.append({"tool_calls": choice["message"]["tool_calls"]})

        chunks = []
        for delta in deltas:
            chunk = {
                "id": response["id"],
                "object": "chat.completion.chunk",
                "created": response["created"],
                "model": response["model"],
                "choices": [{"index": 0, "delta": delta, "finish_reason": None}],
            }
            chunks.append(f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n")

        final_chunk = {
            "id": response["id"],
            "object": "chat.completion.chunk",
            "created": response["created"],
            "model": response["model"],
            "choices": [{"index": 0, "delta": {}, "finish_reason": choice["finish_reason"]}],
        }
        chunks.append(f"data: {json.dumps(final_chunk, ensure_ascii=False)}\n\n")
        chunks.append("data: [DONE]\n\n")
        return chunks

    def _validate_chat_request(self, payload: dict[str, Any]) -> None:
        if payload.get("model") is None or not isinstance(payload["model"], str):
            raise ProxyError(
                message="model is required",
                status_code=400,
                code="invalid_request",
                param="model",
            )
        messages = payload.get("messages")
        if not isinstance(messages, list) or not messages:
            raise ProxyError(
                message="messages must be a non-empty array",
                status_code=400,
                code="invalid_request",
                param="messages",
            )
        unsupported = ["audio", "logprobs", "prediction", "service_tier", "store"]
        for field in unsupported:
            if field in payload:
                raise ProxyError(
                    message=f"{field} is not supported",
                    status_code=400,
                    code="unsupported_parameter",
                    param=field,
                )
        tools = payload.get("tools")
        if tools is not None and not isinstance(tools, list):
            raise ProxyError(
                message="tools must be an array",
                status_code=400,
                code="invalid_request",
                param="tools",
            )
        for message in messages:
            if not isinstance(message, dict):
                raise ProxyError(
                    message="each message must be an object",
                    status_code=400,
                    code="invalid_request",
                    param="messages",
                )
            if message.get("role") not in {"developer", "system", "user", "assistant", "tool"}:
                raise ProxyError(
                    message="invalid message role",
                    status_code=400,
                    code="invalid_request",
                    param="messages.role",
                )
            if "content" in message and not self._is_supported_content(message.get("content")):
                raise ProxyError(
                    message="message content must be a string, object, or array",
                    status_code=400,
                    code="invalid_request",
                    param="messages.content",
                )

    def _resolve_models(self) -> list[dict[str, Any]]:
        if self._fetch_models is not None:
            try:
                upstream_models = self._fetch_models()
            except BaseProxyError:
                upstream_models = []
            if upstream_models:
                return [
                    {
                        "id": model.get("id") or model.get("name") or "gitlab-duo-chat",
                        "owned_by": "gitlab",
                    }
                    for model in upstream_models
                ]
        return [{"id": "gitlab-duo-chat", "owned_by": "gitlab"}]

    @staticmethod
    def _is_supported_content(content: Any) -> bool:
        return content is None or isinstance(content, (str, dict, list, int, float, bool))
