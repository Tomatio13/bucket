"""Translate OpenAI chat requests into GitLab Duo operations."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

from .duo_client import DuoClient
from .errors import ProxyError
from .state_store import StateStore
from .tool_emulator import ToolEmulator


class ChatBridge:
    def __init__(
        self,
        *,
        duo_client: DuoClient,
        state_store: StateStore,
        tool_emulator: ToolEmulator,
        polling_interval_seconds: float,
        polling_timeout_seconds: float,
    ) -> None:
        self._duo_client = duo_client
        self._state_store = state_store
        self._tool_emulator = tool_emulator
        self._polling_interval_seconds = polling_interval_seconds
        self._polling_timeout_seconds = polling_timeout_seconds

    def complete(self, request: dict[str, Any]) -> dict[str, Any]:
        messages = request["messages"]
        tools = request.get("tools") or []
        request_metadata = request.get("metadata")
        metadata_input = request_metadata if isinstance(request_metadata, dict) else {}
        raw_conversation_id = metadata_input.get("conversation_id")
        conversation_id = str(raw_conversation_id) if raw_conversation_id else None
        previous_state = self._state_store.get_conversation(conversation_id) if conversation_id else None
        thread_id = previous_state.get("thread_id") if previous_state else None
        if not thread_id:
            thread_id = self._infer_thread_id_from_messages(messages)
        client_subscription_id = str(uuid.uuid4())

        prompt = self._build_prompt(request=request, messages=messages, tools=tools)
        send_result = self._duo_client.send_chat(
            content=prompt,
            thread_id=thread_id,
            client_subscription_id=client_subscription_id,
        )
        request_id = send_result.get("requestId")
        thread_id = send_result.get("threadId") or thread_id
        if not thread_id:
            raise ProxyError(
                message="GitLab Duo did not return a thread id",
                status_code=502,
                code="empty_thread_id",
                error_type="server_error",
            )

        metadata = dict(metadata_input)
        metadata.update(
            {
                "gitlab_thread_id": thread_id,
                "gitlab_request_id": request_id or "",
                "gitlab_client_subscription_id": client_subscription_id,
            }
        )
        if conversation_id:
            self._state_store.upsert_conversation(
                conversation_id=conversation_id,
                thread_id=thread_id,
                request_id=request_id,
                client_subscription_id=client_subscription_id,
                metadata=metadata,
            )
        if request_id:
            self._state_store.append_audit_log(
                request_id=request_id,
                event_type="chat_request",
                payload={"conversation_id": conversation_id, "tool_count": len(tools)},
            )

        assistant_message = self._wait_for_final_message(thread_id=thread_id)
        if tools:
            tool_calls = self._maybe_parse_tool_calls(assistant_message)
            if tool_calls:
                for tool_call in tool_calls:
                    self._state_store.record_tool_call(
                        tool_call_id=tool_call.tool_call_id,
                        conversation_id=conversation_id or "",
                        thread_id=thread_id,
                        tool_name=tool_call.name,
                        arguments=tool_call.arguments,
                    )
                return {
                    "content": None,
                    "tool_calls": [
                        {
                            "id": tool_call.tool_call_id,
                            "type": "function",
                            "function": {
                                "name": tool_call.name,
                                "arguments": self._dump_json(tool_call.arguments),
                            },
                        }
                        for tool_call in tool_calls
                    ],
                    "finish_reason": "tool_calls",
                    "metadata": metadata,
                }

        return {
            "content": assistant_message,
            "tool_calls": [],
            "finish_reason": "stop",
            "metadata": metadata,
        }

    def _infer_thread_id_from_messages(self, messages: list[dict[str, Any]]) -> str | None:
        for message in reversed(messages):
            if not isinstance(message, dict) or message.get("role") != "tool":
                continue
            tool_call_id = message.get("tool_call_id")
            if not isinstance(tool_call_id, str) or not tool_call_id:
                continue
            stored = self._state_store.get_tool_call(tool_call_id)
            if stored and stored.get("thread_id"):
                return str(stored["thread_id"])
        return None

    def _build_prompt(self, *, request: dict[str, Any], messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> str:
        lines: list[str] = []
        if tools:
            lines.append(self._tool_emulator.build_developer_preamble(tools))
        for message in messages:
            role = message["role"]
            raw_content = message.get("content", "")
            content = self._normalize_message_content(raw_content)
            if role == "tool":
                resolved = self._resolve_tool_message(
                    message,
                    conversation_id=str((request.get("metadata") or {}).get("conversation_id", "")),
                )
                executed = self._execute_tool_message(
                    request=request,
                    tool_name=resolved["tool_name"],
                    content=raw_content,
                )
                name = resolved["tool_name"]
                lines.append(f"[tool:{name}] {self._dump_json(executed)}")
            else:
                lines.append(f"[{role}] {content}")
        return "\n".join(lines)

    def _execute_tool_message(
        self,
        *,
        request: dict[str, Any],
        tool_name: str,
        content: Any,
    ) -> dict[str, Any]:
        _ = request
        return {"client_result": content}

    @staticmethod
    def _normalize_message_content(content: Any) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                    continue
                if isinstance(item, dict):
                    item_type = item.get("type")
                    if item_type == "text" and isinstance(item.get("text"), str):
                        parts.append(item["text"])
                        continue
                parts.append(json.dumps(item, ensure_ascii=False, sort_keys=True))
            return "\n".join(parts)
        if isinstance(content, dict):
            return json.dumps(content, ensure_ascii=False, sort_keys=True)
        return str(content)

    def _resolve_tool_message(self, message: dict[str, Any], conversation_id: str) -> dict[str, Any]:
        if isinstance(message.get("name"), str) and message["name"]:
            explicit_name = str(message["name"])
        else:
            explicit_name = None
        tool_call_id = message.get("tool_call_id")
        if isinstance(tool_call_id, str) and tool_call_id:
            stored = self._state_store.get_tool_call(tool_call_id)
            if stored is None:
                raise ProxyError(
                    message=f"Unknown tool_call_id: {tool_call_id}",
                    status_code=400,
                    code="unknown_tool_call_id",
                    param="messages.tool_call_id",
                )
            if conversation_id and stored["conversation_id"] != conversation_id:
                raise ProxyError(
                    message="tool_call_id does not belong to this conversation",
                    status_code=409,
                    code="tool_call_conversation_mismatch",
                    param="messages.tool_call_id",
                )
            stored_name = str(stored["tool_name"])
            if explicit_name is not None and explicit_name != stored_name:
                raise ProxyError(
                    message="tool name does not match the original tool call",
                    status_code=409,
                    code="tool_name_mismatch",
                    param="messages.name",
                )
            return {
                "tool_name": stored_name,
            }
        if explicit_name is not None:
            return {"tool_name": explicit_name}
        raise ProxyError(
            message="tool message must include name",
            status_code=400,
            code="invalid_request",
            param="messages.name",
        )

    def _wait_for_final_message(self, *, thread_id: str) -> str:
        deadline = time.monotonic() + self._polling_timeout_seconds
        last_content = ""
        while time.monotonic() < deadline:
            nodes = self._duo_client.fetch_messages(thread_id=thread_id)
            for node in reversed(nodes):
                if node.get("role") == "assistant" and node.get("content"):
                    content = str(node["content"])
                    if content != last_content:
                        last_content = content
                    if not node.get("chunkId"):
                        return last_content
            time.sleep(self._polling_interval_seconds)
        raise ProxyError(
            message="Timed out while waiting for GitLab Duo response",
            status_code=504,
            code="upstream_timeout",
            error_type="server_error",
        )

    def _maybe_parse_tool_calls(self, content: str) -> list[Any]:
        try:
            return self._tool_emulator.parse_tool_calls(content)
        except ProxyError:
            return []

    @staticmethod
    def _dump_json(value: dict[str, Any]) -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
