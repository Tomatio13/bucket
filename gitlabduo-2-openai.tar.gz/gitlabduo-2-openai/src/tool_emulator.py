"""Tool emulation helpers for OpenAI-compatible function calling."""

from __future__ import annotations

import json
import uuid
from typing import Any

from .errors import ProxyError
from .models import ToolCall


class ToolEmulator:
    def __init__(self, *, max_preamble_chars: int) -> None:
        self._max_preamble_chars = max_preamble_chars

    def build_developer_preamble(self, tools: list[dict[str, Any]]) -> str:
        summary = {
            "instructions": [
                "When a tool is required, return JSON only.",
                "Use the shape {\"tool_calls\":[{\"name\":\"...\",\"arguments\":{...}}]}.",
                "If no tool is required, answer normally in plain text.",
            ],
            "tools": self._normalize_tools(tools),
        }
        serialized = json.dumps(summary, ensure_ascii=True, separators=(",", ":"))
        return serialized[: self._max_preamble_chars]

    def parse_tool_calls(self, content: str) -> list[ToolCall]:
        try:
            payload = json.loads(content)
        except json.JSONDecodeError as exc:
            raise ProxyError(
                message="Tool response was not valid JSON",
                status_code=422,
                code="invalid_tool_response",
                error_type="invalid_request_error",
            ) from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("tool_calls"), list):
            raise ProxyError(
                message="Tool response did not contain tool_calls",
                status_code=422,
                code="invalid_tool_response",
                error_type="invalid_request_error",
            )
        result: list[ToolCall] = []
        for item in payload["tool_calls"]:
            if not isinstance(item, dict):
                raise ProxyError(
                    message="Tool call item must be an object",
                    status_code=422,
                    code="invalid_tool_response",
                    error_type="invalid_request_error",
                )
            name = item.get("name")
            arguments = item.get("arguments")
            if not isinstance(name, str) or not isinstance(arguments, dict):
                raise ProxyError(
                    message="Tool call must include a string name and object arguments",
                    status_code=422,
                    code="invalid_tool_response",
                    error_type="invalid_request_error",
                )
            result.append(
                ToolCall(
                    tool_call_id=f"call_{uuid.uuid4().hex}",
                    name=name,
                    arguments=arguments,
                )
            )
        return result

    @staticmethod
    def _normalize_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            function = tool.get("function", {})
            if not isinstance(function, dict):
                continue
            name = function.get("name")
            if not isinstance(name, str) or not name:
                continue
            normalized.append(
                {
                    "name": name,
                    "description": function.get("description", ""),
                    "parameters": function.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        return normalized
