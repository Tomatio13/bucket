"""SQLite-backed state and audit storage."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any


class StateStore:
    def __init__(self, path: str | Path) -> None:
        self._path = str(path)
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._path)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    conversation_id TEXT PRIMARY KEY,
                    thread_id TEXT,
                    request_id TEXT,
                    client_subscription_id TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    updated_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tool_calls (
                    tool_call_id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    thread_id TEXT,
                    tool_name TEXT NOT NULL,
                    arguments_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            columns = {
                row[1]
                for row in conn.execute("PRAGMA table_info(tool_calls)").fetchall()
            }
            if "thread_id" not in columns:
                conn.execute("ALTER TABLE tool_calls ADD COLUMN thread_id TEXT")

    def upsert_conversation(
        self,
        *,
        conversation_id: str,
        thread_id: str | None,
        request_id: str | None,
        client_subscription_id: str | None,
        metadata: dict[str, Any],
    ) -> None:
        now = time.time()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO conversations (
                    conversation_id, thread_id, request_id, client_subscription_id, metadata_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(conversation_id) DO UPDATE SET
                    thread_id=excluded.thread_id,
                    request_id=excluded.request_id,
                    client_subscription_id=excluded.client_subscription_id,
                    metadata_json=excluded.metadata_json,
                    updated_at=excluded.updated_at
                """,
                (
                    conversation_id,
                    thread_id,
                    request_id,
                    client_subscription_id,
                    json.dumps(metadata, sort_keys=True),
                    now,
                ),
            )

    def get_conversation(self, conversation_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                """
                SELECT conversation_id, thread_id, request_id, client_subscription_id, metadata_json, updated_at
                FROM conversations
                WHERE conversation_id = ?
                """,
                (conversation_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "conversation_id": row[0],
            "thread_id": row[1],
            "request_id": row[2],
            "client_subscription_id": row[3],
            "metadata": json.loads(row[4]),
            "updated_at": row[5],
        }

    def append_audit_log(self, request_id: str, event_type: str, payload: dict[str, Any]) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO audit_logs (request_id, event_type, payload_json, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (request_id, event_type, json.dumps(payload, sort_keys=True), time.time()),
            )

    def record_tool_call(
        self,
        *,
        tool_call_id: str,
        conversation_id: str,
        thread_id: str | None,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO tool_calls (
                    tool_call_id, conversation_id, thread_id, tool_name, arguments_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (tool_call_id, conversation_id, thread_id, tool_name, json.dumps(arguments, sort_keys=True), time.time()),
            )

    def get_tool_call(self, tool_call_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                """
                SELECT tool_call_id, conversation_id, thread_id, tool_name, arguments_json, created_at
                FROM tool_calls
                WHERE tool_call_id = ?
                """,
                (tool_call_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "tool_call_id": row[0],
            "conversation_id": row[1],
            "thread_id": row[2],
            "tool_name": row[3],
            "arguments": json.loads(row[4]),
            "created_at": row[5],
        }
