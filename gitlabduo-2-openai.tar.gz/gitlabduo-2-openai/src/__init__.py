"""OpenAI to GitLab Duo proxy package."""
