"""Minimal router for the proxy HTTP server."""

from __future__ import annotations

import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from typing import Any

from .errors import ProxyError
from .openai_handlers import OpenAIHandlers


class Router:
    def __init__(self, handlers: OpenAIHandlers) -> None:
        self._handlers = handlers

    def handle(self, request_handler: BaseHTTPRequestHandler) -> None:
        try:
            path = request_handler.path
            if path == "/healthz" and request_handler.command == "GET":
                self._send_json(request_handler, HTTPStatus.OK, self._handlers.health())
                return

            authorization = request_handler.headers.get("Authorization")
            self._handlers.authorize(authorization)

            if path == "/v1/models" and request_handler.command == "GET":
                self._send_json(request_handler, HTTPStatus.OK, self._handlers.list_models())
                return

            if path == "/v1/chat/completions" and request_handler.command == "POST":
                payload = self._read_json(request_handler)
                if payload.get("stream") is True:
                    chunks = self._handlers.stream_chat_completion(payload)
                    self._send_sse(request_handler, chunks)
                    return
                response = self._handlers.handle_chat_completion(payload)
                self._send_json(request_handler, HTTPStatus.OK, response)
                return

            self._send_json(
                request_handler,
                HTTPStatus.NOT_FOUND,
                {"error": {"message": "Not found", "type": "invalid_request_error", "param": None, "code": "not_found"}},
            )
        except ProxyError as exc:
            self._send_json(request_handler, exc.status_code, exc.to_openai_error())

    def _read_json(self, request_handler: BaseHTTPRequestHandler) -> dict[str, Any]:
        length = int(request_handler.headers.get("Content-Length", "0"))
        raw = request_handler.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ProxyError(
                message="Request body must be valid JSON",
                status_code=400,
                code="invalid_json",
                error_type="invalid_request_error",
            ) from exc
        if not isinstance(payload, dict):
            raise ProxyError(
                message="Request body must be a JSON object",
                status_code=400,
                code="invalid_json",
                error_type="invalid_request_error",
            )
        return payload

    @staticmethod
    def _send_json(request_handler: BaseHTTPRequestHandler, status_code: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request_handler.send_response(status_code)
        request_handler.send_header("Content-Type", "application/json; charset=utf-8")
        request_handler.send_header("Content-Length", str(len(body)))
        request_handler.end_headers()
        request_handler.wfile.write(body)

    @staticmethod
    def _send_sse(request_handler: BaseHTTPRequestHandler, chunks: list[str]) -> None:
        request_handler.send_response(HTTPStatus.OK)
        request_handler.send_header("Content-Type", "text/event-stream; charset=utf-8")
        request_handler.send_header("Cache-Control", "no-cache")
        request_handler.send_header("Connection", "keep-alive")
        request_handler.end_headers()
        for chunk in chunks:
            request_handler.wfile.write(chunk.encode("utf-8"))
        request_handler.wfile.flush()
