"""HTTP server entrypoint."""

from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .chat_bridge import ChatBridge
from .config import Settings
from .duo_client import DuoClient
from .openai_handlers import OpenAIHandlers
from .router import Router
from .state_store import StateStore
from .tool_emulator import ToolEmulator


def build_router(settings: Settings) -> Router:
    state_store = StateStore("proxy_state.sqlite3")
    duo_client = DuoClient(
        base_url=settings.gitlab_base_url,
        token=settings.gitlab_token,
        timeout_seconds=settings.request_timeout_seconds,
    )
    tool_emulator = ToolEmulator(max_preamble_chars=settings.tool_preamble_max_chars)
    chat_bridge = ChatBridge(
        duo_client=duo_client,
        state_store=state_store,
        tool_emulator=tool_emulator,
        polling_interval_seconds=settings.polling_interval_seconds,
        polling_timeout_seconds=settings.polling_timeout_seconds,
    )
    handlers = OpenAIHandlers(
        api_key=settings.wrapper_api_key,
        chat_bridge=chat_bridge,
        fetch_models=duo_client.fetch_models,
    )
    return Router(handlers)


def create_app(settings: Settings) -> ThreadingHTTPServer:
    router = build_router(settings)

    class RequestHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            router.handle(self)

        def do_POST(self) -> None:  # noqa: N802
            router.handle(self)

        def log_message(self, format: str, *args: object) -> None:
            return

    return ThreadingHTTPServer((settings.host, settings.port), RequestHandler)


def main() -> None:
    settings = Settings.from_env()
    server = create_app(settings)
    print(f"Serving on http://{settings.host}:{settings.port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
