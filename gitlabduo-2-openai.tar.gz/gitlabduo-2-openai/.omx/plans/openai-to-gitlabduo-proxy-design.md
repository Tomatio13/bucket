# OpenAI → GitLab Duo Protocol Proxy 設計計画

## Requirements Summary

- 目的は、OpenAI 互換 API を話すクライアントからの `POST /v1/chat/completions` と `GET /v1/models` を受け、GitLab Duo の GraphQL API へ変換する proxy を Python で設計することです。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:31)
- GitLab Duo 側の公開 API 面は `/api/graphql` 上の `aiAction`、`aiMessages`、`aiCompletionResponse` を中心に成り立ち、認証や権限エラーの出方も OpenAI API とは異なるため、HTTP と JSON の両方で正規化層が必要です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:5) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:17)
- Function Calling は GitLab Duo のネイティブ機能ではなく、wrapper 側でエミュレートする前提が現実的です。そのため、薄い単純プロキシではなく、チャット翻訳層と tool registry 層を分けた二層以上の構成を採用します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:7) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:11)
- tool 公開面は GraphQL 全面開放ではなく、whitelist した named operation を JSON Schema へ変換する curated registry 方式に限定します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:9) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:43) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:47)
- ストリーミングは GitLab subscription を優先候補にしつつ、stable public contract として弱いため polling fallback を必須にします。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:23) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)
- Python 実装は標準ライブラリのみを使い、HTTP server、HTTP client、JSON、UUID、logging、sqlite3、threading、unittest を中核に設計します。

## Acceptance Criteria

- `POST /v1/chat/completions` が `messages`、`model`、`stream`、`tools`、`tool_choice`、`parallel_tool_calls`、`metadata` を受理し、GitLab Duo への変換仕様が明文化されていること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:39)
- `GET /v1/models` が GitLab 側の available models 系 query と起動時検証の関係を含めて設計されていること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:27)
- Function Calling が registry 検証、prompt preamble、strict parser、`role:"tool"` 往復、失敗時 fallback まで定義されていること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:107)
- OpenAI 風エラー正規化が 401、403、429、500、503 と GitLab GraphQL の `null` / top-level `errors` 差分に対応していること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:17) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:37)
- MVP の streaming 設計が polling fallback を含み、将来の Action Cable 対応を feature flag で差し替え可能であること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:23) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:78) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)
- read/write 分離、write audit、query size guard、retry policy、state 管理、schema drift 対策が設計に入っていること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:19) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:21) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:99) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:116)
- Python 標準ライブラリだけで実装可能な責務分割とテスト戦略が示されていること。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:124)

## Proposed Design

### 1. サービス境界

- 外部公開 API は `GET /healthz`、`GET /v1/models`、`POST /v1/chat/completions` の 3 本に絞ります。
- `audio`、`logprobs`、`prediction`、`service_tier`、`store` は v1 非対応として明示的に 400 を返します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:39)
- wrapper 認証は OpenAI 互換 Bearer key、GitLab 側認証は user-delegated OAuth または Personal Access Token を優先し、session cookie は採用しません。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:97)

### 2. Python 標準ライブラリ構成

- `src/server.py`
  - `ThreadingHTTPServer` と `BaseHTTPRequestHandler` で HTTP 入口を提供します。
- `src/router.py`
  - method と path による最小ルーティングを持ちます。
- `src/openai_handlers.py`
  - OpenAI request の検証、正規化、レスポンス整形、SSE 出力を担います。
- `src/duo_client.py`
  - `urllib.request` で `/api/graphql` を呼び、GitLab エラーを内部例外へ変換します。
- `src/chat_bridge.py`
  - `messages` から Duo chat payload を生成し、`threadId`、`requestId`、`clientSubscriptionId` を管理します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:25) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:120)
- `src/tool_registry.py`
  - whitelist operation を JSON ファイルから読み込み、OpenAI tool 定義へ変換します。
- `src/tool_emulator.py`
  - developer preamble 生成、tool envelope parser、schema validation、fallback 制御を持ちます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:109)
- `src/state_store.py`
  - セッション相関と監査ログを `sqlite3` で保持します。MVP は単一ノード前提です。
- `src/sse.py`
  - `text/event-stream` の chunk 整形と keepalive を担当します。
- `src/config.py`
  - 環境変数読込、timeout、poll 間隔、feature flag を定義します。
- `tests/`
  - `unittest` と fixture JSON で単体・統合テストを構成します。

### 3. Chat Completion 変換フロー

1. OpenAI request を受信し、必須項目、未対応項目、metadata 制限、tools 形状を検証します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:37)
2. `messages` を flatten し、Duo へ渡す chat prompt と内部 state に分解します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:124)
3. tools なしの場合は `aiAction(chat)` を呼び、stream=false は polling、stream=true は polling SSE bridge を返します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:78) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)
4. tools ありの場合は registry で許可済み tool だけを残し、developer preamble に function contract を埋め込みます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:110)
5. Duo 応答が tool envelope なら OpenAI `tool_calls` へ変換し、`finish_reason:"tool_calls"` を返します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:35)
6. クライアントから `role:"tool"` が返ったら machine-readable block として再投入し、最終 assistant 応答へ進みます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:113)
7. parser 不一致、schema 不一致、危険な write、generic executor 要求時は text answer fallback か 400/422 相当エラーで止めます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:114)

### 4. Tool Registry 方針

- registry は `registry/operations.json` のような静的ファイルで持ちます。
- 各 operation は `name`、`kind`、`document`、`variables_schema`、`read_only`、`confirmation_required`、`expose_to_model` を持ちます。
- 初期公開 tool は `available_models`、代表的 read query、限定的 write mutation のみです。`graphql_execute(document, variables)` のような万能 executor は外部非公開です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:43) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:72)
- `strict:true` は read-only かつ bounded variables を持つ tool のみで有効化します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:33)
- write tool は `safe write` と `unsafe write` を分離し、unsafe は確認フェーズなしに実行しません。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:118)

### 5. Streaming 方針

- MVP は `aiMessages(threadId)` polling を正式実装とし、SSE は wrapper が差分を `chat.completion.chunk` に変換して返します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:37) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)
- Action Cable 経由 subscription は `ENABLE_ACTION_CABLE_STREAMING` などの feature flag の背後に置き、transport drift に備えます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:23)
- polling 間隔は設定化し、rate limit と timeout を見ながら指数バックオフします。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:21) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:116)

### 6. Error / Retry / Audit 方針

- GitLab query の `null`、mutation の top-level `errors`、HTTP status を内部例外へそろえ、OpenAI 風 JSON error に正規化します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:17)
- read request は 429、503、timeout に対して自動再試行します。
- mutation と tool write は idempotency が明示されない限り自動再送しません。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:116)
- 監査ログには wrapper request id、GitLab `threadId`、`requestId`、tool 名、tool 引数 hash、結果 status、latency を記録します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:103)
- query size、tool 数、message 長、poll 回数にガードを入れます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:21) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:99)

## Implementation Steps

1. 基本骨格を作る  
   対象: 新規 `src/`、`tests/`、`registry/`、`README.md`  
   内容: HTTP server、router、設定、ヘルスチェック、起動方法を追加する。

2. GitLab GraphQL クライアントと OpenAI エラー正規化を実装する  
   根拠: GitLab 側は auth failure と GraphQL error の返し方が異なるため、専用変換層が必要です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:17)

3. Chat bridge を実装する  
   根拠: `aiAction`、`aiMessages`、`threadId`、`requestId`、`clientSubscriptionId` を中心に状態管理が必要です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:25) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:78)

4. `/v1/models` と `/v1/chat/completions` の非 streaming 経路を実装する  
   根拠: v1 最小セットとして最優先です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:31)

5. polling ベース SSE bridge を実装する  
   根拠: subscription transport は不安定要素があるため、MVP は polling fallback を優先します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:23) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)

6. tool registry と tool emulator を実装する  
   根拠: Function Calling は wrapper 側エミュレーションが必要です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:7) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:107)

7. sqlite3 ベースの state / audit store を実装する  
   根拠: correlation id と write audit の保持が必要です。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:99) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:103)

8. schema drift 検知と registry validation を追加する  
   根拠: GitLab GraphQL は versionless かつ experiment を含みます。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:19) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:27)

9. 単体・統合・E2E テストを追加する  
   根拠: parser robustness、tool flow、streaming、rate limit を重点確認します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:124) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:128)

## Risks And Mitigations

- GitLab Duo schema drift
  - 対策: 起動時 introspection 検証、registry version、CI で compatibility check を回します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:19) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:132)
- streaming transport の不安定さ
  - 対策: MVP は polling 正式採用、Action Cable は feature flag 背後に隔離します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:23) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:101)
- tool injection / 危険 mutation
  - 対策: whitelist registry、strict parser、read/write 分離、confirm/apply 二段階を採用します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:99) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:118)
- rate limit と timeout
  - 対策: query size guard、poll バックオフ、read retry、write no-auto-retry を実装します。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:21) [report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:116)
- 標準ライブラリ限定による実装負荷
  - 対策: HTTP server と client を薄く保ち、registry と parser を純粋関数化して複雑性を局所化します。

## Verification Steps

1. `python -m unittest discover -s tests -v` で request validation、error mapping、tool parser、registry validation を確認する。
2. fixture ベースで GitLab GraphQL success、top-level errors、`null` authorization、429、503、timeout を再現する。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:124)
3. ローカル統合試験で `stream:false` と `stream:true` を OpenAI 互換形式で叩き、JSON と SSE が崩れないことを確認する。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:128)
4. tools あり E2E で `tool_calls` 生成、`role:"tool"` の戻し、最終 assistant 応答までの往復を確認する。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:128)
5. 負荷試験で polling 間隔、thread 長、同時接続数を変え、rate limit と timeout 周辺の挙動を確認する。[report.md](/home/masato/Workspace/gitlabduo-2-openai/report.md:130)

## Deliverables

- 設計書: このファイル
- 次段階の実装対象: `src/` 一式、`registry/operations.json`、`tests/` 一式、`README.md`
- 実装優先順位: 非 streaming chat → models → polling SSE → tool emulation → drift check
