# 理解度チェックの問題データ

各 Markdown は 1 フォルダ分の EPUB に対応しています。

- `## ファイル名.html` の下に、その章の 5 問を書く
- 問題は `### Q1. 問題文`
- 選択肢は `- ` で 4 つ
- 正解は `ANSWER: 1`（1〜4。ビルド時に選択肢を並べ替え、正解位置を分散します）
- 解説は `EXPLANATION: ...`

## 再ビルド

```bash
cd /home/masato/Documents/ClaudeCodeExam/05_CCDV-P
python3 scripts/build_muse_epub.py
# 1冊だけ
python3 scripts/build_muse_epub.py --only 1
```

出力先は `link_contents/epub_muse/`（表紙画像は `covers/`）です。

## 構成

- 本文は元の HTML をそのまま使い、章末に「理解度チェック（5問）」を追加
- 解答と解説は各 EPUB の巻末 `answers.xhtml` にまとめ、問題からリンク
- 章の並び順は `scripts/build_muse_epub.py` の `CHAPTER_ORDER` で指定
- 表紙のタイトル改行は `COVER_TITLES`
- 元の `html_muse/**/*.html` は変更しません
