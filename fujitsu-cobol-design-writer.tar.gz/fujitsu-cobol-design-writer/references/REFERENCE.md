# Reference Guide

Use this guide after the skill is activated. Keep the main `SKILL.md` short and
use this file for detailed instructions.

## Standard workflow

1. Identify the target `.cbl` file.
2. Run `scripts/analyze_cobol.py` to get structured JSON.
3. If the user wants a polished final design document, run
   `scripts/llm_prompt.py` or build an equivalent prompt from the JSON.
4. If the user wants a unit-test viewpoint document, run
   `scripts/test_spec.py`.
5. If the user wants a polished final unit-test document, run
   `scripts/test_llm_prompt.py`.
6. If the user wants machine-readable cases for later automation, run
   `scripts/test_cases_json.py`.
7. Write the final Japanese document.

## JSON fields to inspect

- `program_id`
- `using_parameters`
- `returning`
- `files`
- `working_storage`
- `linkage`
- `local_storage`
- `sections`
- `paragraphs`
- `conditions`
- `event_handlers`
- `loops`
- `file_operations`
- `calls`
- `mutations`
- `warnings`

## Design document rules

- Use the section order in `assets/design-doc-template.md`
- `program_id`, `source_format`, `using_parameters`, and `returning` belong in
  the overview section
- `files` and `file_operations` belong in I/O design
- `working_storage`, `linkage`, and `local_storage` belong in data design
- `sections`, `paragraphs`, `loops`, `file_operations`, and `calls` belong in
  processing flow
- `conditions` belong in the decision section
- `warnings` belong in constraints and exceptions

## Test-spec mode

If the user asks for unit-test viewpoints instead of a design document, derive
the draft from the same JSON.

Map the analysis like this:

- `conditions` -> branch tests, representative values, boundaries
- `event_handlers` -> end handling, exception handling, WHEN branches, abnormal paths, WHEN OTHER fallback
- `loops` -> zero/one/many, termination conditions, continuation values, terminal values
- `file_operations` -> normal and abnormal file handling
- `calls` -> normal and abnormal interface patterns
- `mutations` -> updated fields, before/after values, representative values, boundaries
- `working_storage` and `linkage` -> data boundaries and type coverage

Use this structure or the template in `assets/test-spec-template.md`:

```markdown
# 単体テスト観点書
## 1. 対象概要
## 2. テスト対象機能
## 3. 判定条件観点
## 4. 繰返し観点
## 5. 入出力観点
## 6. 外部CALL観点
## 7. データ境界値観点
## 8. 制約事項
```

## Prompting rules for the second-pass LLM

- The parser output is the source of truth
- Do not invent business rules
- Mark unsupported content as `要確認`
- Mark inferred intent as `推定`
- Mention line numbers when they add review value

## Edge cases

- COPY books are not expanded by the current prototype
- Embedded SQL is not parsed in detail
- Multiple program definitions should produce separate sections
- If a field is absent, say so instead of inferring from naming alone
