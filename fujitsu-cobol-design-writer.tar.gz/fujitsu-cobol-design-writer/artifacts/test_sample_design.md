# 詳細設計書

## 1. 対象概要
- 対象ファイル: `test/sample.cbl`
- 対象プログラム: `SAF-MAIN`
- 解析基準: parser 出力を source of truth とする。
- 注意: COPY `COBW3` は検出されたが、コピー元の展開解析は未実装のため、関連詳細は要確認。

## 2. プログラム概要
- PROGRAM-ID: `SAF-MAIN`
- source_format: `fixed`
- PROCEDURE DIVISION USING: `SAFCTX`
- RETURNING: なし
- プロシージャ本体: `SAFSAMPLE1-START` line 32
- parser 出力上の `sections` は空である。ソースには SECTION 定義があるが、現行 parser では取り切れていないため、該当箇所は要確認。

## 3. 入出力設計
- 入力
  - `SAFCTX` line 28
  - `COBW3` グループは COPY 展開未対応のため詳細不明
- 出力
  - `HTMLFILENAME` により出力 HTML 名を切り替える
  - `COBW3-COOKIE-VALUE`、`COBW3-CNV-VALUE`、`COBW3-HTML-FILENAME` を更新する
- ファイル入出力
  - parser 出力では `files`、`file_operations` ともに検出なし
  - COBOL ソース上も OPEN/READ/WRITE 系は見当たらない

## 4. データ項目設計
- Working-Storage
  - `HTMLFILENAME` line 14 `PIC X(64)`
  - `PATHNAME` line 15 `PIC X(256)`
  - `PATHSIZE` line 16 `PIC 9(05)`
  - `COPYSTARTPOS` line 17 `PIC 9(05)`
  - `LEFTLENGTH` line 18 `PIC 9(05)`
  - `アクセス回数` line 19 `PIC 9(05)`
  - `WORK-CNTR1` line 20 `PIC 9(4) COMP-5`
  - `WORK-CNTR2` line 21 `PIC 9(4) COMP-5`
  - `CONVERT-VALUE` line 22 `PIC X(1024)`
  - `CONVERT-LENGTH` line 23 `PIC S9(4) COMP-5`
  - `SANITIZED-DATA` line 24 `PIC X(1024)`
  - `SANITIZED-LENGTH` line 25 `PIC S9(4) COMP-5`
- Linkage
  - `SAFCTX` line 28 `POINTER`
- Local-Storage
  - なし

## 5. 処理フロー
- `SAFSAMPLE1-START` line 32
  - `COBW3` を LOW-VALUE 初期化し、`SAFCTX` を `COBW3-CONTEXT` に設定する line 35-36
  - `COBW3_INIT` を CALL する line 40
  - `PATHNAME` を SPACE に初期化する line 42
  - Cookie 名 `Your Access Counter` を設定し、`COBW3_GET_COOKIE_XX` を CALL する line 44-45
  - `COBW3-STATUS` と `COBW3-SEARCH-FLAG-NON` で分岐する line 46-56
  - 終了時に `COBW3_FREE` を CALL する line 61
- `継続画面出力処理` line 67
  - アクセス回数を数値化し、1 加算して cookie に戻す line 70-73
  - `アクセスカウンタ登録処理` を PERFORM する line 76
  - `COBW3_GET_REQUEST_INFO` でリモートホスト名を取得し、サニタイズ後に変換データへ登録する line 82-96
  - `COBW3_RECEIVE_HEADER` で `USER-AGENT` を受信し、同様にサニタイズ登録する line 99-113
  - 最終的に `safrply2.htm` を設定して画面出力する line 116-117
- `アクセスカウンタ登録処理` line 123
  - `COBW3_SET_COOKIE_XX` を CALL する line 126
  - 異常時は `saferror.htm` を設定して画面出力し、`終了位置` へ遷移する line 127-131
- `変換データ登録` line 135
  - `COBW3_SET_CNV_NX` を CALL する line 136
  - 異常時は `saferror.htm` を設定して画面出力し、`終了位置` へ遷移する line 137-141
- `画面出力処理` line 145
  - `PATHNAME` が SPACE の場合は `物理パス名取得` を PERFORM する line 148-150
  - `COBW3-HTML-FILENAME` を組み立てて `COBW3_PUT_HTML` を CALL する line 151-160
- `物理パス名取得` line 165
  - `COBW3_GET_REQUEST_INFO` で物理パスを取得し、`PATHNAME` と `PATHSIZE` に格納する line 166-172
- `サニタイズ処理` line 177
  - `CONVERT-VALUE` を 1 文字ずつ走査し、`<`、`>`、`&` を HTML エスケープして `SANITIZED-DATA` に格納する line 181-199
  - `WHEN OTHER` はそのまま転記する line 194-197

## 6. 判定条件
- `COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820` line 46
  - 2 条件の AND 判定
  - `ZERO` と `8820` を除外する分岐
- `COBW3-SEARCH-FLAG-NON` line 49
  - cookie 未検索時の分岐
- `COBW3-STATUS NOT = ZERO` line 84
  - `COBW3_GET_REQUEST_INFO` 失敗時の分岐
- `COBW3-STATUS NOT = ZERO` line 101
  - `COBW3_RECEIVE_HEADER` 失敗時の分岐
- `COBW3-STATUS NOT = ZERO` line 127
  - `COBW3_SET_COOKIE_XX` 失敗時の分岐
- `COBW3-STATUS NOT = ZERO` line 137
  - `COBW3_SET_CNV_NX` 失敗時の分岐
- `PATHNAME = SPACE` line 148
  - 物理パス未設定時に取得処理へ進む
- `EVALUATE CONVERT-VALUE(WORK-CNTR1:1)` line 184
  - `<`、`>`、`&`、その他で分岐する

## 7. 繰返し処理
- parser 出力の `loops` は `PERFORM` 1 件のみで、詳細な反復条件は未抽出
- ソース上の反復
  - `PERFORM WITH TEST BEFORE VARYING WORK-CNTR1 FROM 1 BY 1 UNTIL WORK-CNTR1 > CONVERT-LENGTH` line 181-183
  - `サニタイズ処理` は 0 回、1 回、複数回の入力長で確認が必要

## 8. 外部インタフェース
- CALL 先
  - `COBW3_INIT` line 40
  - `COBW3_GET_COOKIE_XX` line 45
  - `COBW3_GET_REQUEST_INFO` line 83, 168
  - `COBW3_RECEIVE_HEADER` line 100
  - `COBW3_SET_COOKIE_XX` line 126
  - `COBW3_SET_CNV_NX` line 136
  - `COBW3_PUT_HTML` line 160
  - `COBW3_FREE` line 61
- USING
  - 各 CALL は主に `COBW3` を使用する
- 要確認
  - `COBW3` の中身は COPY 未展開のため、インタフェースの全項目は parser からは確定できない

## 9. 例外・制約事項
- `warnings`
  - `COPY句を検出しました。コピー元展開後の解析は未実装です。`
- 例外時の共通動作
  - `saferror.htm` を設定し、画面出力処理へ遷移する箇所が複数ある
- 制約
  - parser output を基準にしており、COPY 展開部分は source of truth として扱えない
  - parser では `sections` が空のため、SECTION 単位の整理は一部要確認

## 10. トレーサビリティ
- `SAF-MAIN` line 8
- `SAFCTX` line 28
- `SAFSAMPLE1-START` line 32
- `COBW3_INIT` line 40
- `COBW3_GET_COOKIE_XX` line 45
- `IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN` line 46
- `継続画面出力処理` line 67
- `アクセスカウンタ登録処理` line 123
- `変換データ登録` line 135
- `画面出力処理` line 145
- `物理パス名取得` line 165
- `サニタイズ処理` line 177
