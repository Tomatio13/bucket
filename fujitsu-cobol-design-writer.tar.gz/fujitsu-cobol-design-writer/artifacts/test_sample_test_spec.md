# 単体テスト観点書

## 1. 対象概要

- 対象プラットフォーム: Fujitsu mainframe COBOL
- 解析元: `test/sample.cbl`
- プログラム数: 1

## 2.1 テスト対象機能

- プログラムID: SAF-MAIN
- ソース形式: fixed
- USING: SAFCTX
- RETURNING: なし
- 更新対象項目: COBW3, COBW3-CONTEXT, SAFCTX, PATHNAME, COBW3-COOKIE-NAME, HTMLFILENAME

## 3.1 判定条件観点

- line 46 block=SAFSAMPLE1-START [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN`
  観点: AND 条件のため、各条件が単独で成立する場合と、すべて成立する場合を確認
  観点: 部分条件 1 の成立・不成立が全体結果へ与える影響を確認: `COBW3-STATUS NOT = ZERO`
  観点: 部分条件 2 の成立・不成立が全体結果へ与える影響を確認: `COBW3-STATUS NOT = 8820 THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 8820、8819、8821 を確認
  観点: 否定条件の成立・不成立を確認

## 4.1 繰返し観点

- line 48 block=SAFSAMPLE1-START target=inline 0回、1回、複数回、終了条件成立を確認する

## 5.1 入出力観点

- 入出力操作なし

## 6.1 外部CALL観点

- line 40 target="COBW3_INIT" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 45 target="COBW3_GET_COOKIE_XX" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし

## 7.1 データ境界値観点

- WORKING-STORAGE line 14 HTMLFILENAME 型・桁数・初期値・空値・最大最小を確認する
  PIC X(64)
  観点: 英数字 64 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 15 PATHNAME 型・桁数・初期値・空値・最大最小を確認する
  PIC X(256)
  観点: 英数字 256 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 16 PATHSIZE 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 17 COPYSTARTPOS 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 18 LEFTLENGTH 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- 更新文観点
  line 35 [MOVE] target=COBW3 更新前後、代表値、境界値、計算結果を確認する
  line 36 [SET] target=COBW3-CONTEXT, SAFCTX 更新前後、代表値、境界値、計算結果を確認する
  line 42 [MOVE] target=PATHNAME 更新前後、代表値、境界値、計算結果を確認する
  line 44 [MOVE] target=COBW3-COOKIE-NAME 更新前後、代表値、境界値、計算結果を確認する
  line 47 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する

## 8.1 制約事項

- COPY句を検出しました。コピー元展開後の解析は未実装です。
