#!/usr/bin/env python3
from __future__ import annotations

import argparse

from _common import analyze_file, render_test_cases_json, write_output


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate machine-readable COBOL unit-test cases JSON.")
    parser.add_argument("source", help="Path to COBOL source file")
    parser.add_argument("-o", "--output", help="Write JSON to a file")
    args = parser.parse_args()
    payload = render_test_cases_json(analyze_file(args.source))
    write_output(payload, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
