#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from _common import analyze_file, write_output


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze Fujitsu COBOL and emit IR JSON.")
    parser.add_argument("source", help="Path to COBOL source file")
    parser.add_argument("-o", "--output", help="Write JSON to a file")
    args = parser.parse_args()
    payload = json.dumps(analyze_file(args.source), ensure_ascii=False, indent=2)
    write_output(payload, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
