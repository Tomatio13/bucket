#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "usage: $0 <source.cbl> [output-dir]" >&2
  exit 1
fi

SOURCE_FILE="$1"
OUTPUT_DIR="${2:-./design-pack}"

mkdir -p "${OUTPUT_DIR}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if command -v uv >/dev/null 2>&1; then
  RUNNER=(uv run python)
else
  RUNNER=(python)
fi

"${RUNNER[@]}" "${SCRIPT_DIR}/analyze_cobol.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/analysis.json"
"${RUNNER[@]}" "${SCRIPT_DIR}/design_doc.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/draft.md"
"${RUNNER[@]}" "${SCRIPT_DIR}/llm_prompt.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/llm-prompt.md"
"${RUNNER[@]}" "${SCRIPT_DIR}/test_spec.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/test-spec.md"
"${RUNNER[@]}" "${SCRIPT_DIR}/test_llm_prompt.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/test-llm-prompt.md"
"${RUNNER[@]}" "${SCRIPT_DIR}/test_cases_json.py" "${SOURCE_FILE}" -o "${OUTPUT_DIR}/test-cases.json"

echo "generated:"
echo "  ${OUTPUT_DIR}/analysis.json"
echo "  ${OUTPUT_DIR}/draft.md"
echo "  ${OUTPUT_DIR}/llm-prompt.md"
echo "  ${OUTPUT_DIR}/test-spec.md"
echo "  ${OUTPUT_DIR}/test-llm-prompt.md"
echo "  ${OUTPUT_DIR}/test-cases.json"
