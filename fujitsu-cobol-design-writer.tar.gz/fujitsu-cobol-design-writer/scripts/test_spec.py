#!/usr/bin/env python3
from __future__ import annotations

import argparse

from _common import analyze_file, render_test_spec_markdown, write_output


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a COBOL unit-test viewpoint draft.")
    parser.add_argument("source", help="Path to COBOL source file")
    parser.add_argument("-o", "--output", help="Write Markdown to a file")
    args = parser.parse_args()
    payload = render_test_spec_markdown(analyze_file(args.source))
    write_output(payload, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
