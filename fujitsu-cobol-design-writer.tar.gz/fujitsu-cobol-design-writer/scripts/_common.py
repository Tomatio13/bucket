from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from tree_sitter import Language, Node, Parser
import tree_sitter_cobol


@dataclass(slots=True)
class DataItem:
    level: str | None
    name: str | None
    picture: str | None = None
    usage: str | None = None
    occurs: str | None = None
    redefines: str | None = None
    value: str | None = None
    section: str | None = None
    line: int | None = None


@dataclass(slots=True)
class FileDefinition:
    name: str
    file_type: str | None = None
    clauses: list[str] = field(default_factory=list)
    line: int | None = None


@dataclass(slots=True)
class ProcedureBlock:
    kind: str
    name: str
    line: int | None = None


@dataclass(slots=True)
class Condition:
    kind: str
    expression: str
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class Loop:
    kind: str
    target: str | None = None
    option: str | None = None
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class FileOperation:
    operation: str
    target: str | None = None
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class CallSite:
    target: str
    using: list[str] = field(default_factory=list)
    giving: str | None = None
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class EventHandler:
    kind: str
    expression: str | None = None
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class Mutation:
    kind: str
    targets: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    block: str | None = None
    line: int | None = None


@dataclass(slots=True)
class ProgramIR:
    program_id: str | None
    source_path: str
    source_format: str
    using_parameters: list[str] = field(default_factory=list)
    returning: str | None = None
    sections: list[ProcedureBlock] = field(default_factory=list)
    paragraphs: list[ProcedureBlock] = field(default_factory=list)
    files: list[FileDefinition] = field(default_factory=list)
    working_storage: list[DataItem] = field(default_factory=list)
    linkage: list[DataItem] = field(default_factory=list)
    local_storage: list[DataItem] = field(default_factory=list)
    conditions: list[Condition] = field(default_factory=list)
    loops: list[Loop] = field(default_factory=list)
    file_operations: list[FileOperation] = field(default_factory=list)
    calls: list[CallSite] = field(default_factory=list)
    event_handlers: list[EventHandler] = field(default_factory=list)
    mutations: list[Mutation] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def procedure_division_present(self) -> bool:
        return bool(
            self.sections
            or self.paragraphs
            or self.conditions
            or self.loops
            or self.file_operations
            or self.calls
            or self.event_handlers
            or self.mutations
        )


SECTION_LABELS = {
    "working_storage_section": "working-storage",
    "linkage_section": "linkage",
    "local_storage_section": "local-storage",
}

FILE_OPERATION_TYPES = {
    "open_statement": "OPEN",
    "close_statement": "CLOSE",
    "read_statement": "READ",
    "write_statement": "WRITE",
    "rewrite_statement": "REWRITE",
    "delete_statement": "DELETE",
    "start_statement": "START",
    "return_statement": "RETURN",
    "release_statement": "RELEASE",
}

SOURCE_FILE_OPERATION_TYPES = {
    "OPEN": "OPEN",
    "CLOSE": "CLOSE",
    "READ": "READ",
    "WRITE": "WRITE",
    "REWRITE": "REWRITE",
    "DELETE": "DELETE",
    "START": "START",
    "RETURN": "RETURN",
    "RELEASE": "RELEASE",
}

SOURCE_HANDLER_PREFIXES = {
    "AT END",
    "NOT AT END",
    "INVALID KEY",
    "NOT INVALID KEY",
    "ON EXCEPTION",
    "NOT ON EXCEPTION",
}

SOURCE_MUTATION_PREFIXES = (
    "MOVE ",
    "ADD ",
    "COMPUTE ",
    "SUBTRACT ",
    "MULTIPLY ",
    "DIVIDE ",
    "INITIALIZE ",
    "SET ",
)

PARAGRAPH_HEADER_EXCLUDES = {
    "ELSE",
    "END-IF",
    "END-EVALUATE",
    "END-PERFORM",
    "EXIT",
    "GOBACK",
    "STOP",
}


def build_parser() -> Parser:
    return Parser(Language(tree_sitter_cobol.language()))


def parse_cobol(source: bytes) -> Node:
    parser = build_parser()
    tree = parser.parse(source)
    return tree.root_node


def analyze_file(path: str | Path) -> dict[str, Any]:
    source_path = Path(path)
    source = source_path.read_bytes()
    return analyze_source(source, source_path=str(source_path))


def analyze_source(source: bytes, source_path: str = "<memory>") -> dict[str, Any]:
    root = parse_cobol(source)
    programs = []
    for child in root.children:
        if child.type == "program_definition":
            programs.append(_extract_program(child, source, source_path))
    if not programs:
        programs.append(
            ProgramIR(
                program_id=None,
                source_path=source_path,
                source_format=_detect_source_format(source),
                warnings=["program_definition が見つかりませんでした。文法未対応の可能性があります。"],
            ).to_dict()
        )
    return {
        "target_platform": "Fujitsu mainframe COBOL",
        "parser": "tree-sitter-cobol",
        "source_path": source_path,
        "program_count": len(programs),
        "programs": programs,
    }


def render_design_markdown(analysis: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# Fujitsu COBOL Detailed Design Draft")
    lines.append("")
    lines.append(f"- Target platform: {analysis['target_platform']}")
    lines.append(f"- Parser: {analysis['parser']}")
    lines.append(f"- Source: `{analysis['source_path']}`")
    lines.append("")
    for index, program in enumerate(analysis["programs"], start=1):
        lines.extend(_render_program(program, index))
    return "\n".join(lines).rstrip() + "\n"


def render_llm_prompt(analysis: dict[str, Any]) -> str:
    analysis_json = json.dumps(analysis, ensure_ascii=False, indent=2)
    return (
        "# Fujitsu COBOL Detailed Design Prompt\n\n"
        "以下の制約に従って、日本語の詳細設計書をMarkdownで作成してください。\n\n"
        "## 目的\n"
        "- 入力は Fujitsu メインフレーム COBOL の構文解析結果です。\n"
        "- この解析結果だけを根拠に、保守担当者が読める詳細設計書を作成してください。\n\n"
        "## 絶対条件\n"
        "- 日本語で書く\n"
        "- 断定は根拠があるものだけに限定する\n"
        "- 不明な点は「要確認」または「推定」と明記する\n"
        "- JSONに存在しない業務仕様を創作しない\n"
        "- `warnings` がある場合は設計書末尾に制約として必ず記載する\n"
        "- 条件分岐、繰返し、ファイル操作、外部CALLは必ず節を分けて記載する\n\n"
        "## 出力構成\n"
        "以下の見出しをこの順で出力すること。\n\n"
        "# 詳細設計書\n"
        "## 1. 対象概要\n"
        "## 2. プログラム概要\n"
        "## 3. 入出力設計\n"
        "## 4. データ項目設計\n"
        "## 5. 処理フロー\n"
        "## 6. 判定条件\n"
        "## 7. 繰返し処理\n"
        "## 8. 外部インタフェース\n"
        "## 9. 例外・制約事項\n"
        "## 10. トレーサビリティ\n\n"
        "## 各節の書き方\n"
        "- 2. プログラム概要: PROGRAM-ID, source_format, USING, RETURNING を整理する\n"
        "- 3. 入出力設計: files と file_operations を対応付けて、入力/出力/更新の観点でまとめる\n"
        "- 4. データ項目設計: working_storage, linkage, local_storage を節ごとに整理する\n"
        "- 5. 処理フロー: sections, paragraphs, loops, file_operations, calls を時系列でまとめる\n"
        "- 6. 判定条件: conditions を列挙し、関係する block を付ける\n"
        "- 7. 繰返し処理: loops を列挙し、終了条件や対象 paragraph を明記する\n"
        "- 8. 外部インタフェース: calls を列挙し、target, using, giving を整理する\n"
        "- 9. 例外・制約事項: warnings と、AT END 等が読み取れる場合の注意を書く\n"
        "- 10. トレーサビリティ: 重要要素に source line を対応付ける\n\n"
        "## 入力JSON\n"
        "```json\n"
        f"{analysis_json}\n"
        "```\n"
    )


def render_test_spec_markdown(analysis: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# 単体テスト観点書")
    lines.append("")
    lines.append("## 1. 対象概要")
    lines.append("")
    lines.append(f"- 対象プラットフォーム: {analysis['target_platform']}")
    lines.append(f"- 解析元: `{analysis['source_path']}`")
    lines.append(f"- プログラム数: {analysis['program_count']}")
    lines.append("")
    for index, program in enumerate(analysis["programs"], start=1):
        lines.extend(_render_test_program(program, index))
    return "\n".join(lines).rstrip() + "\n"


def render_test_llm_prompt(analysis: dict[str, Any]) -> str:
    analysis_json = json.dumps(analysis, ensure_ascii=False, indent=2)
    return (
        "# Fujitsu COBOL Unit Test Viewpoints Prompt\n\n"
        "以下の構文解析結果を根拠に、日本語の単体テスト観点書をMarkdownで作成してください。\n\n"
        "## 絶対条件\n"
        "- 日本語で書く\n"
        "- JSONに存在しない仕様を創作しない\n"
        "- 断定できない内容は `要確認` または `推定` と明記する\n"
        "- 条件分岐、繰返し、入出力、外部CALL、データ境界は必ず独立した節に分ける\n"
        "- `warnings` がある場合は制約事項に必ず記載する\n\n"
        "## 出力構成\n"
        "# 単体テスト観点書\n"
        "## 1. 対象概要\n"
        "## 2. テスト対象機能\n"
        "## 3. 判定条件観点\n"
        "## 4. 繰返し観点\n"
        "## 5. 入出力観点\n"
        "## 6. 外部CALL観点\n"
        "## 7. データ境界値観点\n"
        "## 8. 制約事項\n\n"
        "## 観点化ルール\n"
        "- `conditions`: 真/偽、代表値、境界値、分岐網羅の観点に展開する\n"
        "- `event_handlers`: AT END, NOT AT END, WHEN, WHEN OTHER, INVALID KEY を正常系・異常系へ展開する\n"
        "- `loops`: 0回、1回、複数回、終了条件成立、異常終了、継続値と終了値の観点に展開する\n"
        "- `file_operations`: OPEN/READ/CLOSE 等の正常系と異常系に展開する\n"
        "- `calls`: 正常応答、異常応答、引数の妥当性確認に展開する\n"
        "- `mutations`: 更新先項目ごとに更新前後、代表値、境界値、演算結果を確認する\n"
        "- `working_storage` と `linkage`: 型、桁数、初期値、境界値、空値に展開する\n\n"
        "## 入力JSON\n"
        "```json\n"
        f"{analysis_json}\n"
        "```\n"
    )


def render_test_cases_json(analysis: dict[str, Any]) -> str:
    payload = {
        "target_platform": analysis["target_platform"],
        "source_path": analysis["source_path"],
        "program_count": analysis["program_count"],
        "programs": [],
    }
    for program in analysis["programs"]:
        payload["programs"].append(_build_program_test_cases(program))
    return json.dumps(payload, ensure_ascii=False, indent=2)


def write_output(payload: str, output_path: str | None) -> None:
    if output_path:
        Path(output_path).write_text(payload, encoding="utf-8")
    else:
        print(payload)


def _extract_program(program_node: Node, source: bytes, source_path: str) -> dict[str, Any]:
    identification = _find_first(program_node, "identification_division")
    procedure = _find_first(program_node, "procedure_division")
    ir = ProgramIR(
        program_id=_extract_program_id(identification, source),
        source_path=source_path,
        source_format=_detect_source_format(source),
    )
    if procedure is not None:
        ir.using_parameters = _extract_procedure_params(procedure, source)
        ir.returning = _extract_returning(procedure, source)
        _collect_procedure_metadata(procedure, source, ir)
    for section_type, label in SECTION_LABELS.items():
        section_node = _find_first(program_node, section_type)
        if section_node is None:
            continue
        items = [_extract_data_item(node, source, label) for node in _find_all(section_node, "data_description")]
        getattr(ir, label.replace("-", "_")).extend([item for item in items if item is not None])
    for file_section in _find_all(program_node, "file_section"):
        ir.files.extend(_extract_file_definitions(file_section, source))
    if _augment_ir_from_source(source, ir):
        ir.warnings.append("tree-sitter-cobol の解析欠落をソース行ベースで補完しました。")
    _append_warnings(ir, program_node)
    ir.warnings = _dedupe(ir.warnings)
    return ir.to_dict()


def _append_warnings(ir: ProgramIR, program_node: Node) -> None:
    if _find_first(program_node, "copy_statement") is not None:
        ir.warnings.append("COPY句を検出しました。コピー元展開後の解析は未実装です。")
    if _find_first(program_node, "exec_sql_statement") is not None:
        ir.warnings.append("埋め込みSQLを検出しました。現行文法では詳細解析できません。")
    if not ir.procedure_division_present():
        ir.warnings.append("PROCEDURE DIVISION が見つかりませんでした。設計書の処理記述は限定的です。")


def _augment_ir_from_source(source: bytes, ir: ProgramIR) -> bool:
    lines = source.decode("utf-8", errors="replace").splitlines()
    changed = False
    changed |= _augment_data_items_from_source(lines, ir)
    changed |= _augment_procedure_from_source(lines, ir)
    return changed


def _augment_data_items_from_source(lines: list[str], ir: ProgramIR) -> bool:
    changed = False
    current_section: str | None = None
    for line_number, raw_line in enumerate(lines, start=1):
        code = _source_code(raw_line)
        if not code:
            continue
        upper = code.upper()
        if upper.startswith("PROCEDURE DIVISION"):
            break
        if upper.startswith("WORKING-STORAGE SECTION"):
            current_section = "working-storage"
            continue
        if upper.startswith("LINKAGE SECTION"):
            current_section = "linkage"
            continue
        if upper.startswith("LOCAL-STORAGE SECTION"):
            current_section = "local-storage"
            continue
        if upper.endswith("DIVISION."):
            current_section = None
            continue
        if current_section is None:
            continue
        item = _parse_data_item_from_source_line(code, current_section, line_number)
        if item is not None and _append_unique_data_item(getattr(ir, current_section.replace("-", "_")), item):
            changed = True
    return changed


def _augment_procedure_from_source(lines: list[str], ir: ProgramIR) -> bool:
    changed = False
    in_procedure = False
    current_section: str | None = None
    current_paragraph: str | None = None

    for line_number, raw_line in enumerate(lines, start=1):
        code = _source_code(raw_line)
        if not code:
            continue
        upper = code.upper()
        if upper.startswith("PROCEDURE DIVISION"):
            in_procedure = True
            continue
        if not in_procedure:
            continue

        section_name = _parse_section_header_from_source(code)
        if section_name is not None:
            current_section = section_name
            current_paragraph = None
            if _append_unique_block(ir.sections, ProcedureBlock(kind="section", name=section_name, line=line_number)):
                changed = True
            continue

        paragraph_name = _parse_paragraph_header_from_source(code)
        if paragraph_name is not None:
            current_paragraph = paragraph_name
            if _append_unique_block(ir.paragraphs, ProcedureBlock(kind="paragraph", name=paragraph_name, line=line_number)):
                changed = True
            continue

        block_name = current_paragraph or current_section

        if upper.startswith("IF ") or upper.startswith("ELSE IF "):
            condition = Condition("IF", code.rstrip("."), block_name, line_number)
            if _append_unique_condition(ir.conditions, condition):
                changed = True
            continue

        if upper.startswith("EVALUATE "):
            condition = Condition("EVALUATE", code.rstrip("."), block_name, line_number)
            if _append_unique_condition(ir.conditions, condition):
                changed = True
            continue

        if upper.startswith("WHEN OTHER"):
            handler = EventHandler("WHEN OTHER", "WHEN OTHER", block_name, line_number)
            if _append_unique_event_handler(ir.event_handlers, handler):
                changed = True
            continue

        if upper.startswith("WHEN "):
            handler = EventHandler("WHEN", code.rstrip("."), block_name, line_number)
            if _append_unique_event_handler(ir.event_handlers, handler):
                changed = True
            continue

        for prefix in SOURCE_HANDLER_PREFIXES:
            if upper.startswith(prefix):
                handler = EventHandler(prefix, code.rstrip("."), block_name, line_number)
                if _append_unique_event_handler(ir.event_handlers, handler):
                    changed = True
                break
        else:
            if upper.startswith("PERFORM "):
                loop = _parse_loop_from_source_line(code, block_name, line_number)
                if _append_unique_loop(ir.loops, loop):
                    changed = True
                continue

            for verb, operation in SOURCE_FILE_OPERATION_TYPES.items():
                if upper.startswith(f"{verb} "):
                    file_operation = FileOperation(operation, _parse_operation_target_from_source(code, verb), block_name, line_number)
                    if _append_unique_file_operation(ir.file_operations, file_operation):
                        changed = True
                    break
            else:
                if any(upper.startswith(prefix) for prefix in SOURCE_MUTATION_PREFIXES):
                    mutation = _parse_mutation_from_source_line(code, block_name, line_number)
                    if mutation is not None and _append_unique_mutation(ir.mutations, mutation):
                        changed = True
                    continue

                if upper.startswith("CALL "):
                    call = _parse_call_from_source_line(code, block_name, line_number)
                    if _append_unique_call(ir.calls, call):
                        changed = True
                    continue
    return changed


def _parse_data_item_from_source_line(code: str, section_label: str, line_number: int) -> DataItem | None:
    if code.upper().startswith("COPY "):
        return None
    match = re.match(r"^(?P<level>\d{2}|77|88)\s+(?P<name>[^\s.]+)(?P<rest>.*?)(?:\.)?$", code)
    if match is None:
        return None
    rest = match.group("rest").strip()
    picture_match = re.search(r"\bPIC(?:TURE)?\s+([^\s.]+)", rest, flags=re.IGNORECASE)
    picture = f"PIC {picture_match.group(1)}" if picture_match is not None else None
    usage_match = re.search(r"\bUSAGE\s+([A-Z0-9-]+)\b", rest, flags=re.IGNORECASE)
    usage = f"USAGE {usage_match.group(1)}" if usage_match is not None else None
    if usage is None:
        shorthand_usage = re.search(r"\b(COMP(?:-[1-9])?|BINARY|PACKED-DECIMAL|POINTER|INDEX)\b", rest, flags=re.IGNORECASE)
        if shorthand_usage is not None:
            usage = shorthand_usage.group(1).upper()
    occurs_match = re.search(r"\bOCCURS\s+(.+?)(?=\b(?:PIC|PICTURE|USAGE|VALUE|REDEFINES)\b|$)", rest, flags=re.IGNORECASE)
    redefines_match = re.search(r"\bREDEFINES\s+([^\s.]+)", rest, flags=re.IGNORECASE)
    value_match = re.search(r"\bVALUE\s+(.+?)(?=\b(?:PIC|PICTURE|USAGE|OCCURS|REDEFINES)\b|$)", rest, flags=re.IGNORECASE)
    compact_usage = _compact_text(usage or "") or None
    return DataItem(
        level=match.group("level"),
        name=match.group("name"),
        picture=picture,
        usage=compact_usage,
        occurs=_compact_text(occurs_match.group(0)) if occurs_match is not None else None,
        redefines=_compact_text(redefines_match.group(0)) if redefines_match is not None else None,
        value=_compact_text(value_match.group(0)) if value_match is not None else None,
        section=section_label,
        line=line_number,
    )


def _parse_section_header_from_source(code: str) -> str | None:
    match = re.match(r"^(?P<name>[^\s.]+(?:\s+[^\s.]+)*)\s+SECTION\.$", code, flags=re.IGNORECASE)
    if match is None:
        return None
    return _normalize_block_name(match.group("name"))


def _parse_paragraph_header_from_source(code: str) -> str | None:
    match = re.match(r"^(?P<name>[^\s.]+)\.$", code)
    if match is None:
        return None
    name = match.group("name")
    if name.upper() in PARAGRAPH_HEADER_EXCLUDES:
        return None
    return _normalize_block_name(name)


def _parse_loop_from_source_line(code: str, block_name: str | None, line_number: int) -> Loop:
    body = code[8:].strip().rstrip(".")
    upper_body = body.upper()
    option_keywords = (" WITH ", " UNTIL ", " VARYING ", " TIMES", " TEST ", " FOREVER")
    target = body
    option = None
    if upper_body.startswith(("WITH ", "UNTIL ", "VARYING ", "TIMES ", "TEST ", "FOREVER")):
        target = None
        option = body
    else:
        for keyword in option_keywords:
            index = upper_body.find(keyword)
            if index != -1:
                target = body[:index].strip() or None
                option = body[index + 1 :].strip() or None
                break
    return Loop(kind="PERFORM", target=target, option=option, block=block_name, line=line_number)


def _parse_call_from_source_line(code: str, block_name: str | None, line_number: int) -> CallSite:
    statement = code.rstrip(".")
    target_match = re.match(r'^CALL\s+("[^"]+"|[^\s]+)', statement, flags=re.IGNORECASE)
    target = target_match.group(1) if target_match is not None else statement
    using_match = re.search(r"\bUSING\s+(.+?)(?=\b(?:GIVING|RETURNING)\b|$)", statement, flags=re.IGNORECASE)
    using = _extract_identifiers_from_source_text(using_match.group(1)) if using_match is not None else []
    giving_match = re.search(r"\b(?:GIVING|RETURNING)\s+(.+)$", statement, flags=re.IGNORECASE)
    giving = _compact_text(giving_match.group(1)) if giving_match is not None else None
    return CallSite(target=target, using=using, giving=giving, block=block_name, line=line_number)


def _parse_operation_target_from_source(code: str, verb: str) -> str | None:
    statement = code.rstrip(".")
    remainder = statement[len(verb) :].strip()
    if not remainder:
        return None
    words = []
    for token in re.split(r"\s+", remainder):
        upper = token.upper()
        if upper in {"INPUT", "OUTPUT", "I-O", "EXTEND", "INTO", "FROM", "KEY", "INVALID", "NOT", "AT", "END"}:
            continue
        cleaned = token.strip(",.")
        if cleaned:
            words.append(cleaned)
    return ", ".join(words) if words else None


def _parse_mutation_from_source_line(code: str, block_name: str | None, line_number: int) -> Mutation | None:
    statement = code.rstrip(".")
    upper = statement.upper()
    kind = statement.split(" ", 1)[0].upper()
    targets: list[str] = []
    sources: list[str] = []

    if upper.startswith("MOVE "):
        parts = re.split(r"\bTO\b", statement, maxsplit=1, flags=re.IGNORECASE)
        if len(parts) == 2:
            sources = _extract_identifiers_from_source_text(parts[0][5:])
            targets = _extract_identifiers_from_source_text(parts[1])
    elif upper.startswith("ADD "):
        from_part, to_part = re.split(r"\bTO\b", statement, maxsplit=1, flags=re.IGNORECASE) if " TO " in upper else (statement, "")
        sources = _extract_identifiers_from_source_text(from_part[4:])
        if to_part:
            giving_split = re.split(r"\bGIVING\b", to_part, maxsplit=1, flags=re.IGNORECASE)
            to_only = giving_split[0]
            giving_part = giving_split[1] if len(giving_split) > 1 else ""
            targets.extend(_extract_identifiers_from_source_text(to_only))
            targets.extend(_extract_identifiers_from_source_text(giving_part))
    elif upper.startswith("COMPUTE "):
        parts = statement[8:].split("=", 1)
        if len(parts) == 2:
            targets = _extract_identifiers_from_source_text(parts[0])
            sources = _extract_identifiers_from_source_text(parts[1])
    elif upper.startswith("SET "):
        parts = re.split(r"\bTO\b", statement, maxsplit=1, flags=re.IGNORECASE)
        if len(parts) == 2:
            targets = _extract_identifiers_from_source_text(parts[0][4:])
            sources = _extract_identifiers_from_source_text(parts[1])
    elif upper.startswith("INITIALIZE "):
        targets = _extract_identifiers_from_source_text(statement[11:])
    else:
        targets = _extract_identifiers_from_source_text(statement)

    targets = _dedupe(targets)
    sources = _dedupe(sources)
    if not targets and not sources:
        return None
    return Mutation(kind=kind, targets=targets, sources=sources, block=block_name, line=line_number)


def _extract_identifiers_from_source_text(text: str) -> list[str]:
    text = re.sub(r'(?i)N?C?"[^"]*"', " ", text)
    candidates = re.findall(r"[A-Za-z0-9-一-龯ぁ-んァ-ン_]+", text)
    result: list[str] = []
    for candidate in candidates:
        upper = candidate.upper()
        if candidate == "-":
            continue
        if upper in {
            "BY",
            "CONTENT",
            "DELIMITED",
            "FALSE",
            "FUNCTION",
            "FROM",
            "GIVING",
            "INTO",
            "LOW-VALUE",
            "NUMVAL",
            "OF",
            "REFERENCE",
            "SPACE",
            "SPACES",
            "THEN",
            "TO",
            "TRUE",
            "USING",
            "VALUE",
            "ZERO",
        }:
            continue
        if candidate.isdigit():
            continue
        if candidate not in result:
            result.append(candidate)
    return result


def _source_code(raw_line: str) -> str:
    if not raw_line:
        return ""
    if len(raw_line) >= 7 and raw_line[:6].isdigit():
        indicator = raw_line[6:7]
        if indicator in {"*", "/"}:
            return ""
        return raw_line[7:72].rstrip()
    stripped = raw_line.strip()
    if stripped.startswith("*") or stripped.startswith("/"):
        return ""
    return raw_line.rstrip()


def _append_unique_data_item(items: list[DataItem], item: DataItem) -> bool:
    key = (item.section, item.line, item.level, item.name)
    for existing in items:
        if (existing.section, existing.line, existing.level, existing.name) == key:
            return False
    items.append(item)
    return True


def _append_unique_block(items: list[ProcedureBlock], item: ProcedureBlock) -> bool:
    key = (item.kind, item.name, item.line)
    for existing in items:
        if (existing.kind, existing.name, existing.line) == key:
            return False
    items.append(item)
    return True


def _append_unique_condition(items: list[Condition], item: Condition) -> bool:
    key = (item.kind, item.expression, item.line)
    for existing in items:
        if (existing.kind, existing.expression, existing.line) == key:
            return False
    items.append(item)
    return True


def _append_unique_loop(items: list[Loop], item: Loop) -> bool:
    for existing in items:
        if existing.kind == item.kind and existing.line == item.line:
            updated = False
            if existing.target is None and item.target is not None:
                existing.target = item.target
                updated = True
            if existing.option is None and item.option is not None:
                existing.option = item.option
                updated = True
            return updated
    items.append(item)
    return True


def _append_unique_file_operation(items: list[FileOperation], item: FileOperation) -> bool:
    key = (item.operation, item.target, item.line)
    for existing in items:
        if (existing.operation, existing.target, existing.line) == key:
            return False
    items.append(item)
    return True


def _append_unique_call(items: list[CallSite], item: CallSite) -> bool:
    for existing in items:
        if existing.line == item.line:
            updated = False
            if not existing.using and item.using:
                existing.using = item.using
                updated = True
            if existing.giving is None and item.giving is not None:
                existing.giving = item.giving
                updated = True
            if not existing.target and item.target:
                existing.target = item.target
                updated = True
            return updated
    items.append(item)
    return True


def _append_unique_event_handler(items: list[EventHandler], item: EventHandler) -> bool:
    key = (item.kind, item.expression, item.line)
    for existing in items:
        if (existing.kind, existing.expression, existing.line) == key:
            return False
    items.append(item)
    return True


def _append_unique_mutation(items: list[Mutation], item: Mutation) -> bool:
    for existing in items:
        if existing.kind == item.kind and existing.line == item.line:
            if existing.kind == "SET" and item.targets and item.sources:
                merged_targets = item.targets
            else:
                merged_targets = _dedupe(existing.targets + item.targets)
            merged_sources = _dedupe(existing.sources + item.sources)
            updated = merged_targets != existing.targets or merged_sources != existing.sources
            existing.targets = merged_targets
            existing.sources = merged_sources
            return updated
    items.append(item)
    return True


def _extract_program_id(identification_node: Node | None, source: bytes) -> str | None:
    if identification_node is None:
        return None
    program_name = _find_first(identification_node, "program_name")
    return _node_text(program_name, source) if program_name is not None else None


def _extract_procedure_params(procedure_node: Node, source: bytes) -> list[str]:
    params = []
    for param in _find_all(procedure_node, "procedure_param"):
        text = _compact_text(_node_text(param, source))
        if text:
            params.append(text)
    return params


def _extract_returning(procedure_node: Node, source: bytes) -> str | None:
    returning = _find_first(procedure_node, "procedure_returning")
    if returning is None:
        return None
    word = _extract_last_word(returning, source)
    if word:
        return word
    text = _compact_text(_node_text(returning, source))
    if text.upper().startswith("RETURNING "):
        return text.split(" ", 1)[1]
    return text


def _collect_procedure_metadata(procedure_node: Node, source: bytes, ir: ProgramIR) -> None:
    current_section: str | None = None
    current_paragraph: str | None = None
    for node in _walk_named(procedure_node):
        if node.type == "section_header":
            name = _normalize_block_name(_extract_field_or_text(node, "name", source))
            current_section = name
            ir.sections.append(ProcedureBlock(kind="section", name=name, line=_line(node)))
            continue
        if node.type == "paragraph_header":
            name = _normalize_block_name(_extract_field_or_text(node, "name", source))
            current_paragraph = name
            ir.paragraphs.append(ProcedureBlock(kind="paragraph", name=name, line=_line(node)))
            continue
        if node.type == "if_header":
            ir.conditions.append(Condition("IF", _compact_text(_node_text(node, source)), current_paragraph or current_section, _line(node)))
            continue
        if node.type == "evaluate_header":
            ir.conditions.append(Condition("EVALUATE", _compact_text(_node_text(node, source)), current_paragraph or current_section, _line(node)))
            continue
        if node.type == "when":
            ir.event_handlers.append(EventHandler("WHEN", _compact_text(_node_text(node, source)), current_paragraph or current_section, _line(node)))
            continue
        if node.type == "when_other":
            ir.event_handlers.append(EventHandler("WHEN OTHER", "WHEN OTHER", current_paragraph or current_section, _line(node)))
            continue
        if node.type in {"at_end", "not_at_end", "invalid_key", "not_invalid_key", "on_exception", "not_on_exception"}:
            ir.event_handlers.append(
                EventHandler(
                    node.type.upper().replace("_", " "),
                    _compact_text(_node_text(node, source)),
                    current_paragraph or current_section,
                    _line(node),
                )
            )
            continue
        if node.type in {"perform_statement_call_proc", "perform_statement_loop"}:
            proc = node.child_by_field_name("procedure")
            opt = node.child_by_field_name("option")
            ir.loops.append(
                Loop(
                    kind="PERFORM",
                    target=_compact_text(_node_text(proc, source)) if proc is not None else None,
                    option=_compact_text(_node_text(opt, source)) if opt is not None else None,
                    block=current_paragraph or current_section,
                    line=_line(node),
                )
            )
            continue
        if node.type in {
            "move_statement",
            "add_statement",
            "compute_statement",
            "subtract_statement",
            "multiply_statement",
            "divide_statement",
            "initialize_statement",
            "set_statement",
        }:
            mutation = _extract_mutation(node, source, current_paragraph or current_section)
            if mutation is not None:
                ir.mutations.append(mutation)
            continue
        if node.type == "call_statement":
            ir.calls.append(_extract_call(node, source, current_paragraph or current_section))
            continue
        if node.type in FILE_OPERATION_TYPES:
            ir.file_operations.append(
                FileOperation(FILE_OPERATION_TYPES[node.type], _extract_operation_target(node, source), current_paragraph or current_section, _line(node))
            )


def _extract_call(node: Node, source: bytes, block_name: str | None) -> CallSite:
    target = _compact_text(_node_text(node.child_by_field_name("x"), source))
    using: list[str] = []
    using_node = node.child_by_field_name("using")
    if using_node is not None:
        for child in using_node.named_children:
            text = _compact_text(_node_text(child, source))
            if text:
                using.append(text)
    giving = _compact_text(_node_text(node.child_by_field_name("giving"), source)) or None
    returning = _compact_text(_node_text(node.child_by_field_name("returning"), source)) or None
    return CallSite(target or _compact_text(_node_text(node, source)), using, giving or returning, block_name, _line(node))


def _extract_mutation(node: Node, source: bytes, block_name: str | None) -> Mutation | None:
    kind = node.type.replace("_statement", "").upper()
    targets: list[str] = []
    sources: list[str] = []

    if node.type == "move_statement":
        src = node.child_by_field_name("src")
        dst = node.child_by_field_name("dst")
        if src is not None:
            sources.extend(_extract_identifiers(src, source))
        if dst is not None:
            targets.extend(_extract_identifiers(dst, source))
    elif node.type == "add_statement":
        field_from = node.child_by_field_name("from")
        field_to = node.child_by_field_name("to")
        field_giving = node.child_by_field_name("giving")
        if field_from is not None:
            sources.extend(_extract_identifiers(field_from, source))
        if field_to is not None:
            targets.extend(_extract_identifiers(field_to, source))
        if field_giving is not None:
            targets.extend(_extract_identifiers(field_giving, source))
    elif node.type == "compute_statement":
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if left is not None:
            targets.extend(_extract_identifiers(left, source))
        if right is not None:
            sources.extend(_extract_identifiers(right, source))
    elif node.type == "subtract_statement":
        field_from = node.child_by_field_name("from")
        field_from_to = node.child_by_field_name("from_to")
        field_giving = node.child_by_field_name("giving")
        if field_from is not None:
            sources.extend(_extract_identifiers(field_from, source))
        if field_from_to is not None:
            targets.extend(_extract_identifiers(field_from_to, source))
        if field_giving is not None:
            targets.extend(_extract_identifiers(field_giving, source))
    elif node.type == "multiply_statement":
        val1 = node.child_by_field_name("val1")
        val2 = node.child_by_field_name("val2")
        giving = node.child_by_field_name("giving")
        if val1 is not None:
            sources.extend(_extract_identifiers(val1, source))
        if val2 is not None:
            targets.extend(_extract_identifiers(val2, source))
        if giving is not None:
            targets.extend(_extract_identifiers(giving, source))
    elif node.type == "divide_statement":
        field_x = node.child_by_field_name("x")
        field_into = node.child_by_field_name("into")
        field_by = node.child_by_field_name("by")
        field_giving = node.child_by_field_name("giving")
        if field_x is not None:
            sources.extend(_extract_identifiers(field_x, source))
        if field_by is not None:
            sources.extend(_extract_identifiers(field_by, source))
        if field_into is not None:
            targets.extend(_extract_identifiers(field_into, source))
        if field_giving is not None:
            targets.extend(_extract_identifiers(field_giving, source))
    elif node.type == "initialize_statement":
        field_x = node.child_by_field_name("x")
        if field_x is not None:
            targets.extend(_extract_identifiers(field_x, source))
    elif node.type == "set_statement":
        targets.extend(_extract_identifiers(node, source))

    targets = _dedupe(targets)
    sources = _dedupe(sources)
    if not targets and not sources:
        return None
    return Mutation(kind=kind, targets=targets, sources=sources, block=block_name, line=_line(node))


def _extract_operation_target(node: Node, source: bytes) -> str | None:
    for field in ("file_name", "target", "procedure"):
        child = node.child_by_field_name(field)
        if child is not None:
            return _compact_text(_node_text(child, source))
    if node.type in {"open_statement", "close_statement"}:
        names: list[str] = []
        for child in node.named_children:
            if child.type in {"open_arg", "close_arg"}:
                for nested in child.named_children:
                    if nested.type == "WORD":
                        names.append(_compact_text(_node_text(nested, source)))
        if names:
            return ", ".join(names)
    for child in node.named_children:
        if child.type in {"WORD", "qualified_word"}:
            return _compact_text(_node_text(child, source))
    return None


def _extract_file_definitions(file_section: Node, source: bytes) -> list[FileDefinition]:
    definitions: list[FileDefinition] = []
    for node in _find_all(file_section, "file_description"):
        file_type = _compact_text(_node_text(_find_first(node, "file_type"), source))
        entry = _find_first(node, "file_description_entry")
        if entry is None:
            continue
        name = _compact_text(_extract_first_word(entry, source))
        clauses = []
        for clause in _find_all(entry, "file_description_clause"):
            clause_text = _compact_text(_node_text(clause, source))
            if clause_text:
                clauses.append(clause_text)
        definitions.append(FileDefinition(name, file_type, clauses, _line(node)))
    return definitions


def _extract_data_item(node: Node, source: bytes, section_label: str) -> DataItem | None:
    level = _extract_first_text(node, {"level_number", "level_number_88"}, source)
    name = _extract_first_text(node, {"entry_name"}, source)
    if level is None and name is None:
        return None
    return DataItem(
        level=level,
        name=name,
        picture=_extract_clause_text(node, "picture_clause", source),
        usage=_extract_clause_text(node, "usage_clause", source),
        occurs=_extract_clause_text(node, "occurs_clause", source),
        redefines=_extract_clause_text(node, "redefines_clause", source),
        value=_extract_clause_text(node, "value_clause", source),
        section=section_label,
        line=_line(node),
    )


def _render_program(program: dict[str, Any], index: int) -> list[str]:
    lines = [
        f"## Program {index}: {program.get('program_id') or 'UNKNOWN'}",
        "",
        "### Summary",
        "",
        f"- Source format: {program.get('source_format') or 'unknown'}",
        f"- Procedure USING: {_format_list(program.get('using_parameters', []))}",
        f"- Procedure RETURNING: {program.get('returning') or 'なし'}",
        "",
        "### Files",
        "",
    ]
    if program.get("files"):
        for file_def in program["files"]:
            clauses = ", ".join(file_def["clauses"]) if file_def["clauses"] else "なし"
            lines.append(f"- {file_def['name']} [{file_def.get('file_type') or '?'}] line {file_def.get('line') or '?'} clauses: {clauses}")
    else:
        lines.append("- 定義なし")
    lines.extend(["", "### Data Items", "", "#### Working-Storage", ""])
    lines.extend(_render_data_items(program.get("working_storage", [])))
    lines.extend(["", "#### Linkage", ""])
    lines.extend(_render_data_items(program.get("linkage", [])))
    lines.extend(["", "#### Local-Storage", ""])
    lines.extend(_render_data_items(program.get("local_storage", [])))
    lines.extend(["", "### Procedure Blocks", ""])
    lines.extend(_render_blocks("Section", program.get("sections", [])))
    lines.extend(_render_blocks("Paragraph", program.get("paragraphs", [])))
    lines.extend(["", "### Decision Logic", ""])
    if program.get("conditions"):
        for condition in program["conditions"]:
            lines.append(f"- [{condition['kind']}] line {condition.get('line') or '?'} block={condition.get('block') or 'TOP'} expr: `{condition['expression']}`")
    else:
        lines.append("- 条件分岐なし")
    lines.extend(["", "### Loops", ""])
    if program.get("loops"):
        for loop in program["loops"]:
            lines.append(f"- line {loop.get('line') or '?'} block={loop.get('block') or 'TOP'} target={loop.get('target') or 'inline'} option={loop.get('option') or 'なし'}")
    else:
        lines.append("- 繰返しなし")
    lines.extend(["", "### External Calls", ""])
    if program.get("calls"):
        for call in program["calls"]:
            lines.append(f"- line {call.get('line') or '?'} block={call.get('block') or 'TOP'} target={call['target']} using={_format_list(call.get('using', []))} giving={call.get('giving') or 'なし'}")
    else:
        lines.append("- 外部CALLなし")
    lines.extend(["", "### File Operations", ""])
    if program.get("file_operations"):
        for op in program["file_operations"]:
            lines.append(f"- line {op.get('line') or '?'} block={op.get('block') or 'TOP'} op={op['operation']} target={op.get('target') or 'unknown'}")
    else:
        lines.append("- 入出力操作なし")
    lines.extend(["", "### Notes", ""])
    warnings = program.get("warnings", [])
    lines.extend(f"- {warning}" for warning in warnings) if warnings else lines.append("- 追加警告なし")
    lines.append("")
    return lines


def _render_test_program(program: dict[str, Any], index: int) -> list[str]:
    lines = [
        f"## 2.{index} テスト対象機能",
        "",
        f"- プログラムID: {program.get('program_id') or 'UNKNOWN'}",
        f"- ソース形式: {program.get('source_format') or 'unknown'}",
        f"- USING: {_format_list(program.get('using_parameters', []))}",
        f"- RETURNING: {program.get('returning') or 'なし'}",
        "",
        f"## 3.{index} 判定条件観点",
        "",
    ]
    mutations = program.get("mutations", [])
    if mutations:
        lines.insert(6, f"- 更新対象項目: {_format_list(_collect_mutation_targets(mutations))}")
    conditions = program.get("conditions", [])
    if conditions:
        for condition in conditions:
            lines.append(
                f"- line {condition.get('line') or '?'} block={condition.get('block') or 'TOP'} [{condition['kind']}] 真偽、代表値、境界値、分岐通過順を確認する"
            )
            lines.append(f"  条件式: `{condition['expression']}`")
            for case_line in _suggest_condition_cases(condition["expression"]):
                lines.append(f"  観点: {case_line}")
    else:
        lines.append("- 判定条件なし")
    handlers = program.get("event_handlers", [])
    if handlers:
        for handler in handlers:
            lines.append(
                f"- line {handler.get('line') or '?'} block={handler.get('block') or 'TOP'} [{handler['kind']}] 正常系、異常系、終端系の遷移を確認する"
            )
            if handler.get("expression"):
                lines.append(f"  ハンドラ: `{handler['expression']}`")
                for case_line in _suggest_handler_cases(handler["kind"], handler["expression"]):
                    lines.append(f"  観点: {case_line}")
    lines.extend(["", f"## 4.{index} 繰返し観点", ""])
    loops = program.get("loops", [])
    if loops:
        for loop in loops:
            lines.append(
                f"- line {loop.get('line') or '?'} block={loop.get('block') or 'TOP'} target={loop.get('target') or 'inline'} 0回、1回、複数回、終了条件成立を確認する"
            )
            if loop.get("option"):
                lines.append(f"  条件: `{loop['option']}`")
                for case_line in _suggest_loop_cases(loop["option"]):
                    lines.append(f"  観点: {case_line}")
    else:
        lines.append("- 繰返しなし")
    lines.extend(["", f"## 5.{index} 入出力観点", ""])
    files = {file_def["name"]: file_def for file_def in program.get("files", [])}
    file_ops = program.get("file_operations", [])
    if file_ops:
        for op in file_ops:
            target = op.get("target") or "unknown"
            lines.append(
                f"- line {op.get('line') or '?'} op={op['operation']} target={target} 正常系、異常系、終端条件、資源解放を確認する"
            )
            if target in files:
                file_def = files[target]
                clauses = ", ".join(file_def.get("clauses", [])) or "なし"
                lines.append(f"  FD: {file_def.get('file_type') or '?'} clauses={clauses}")
    else:
        lines.append("- 入出力操作なし")
    lines.extend(["", f"## 6.{index} 外部CALL観点", ""])
    calls = program.get("calls", [])
    if calls:
        for call in calls:
            lines.append(
                f"- line {call.get('line') or '?'} target={call['target']} 正常応答、異常応答、引数妥当性を確認する"
            )
            lines.append(f"  using={_format_list(call.get('using', []))} giving={call.get('giving') or 'なし'}")
    else:
        lines.append("- 外部CALLなし")
    lines.extend(["", f"## 7.{index} データ境界値観点", ""])
    data_items = [
        ("WORKING-STORAGE", program.get("working_storage", [])),
        ("LINKAGE", program.get("linkage", [])),
        ("LOCAL-STORAGE", program.get("local_storage", [])),
    ]
    has_data = False
    for section_name, items in data_items:
        for item in items:
            has_data = True
            attrs = []
            if item.get("picture"):
                attrs.append(item["picture"])
            if item.get("usage"):
                attrs.append(item["usage"])
            if item.get("value"):
                attrs.append(item["value"])
            attr_text = ", ".join(attrs) if attrs else "属性なし"
            lines.append(
                f"- {section_name} line {item.get('line') or '?'} {item.get('name') or 'FILLER'} 型・桁数・初期値・空値・最大最小を確認する"
            )
            lines.append(f"  {attr_text}")
            pic_note = _format_picture_info(_analyze_picture(item.get("picture"), item.get("usage")))
            if pic_note:
                lines.append(f"  観点: {pic_note}")
    if not has_data:
        lines.append("- データ項目なし")
    if mutations:
        lines.append("- 更新文観点")
        for mutation in mutations:
            lines.append(
                f"  line {mutation.get('line') or '?'} [{mutation['kind']}] target={_format_list(mutation.get('targets', []))} 更新前後、代表値、境界値、計算結果を確認する"
            )
            if mutation.get("sources"):
                lines.append(f"  source={_format_list(mutation.get('sources', []))}")
    lines.extend(["", f"## 8.{index} 制約事項", ""])
    warnings = program.get("warnings", [])
    if warnings:
        lines.extend(f"- {warning}" for warning in warnings)
    else:
        lines.append("- 追加制約なし")
    lines.append("")
    return lines


def _render_data_items(items: list[dict[str, Any]]) -> list[str]:
    if not items:
        return ["- 定義なし"]
    lines = []
    for item in items:
        attrs = []
        for label, key in (("PIC", "picture"), ("USAGE", "usage"), ("OCCURS", "occurs"), ("REDEFINES", "redefines"), ("VALUE", "value")):
            value = item.get(key)
            if value:
                attrs.append(f"{label}={value}")
        attr_text = ", ".join(attrs) if attrs else "属性なし"
        lines.append(f"- L{item.get('level') or '??'} {item.get('name') or 'FILLER'} line {item.get('line') or '?'} {attr_text}")
    return lines


def _render_blocks(label: str, blocks: Iterable[dict[str, Any]]) -> list[str]:
    blocks = list(blocks)
    if not blocks:
        return [f"- {label}なし"]
    return [f"- {label}: {block['name']} line {block.get('line') or '?'}" for block in blocks]


def _extract_clause_text(node: Node, clause_type: str, source: bytes) -> str | None:
    clause = _find_first(node, clause_type)
    return _compact_text(_node_text(clause, source)) if clause is not None else None


def _extract_first_word(node: Node, source: bytes) -> str | None:
    for child in node.named_children:
        if child.type == "WORD":
            return _compact_text(_node_text(child, source))
    return None


def _extract_last_word(node: Node, source: bytes) -> str | None:
    last = None
    for child in node.named_children:
        if child.type == "WORD":
            last = _compact_text(_node_text(child, source))
    return last


def _extract_first_text(node: Node, types: set[str], source: bytes) -> str | None:
    for child in node.named_children:
        if child.type in types:
            return _compact_text(_node_text(child, source))
    return None


def _extract_field_or_text(node: Node, field_name: str, source: bytes) -> str:
    field = node.child_by_field_name(field_name)
    if field is not None:
        return _compact_text(_node_text(field, source))
    return _compact_text(_node_text(node, source))


def _find_first(node: Node, node_type: str) -> Node | None:
    if node.type == node_type:
        return node
    for child in node.named_children:
        result = _find_first(child, node_type)
        if result is not None:
            return result
    return None


def _find_all(node: Node, node_type: str) -> list[Node]:
    found: list[Node] = []
    if node.type == node_type:
        found.append(node)
    for child in node.named_children:
        found.extend(_find_all(child, node_type))
    return found


def _walk_named(node: Node):
    yield node
    for child in node.named_children:
        yield from _walk_named(child)


def _node_text(node: Node | None, source: bytes) -> str:
    if node is None:
        return ""
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _compact_text(text: str) -> str:
    return " ".join(text.split())


def _normalize_block_name(text: str) -> str:
    normalized = text.strip()
    if normalized.endswith("."):
        normalized = normalized[:-1]
    if normalized.upper().endswith(" SECTION"):
        normalized = normalized[:-8]
    return normalized.strip()


def _line(node: Node | None) -> int | None:
    return None if node is None else node.start_point[0] + 1


def _detect_source_format(source: bytes) -> str:
    lines = source.decode("utf-8", errors="replace").splitlines()
    fixed_like = 0
    checked = 0
    for line in lines[:30]:
        if not line.strip():
            continue
        checked += 1
        if len(line) >= 7 and line[:6].strip().isdigit():
            fixed_like += 1
        elif len(line) >= 7 and line[6:7] in {" ", "*", "/"}:
            fixed_like += 1
    if checked and fixed_like >= max(2, checked // 2):
        return "fixed"
    return "free"


def _format_list(values: list[str]) -> str:
    return ", ".join(values) if values else "なし"


def _analyze_picture(picture: str | None, usage: str | None) -> dict[str, Any]:
    if not picture:
        return {}
    raw = picture.upper().replace("PICTURE", "").replace("PIC", "").strip()
    result: dict[str, Any] = {"raw": raw}
    if "X" in raw:
        result["category"] = "alphanumeric"
        result["length"] = _count_picture_units(raw, "X")
    elif "A" in raw:
        result["category"] = "alphabetic"
        result["length"] = _count_picture_units(raw, "A")
    elif "9" in raw or "V" in raw or "S" in raw:
        result["category"] = "numeric"
        result["signed"] = "S" in raw
        integer_part, dot, decimal_part = raw.partition("V")
        result["integer_digits"] = _count_picture_units(integer_part, "9")
        result["decimal_digits"] = _count_picture_units(decimal_part, "9") if dot else 0
    if usage:
        result["usage"] = usage
    return result


def _count_picture_units(raw: str, token: str) -> int:
    total = 0
    index = 0
    while index < len(raw):
        if raw[index] != token:
            index += 1
            continue
        if index + 1 < len(raw) and raw[index + 1] == "(":
            end = raw.find(")", index + 2)
            if end != -1:
                count_text = raw[index + 2:end]
                if count_text.isdigit():
                    total += int(count_text)
                    index = end + 1
                    continue
        total += 1
        index += 1
    return total


def _format_picture_info(info: dict[str, Any]) -> str:
    if not info:
        return ""
    if info.get("category") == "alphanumeric":
        return f"英数字 {info.get('length', '?')} 桁、空値、最大長、最小長を確認"
    if info.get("category") == "alphabetic":
        return f"英字 {info.get('length', '?')} 桁、空値、最大長、最小長を確認"
    if info.get("category") == "numeric":
        signed = "符号あり" if info.get("signed") else "符号なし"
        integer_digits = info.get("integer_digits", 0)
        decimal_digits = info.get("decimal_digits", 0)
        if decimal_digits:
            return f"{signed} 数値 整数{integer_digits}桁 小数{decimal_digits}桁、0、最小、最大、桁あふれを確認"
        return f"{signed} 数値 {integer_digits}桁、0、最小、最大、桁あふれを確認"
    return ""


def _extract_identifiers(node: Node, source: bytes) -> list[str]:
    identifiers: list[str] = []
    for child in _walk_named(node):
        if child.type in {"qualified_word", "WORD"}:
            text = _compact_text(_node_text(child, source))
            if text and text not in identifiers:
                identifiers.append(text)
    return identifiers


def _collect_mutation_targets(mutations: list[dict[str, Any]]) -> list[str]:
    targets: list[str] = []
    for mutation in mutations:
        for target in mutation.get("targets", []):
            if target not in targets:
                targets.append(target)
    return targets


def _dedupe(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def _build_program_test_cases(program: dict[str, Any]) -> dict[str, Any]:
    cases: list[dict[str, Any]] = []
    seq = 1

    for condition in program.get("conditions", []):
        for suggestion in _suggest_condition_cases(condition["expression"]) or ["条件成立時と不成立時を確認"]:
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "condition",
                    condition.get("block"),
                    condition.get("line"),
                    condition["kind"],
                    condition["expression"],
                    suggestion,
                )
            )
            seq += 1

    for handler in program.get("event_handlers", []):
        for suggestion in _suggest_handler_cases(handler["kind"], handler.get("expression") or "") or ["対象ハンドラへの遷移条件を確認"]:
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "event_handler",
                    handler.get("block"),
                    handler.get("line"),
                    handler["kind"],
                    handler.get("expression"),
                    suggestion,
                )
            )
            seq += 1

    for loop in program.get("loops", []):
        for suggestion in _suggest_loop_cases(loop.get("option") or "") or ["0回、1回、複数回の実行を確認"]:
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "loop",
                    loop.get("block"),
                    loop.get("line"),
                    loop["kind"],
                    loop.get("option") or loop.get("target"),
                    suggestion,
                )
            )
            seq += 1

    for op in program.get("file_operations", []):
        suggestions = ["正常系を確認", "異常系を確認"]
        if op["operation"] in {"READ", "RETURN"}:
            suggestions.append("終端条件を確認")
        if op["operation"] in {"OPEN", "CLOSE"}:
            suggestions.append("資源確保と解放を確認")
        for suggestion in _dedupe(suggestions):
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "file_operation",
                    op.get("block"),
                    op.get("line"),
                    op["operation"],
                    op.get("target"),
                    suggestion,
                )
            )
            seq += 1

    for call in program.get("calls", []):
        for suggestion in ["正常応答を確認", "異常応答を確認", "引数妥当性を確認"]:
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "call",
                    call.get("block"),
                    call.get("line"),
                    "CALL",
                    call["target"],
                    suggestion,
                    {"using": call.get("using", []), "giving": call.get("giving")},
                )
            )
            seq += 1

    for item in program.get("working_storage", []) + program.get("linkage", []) + program.get("local_storage", []):
        suggestions = []
        pic_note = _format_picture_info(_analyze_picture(item.get("picture"), item.get("usage")))
        if pic_note:
            suggestions.append(pic_note)
        if item.get("value") is not None:
            suggestions.append("初期値を確認")
        if not suggestions:
            suggestions.append("空値と代表値を確認")
        for suggestion in suggestions:
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "data_item",
                    item.get("section"),
                    item.get("line"),
                    item.get("name") or "FILLER",
                    item.get("picture"),
                    suggestion,
                )
            )
            seq += 1

    for mutation in program.get("mutations", []):
        suggestions = ["更新前後を確認", "代表値を確認", "境界値を確認"]
        if mutation["kind"] in {"ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "COMPUTE"}:
            suggestions.append("計算結果を確認")
        for suggestion in _dedupe(suggestions):
            cases.append(
                _case_dict(
                    program,
                    seq,
                    "mutation",
                    mutation.get("block"),
                    mutation.get("line"),
                    mutation["kind"],
                    _format_list(mutation.get("targets", [])),
                    suggestion,
                    {"sources": mutation.get("sources", [])},
                )
            )
            seq += 1

    return {
        "program_id": program.get("program_id"),
        "source_format": program.get("source_format"),
        "cases": cases,
        "warnings": program.get("warnings", []),
    }


def _case_dict(
    program: dict[str, Any],
    seq: int,
    category: str,
    block: str | None,
    line: int | None,
    kind: str,
    target: str | None,
    expectation: str,
    inputs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "id": f"{program.get('program_id') or 'UNKNOWN'}-{seq:03d}",
        "category": category,
        "block": block,
        "line": line,
        "kind": kind,
        "target": target,
        "expectation": expectation,
        "inputs": inputs or {},
    }


def _suggest_condition_cases(expression: str) -> list[str]:
    expr = expression.strip()
    upper = expr.upper()
    suggestions: list[str] = []

    logical_cases = _suggest_logical_cases(expr)
    suggestions.extend(logical_cases)

    if " SPACES" in upper:
        suggestions.append("対象項目に空白を設定した場合と、空白以外を設定した場合を確認")

    if " ZERO" in upper or re.search(r"(?<![A-Z0-9])0(?![A-Z0-9])", upper):
        suggestions.append("0、一つ上、一つ下の値を確認")

    string_literals = re.findall(r'"([^"]*)"' , expr) + re.findall(r"'([^']*)'", expr)
    for literal in string_literals:
        if literal == "":
            suggestions.append("空文字と非空文字を確認")
        else:
            suggestions.append(f"'{literal}' に一致する場合と一致しない場合を確認")

    numeric_literals = re.findall(r"(?<![A-Z0-9])([0-9]+)(?![A-Z0-9])", upper)
    for literal in numeric_literals:
        value = int(literal)
        suggestions.append(f"{value}、{value - 1}、{value + 1} を確認")

    if " NOT " in upper:
        suggestions.append("否定条件の成立・不成立を確認")

    if ">" in expr or " GREATER " in upper:
        suggestions.append("しきい値の直前、等値、直後を確認")
    if "<" in expr or " LESS " in upper:
        suggestions.append("しきい値の直前、等値、直後を確認")

    return _dedupe(suggestions)


def _suggest_logical_cases(expression: str) -> list[str]:
    normalized = re.sub(r"^\s*(IF|ELSE IF|EVALUATE)\s+", "", expression.strip(), flags=re.IGNORECASE)
    upper = normalized.upper()
    suggestions: list[str] = []

    if " AND " in upper:
        parts = [part.strip() for part in re.split(r"\bAND\b", normalized, flags=re.IGNORECASE) if part.strip()]
        if len(parts) >= 2:
            suggestions.append("AND 条件のため、各条件が単独で成立する場合と、すべて成立する場合を確認")
            suggestions.extend(
                f"部分条件 {index} の成立・不成立が全体結果へ与える影響を確認: `{part}`"
                for index, part in enumerate(parts, start=1)
            )

    if " OR " in upper:
        parts = [part.strip() for part in re.split(r"\bOR\b", normalized, flags=re.IGNORECASE) if part.strip()]
        if len(parts) >= 2:
            suggestions.append("OR 条件のため、各条件が単独で成立する場合と、すべて不成立の場合を確認")
            suggestions.extend(
                f"部分条件 {index} の単独成立で全体が成立することを確認: `{part}`"
                for index, part in enumerate(parts, start=1)
            )

    if re.search(r"\bNOT\b", upper):
        suggestions.append("否定対象の条件が成立する場合と、不成立になる場合の両方を確認")

    return suggestions


def _suggest_handler_cases(kind: str, expression: str) -> list[str]:
    upper_kind = kind.upper()
    upper_expr = expression.upper()
    suggestions: list[str] = []

    if upper_kind == "WHEN":
        string_literals = re.findall(r'"([^"]*)"' , expression) + re.findall(r"'([^']*)'", expression)
        numeric_literals = re.findall(r"(?<![A-Z0-9])([0-9]+)(?![A-Z0-9])", upper_expr)
        for literal in string_literals:
            suggestions.append(f"WHEN 条件に一致する値 '{literal}' と、不一致で WHEN OTHER に流れる値を確認")
        for literal in numeric_literals:
            suggestions.append(f"WHEN 条件に一致する値 {literal} と、不一致で WHEN OTHER に流れる値を確認")
    elif upper_kind == "WHEN OTHER":
        suggestions.append("どの WHEN 条件にも一致しない代表値を設定して分岐することを確認")
    elif upper_kind == "AT END":
        suggestions.append("入力終端到達時にこの分岐へ遷移することを確認")
    elif upper_kind == "NOT AT END":
        suggestions.append("入力継続時にこの分岐へ遷移し、終端時には遷移しないことを確認")
    elif upper_kind == "INVALID KEY":
        suggestions.append("無効キー時にこの分岐へ遷移することを確認")
    elif upper_kind == "NOT INVALID KEY":
        suggestions.append("有効キー時にこの分岐へ遷移し、無効キー時には遷移しないことを確認")
    elif "EXCEPTION" in upper_kind:
        suggestions.append("例外発生時と非発生時の両方を確認")

    return _dedupe(suggestions)


def _suggest_loop_cases(option: str) -> list[str]:
    upper = option.upper()
    suggestions = ["0回、1回、複数回の実行を確認"]

    if upper.startswith("UNTIL "):
        condition = option[6:].strip()
        suggestions.append("条件成立時にループ終了することを確認")
        suggestions.extend(_suggest_until_condition_cases(condition))
    elif " UNTIL " in upper:
        before, _, after = option.partition("UNTIL ")
        suggestions.append("ループ終了条件が評価される位置を確認")
        suggestions.extend(_suggest_until_condition_cases(after.strip()))
    elif " VARYING " in upper:
        suggestions.append("開始値、増分、終了条件の組合せを確認")

    return _dedupe(suggestions)


def _suggest_until_condition_cases(condition: str) -> list[str]:
    suggestions: list[str] = []
    expr = condition.strip()
    upper = expr.upper()

    string_literals = re.findall(r'"([^"]*)"' , expr) + re.findall(r"'([^']*)'", expr)
    for literal in string_literals:
        suggestions.append(f"継続値として '{_choose_alternate_string(literal)}'、終了値として '{literal}' を確認")

    numeric_literals = re.findall(r"(?<![A-Z0-9])([0-9]+)(?![A-Z0-9])", upper)
    for literal in numeric_literals:
        value = int(literal)
        if ">" in expr or " GREATER " in upper:
            suggestions.append(f"継続値 {value} と終了値 {value + 1} を確認")
        elif "<" in expr or " LESS " in upper:
            suggestions.append(f"継続値 {value} と終了値 {value - 1} を確認")
        else:
            suggestions.append(f"継続値 {value - 1} と終了値 {value} を確認")

    if "SPACES" in upper:
        suggestions.append("継続値として空白以外、終了値として空白を確認")

    return _dedupe(suggestions)


def _choose_alternate_string(value: str) -> str:
    if value == "":
        return "X"
    if value.strip() == "":
        return "A"
    if value == "1":
        return "0"
    if value.upper() == "VIP":
        return "NORMAL"
    return f"{value}_OTHER"
