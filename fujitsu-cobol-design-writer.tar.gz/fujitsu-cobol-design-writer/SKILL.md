---
name: fujitsu-cobol-design-writer
description: Generates Japanese detailed design documents and unit-test viewpoint drafts from Fujitsu mainframe COBOL by running the bundled Python scripts and grounding the output in parser JSON. Use when the user asks to analyze `.cbl` files, create a 詳細設計書, summarize Fujitsu COBOL structure, or derive unit-test viewpoints from COBOL, with prompts such as "COBOLから詳細設計書を作って", "富士通COBOLを解析して設計書化して", "この.cblから単体テスト観点を出して", or "COBOLを日本語で設計書にして".
compatibility: Requires Python 3.10+ and importable `tree_sitter` / `tree_sitter_cobol`. `tree_sitter_cobol` is expected from https://github.com/yutaro-sakamoto/tree-sitter-cobol, not from this repository. Prefer an interpreter that already imports both modules successfully; in this repo, `test/.venv/bin/python` may already satisfy that requirement.
allowed-tools: Bash(test/.venv/bin/python scripts/*) Bash(.venv/bin/python scripts/*) Bash(uv run python scripts/*) Bash(python scripts/*) Read
metadata:
  author: masato
  repo: tree-sitter-cobol
  target_platform: fujitsu-mainframe-cobol
---

# Fujitsu COBOL Design Writer

Turn Fujitsu mainframe COBOL into a Japanese detailed design document or a
unit-test viewpoint draft. The bundled Python scripts run directly from this
skill directory. Do not invent business rules that are not supported by the
analysis.

## When to use

- The user gives you one or more `.cbl` files and asks for a design document
- The user asks to explain or document Fujitsu COBOL in Japanese
- The user asks for unit-test viewpoints from COBOL
- The user asks for a 単体テスト観点書 or test-spec draft

## Quick start

1. Pick a Python interpreter that can import both `tree_sitter` and `tree_sitter_cobol`.
2. Run the bundled analyzer on the COBOL file.
3. Read the emitted JSON carefully and treat it as the source of truth.
4. Generate the local draft or second-pass LLM prompt that matches the user request.
5. Write the final Japanese document from the JSON and surface parser limitations explicitly.

## Preflight

Choose the first working interpreter from this order:

- `test/.venv/bin/python`
- `.venv/bin/python`
- `uv run python`
- `python`

If none of them can import both modules, stop and report the missing dependency instead of fabricating output.

Recommended import check:

```bash
<python> -c "import tree_sitter, tree_sitter_cobol"
```

If setup is needed, install `tree-sitter` into the chosen environment and make `tree_sitter_cobol` importable from the grammar repository:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install tree-sitter
```

`tree_sitter_cobol` is not packaged in this repository. Use the grammar source from `yutaro-sakamoto/tree-sitter-cobol`, or another environment where that module is already importable. Do not assume `pip install -e .` in this repository will make `tree_sitter_cobol` available.

## Standard runners

Use the same working interpreter for all script calls below. Replace `<python>` with the interpreter selected in Preflight.

Use this script when you want the standard bundle and `uv run python` or plain
`python` is already known-good in the current environment:

`scripts/generate_design_pack.sh <source.cbl> [output-dir]`

If your working interpreter is `test/.venv/bin/python` or `.venv/bin/python`,
run the individual scripts instead of `generate_design_pack.sh`, because the
bundle script does not inherit the Preflight interpreter selection.

## Commands

Analyze to JSON:

```bash
<python> scripts/analyze_cobol.py <source.cbl>
```

Generate a local draft:

```bash
<python> scripts/design_doc.py <source.cbl>
```

Generate the second-pass LLM prompt:

```bash
<python> scripts/llm_prompt.py <source.cbl>
```

Generate a local unit-test viewpoint draft:

```bash
<python> scripts/test_spec.py <source.cbl>
```

Generate the second-pass LLM prompt for the unit-test document:

```bash
<python> scripts/test_llm_prompt.py <source.cbl>
```

Generate machine-readable unit-test cases JSON:

```bash
<python> scripts/test_cases_json.py <source.cbl>
```

## Required output behavior

- Write in Japanese
- Use parser output as the source of truth
- Mark unsupported conclusions as `要確認`
- Mark inferences as `推定`
- Carry parser limitations and warnings into the final document
- Keep file paths and line numbers when they help review
- If parser execution fails, stop and report the exact failing prerequisite or command
- Do not clone, build, or fetch alternate grammars unless the user explicitly asks for environment setup work

## Output structure

For the detailed design document, use the template in
[assets/design-doc-template.md](assets/design-doc-template.md).

For detailed workflow rules, field mapping, and test-spec mode, see
[references/REFERENCE.md](references/REFERENCE.md).

For the unit-test viewpoint document, use the template in
[assets/test-spec-template.md](assets/test-spec-template.md).

## Failure handling

- If parsing fails or no `program_definition` exists, stop and report that the
  grammar could not parse the source
- If `warnings` contains COPY or SQL notes, surface them explicitly
- If multiple programs exist, split the output by program
- If the JSON omits constructs that are visibly present in the source, do not
  backfill them as facts; cite the source line and mark the gap as `要確認`
