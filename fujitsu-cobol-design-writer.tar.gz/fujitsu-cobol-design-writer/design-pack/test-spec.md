# 単体テスト観点書

## 1. 対象概要

- 対象プラットフォーム: Fujitsu mainframe COBOL
- 解析元: `test/sample.cbl`
- プログラム数: 1

## 2.1 テスト対象機能

- プログラムID: SAF-MAIN
- ソース形式: fixed
- USING: SAFCTX
- RETURNING: なし
- 更新対象項目: COBW3, COBW3-CONTEXT, PATHNAME, COBW3-COOKIE-NAME, HTMLFILENAME, COBW3-COOKIE-VALUE, アクセス回数, COBW3-COOKIE-VALUE-LENGTH, COBW3-CNV-NAME-N, COBW3-CNV-VALUE, COBW3-REMOTE-HOST, CONVERT-VALUE, CONVERT-LENGTH, COBW3-HEADER-NAME, COBW3-HTML-FILENAME, COPYSTARTPOS, LEFTLENGTH, COBW3-PHYSICALPATH, PATHSIZE, WORK-CNTR1, WORK-CNTR2, SANITIZED-DATA, SANITIZED-LENGTH

## 3.1 判定条件観点

- line 46 block=SAFSAMPLE1-START [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN`
  観点: AND 条件のため、各条件が単独で成立する場合と、すべて成立する場合を確認
  観点: 部分条件 1 の成立・不成立が全体結果へ与える影響を確認: `COBW3-STATUS NOT = ZERO`
  観点: 部分条件 2 の成立・不成立が全体結果へ与える影響を確認: `COBW3-STATUS NOT = 8820 THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 8820、8819、8821 を確認
  観点: 否定条件の成立・不成立を確認
- line 84 block=SAFSAMPLE1-END [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 否定条件の成立・不成立を確認
- line 101 block=SAFSAMPLE1-END [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 否定条件の成立・不成立を確認
- line 127 block=継続画面出力処理終了 [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 否定条件の成立・不成立を確認
- line 137 block=アクセスカウンタ登録処理終了 [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS NOT = ZERO THEN`
  観点: 否定対象の条件が成立する場合と、不成立になる場合の両方を確認
  観点: 0、一つ上、一つ下の値を確認
  観点: 否定条件の成立・不成立を確認
- line 148 block=変換データ登録終了 [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF PATHNAME = SPACE THEN`
- line 169 block=画面出力処理終了 [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `IF COBW3-STATUS = ZERO THEN`
  観点: 0、一つ上、一つ下の値を確認
- line 184 block=物理パス名取得終了 [EVALUATE] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `EVALUATE CONVERT-VALUE(WORK-CNTR1:1)`
  観点: 1、0、2 を確認
- line 49 block=SAFSAMPLE1-START [IF] 真偽、代表値、境界値、分岐通過順を確認する
  条件式: `ELSE IF COBW3-SEARCH-FLAG-NON THEN`
- line 185 block=物理パス名取得終了 [WHEN] 正常系、異常系、終端系の遷移を確認する
  ハンドラ: `WHEN "<"`
  観点: WHEN 条件に一致する値 '<' と、不一致で WHEN OTHER に流れる値を確認
- line 188 block=物理パス名取得終了 [WHEN] 正常系、異常系、終端系の遷移を確認する
  ハンドラ: `WHEN ">"`
  観点: WHEN 条件に一致する値 '>' と、不一致で WHEN OTHER に流れる値を確認
- line 191 block=物理パス名取得終了 [WHEN] 正常系、異常系、終端系の遷移を確認する
  ハンドラ: `WHEN "&"`
  観点: WHEN 条件に一致する値 '&' と、不一致で WHEN OTHER に流れる値を確認
- line 194 block=物理パス名取得終了 [WHEN OTHER] 正常系、異常系、終端系の遷移を確認する
  ハンドラ: `WHEN OTHER`
  観点: どの WHEN 条件にも一致しない代表値を設定して分岐することを確認

## 4.1 繰返し観点

- line 48 block=SAFSAMPLE1-START target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 51 block=SAFSAMPLE1-START target=アクセスカウンタ登録処理 0回、1回、複数回、終了条件成立を確認する
- line 53 block=SAFSAMPLE1-START target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 55 block=SAFSAMPLE1-START target=継続画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 76 block=SAFSAMPLE1-END target=アクセスカウンタ登録処理 0回、1回、複数回、終了条件成立を確認する
- line 79 block=SAFSAMPLE1-END target=変換データ登録 0回、1回、複数回、終了条件成立を確認する
- line 86 block=SAFSAMPLE1-END target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 94 block=SAFSAMPLE1-END target=サニタイズ処理 0回、1回、複数回、終了条件成立を確認する
- line 96 block=SAFSAMPLE1-END target=変換データ登録 0回、1回、複数回、終了条件成立を確認する
- line 103 block=SAFSAMPLE1-END target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 111 block=SAFSAMPLE1-END target=サニタイズ処理 0回、1回、複数回、終了条件成立を確認する
- line 113 block=SAFSAMPLE1-END target=変換データ登録 0回、1回、複数回、終了条件成立を確認する
- line 117 block=SAFSAMPLE1-END target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 129 block=継続画面出力処理終了 target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 139 block=アクセスカウンタ登録処理終了 target=画面出力処理 0回、1回、複数回、終了条件成立を確認する
- line 149 block=変換データ登録終了 target=物理パス名取得 0回、1回、複数回、終了条件成立を確認する
- line 181 block=物理パス名取得終了 target=inline 0回、1回、複数回、終了条件成立を確認する
  条件: `WITH TEST BEFORE 001820 VARYING WORK-CNTR1 FROM 1 BY 1 001830 UNTIL WORK-CNTR1 > CONVERT-LENGTH`
  観点: 0回、1回、複数回の実行を確認
  観点: ループ終了条件が評価される位置を確認

## 5.1 入出力観点

- 入出力操作なし

## 6.1 外部CALL観点

- line 40 target="COBW3_INIT" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 45 target="COBW3_GET_COOKIE_XX" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 61 target="COBW3_FREE" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 83 target="COBW3_GET_REQUEST_INFO" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 100 target="COBW3_RECEIVE_HEADER" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 126 target="COBW3_SET_COOKIE_XX" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 136 target="COBW3_SET_CNV_NX" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 160 target="COBW3_PUT_HTML" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし
- line 168 target="COBW3_GET_REQUEST_INFO" 正常応答、異常応答、引数妥当性を確認する
  using=COBW3 giving=なし

## 7.1 データ境界値観点

- WORKING-STORAGE line 14 HTMLFILENAME 型・桁数・初期値・空値・最大最小を確認する
  PIC X(64)
  観点: 英数字 64 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 15 PATHNAME 型・桁数・初期値・空値・最大最小を確認する
  PIC X(256)
  観点: 英数字 256 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 16 PATHSIZE 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 17 COPYSTARTPOS 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 18 LEFTLENGTH 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 19 アクセス回数 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(05)
  観点: 符号なし 数値 5桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 20 WORK-CNTR1 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(4), COMP-5
  観点: 符号なし 数値 4桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 21 WORK-CNTR2 型・桁数・初期値・空値・最大最小を確認する
  PIC 9(4), COMP-5
  観点: 符号なし 数値 4桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 22 CONVERT-VALUE 型・桁数・初期値・空値・最大最小を確認する
  PIC X(1024)
  観点: 英数字 1024 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 23 CONVERT-LENGTH 型・桁数・初期値・空値・最大最小を確認する
  PIC S9(4), COMP-5
  観点: 符号あり 数値 4桁、0、最小、最大、桁あふれを確認
- WORKING-STORAGE line 24 SANITIZED-DATA 型・桁数・初期値・空値・最大最小を確認する
  PIC X(1024)
  観点: 英数字 1024 桁、空値、最大長、最小長を確認
- WORKING-STORAGE line 25 SANITIZED-LENGTH 型・桁数・初期値・空値・最大最小を確認する
  PIC S9(4), COMP-5
  観点: 符号あり 数値 4桁、0、最小、最大、桁あふれを確認
- LINKAGE line 28 SAFCTX 型・桁数・初期値・空値・最大最小を確認する
  POINTER
- 更新文観点
  line 35 [MOVE] target=COBW3 更新前後、代表値、境界値、計算結果を確認する
  line 36 [SET] target=COBW3-CONTEXT 更新前後、代表値、境界値、計算結果を確認する
  source=SAFCTX
  line 42 [MOVE] target=PATHNAME 更新前後、代表値、境界値、計算結果を確認する
  line 44 [MOVE] target=COBW3-COOKIE-NAME 更新前後、代表値、境界値、計算結果を確認する
  line 47 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 50 [MOVE] target=COBW3-COOKIE-VALUE 更新前後、代表値、境界値、計算結果を確認する
  line 52 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 70 [COMPUTE] target=アクセス回数 更新前後、代表値、境界値、計算結果を確認する
  source=NUMVAL, COBW3-COOKIE-VALUE
  line 71 [ADD] target=アクセス回数 更新前後、代表値、境界値、計算結果を確認する
  line 72 [MOVE] target=COBW3-COOKIE-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=アクセス回数
  line 73 [MOVE] target=COBW3-COOKIE-VALUE-LENGTH 更新前後、代表値、境界値、計算結果を確認する
  source=ZERO
  line 77 [MOVE] target=COBW3-CNV-NAME-N 更新前後、代表値、境界値、計算結果を確認する
  line 78 [MOVE] target=COBW3-CNV-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=アクセス回数
  line 82 [SET] target=COBW3-REMOTE-HOST 更新前後、代表値、境界値、計算結果を確認する
  line 85 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 89 [MOVE] target=COBW3-CNV-NAME-N 更新前後、代表値、境界値、計算結果を確認する
  line 92 [MOVE] target=CONVERT-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-REQUEST-INFO
  line 93 [MOVE] target=CONVERT-LENGTH 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-REQUEST-INFO-LENGTH
  line 95 [MOVE] target=COBW3-CNV-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=SANITIZED-DATA
  line 99 [MOVE] target=COBW3-HEADER-NAME 更新前後、代表値、境界値、計算結果を確認する
  line 102 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 106 [MOVE] target=COBW3-CNV-NAME-N 更新前後、代表値、境界値、計算結果を確認する
  line 109 [MOVE] target=CONVERT-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-HEADER-VALUE
  line 110 [MOVE] target=CONVERT-LENGTH 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-HEADER-VALUE-LENGTH
  line 112 [MOVE] target=COBW3-CNV-VALUE 更新前後、代表値、境界値、計算結果を確認する
  source=SANITIZED-DATA
  line 116 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 128 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 138 [MOVE] target=HTMLFILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 151 [MOVE] target=COBW3-HTML-FILENAME 更新前後、代表値、境界値、計算結果を確認する
  line 152 [MOVE] target=COBW3-HTML-FILENAME 更新前後、代表値、境界値、計算結果を確認する
  source=PATHNAME, PATHSIZE
  line 153 [COMPUTE] target=COPYSTARTPOS 更新前後、代表値、境界値、計算結果を確認する
  source=PATHSIZE
  line 154 [MOVE] target=COBW3-HTML-FILENAME, COPYSTARTPOS 更新前後、代表値、境界値、計算結果を確認する
  line 155 [COMPUTE] target=COPYSTARTPOS 更新前後、代表値、境界値、計算結果を確認する
  source=COPYSTARTPOS
  line 156 [COMPUTE] target=LEFTLENGTH 更新前後、代表値、境界値、計算結果を確認する
  source=COPYSTARTPOS
  line 157 [MOVE] target=COBW3-HTML-FILENAME, COPYSTARTPOS 更新前後、代表値、境界値、計算結果を確認する
  source=HTMLFILENAME
  line 166 [MOVE] target=PATHNAME 更新前後、代表値、境界値、計算結果を確認する
  line 167 [SET] target=COBW3-PHYSICALPATH 更新前後、代表値、境界値、計算結果を確認する
  line 170 [MOVE] target=PATHNAME 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-REQUEST-INFO
  line 171 [MOVE] target=PATHSIZE 更新前後、代表値、境界値、計算結果を確認する
  source=COBW3-REQUEST-INFO-LENGTH
  line 178 [MOVE] target=WORK-CNTR1 更新前後、代表値、境界値、計算結果を確認する
  line 179 [MOVE] target=WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 180 [MOVE] target=SANITIZED-DATA 更新前後、代表値、境界値、計算結果を確認する
  line 186 [MOVE] target=SANITIZED-DATA, WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 187 [ADD] target=WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 189 [MOVE] target=SANITIZED-DATA, WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 190 [ADD] target=WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 192 [MOVE] target=SANITIZED-DATA, WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 193 [ADD] target=WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 195 [MOVE] target=SANITIZED-DATA 更新前後、代表値、境界値、計算結果を確認する
  source=CONVERT-VALUE
  line 197 [ADD] target=WORK-CNTR2 更新前後、代表値、境界値、計算結果を確認する
  line 200 [MOVE] target=SANITIZED-LENGTH 更新前後、代表値、境界値、計算結果を確認する
  source=WORK-CNTR2

## 8.1 制約事項

- tree-sitter-cobol の解析欠落をソース行ベースで補完しました。
- COPY句を検出しました。コピー元展開後の解析は未実装です。
