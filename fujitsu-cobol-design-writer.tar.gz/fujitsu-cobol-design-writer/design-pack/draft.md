# Fujitsu COBOL Detailed Design Draft

- Target platform: Fujitsu mainframe COBOL
- Parser: tree-sitter-cobol
- Source: `test/sample.cbl`

## Program 1: SAF-MAIN

### Summary

- Source format: fixed
- Procedure USING: SAFCTX
- Procedure RETURNING: なし

### Files

- 定義なし

### Data Items

#### Working-Storage

- L01 HTMLFILENAME line 14 PIC=PIC X(64)
- L01 PATHNAME line 15 PIC=PIC X(256)
- L01 PATHSIZE line 16 PIC=PIC 9(05)
- L01 COPYSTARTPOS line 17 PIC=PIC 9(05)
- L01 LEFTLENGTH line 18 PIC=PIC 9(05)
- L01 アクセス回数 line 19 PIC=PIC 9(05)
- L01 WORK-CNTR1 line 20 PIC=PIC 9(4), USAGE=COMP-5
- L01 WORK-CNTR2 line 21 PIC=PIC 9(4), USAGE=COMP-5
- L01 CONVERT-VALUE line 22 PIC=PIC X(1024)
- L01 CONVERT-LENGTH line 23 PIC=PIC S9(4), USAGE=COMP-5
- L01 SANITIZED-DATA line 24 PIC=PIC X(1024)
- L01 SANITIZED-LENGTH line 25 PIC=PIC S9(4), USAGE=COMP-5

#### Linkage

- L01 SAFCTX line 28 USAGE=POINTER

#### Local-Storage

- 定義なし

### Procedure Blocks

- Section: 継続画面出力処理 line 67
- Section: アクセスカウンタ登録処理 line 123
- Section: 変換データ登録 line 135
- Section: 画面出力処理 line 145
- Section: 物理パス名取得 line 165
- Section: サニタイズ処理 line 177
- Paragraph: SAFSAMPLE1-START line 32
- Paragraph: 終了位置 line 58
- Paragraph: SAFSAMPLE1-END line 63
- Paragraph: 継続画面出力処理終了 line 119
- Paragraph: アクセスカウンタ登録処理終了 line 132
- Paragraph: 変換データ登録終了 line 142
- Paragraph: 画面出力処理終了 line 162
- Paragraph: 物理パス名取得終了 line 174
- Paragraph: サニタイズ処理終了 line 201

### Decision Logic

- [IF] line 46 block=SAFSAMPLE1-START expr: `IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN`
- [IF] line 84 block=SAFSAMPLE1-END expr: `IF COBW3-STATUS NOT = ZERO THEN`
- [IF] line 101 block=SAFSAMPLE1-END expr: `IF COBW3-STATUS NOT = ZERO THEN`
- [IF] line 127 block=継続画面出力処理終了 expr: `IF COBW3-STATUS NOT = ZERO THEN`
- [IF] line 137 block=アクセスカウンタ登録処理終了 expr: `IF COBW3-STATUS NOT = ZERO THEN`
- [IF] line 148 block=変換データ登録終了 expr: `IF PATHNAME = SPACE THEN`
- [IF] line 169 block=画面出力処理終了 expr: `IF COBW3-STATUS = ZERO THEN`
- [EVALUATE] line 184 block=物理パス名取得終了 expr: `EVALUATE CONVERT-VALUE(WORK-CNTR1:1)`
- [IF] line 49 block=SAFSAMPLE1-START expr: `ELSE IF COBW3-SEARCH-FLAG-NON THEN`

### Loops

- line 48 block=SAFSAMPLE1-START target=画面出力処理 option=なし
- line 51 block=SAFSAMPLE1-START target=アクセスカウンタ登録処理 option=なし
- line 53 block=SAFSAMPLE1-START target=画面出力処理 option=なし
- line 55 block=SAFSAMPLE1-START target=継続画面出力処理 option=なし
- line 76 block=SAFSAMPLE1-END target=アクセスカウンタ登録処理 option=なし
- line 79 block=SAFSAMPLE1-END target=変換データ登録 option=なし
- line 86 block=SAFSAMPLE1-END target=画面出力処理 option=なし
- line 94 block=SAFSAMPLE1-END target=サニタイズ処理 option=なし
- line 96 block=SAFSAMPLE1-END target=変換データ登録 option=なし
- line 103 block=SAFSAMPLE1-END target=画面出力処理 option=なし
- line 111 block=SAFSAMPLE1-END target=サニタイズ処理 option=なし
- line 113 block=SAFSAMPLE1-END target=変換データ登録 option=なし
- line 117 block=SAFSAMPLE1-END target=画面出力処理 option=なし
- line 129 block=継続画面出力処理終了 target=画面出力処理 option=なし
- line 139 block=アクセスカウンタ登録処理終了 target=画面出力処理 option=なし
- line 149 block=変換データ登録終了 target=物理パス名取得 option=なし
- line 181 block=物理パス名取得終了 target=inline option=WITH TEST BEFORE 001820 VARYING WORK-CNTR1 FROM 1 BY 1 001830 UNTIL WORK-CNTR1 > CONVERT-LENGTH

### External Calls

- line 40 block=SAFSAMPLE1-START target="COBW3_INIT" using=COBW3 giving=なし
- line 45 block=SAFSAMPLE1-START target="COBW3_GET_COOKIE_XX" using=COBW3 giving=なし
- line 61 block=終了位置 target="COBW3_FREE" using=COBW3 giving=なし
- line 83 block=SAFSAMPLE1-END target="COBW3_GET_REQUEST_INFO" using=COBW3 giving=なし
- line 100 block=SAFSAMPLE1-END target="COBW3_RECEIVE_HEADER" using=COBW3 giving=なし
- line 126 block=継続画面出力処理終了 target="COBW3_SET_COOKIE_XX" using=COBW3 giving=なし
- line 136 block=アクセスカウンタ登録処理終了 target="COBW3_SET_CNV_NX" using=COBW3 giving=なし
- line 160 block=変換データ登録終了 target="COBW3_PUT_HTML" using=COBW3 giving=なし
- line 168 block=画面出力処理終了 target="COBW3_GET_REQUEST_INFO" using=COBW3 giving=なし

### File Operations

- 入出力操作なし

### Notes

- tree-sitter-cobol の解析欠落をソース行ベースで補完しました。
- COPY句を検出しました。コピー元展開後の解析は未実装です。
