# 単体テスト観点書

## 1. 対象概要

| 項目 | 値 |
|------|-----|
| プログラムID | SAF-MAIN |
| ソースパス | test/sample.cbl |
| ソース形式 | fixed |
| ターゲット | Fujitsu メインフレーム COBOL |
| パーサー | tree-sitter-cobol |
| USING パラメタ | SAFCTX (POINTER) |
| RETURNING | なし |

## 2. テスト対象機能

| No. | 機能名 | SECTION / Paragraph | 行 | 概要 |
|-----|--------|---------------------|----|------|
| F1 | 初期化処理 | SAFSAMPLE1-START | 32 | COBW3初期化、クッキー取得、エラー分岐 |
| F2 | 終了処理 | 終了位置 | 58 | COBW3リソース解放 |
| F3 | メイン終了処理 | SAFSAMPLE1-END | 63 | アクセスカウント更新、リクエスト情報取得・サニタイズ・登録、ヘッダ取得・サニタイズ・登録 |
| F4 | 継続画面出力 | 継続画面出力処理 | 67 | クッキー設定と画面出力 |
| F5 | アクセスカウンタ登録 | アクセスカウンタ登録処理 | 123 | 変換データ次エントリ登録 |
| F6 | 変換データ登録 | 変換データ登録 | 135 | 物理パス取得、ファイルパス構築、HTML出力 |
| F7 | 画面出力 | 画面出力処理 | 145 | 物理パス取得と設定 |
| F8 | サニタイズ | サニタイズ処理 | 177 | HTML特殊文字（\<, >, &）のエンティティ変換 |

## 3. 判定条件観点

### C1: COBW3-STATUS 複合条件（行 46, SAFSAMPLE1-START）

```
IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN
```

| No. | 条件ケース | COBW3-STATUS | 期待分岐先 | 備考 |
|-----|-----------|-------------|-----------|------|
| C1-1 | 正常（ZERO） | 0 | ELSE IF へ | クッキー取得成功 |
| C1-2 | クッキーなし（推定） | 8820 | ELSE IF へ | クッキー未存在（推定） |
| C1-3 | その他エラー | 1 | THEN 節（エラー処理） | クッキー取得エラー |
| C1-4 | その他エラー | 9999（代表値） | THEN 節（エラー処理） | 汎用エラー |
| C1-5 | 境界: ZERO直後 | 1 | THEN 節 | ZERO≠1 かつ 1≠8820 |
| C1-6 | 境界: 8820直前 | 8819 | THEN 節 | 8819≠0 かつ 8819≠8820 |

※ 8820 の意味は要確認。COBW3ライブラリの仕様書での確認が必要。

### C2: COBW3-STATUS ≠ ZERO（行 84, SAFSAMPLE1-END）

```
IF COBW3-STATUS NOT = ZERO THEN
```

| No. | 条件ケース | COBW3-STATUS | 期待分岐先 |
|-----|-----------|-------------|-----------|
| C2-1 | 正常 | 0 | ELSE 節（後続処理） |
| C2-2 | エラー | 1（代表値） | THEN 節（エラー画面出力） |

### C3: COBW3-STATUS ≠ ZERO（行 101, SAFSAMPLE1-END）

```
IF COBW3-STATUS NOT = ZERO THEN
```

C2と同一パターン。COBW3_RECEIVE_HEADER 後のチェック。

| No. | 条件ケース | COBW3-STATUS | 期待分岐先 |
|-----|-----------|-------------|-----------|
| C3-1 | 正常 | 0 | ELSE 節 |
| C3-2 | エラー | 1（代表値） | THEN 節（エラー画面出力） |

### C4: COBW3-STATUS ≠ ZERO（行 127, 継続画面出力処理終了）

```
IF COBW3-STATUS NOT = ZERO THEN
```

COBW3_SET_COOKIE_XX 後のチェック。C2/C3と同一パターン。

| No. | 条件ケース | COBW3-STATUS | 期待分岐先 |
|-----|-----------|-------------|-----------|
| C4-1 | 正常 | 0 | 後続処理 |
| C4-2 | エラー | 1（代表値） | エラー画面出力 |

### C5: COBW3-STATUS ≠ ZERO（行 137, アクセスカウンタ登録処理終了）

```
IF COBW3-STATUS NOT = ZERO THEN
```

COBW3_SET_CNV_NX 後のチェック。C2/C3/C4と同一パターン。

| No. | 条件ケース | COBW3-STATUS | 期待分岐先 |
|-----|-----------|-------------|-----------|
| C5-1 | 正常 | 0 | 後続処理 |
| C5-2 | エラー | 1（代表値） | エラー画面出力 |

### C6: PATHNAME = SPACE（行 148, 変換データ登録終了）

```
IF PATHNAME = SPACE THEN
```

| No. | 条件ケース | PATHNAME | 期待動作 |
|-----|-----------|----------|---------|
| C6-1 | 未設定（SPACE） | SPACE | PERFORM 物理パス名取得 実行 |
| C6-2 | 設定済み | 非SPACE | 物理パス名取得をスキップ |
| C6-3 | 境界: 1文字のみ | "A" 等 | スキップ |

### C7: COBW3-STATUS = ZERO（行 169, 画面出力処理終了）

```
IF COBW3-STATUS = ZERO THEN
```

C2-C5と逆条件（= ZERO が真の場合に処理継続）。

| No. | 条件ケース | COBW3-STATUS | 期待動作 |
|-----|-----------|-------------|---------|
| C7-1 | 正常 | 0 | PATHNAME にリクエスト情報を設定 |
| C7-2 | エラー | 1（代表値） | PATHNAME 未更新 |

### C8: EVALUATE CONVERT-VALUE(WORK-CNTR1:1)（行 184, 物理パス名取得終了 ※）

```
EVALUATE CONVERT-VALUE(WORK-CNTR1:1)
```

※ block割当不整合あり（サニタイズ処理 SECTION 内と推定、詳細設計書 5.8 参照）

| No. | 条件ケース | 対象文字 | 期待WHEN分岐 | 期待変換結果 |
|-----|-----------|---------|-------------|-------------|
| C8-1 | "\<" | "\<" | WHEN "\<" | "\<" |
| C8-2 | ">" | ">" | WHEN ">" | ">" |
| C8-3 | "&" | "&" | WHEN "&" | "&" |
| C8-4 | 通常文字（英数字） | "A" | WHEN OTHER | "A"（そのまま） |
| C8-5 | 空白 | SPACE | WHEN OTHER | SPACE（そのまま） |
| C8-6 | 数字 | "0" | WHEN OTHER | "0"（そのまま） |
| C8-7 | 複合: "\<>" | 2文字入力 | "\<"→WHEN "\<", ">"→WHEN ">" | "\<>" |
| C8-8 | 複合: "\<" | 4文字入力 | "&"→WHEN "&", 残り→WHEN OTHER | "\&lt;" |

### C9: COBW3-SEARCH-FLAG-NON（行 49, SAFSAMPLE1-START）

```
ELSE IF COBW3-SEARCH-FLAG-NON THEN
```

| No. | 条件ケース | フラグ状態 | 期待分岐先 |
|-----|-----------|-----------|-----------|
| C9-1 | クッキーあり | TRUE（推定） | THEN 節（カウンタ処理） |
| C9-2 | クッキーなし | FALSE（推定） | ELSE 節または後続 |

※ COBW3-SEARCH-FLAG-NON の定義と値の意味は要確認。

## 4. 繰返し観点

### L1: PERFORM VARYING（行 181, サニタイズ処理内）

```
PERFORM WITH TEST BEFORE
  VARYING WORK-CNTR1 FROM 1 BY 1
  UNTIL WORK-CNTR1 > CONVERT-LENGTH
```

| No. | テストケース | CONVERT-LENGTH | 期待ループ回数 | 備考 |
|-----|-------------|---------------|--------------|------|
| L1-1 | 0回（空入力） | 0 | 0回 | WORK-CNTR1(1) > 0 で即終了 |
| L1-2 | 1回 | 1 | 1回 | WORK-CNTR1=1 のみ実行 |
| L1-3 | 複数回 | 10 | 10回 | 代表値 |
| L1-4 | 最大値境界 | 9999（PIC 9(4) の最大値） | 9999回 | WORK-CNTR1 の上限境界 |
| L1-5 | CONVERT-LENGTH境界 | 1024（PIC X(1024) の最大長） | 1024回 | CONVERT-VALUE の最大長境界 |
| L1-6 | 終了条件境界 | 1 | 1回 | WORK-CNTR1=1 → 1>1 不成立 → 実行 → 2>1 成立で終了 |
| L1-7 | 負数（CONVERT-LENGTH が負） | -1 | 0回 | PIC S9(4) で負数あり得る。1 > -1 で即終了 |

### L1 継続値と終了値の確認

| No. | 確認項目 | 詳細 |
|-----|---------|------|
| L1-8 | ループ内 WORK-CNTR1 の遷移 | 1, 2, 3, ... CONVERT-LENGTH まで増分されることを確認 |
| L1-9 | ループ内 WORK-CNTR2 の遷移 | 変換後文字列長に応じて増分（特殊文字は4バイト、通常は1バイト） |
| L1-10 | ループ終了後の WORK-CNTR1 | CONVERT-LENGTH + 1 であることを確認 |
| L1-11 | ループ終了後の SANITIZED-LENGTH | WORK-CNTR2 と一致することを確認（行 200） |
| L1-12 | SANITIZED-DATA の内容 | 全特殊文字が正しく変換されていることを確認 |

### PERFORM（セクション呼出し）の網羅

各 PERFORM 呼出しについて、呼出し元の全条件パターンから到達することを確認。

| No. | 呼出先 | 呼出元 | 行 | 到達パターン |
|-----|--------|--------|----|-------------|
| P1 | 画面出力処理 | SAFSAMPLE1-START | 48 | C1 エラー時（STATUS≠0 AND ≠8820） |
| P2 | アクセスカウンタ登録処理 | SAFSAMPLE1-START | 51 | C9 クッキーあり時 |
| P3 | 画面出力処理 | SAFSAMPLE1-START | 53 | C9 クッキーあり時 |
| P4 | 継続画面出力処理 | SAFSAMPLE1-START | 55 | 通常経路 |
| P5 | アクセスカウンタ登録処理 | SAFSAMPLE1-END | 76 | メイン終了処理 |
| P6 | 変換データ登録 | SAFSAMPLE1-END | 79 | メイン終了処理 |
| P7 | 画面出力処理 | SAFSAMPLE1-END | 86 | C2 エラー時 |
| P8 | サニタイズ処理 | SAFSAMPLE1-END | 94 | C2 正常時 |
| P9 | 変換データ登録 | SAFSAMPLE1-END | 96 | C2 正常時 |
| P10 | 画面出力処理 | SAFSAMPLE1-END | 103 | C3 エラー時 |
| P11 | サニタイズ処理 | SAFSAMPLE1-END | 111 | C3 正常時 |
| P12 | 変換データ登録 | SAFSAMPLE1-END | 113 | C3 正常時 |
| P13 | 画面出力処理 | SAFSAMPLE1-END | 117 | 通常経路（最終出力） |
| P14 | 画面出力処理 | 継続画面出力処理終了 | 129 | C4 エラー時 |
| P15 | 画面出力処理 | アクセスカウンタ登録処理終了 | 139 | C5 エラー時 |
| P16 | 物理パス名取得 | 変換データ登録終了 | 149 | C6 PATHNAME=SPACE 時 |

## 5. 入出力観点

### 5.1 ファイル入出力

`files` および `file_operations` は空配列。ファイル入出力は COBW3 API 経由のみ。

### 5.2 COBW3 API 経由の入出力

| No. | 入出力種別 | API | テスト観点 |
|-----|-----------|-----|-----------|
| IO-1 | 入力 | COBW3_GET_COOKIE_XX | クッキーあり/なし/エラー時の戻り値確認 |
| IO-2 | 入力 | COBW3_GET_REQUEST_INFO（行 83） | リモートホスト取得の正常/異常 |
| IO-3 | 入力 | COBW3_GET_REQUEST_INFO（行 168） | 物理パス取得の正常/異常 |
| IO-4 | 入力 | COBW3_RECEIVE_HEADER | ヘッダ受信の正常/異常 |
| IO-5 | 出力 | COBW3_SET_COOKIE_XX | クッキー値の設定確認 |
| IO-6 | 出力 | COBW3_SET_CNV_NX | 変換データの登録確認 |
| IO-7 | 出力 | COBW3_PUT_HTML | HTML出力内容の確認 |

### 5.3 LINKAGE 入力

| No. | テストケース | SAFCTX | 期待動作 |
|-----|-------------|--------|---------|
| IO-8 | 正常ポインタ | 有効なPOINTER | SET COBW3-CONTEXT が正常動作 |
| IO-9 | NULLポインタ | NULL | 動作未定義（要確認） |

## 6. 外部CALL観点

### 6.1 各CALLの正常/異常テスト

| No. | CALL対象 | 行 | 正常応答観点 | 異常応答観点 |
|-----|---------|----|-------------|-------------|
| CL-1 | COBW3_INIT | 40 | COBW3-STATUS = ZERO を返す | COBW3-STATUS ≠ ZERO の場合のハンドリング（要確認） |
| CL-2 | COBW3_GET_COOKIE_XX | 45 | STATUS=0（クッキーあり）、STATUS=8820（クッキーなし）を返す | STATUS≠0 AND ≠8820 のエラー |
| CL-3 | COBW3_FREE | 61 | リソース正常解放 | 二重解放や未初期化解放の動作（要確認） |
| CL-4 | COBW3_GET_REQUEST_INFO | 83 | COBW3-REQUEST-INFO にリモートホスト情報設定 | STATUS≠ZERO |
| CL-5 | COBW3_RECEIVE_HEADER | 100 | COBW3-HEADER-VALUE にヘッダ値設定 | STATUS≠ZERO |
| CL-6 | COBW3_SET_COOKIE_XX | 126 | クッキー設定完了 | STATUS≠ZERO |
| CL-7 | COBW3_SET_CNV_NX | 136 | 変換エントリ登録完了 | STATUS≠ZERO |
| CL-8 | COBW3_PUT_HTML | 160 | HTML出力完了 | STATUS≠ZERO（ハンドリングなし、要確認） |
| CL-9 | COBW3_GET_REQUEST_INFO | 168 | COBW3-REQUEST-INFO に物理パス設定 | STATUS≠ZERO |

### 6.2 引数の妥当性

全CALLの USING は `COBW3` のみ。COBW3 の内部状態が各CALL間で正しく維持されていることを確認する必要がある。

| No. | 確認項目 | 詳細 |
|-----|---------|------|
| CL-10 | COBW3初期化状態 | COBW3_INIT 前の他CALL呼出しは不可（推定） |
| CL-11 | COBW3解放後のCALL | COBW3_FREE 後の他CALL呼出しは不可（推定） |
| CL-12 | COBW3-CONTEXT設定 | SET COBW3-CONTEXT FROM SAFCTX の前後でCOBW3内部状態の整合性確認 |

### 6.3 CALL順序の網羅

| No. | 経路 | CALL順序 |
|-----|------|---------|
| CL-13 | クッキーあり・全正常 | INIT → GET_COOKIE_XX → ... → SET_COOKIE_XX → ... → FREE |
| CL-14 | クッキーなし・全正常 | INIT → GET_COOKIE_XX(8820) → ... → FREE |
| CL-15 | クッキー取得エラー | INIT → GET_COOKIE_XX(err) → 画面出力 → FREE |
| CL-16 | リクエスト情報エラー | ... → GET_REQUEST_INFO(err) → 画面出力 → ... → FREE |
| CL-17 | ヘッダ受信エラー | ... → RECEIVE_HEADER(err) → 画面出力 → ... → FREE |

## 7. データ境界値観点

### 7.1 WORKING-STORAGE 項目の境界値

| No. | データ項目 | PICTURE | 最小値 | 最大値 | 空値 | テスト観点 |
|-----|-----------|---------|--------|--------|------|-----------|
| D1 | HTMLFILENAME | PIC X(64) | 0文字 | 64文字 | SPACE | 0文字/64文字/65文字（オーバフロー確認） |
| D2 | PATHNAME | PIC X(256) | 0文字 | 256文字 | SPACE | 0文字/256文字。C6の分岐条件と関連 |
| D3 | PATHSIZE | PIC 9(05) | 00000 | 99999 | ZERO | 0/1/99999。コピー開始位置の計算に使用 |
| D4 | COPYSTARTPOS | PIC 9(05) | 00000 | 99999 | ZERO | PATHSIZE から算出。境界値は PATHSIZE に依存 |
| D5 | LEFTLENGTH | PIC 9(05) | 00000 | 99999 | ZERO | コピー残長。COPYSTARTPOS から算出 |
| D6 | アクセス回数 | PIC 9(05) | 00000 | 99999 | ZERO | COMPUTE/ADD 結果が 99999 を超える場合のオーバフロー確認 |
| D7 | WORK-CNTR1 | PIC 9(4) COMP-5 | 0 | 9999 | - | VARYING のカウンタ。上限 9999 |
| D8 | WORK-CNTR2 | PIC 9(4) COMP-5 | 0 | 9999 | - | サニタイズ後の文字位置。特殊文字変換で最大4倍に増大 |
| D9 | CONVERT-VALUE | PIC X(1024) | 0文字 | 1024文字 | SPACE | 入力上限 1024 文字 |
| D10 | CONVERT-LENGTH | PIC S9(4) COMP-5 | -9999 | 9999 | - | 負数入力時の挙動確認（L1-7） |
| D11 | SANITIZED-DATA | PIC X(1024) | 0文字 | 1024文字 | SPACE | 変換結果が 1024 を超える可能性の確認 |
| D12 | SANITIZED-LENGTH | PIC S9(4) COMP-5 | -9999 | 9999 | - | WORK-CNTR2 からの設定。上限確認 |

### 7.2 主要な更新前後確認（mutations）

#### M1: COMPUTE アクセス回数 = NUMVAL(COBW3-COOKIE-VALUE)（行 70）

| No. | テストケース | COBW3-COOKIE-VALUE | 期待結果（アクセス回数） | 備考 |
|-----|-------------|-------------------|----------------------|------|
| M1-1 | 正常値 | "00001" | 1 | 代表値 |
| M1-2 | ゼロ | "00000" | 0 | |
| M1-3 | 最大値 | "99999" | 99999 | ADD 1 後のオーバフロー注意 |
| M1-4 | 非数値 | SPACE等 | 要確認 | NUMVAL のエラー処理 |
| M1-5 | 空文字 | "" | 要確認 | NUMVAL の入力制約 |

#### M2: ADD 1 TO アクセス回数（行 71）

| No. | テストケース | ADD前 | ADD後 | 備考 |
|-----|-------------|-------|-------|------|
| M2-1 | 正常インクリメント | 1 | 2 | |
| M2-2 | ゼロから | 0 | 1 | |
| M2-3 | 桁あふれ境界 | 99999 | 要確認 | PIC 9(05) の上限超過時の動作 |

#### M3: COMPUTE COPYSTARTPOS（行 153, 155）

| No. | テストケース | PATHSIZE | COPYSTARTPOS(行153) | COPYSTARTPOS(行155) | 備考 |
|-----|-------------|---------|--------------------|--------------------|------|
| M3-1 | 正常 | 10 | 要確認（PATHSIZE算出） | 要確認（インクリメント推定） | 算出内容は要確認 |
| M3-2 | PATHSIZE = 0 | 0 | 要確認 | 要確認 | |
| M3-3 | PATHSIZE = 256 | 256 | 要確認 | 要確認 | PATHNAME の最大長 |

#### M4: COMPUTE LEFTLENGTH（行 156）

| No. | テストケース | COPYSTARTPOS | LEFTLENGTH | 備考 |
|-----|-------------|-------------|-----------|------|
| M4-1 | 正常 | 10 | 要確認（残長算出推定） | 算出式は要確認 |
| M4-2 | COPYSTARTPOS = 0 | 0 | 要確認 | |
| M4-3 | COPYSTARTPOS 大 | 256 | 要確認（負数になる可能性） | |

### 7.3 LINKAGE 項目

| No. | データ項目 | USAGE | テスト観点 |
|-----|-----------|-------|-----------|
| D13 | SAFCTX | POINTER | NULLポインタ、有効ポインタ、解放済みポインタ |

### 7.4 サニタイズ処理の境界値

CONVERT-VALUE が全て特殊文字で構成される場合、SANITIZED-DATA は最大 4 倍の長さになる。

| No. | テストケース | CONVERT-LENGTH | 内容 | 期待SANITIZED-LENGTH | 備考 |
|-----|-------------|---------------|------|---------------------|------|
| S1 | 全て"\<" | 256 | "\<<\<...\<" | 1024 | SANITIZED-DATA の最大長到達 |
| S2 | 全て通常文字 | 1024 | "AAAA...A" | 1024 | CONVERT-VALUE の最大長 |
| S3 | 混合 | 341 | "\<>&"×113 + "\<" | 1364 | SANITIZED-DATA(PIC X(1024)) を超える可能性。オーバフロー要確認 |
| S4 | 空入力 | 0 | "" | 0 | ループ0回 |

## 8. 制約事項

### 8.1 warnings

1. **tree-sitter-cobol の解析欠落をソース行ベースで補完しました。**
   — 本観点書は補完後の解析結果に基づいているため、補完の正確性がテスト観点の妥当性に直結する。ソースコードとの突合確認が必須。

1. **COPY句を検出しました。コピー元展開後の解析は未実装です。**
   — COBW3 関連のデータ項目（COBW3-STATUS, COBW3-COOKIE-NAME, COBW3-CNV-VALUE 等）の定義内容が不明。これらの型、桁数、初期値、境界値は COBW3 コピー句の展開結果に依存するため、展開後の再解析が推奨される。

### 8.2 MOVE文の source 欠落

多数の MOVE mutations で `sources` が空配列。MOVE 先と MOVE 元の完全な対応が不明なため、更新前後の値の確認にはソースコードの直接確認が必要。

### 8.3 parser のblock割当不整合

行 178–200（サニタイズロジック）の block が「物理パス名取得終了」とされているが、行番号的にサニタイズ処理 SECTION 内に該当する可能性が高い。本観点書ではサニタイズ処理として扱っているが、ソースコードで要確認。

### 8.4 未確認項目一覧

| No. | 項目 | 理由 |
|-----|------|------|
| U1 | COBW3-STATUS = 8820 の意味 | COPY句未展開のため |
| U2 | COBW3-SEARCH-FLAG-NON の値と意味 | COPY句未展開のため |
| U3 | COMPUTE COPYSTARTPOS の算出式（行 153, 155） | sources に変数名のみで式が不明 |
| U4 | COMPUTE LEFTLENGTH の算出式（行 156） | 同上 |
| U5 | COBW3_INIT 失敗時のハンドリング | 行 40 の直後に STATUS チェックがJSON上に存在しない |
| U6 | COBW3_PUT_HTML 失敗時のハンドリング | 行 160 の直後に STATUS チェックがJSON上に存在しない |
| U7 | NUMVAL の非数値入力時の動作 | COBOL実行環境依存 |
| U8 | アクセス回数の ADD 1 オーバフロー時の動作 | PIC 9(05) の上限超過 |
| U9 | SANITIZED-DATA のオーバフロー時の動作 | PIC X(1024) を超える書込みの挙動 |
