# Fujitsu COBOL Detailed Design Prompt

以下の制約に従って、日本語の詳細設計書をMarkdownで作成してください。

## 目的
- 入力は Fujitsu メインフレーム COBOL の構文解析結果です。
- この解析結果だけを根拠に、保守担当者が読める詳細設計書を作成してください。

## 絶対条件
- 日本語で書く
- 断定は根拠があるものだけに限定する
- 不明な点は「要確認」または「推定」と明記する
- JSONに存在しない業務仕様を創作しない
- `warnings` がある場合は設計書末尾に制約として必ず記載する
- 条件分岐、繰返し、ファイル操作、外部CALLは必ず節を分けて記載する

## 出力構成
以下の見出しをこの順で出力すること。

# 詳細設計書
## 1. 対象概要
## 2. プログラム概要
## 3. 入出力設計
## 4. データ項目設計
## 5. 処理フロー
## 6. 判定条件
## 7. 繰返し処理
## 8. 外部インタフェース
## 9. 例外・制約事項
## 10. トレーサビリティ

## 各節の書き方
- 2. プログラム概要: PROGRAM-ID, source_format, USING, RETURNING を整理する
- 3. 入出力設計: files と file_operations を対応付けて、入力/出力/更新の観点でまとめる
- 4. データ項目設計: working_storage, linkage, local_storage を節ごとに整理する
- 5. 処理フロー: sections, paragraphs, loops, file_operations, calls を時系列でまとめる
- 6. 判定条件: conditions を列挙し、関係する block を付ける
- 7. 繰返し処理: loops を列挙し、終了条件や対象 paragraph を明記する
- 8. 外部インタフェース: calls を列挙し、target, using, giving を整理する
- 9. 例外・制約事項: warnings と、AT END 等が読み取れる場合の注意を書く
- 10. トレーサビリティ: 重要要素に source line を対応付ける

## 入力JSON
```json
{
  "target_platform": "Fujitsu mainframe COBOL",
  "parser": "tree-sitter-cobol",
  "source_path": "test/sample.cbl",
  "program_count": 1,
  "programs": [
    {
      "program_id": "SAF-MAIN",
      "source_path": "test/sample.cbl",
      "source_format": "fixed",
      "using_parameters": [
        "SAFCTX"
      ],
      "returning": null,
      "sections": [
        {
          "kind": "section",
          "name": "継続画面出力処理",
          "line": 67
        },
        {
          "kind": "section",
          "name": "アクセスカウンタ登録処理",
          "line": 123
        },
        {
          "kind": "section",
          "name": "変換データ登録",
          "line": 135
        },
        {
          "kind": "section",
          "name": "画面出力処理",
          "line": 145
        },
        {
          "kind": "section",
          "name": "物理パス名取得",
          "line": 165
        },
        {
          "kind": "section",
          "name": "サニタイズ処理",
          "line": 177
        }
      ],
      "paragraphs": [
        {
          "kind": "paragraph",
          "name": "SAFSAMPLE1-START",
          "line": 32
        },
        {
          "kind": "paragraph",
          "name": "終了位置",
          "line": 58
        },
        {
          "kind": "paragraph",
          "name": "SAFSAMPLE1-END",
          "line": 63
        },
        {
          "kind": "paragraph",
          "name": "継続画面出力処理終了",
          "line": 119
        },
        {
          "kind": "paragraph",
          "name": "アクセスカウンタ登録処理終了",
          "line": 132
        },
        {
          "kind": "paragraph",
          "name": "変換データ登録終了",
          "line": 142
        },
        {
          "kind": "paragraph",
          "name": "画面出力処理終了",
          "line": 162
        },
        {
          "kind": "paragraph",
          "name": "物理パス名取得終了",
          "line": 174
        },
        {
          "kind": "paragraph",
          "name": "サニタイズ処理終了",
          "line": 201
        }
      ],
      "files": [],
      "working_storage": [
        {
          "level": "01",
          "name": "HTMLFILENAME",
          "picture": "PIC X(64)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 14
        },
        {
          "level": "01",
          "name": "PATHNAME",
          "picture": "PIC X(256)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 15
        },
        {
          "level": "01",
          "name": "PATHSIZE",
          "picture": "PIC 9(05)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 16
        },
        {
          "level": "01",
          "name": "COPYSTARTPOS",
          "picture": "PIC 9(05)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 17
        },
        {
          "level": "01",
          "name": "LEFTLENGTH",
          "picture": "PIC 9(05)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 18
        },
        {
          "level": "01",
          "name": "アクセス回数",
          "picture": "PIC 9(05)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 19
        },
        {
          "level": "01",
          "name": "WORK-CNTR1",
          "picture": "PIC 9(4)",
          "usage": "COMP-5",
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 20
        },
        {
          "level": "01",
          "name": "WORK-CNTR2",
          "picture": "PIC 9(4)",
          "usage": "COMP-5",
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 21
        },
        {
          "level": "01",
          "name": "CONVERT-VALUE",
          "picture": "PIC X(1024)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 22
        },
        {
          "level": "01",
          "name": "CONVERT-LENGTH",
          "picture": "PIC S9(4)",
          "usage": "COMP-5",
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 23
        },
        {
          "level": "01",
          "name": "SANITIZED-DATA",
          "picture": "PIC X(1024)",
          "usage": null,
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 24
        },
        {
          "level": "01",
          "name": "SANITIZED-LENGTH",
          "picture": "PIC S9(4)",
          "usage": "COMP-5",
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "working-storage",
          "line": 25
        }
      ],
      "linkage": [
        {
          "level": "01",
          "name": "SAFCTX",
          "picture": null,
          "usage": "POINTER",
          "occurs": null,
          "redefines": null,
          "value": null,
          "section": "linkage",
          "line": 28
        }
      ],
      "local_storage": [],
      "conditions": [
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS NOT = ZERO AND COBW3-STATUS NOT = 8820 THEN",
          "block": "SAFSAMPLE1-START",
          "line": 46
        },
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS NOT = ZERO THEN",
          "block": "SAFSAMPLE1-END",
          "line": 84
        },
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS NOT = ZERO THEN",
          "block": "SAFSAMPLE1-END",
          "line": 101
        },
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS NOT = ZERO THEN",
          "block": "継続画面出力処理終了",
          "line": 127
        },
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS NOT = ZERO THEN",
          "block": "アクセスカウンタ登録処理終了",
          "line": 137
        },
        {
          "kind": "IF",
          "expression": "IF PATHNAME = SPACE THEN",
          "block": "変換データ登録終了",
          "line": 148
        },
        {
          "kind": "IF",
          "expression": "IF COBW3-STATUS = ZERO THEN",
          "block": "画面出力処理終了",
          "line": 169
        },
        {
          "kind": "EVALUATE",
          "expression": "EVALUATE CONVERT-VALUE(WORK-CNTR1:1)",
          "block": "物理パス名取得終了",
          "line": 184
        },
        {
          "kind": "IF",
          "expression": "ELSE IF COBW3-SEARCH-FLAG-NON THEN",
          "block": "SAFSAMPLE1-START",
          "line": 49
        }
      ],
      "loops": [
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-START",
          "line": 48
        },
        {
          "kind": "PERFORM",
          "target": "アクセスカウンタ登録処理",
          "option": null,
          "block": "SAFSAMPLE1-START",
          "line": 51
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-START",
          "line": 53
        },
        {
          "kind": "PERFORM",
          "target": "継続画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-START",
          "line": 55
        },
        {
          "kind": "PERFORM",
          "target": "アクセスカウンタ登録処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 76
        },
        {
          "kind": "PERFORM",
          "target": "変換データ登録",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 79
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 86
        },
        {
          "kind": "PERFORM",
          "target": "サニタイズ処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 94
        },
        {
          "kind": "PERFORM",
          "target": "変換データ登録",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 96
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 103
        },
        {
          "kind": "PERFORM",
          "target": "サニタイズ処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 111
        },
        {
          "kind": "PERFORM",
          "target": "変換データ登録",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 113
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "SAFSAMPLE1-END",
          "line": 117
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "継続画面出力処理終了",
          "line": 129
        },
        {
          "kind": "PERFORM",
          "target": "画面出力処理",
          "option": null,
          "block": "アクセスカウンタ登録処理終了",
          "line": 139
        },
        {
          "kind": "PERFORM",
          "target": "物理パス名取得",
          "option": null,
          "block": "変換データ登録終了",
          "line": 149
        },
        {
          "kind": "PERFORM",
          "target": null,
          "option": "WITH TEST BEFORE 001820 VARYING WORK-CNTR1 FROM 1 BY 1 001830 UNTIL WORK-CNTR1 > CONVERT-LENGTH",
          "block": "物理パス名取得終了",
          "line": 181
        }
      ],
      "file_operations": [],
      "calls": [
        {
          "target": "\"COBW3_INIT\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "SAFSAMPLE1-START",
          "line": 40
        },
        {
          "target": "\"COBW3_GET_COOKIE_XX\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "SAFSAMPLE1-START",
          "line": 45
        },
        {
          "target": "\"COBW3_FREE\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "終了位置",
          "line": 61
        },
        {
          "target": "\"COBW3_GET_REQUEST_INFO\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "SAFSAMPLE1-END",
          "line": 83
        },
        {
          "target": "\"COBW3_RECEIVE_HEADER\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "SAFSAMPLE1-END",
          "line": 100
        },
        {
          "target": "\"COBW3_SET_COOKIE_XX\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "継続画面出力処理終了",
          "line": 126
        },
        {
          "target": "\"COBW3_SET_CNV_NX\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "アクセスカウンタ登録処理終了",
          "line": 136
        },
        {
          "target": "\"COBW3_PUT_HTML\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "変換データ登録終了",
          "line": 160
        },
        {
          "target": "\"COBW3_GET_REQUEST_INFO\"",
          "using": [
            "COBW3"
          ],
          "giving": null,
          "block": "画面出力処理終了",
          "line": 168
        }
      ],
      "event_handlers": [
        {
          "kind": "WHEN",
          "expression": "WHEN \"<\"",
          "block": "物理パス名取得終了",
          "line": 185
        },
        {
          "kind": "WHEN",
          "expression": "WHEN \">\"",
          "block": "物理パス名取得終了",
          "line": 188
        },
        {
          "kind": "WHEN",
          "expression": "WHEN \"&\"",
          "block": "物理パス名取得終了",
          "line": 191
        },
        {
          "kind": "WHEN OTHER",
          "expression": "WHEN OTHER",
          "block": "物理パス名取得終了",
          "line": 194
        }
      ],
      "mutations": [
        {
          "kind": "MOVE",
          "targets": [
            "COBW3"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 35
        },
        {
          "kind": "SET",
          "targets": [
            "COBW3-CONTEXT"
          ],
          "sources": [
            "SAFCTX"
          ],
          "block": "SAFSAMPLE1-START",
          "line": 36
        },
        {
          "kind": "MOVE",
          "targets": [
            "PATHNAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 42
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-COOKIE-NAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 44
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 47
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-COOKIE-VALUE"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 50
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-START",
          "line": 52
        },
        {
          "kind": "COMPUTE",
          "targets": [
            "アクセス回数"
          ],
          "sources": [
            "NUMVAL",
            "COBW3-COOKIE-VALUE"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 70
        },
        {
          "kind": "ADD",
          "targets": [
            "アクセス回数"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 71
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-COOKIE-VALUE"
          ],
          "sources": [
            "アクセス回数"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 72
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-COOKIE-VALUE-LENGTH"
          ],
          "sources": [
            "ZERO"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 73
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-NAME-N"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 77
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-VALUE"
          ],
          "sources": [
            "アクセス回数"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 78
        },
        {
          "kind": "SET",
          "targets": [
            "COBW3-REMOTE-HOST"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 82
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 85
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-NAME-N"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 89
        },
        {
          "kind": "MOVE",
          "targets": [
            "CONVERT-VALUE"
          ],
          "sources": [
            "COBW3-REQUEST-INFO"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 92
        },
        {
          "kind": "MOVE",
          "targets": [
            "CONVERT-LENGTH"
          ],
          "sources": [
            "COBW3-REQUEST-INFO-LENGTH"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 93
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-VALUE"
          ],
          "sources": [
            "SANITIZED-DATA"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 95
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-HEADER-NAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 99
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 102
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-NAME-N"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 106
        },
        {
          "kind": "MOVE",
          "targets": [
            "CONVERT-VALUE"
          ],
          "sources": [
            "COBW3-HEADER-VALUE"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 109
        },
        {
          "kind": "MOVE",
          "targets": [
            "CONVERT-LENGTH"
          ],
          "sources": [
            "COBW3-HEADER-VALUE-LENGTH"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 110
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-CNV-VALUE"
          ],
          "sources": [
            "SANITIZED-DATA"
          ],
          "block": "SAFSAMPLE1-END",
          "line": 112
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "SAFSAMPLE1-END",
          "line": 116
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "継続画面出力処理終了",
          "line": 128
        },
        {
          "kind": "MOVE",
          "targets": [
            "HTMLFILENAME"
          ],
          "sources": [],
          "block": "アクセスカウンタ登録処理終了",
          "line": 138
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-HTML-FILENAME"
          ],
          "sources": [],
          "block": "変換データ登録終了",
          "line": 151
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-HTML-FILENAME"
          ],
          "sources": [
            "PATHNAME",
            "PATHSIZE"
          ],
          "block": "変換データ登録終了",
          "line": 152
        },
        {
          "kind": "COMPUTE",
          "targets": [
            "COPYSTARTPOS"
          ],
          "sources": [
            "PATHSIZE"
          ],
          "block": "変換データ登録終了",
          "line": 153
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-HTML-FILENAME",
            "COPYSTARTPOS"
          ],
          "sources": [],
          "block": "変換データ登録終了",
          "line": 154
        },
        {
          "kind": "COMPUTE",
          "targets": [
            "COPYSTARTPOS"
          ],
          "sources": [
            "COPYSTARTPOS"
          ],
          "block": "変換データ登録終了",
          "line": 155
        },
        {
          "kind": "COMPUTE",
          "targets": [
            "LEFTLENGTH"
          ],
          "sources": [
            "COPYSTARTPOS"
          ],
          "block": "変換データ登録終了",
          "line": 156
        },
        {
          "kind": "MOVE",
          "targets": [
            "COBW3-HTML-FILENAME",
            "COPYSTARTPOS"
          ],
          "sources": [
            "HTMLFILENAME"
          ],
          "block": "変換データ登録終了",
          "line": 157
        },
        {
          "kind": "MOVE",
          "targets": [
            "PATHNAME"
          ],
          "sources": [],
          "block": "画面出力処理終了",
          "line": 166
        },
        {
          "kind": "SET",
          "targets": [
            "COBW3-PHYSICALPATH"
          ],
          "sources": [],
          "block": "画面出力処理終了",
          "line": 167
        },
        {
          "kind": "MOVE",
          "targets": [
            "PATHNAME"
          ],
          "sources": [
            "COBW3-REQUEST-INFO"
          ],
          "block": "画面出力処理終了",
          "line": 170
        },
        {
          "kind": "MOVE",
          "targets": [
            "PATHSIZE"
          ],
          "sources": [
            "COBW3-REQUEST-INFO-LENGTH"
          ],
          "block": "画面出力処理終了",
          "line": 171
        },
        {
          "kind": "MOVE",
          "targets": [
            "WORK-CNTR1"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 178
        },
        {
          "kind": "MOVE",
          "targets": [
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 179
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-DATA"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 180
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-DATA",
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 186
        },
        {
          "kind": "ADD",
          "targets": [
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 187
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-DATA",
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 189
        },
        {
          "kind": "ADD",
          "targets": [
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 190
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-DATA",
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 192
        },
        {
          "kind": "ADD",
          "targets": [
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 193
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-DATA"
          ],
          "sources": [
            "CONVERT-VALUE"
          ],
          "block": "物理パス名取得終了",
          "line": 195
        },
        {
          "kind": "ADD",
          "targets": [
            "WORK-CNTR2"
          ],
          "sources": [],
          "block": "物理パス名取得終了",
          "line": 197
        },
        {
          "kind": "MOVE",
          "targets": [
            "SANITIZED-LENGTH"
          ],
          "sources": [
            "WORK-CNTR2"
          ],
          "block": "物理パス名取得終了",
          "line": 200
        }
      ],
      "warnings": [
        "tree-sitter-cobol の解析欠落をソース行ベースで補完しました。",
        "COPY句を検出しました。コピー元展開後の解析は未実装です。"
      ]
    }
  ]
}
```
