# 詳細設計書

## 1. 対象概要

| 項目 | 値 |
|------|-----|
| ターゲットプラットフォーム | Fujitsu メインフレーム COBOL |
| パーサー | tree-sitter-cobol |
| ソースパス | test/sample.cbl |
| プログラム数 | 1 |
| ソース形式 | fixed |

## 2. プログラム概要

| 項目 | 値 |
|------|-----|
| PROGRAM-ID | SAF-MAIN |
| ソース形式 | fixed |
| USING パラメタ | SAFCTX |
| RETURNING | なし |

COBW3（推定: Fujitsu COBOL Web3 CGI ライブラリ）のAPI群を用いて、HTTPクッキーによるアクセスカウンタとHTML画面出力を行うCGIプログラムと推定される。ユーザ入力のサニタイズ（`<`, `>`, `&` のHTMLエンティティ変換）を実装している。

## 3. 入出力設計

### 3.1 ファイル定義

JSON上、`files` および `file_operations` は空配列である。ファイル入出力はCOBW3 API経由でのみ行われると推定される。

### 3.2 外部インタフェース経由の入出力

| API | 種別 | 概要 |
|-----|------|------|
| COBW3_INIT | 初期化 | COBW3 環境初期化 |
| COBW3_GET_COOKIE_XX | 入力 | クッキー取得 |
| COBW3_GET_REQUEST_INFO | 入力 | リクエスト情報取得 |
| COBW3_RECEIVE_HEADER | 入力 | HTTPヘッダ受信 |
| COBW3_SET_COOKIE_XX | 出力 | クッキー設定 |
| COBW3_SET_CNV_NX | 出力 | 変換データ登録（次エントリ） |
| COBW3_PUT_HTML | 出力 | HTML出力 |
| COBW3_FREE | 終了 | COBW3 リソース解放 |

## 4. データ項目設計

### 4.1 WORKING-STORAGE SECTION

| LVL | データ項目名 | PICTURE | USAGE | 備考 | 行 |
|-----|-------------|---------|-------|------|----|
| 01 | HTMLFILENAME | PIC X(64) | - | HTMLテンプレートファイル名（推定） | 14 |
| 01 | PATHNAME | PIC X(256) | - | 物理パス名 | 15 |
| 01 | PATHSIZE | PIC 9(05) | - | パス長 | 16 |
| 01 | COPYSTARTPOS | PIC 9(05) | - | コピー開始位置 | 17 |
| 01 | LEFTLENGTH | PIC 9(05) | - | 残長 | 18 |
| 01 | アクセス回数 | PIC 9(05) | - | アクセスカウンタ値 | 19 |
| 01 | WORK-CNTR1 | PIC 9(4) | COMP-5 | サニタイズループカウンタ | 20 |
| 01 | WORK-CNTR2 | PIC 9(4) | COMP-5 | サニタイズ出力位置カウンタ | 21 |
| 01 | CONVERT-VALUE | PIC X(1024) | - | 変換対象データ | 22 |
| 01 | CONVERT-LENGTH | PIC S9(4) | COMP-5 | 変換対象データ長 | 23 |
| 01 | SANITIZED-DATA | PIC X(1024) | - | サニタイズ済データ | 24 |
| 01 | SANITIZED-LENGTH | PIC S9(4) | COMP-5 | サニタイズ済データ長 | 25 |

### 4.2 LINKAGE SECTION

| LVL | データ項目名 | PICTURE | USAGE | 行 |
|-----|-------------|---------|-------|----|
| 01 | SAFCTX | - | POINTER | 呼出元コンテキスト |

### 4.3 LOCAL-STORAGE SECTION

なし

### 4.4 COPY句による定義（要確認）

COBW3 関連のデータ項目（COBW3, COBW3-STATUS, COBW3-COOKIE-NAME 等）は COPY 句で導入されている。コピー元展開後の解析は未実装のため、これらの定義内容はJSON上に存在しない。

## 5. 処理フロー

### 5.1 SAFSAMPLE1-START（行 32）— メイン開始処理

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 35 | MOVE → COBW3 初期化 |
| 2 | 36 | SET COBW3-CONTEXT ← SAFCTX |
| 3 | 40 | CALL "COBW3_INIT" USING COBW3 |
| 4 | 42 | MOVE SPACE → PATHNAME（推定） |
| 5 | 44 | MOVE → COBW3-COOKIE-NAME（値は要確認） |
| 6 | 45 | CALL "COBW3_GET_COOKIE_XX" USING COBW3 |
| 7 | 46 | IF COBW3-STATUS ≠ ZERO AND COBW3-STATUS ≠ 8820 → エラー処理へ |
| 8 | 47 | MOVE → HTMLFILENAME（エラー時） |
| 9 | 48 | PERFORM 画面出力処理（エラー時） |
| 10 | 49 | ELSE IF COBW3-SEARCH-FLAG-NON → クッキーあり分岐 |
| 11 | 50 | MOVE → COBW3-COOKIE-VALUE |
| 12 | 51 | PERFORM アクセスカウンタ登録処理 |
| 13 | 52 | MOVE → HTMLFILENAME |
| 14 | 53 | PERFORM 画面出力処理 |
| 15 | 55 | PERFORM 継続画面出力処理 |

### 5.2 終了位置（行 58）

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 61 | CALL "COBW3_FREE" USING COBW3 |

### 5.3 SAFSAMPLE1-END（行 63）— メイン終了処理

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 70 | COMPUTE アクセス回数 = NUMVAL(COBW3-COOKIE-VALUE) |
| 2 | 71 | ADD 1 TO アクセス回数 |
| 3 | 72 | MOVE アクセス回数 → COBW3-COOKIE-VALUE |
| 4 | 73 | MOVE ZERO → COBW3-COOKIE-VALUE-LENGTH |
| 5 | 76 | PERFORM アクセスカウンタ登録処理 |
| 6 | 77 | MOVE → COBW3-CNV-NAME-N |
| 7 | 78 | MOVE アクセス回数 → COBW3-CNV-VALUE |
| 8 | 79 | PERFORM 変換データ登録 |
| 9 | 82 | SET COBW3-REMOTE-HOST（値は要確認） |
| 10 | 83 | CALL "COBW3_GET_REQUEST_INFO" USING COBW3 |
| 11 | 84 | IF COBW3-STATUS ≠ ZERO → エラー処理 |
| 12 | 85 | MOVE → HTMLFILENAME（エラー時） |
| 13 | 86 | PERFORM 画面出力処理（エラー時） |
| 14 | 89 | MOVE → COBW3-CNV-NAME-N |
| 15 | 92 | MOVE COBW3-REQUEST-INFO → CONVERT-VALUE |
| 16 | 93 | MOVE COBW3-REQUEST-INFO-LENGTH → CONVERT-LENGTH |
| 17 | 94 | PERFORM サニタイズ処理 |
| 18 | 95 | MOVE SANITIZED-DATA → COBW3-CNV-VALUE |
| 19 | 96 | PERFORM 変換データ登録 |
| 20 | 99 | MOVE → COBW3-HEADER-NAME |
| 21 | 100 | CALL "COBW3_RECEIVE_HEADER" USING COBW3 |
| 22 | 101 | IF COBW3-STATUS ≠ ZERO → エラー処理 |
| 23 | 102 | MOVE → HTMLFILENAME（エラー時） |
| 24 | 103 | PERFORM 画面出力処理（エラー時） |
| 25 | 106 | MOVE → COBW3-CNV-NAME-N |
| 26 | 109 | MOVE COBW3-HEADER-VALUE → CONVERT-VALUE |
| 27 | 110 | MOVE COBW3-HEADER-VALUE-LENGTH → CONVERT-LENGTH |
| 28 | 111 | PERFORM サニタイズ処理 |
| 29 | 112 | MOVE SANITIZED-DATA → COBW3-CNV-VALUE |
| 30 | 113 | PERFORM 変換データ登録 |
| 31 | 116 | MOVE → HTMLFILENAME |
| 32 | 117 | PERFORM 画面出力処理 |

### 5.4 継続画面出力処理 SECTION（行 67）

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 126 | CALL "COBW3_SET_COOKIE_XX" USING COBW3 |
| 2 | 127 | IF COBW3-STATUS ≠ ZERO → エラー処理 |
| 3 | 128 | MOVE → HTMLFILENAME（エラー時） |
| 4 | 129 | PERFORM 画面出力処理（エラー時） |

### 5.5 アクセスカウンタ登録処理 SECTION（行 123）

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 136 | CALL "COBW3_SET_CNV_NX" USING COBW3 |
| 2 | 137 | IF COBW3-STATUS ≠ ZERO → エラー処理 |
| 3 | 138 | MOVE → HTMLFILENAME（エラー時） |
| 4 | 139 | PERFORM 画面出力処理（エラー時） |

### 5.6 変換データ登録 SECTION（行 135）

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 148 | IF PATHNAME = SPACE → PERFORM 物理パス名取得 |
| 2 | 151 | MOVE SPACE → COBW3-HTML-FILENAME（推定） |
| 3 | 152 | MOVE PATHNAME, PATHSIZE → COBW3-HTML-FILENAME |
| 4 | 153 | COMPUTE COPYSTARTPOS ← PATHSIZE（算出内容は要確認） |
| 5 | 154 | MOVE → COBW3-HTML-FILENAME, COPYSTARTPOS |
| 6 | 155 | COMPUTE COPYSTARTPOS ← COPYSTARTPOS（インクリメント推定） |
| 7 | 156 | COMPUTE LEFTLENGTH ← COPYSTARTPOS（残長算出推定） |
| 8 | 157 | MOVE HTMLFILENAME → COBW3-HTML-FILENAME（COPYSTARTPOS位置から） |
| 9 | 160 | CALL "COBW3_PUT_HTML" USING COBW3 |

### 5.7 画面出力処理 SECTION（行 145）

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 166 | MOVE SPACE → PATHNAME |
| 2 | 167 | SET COBW3-PHYSICALPATH（値は要確認） |
| 3 | 168 | CALL "COBW3_GET_REQUEST_INFO" USING COBW3 |
| 4 | 169 | IF COBW3-STATUS = ZERO → 正常時 |
| 5 | 170 | MOVE COBW3-REQUEST-INFO → PATHNAME |
| 6 | 171 | MOVE COBW3-REQUEST-INFO-LENGTH → PATHSIZE |

### 5.8 サニタイズ処理 SECTION（行 177）

> **注:** JSON上、行 178–200 のmutationsのblockは「物理パス名取得終了」とされているが、行番号的に行 177 以降はサニタイズ処理 SECTION 内に該当する。parserのblock割当に不整合がある可能性あり（要確認）。

| 手順 | 行 | 内容 |
|------|----|------|
| 1 | 178 | MOVE ZERO → WORK-CNTR1 |
| 2 | 179 | MOVE ZERO → WORK-CNTR2 |
| 3 | 180 | MOVE SPACE → SANITIZED-DATA |
| 4 | 181 | PERFORM VARYING WORK-CNTR1 FROM 1 BY 1 UNTIL WORK-CNTR1 > CONVERT-LENGTH |
| 5 | 184 | EVALUATE CONVERT-VALUE(WORK-CNTR1:1) |
| 6 | 185 | WHEN "\<" → SANITIZED-DATA に "\<" を設定（WORK-CNTR2位置） |
| 7 | 188 | WHEN ">" → SANITIZED-DATA に ">" を設定（WORK-CNTR2位置） |
| 8 | 191 | WHEN "&" → SANITIZED-DATA に "&" を設定（WORK-CNTR2位置） |
| 9 | 194 | WHEN OTHER → SANITIZED-DATA に CONVERT-VALUE の該当文字をそのままコピー |
| 10 | 200 | MOVE WORK-CNTR2 → SANITIZED-LENGTH |

## 6. 判定条件

| No. | 種別 | 条件式 | 所属ブロック | 行 | 備考 |
|-----|------|--------|-------------|----|------|
| 1 | IF | COBW3-STATUS ≠ ZERO AND COBW3-STATUS ≠ 8820 | SAFSAMPLE1-START | 46 | クッキー取得のエラーチェック。8820 は「クッキーなし」を示す戻り値と推定 |
| 2 | IF | COBW3-STATUS ≠ ZERO | SAFSAMPLE1-END | 84 | リクエスト情報取得エラーチェック |
| 3 | IF | COBW3-STATUS ≠ ZERO | SAFSAMPLE1-END | 101 | ヘッダ受信エラーチェック |
| 4 | IF | COBW3-STATUS ≠ ZERO | 継続画面出力処理終了 | 127 | クッキー設定エラーチェック |
| 5 | IF | COBW3-STATUS ≠ ZERO | アクセスカウンタ登録処理終了 | 137 | 変換データ登録エラーチェック |
| 6 | IF | PATHNAME = SPACE | 変換データ登録終了 | 148 | 物理パス未取得時の判定 |
| 7 | IF | COBW3-STATUS = ZERO | 画面出力処理終了 | 169 | リクエスト情報取得成功判定 |
| 8 | EVALUATE | CONVERT-VALUE(WORK-CNTR1:1) | 物理パス名取得終了 ※ | 184 | サニタイズ対象文字の分岐（※block割当の不整合あり、5.8参照） |
| 9 | IF | COBW3-SEARCH-FLAG-NON | SAFSAMPLE1-START | 49 | クッキー検索フラグ判定（値の意味は要確認） |

## 7. 繰返し処理

### 7.1 PERFORM（セクション・段落呼出し）

| No. | 呼出先 | 呼出元ブロック | 行 | 備考 |
|-----|--------|--------------|----|------|
| 1 | 画面出力処理 | SAFSAMPLE1-START | 48 | エラー時画面出力 |
| 2 | アクセスカウンタ登録処理 | SAFSAMPLE1-START | 51 | クッキーあり時 |
| 3 | 画面出力処理 | SAFSAMPLE1-START | 53 | クッキーあり時画面出力 |
| 4 | 継続画面出力処理 | SAFSAMPLE1-START | 55 | 最終画面出力 |
| 5 | アクセスカウンタ登録処理 | SAFSAMPLE1-END | 76 | カウンタ更新後登録 |
| 6 | 変換データ登録 | SAFSAMPLE1-END | 79 | カウンタ値登録 |
| 7 | 画面出力処理 | SAFSAMPLE1-END | 86 | エラー時 |
| 8 | サニタイズ処理 | SAFSAMPLE1-END | 94 | リクエスト情報のサニタイズ |
| 9 | 変換データ登録 | SAFSAMPLE1-END | 96 | リクエスト情報登録 |
| 10 | 画面出力処理 | SAFSAMPLE1-END | 103 | ヘッダ受信エラー時 |
| 11 | サニタイズ処理 | SAFSAMPLE1-END | 111 | ヘッダ値のサニタイズ |
| 12 | 変換データ登録 | SAFSAMPLE1-END | 113 | ヘッダ値登録 |
| 13 | 画面出力処理 | SAFSAMPLE1-END | 117 | 最終画面出力 |
| 14 | 画面出力処理 | 継続画面出力処理終了 | 129 | エラー時 |
| 15 | 画面出力処理 | アクセスカウンタ登録処理終了 | 139 | エラー時 |
| 16 | 物理パス名取得 | 変換データ登録終了 | 149 | パス未取得時のみ |

### 7.2 PERFORM VARYING（反復ループ）

| 対象 | 反復変数 | 初期値 | 増分 | 終了条件 | 所属ブロック | 行 |
|------|---------|--------|------|----------|-------------|----|
| （インライン） | WORK-CNTR1 | 1 | 1 | WORK-CNTR1 > CONVERT-LENGTH | 物理パス名取得終了 ※ | 181 |

※ block割当の不整合あり（5.8参照）。実際はサニタイズ処理 SECTION 内のループ。

CONVERT-VALUE の文字を1文字ずつ走査し、HTML特殊文字をエンティティに変換して SANITIZED-DATA に格納する。

## 8. 外部インタフェース

| No. | 呼出先 | USING | GIVING | 所属ブロック | 行 | 備考 |
|-----|--------|-------|--------|-------------|----|------|
| 1 | "COBW3_INIT" | COBW3 | - | SAFSAMPLE1-START | 40 | 環境初期化 |
| 2 | "COBW3_GET_COOKIE_XX" | COBW3 | - | SAFSAMPLE1-START | 45 | クッキー取得 |
| 3 | "COBW3_FREE" | COBW3 | - | 終了位置 | 61 | リソース解放 |
| 4 | "COBW3_GET_REQUEST_INFO" | COBW3 | - | SAFSAMPLE1-END | 83 | リクエスト情報取得（リモートホスト） |
| 5 | "COBW3_RECEIVE_HEADER" | COBW3 | - | SAFSAMPLE1-END | 100 | HTTPヘッダ受信 |
| 6 | "COBW3_SET_COOKIE_XX" | COBW3 | - | 継続画面出力処理終了 | 126 | クッキー設定 |
| 7 | "COBW3_SET_CNV_NX" | COBW3 | - | アクセスカウンタ登録処理終了 | 136 | 変換データ次エントリ登録 |
| 8 | "COBW3_PUT_HTML" | COBW3 | - | 変換データ登録終了 | 160 | HTML出力 |
| 9 | "COBW3_GET_REQUEST_INFO" | COBW3 | - | 画面出力処理終了 | 168 | リクエスト情報取得（物理パス） |

すべての外部CALLの引数は COBW3 のみ。COBW3 の内部データ項目を通じてパラメタを授受する設計と推定される。

## 9. 例外・制約事項

### 9.1 warnings

1. **tree-sitter-cobol の解析欠落をソース行ベースで補完しました。**
   — パーサーの解析精度に制限があり、一部の情報がソース行からの推定に依存している。

1. **COPY句を検出しました。コピー元展開後の解析は未実装です。**
   — COBW3 関連のデータ項目定義（COBW3, COBW3-STATUS 等）は COPY 句により導入されているが、展開後の解析が未実装のため、これらのデータ構造の詳細は不明。

### 9.2 エラー処理パターン

COBW3 API 呼出し後、`COBW3-STATUS ≠ ZERO` により一貫してエラーチェックを行っている。エラー時は HTMLFILENAME を設定し、画面出力処理（PERFORM 画面出力処理）を実行する共通パターンを採用している。

### 9.3 parser のblock割当不整合

行 178–200 のサニタイズロジック（WORK-CNTR1, WORK-CNTR2, SANITIZED-DATA への操作）は、JSON上 block = "物理パス名取得終了" とされているが、行番号的にサニタイズ処理 SECTION（行 177開始）に含まれる。サニタイズ処理 SECTION の内容として解釈することを推奨。

### 9.4 MOVE文のsource欠落

多数の MOVE mutations で `sources` が空配列となっている。実際の MOVE 先と MOVE 元の完全な対応関係はソースコード直読で確認が必要。

### 9.5 AT END / ファイル終了条件

`file_operations` が空のため、AT END 処理の有無はJSONからは読み取れない。

## 10. トレーサビリティ

| 処理概要 | ソース行 | 根拠JSON要素 |
|---------|---------|-------------|
| プログラム開始・COBW3初期化 | 32–40 | paragraphs(SAFSAMPLE1-START), calls(line 40) |
| クッキー取得 | 44–45 | mutations(line 44), calls(line 45) |
| エラー分岐（ステータスチェック） | 46 | conditions(line 46) |
| クッキーあり分岐 | 49 | conditions(line 49) |
| アクセスカウント更新 | 70–73 | mutations(lines 70–73) |
| リクエスト情報取得（リモートホスト） | 82–83 | mutations(line 82), calls(line 83) |
| サニタイズ対象設定（リクエスト情報） | 92–93 | mutations(lines 92–93) |
| サニタイズ実行（リクエスト情報） | 94 | loops(line 94) |
| HTTPヘッダ受信 | 99–100 | mutations(line 99), calls(line 100) |
| サニタイズ対象設定（ヘッダ値） | 109–110 | mutations(lines 109–110) |
| サニタイズ実行（ヘッダ値） | 111 | loops(line 111) |
| COBW3リソース解放 | 61 | calls(line 61) |
| サニタイズループ（文字走査） | 178–200 | mutations(lines 178–200), conditions(line 184), event_handlers(lines 185–194) |
| HTML特殊文字変換（\<, >, &） | 185–194 | event_handlers(lines 185, 188, 191, 194) |
| 物理パス取得 | 166–171 | mutations(lines 166–171) |
| HTML出力 | 160 | calls(line 160) |
| ファイルパス構築 | 151–157 | mutations(lines 151–157) |
