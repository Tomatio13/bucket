# sar-analyze 設計書

## 1. 目的

`sar-analyze` は、Linux の `sar` / `sadf` データをもとに、性能試験・長時間安定化試験向けの分析結果を生成するためのツールです。  
入力データから前処理、分析、可視化、レポート生成、LLM 向け入力生成までを一連で扱います。

今回の拡張では、ローカル LLM の入力長制約に対応するため、Python 側で LLM 入力を自動分割する仕組みを追加しました。

## 2. 設計方針

- 小規模データでは従来どおり単発 prompt を使う
- 長時間データでは Python 側で自動判定して分割 prompt を生成する
- 分割判定の閾値と時間窓は config で変更可能にする
- 顧客向け Markdown レポート生成の既存挙動は壊さない
- LLM 分割は `compact.json` に埋め込み、後段の prompt 生成スクリプトで利用する

## 3. 全体構成

### 3.1 処理フロー

1. 入力ファイルを読み込む
2. 前処理を行う
3. 分析結果を計算する
4. Markdown / JSON / compact JSON を生成する
5. compact JSON 生成時に LLM 分割判定を行う
6. `build_llm_prompt.py` が単発 prompt か分割 bundle を生成する

### 3.2 関連ファイル

- [scripts/analyze-sar.sh](../sar-analyze/scripts/analyze-sar.sh)
- [scripts/sar_analyze/cli.py](../sar-analyze/scripts/sar_analyze/cli.py)
- [scripts/sar_analyze/preprocess.py](../sar-analyze/scripts/sar_analyze/preprocess.py)
- [scripts/sar_analyze/analysis.py](../sar-analyze/scripts/sar_analyze/analysis.py)
- [scripts/sar_analyze/report.py](../sar-analyze/scripts/sar_analyze/report.py)
- [scripts/sar_analyze/llm_partition.py](../sar-analyze/scripts/sar_analyze/llm_partition.py)
- [scripts/build_llm_prompt.py](../sar-analyze/scripts/build_llm_prompt.py)
- [scripts/assets/llm_partition_config.json](../sar-analyze/scripts/assets/llm_partition_config.json)

## 4. LLM 入力分割設計

### 4.1 背景

長時間の `sar` データでは、10 秒周期で 72 時間のようなケースがありえます。  
この場合、1 系列あたり約 25,920 サンプルになり、全期間を単発 prompt に詰めると次の問題が起きます。

- prompt 長がローカル LLM の制限を超えやすい
- 一過性の異常や劣化開始点が埋もれる
- 観点ごとの評価が不安定になる

このため、分割戦略として `時分割 + 観点別要約 + 最終統合` を採用します。

### 4.2 分割の責務

#### Python 側

- 分割が必要かどうかの判定
- 時間窓単位への分割
- 観点別 packet の生成
- 最終統合用の全体コンテキスト生成

#### LLM 側

- 観点別 packet をもとに、日本語の要約を作る
- 最終統合 prompt で各観点の要約をマージする

### 4.3 分割判定

判定ロジックは [scripts/sar_analyze/llm_partition.py](../sar-analyze/scripts/sar_analyze/llm_partition.py) にあります。

入力条件:

- 総行数
- 総時間幅
- prompt 推定文字数
- `split_mode`

判定結果:

- `single`: 非分割
- `partitioned`: 分割

判定理由は `compact.json` の `llm_input.decision.reasons` に保存します。

### 4.4 config

設定値は JSON で持ちます。

- `split_mode`
  - `auto`: 閾値超過時のみ分割
  - `always`: 常に分割
  - `never`: 常に非分割
- `time_window`
  - 時分割単位。例: `1h`, `3h`, `30min`
- `max_rows_no_split`
  - 非分割を許容する最大行数
- `max_duration_no_split_hours`
  - 非分割を許容する最大時間幅
- `max_prompt_chars`
  - 非分割を許容する最大 prompt 文字数目安
- `enable_dimension_split`
  - `true` の場合、CPU / メモリ / I/O / ネットワークに分割
  - `false` の場合、時間窓だけ分割して 1 本の `all` packet にまとめる
- `dimensions`
  - 対象観点の並び順

### 4.5 packet 構造

`compact.json` の `llm_input` に次を持たせます。

- `strategy`
- `decision`
- `global_context`
- `dimension_packets`
- `final_report_requirements`

#### `global_context`

- 入力期間
- 行数
- サンプリング間隔
- 前処理メモ
- 全体仮説
- 全体の相関 / lag / Granger / anomaly / change point

#### `dimension_packets`

各 packet は 1 観点を表します。

- `dimension`
- `metrics`
- `window_summaries`

各 `window_summary` は次を持ちます。

- `window.start`
- `window.end`
- `window.rows`
- `metric_snapshot`
- `hypotheses`
- `events.anomalies`
- `events.change_points`

## 5. prompt 生成設計

### 5.1 単発 prompt

`llm_input.strategy == single` の場合、従来どおり `compact.json` 全体をテンプレートへ埋め込みます。

### 5.2 分割 prompt bundle

`llm_input.strategy == partitioned` の場合、[scripts/build_llm_prompt.py](../sar-analyze/scripts/build_llm_prompt.py) は bundle を出力します。

bundle には以下を含みます。

1. 観点別 prompt
2. 最終統合 prompt

観点別 prompt は、各観点について以下の出力を要求します。

- 全体傾向
- 時間帯ごとの特記事項
- 根拠指標
- 追加確認事項

最終統合 prompt は、観点別要約を貼り付けて最終レポート化するためのものです。

## 6. CLI / シェル連携

### 6.1 CLI

[scripts/sar_analyze/cli.py](../sar-analyze/scripts/sar_analyze/cli.py) に `--llm-config` を追加しています。

用途:

- 既定 config の上書き
- 環境別の閾値切り替え
- ローカル LLM ごとの分割単位調整

### 6.2 シェルスクリプト

[scripts/analyze-sar.sh](../sar-analyze/scripts/analyze-sar.sh) は `SAR_ANALYZE_LLM_CONFIG` を受け取り、compact JSON 生成時だけ `--llm-config` を渡します。

これにより、通常の Markdown / full JSON 出力を壊さず、LLM 用出力だけ切り替えられます。

## 7. 互換性

- Markdown レポート生成には影響しません
- full JSON の構造は維持します
- compact JSON には `llm_input` が追加されます
- `build_llm_prompt.py` は従来の単発 prompt 生成と新しい bundle 生成の両方を扱います

## 8. テスト方針

### 8.1 自動テスト

- 小規模データで `single` になること
- 長時間データで `partitioned` になること
- 分割 bundle に観点別 prompt と最終統合 prompt が含まれること

対象:

- [tests/test_llm_partition.py](../tests/test_llm_partition.py)
- [tests/test_build_llm_prompt.py](../tests/test_build_llm_prompt.py)

### 8.2 手動確認ポイント

- 72 時間級データで `llm_input.decision.reasons` が期待どおりか
- `time_window` を `1h` / `3h` で切り替えたとき packet 数が変わるか
- `enable_dimension_split=false` で `all` packet になるか
- 生成された bundle をローカル LLM に順に投入できるか

## 9. 今後の拡張候補

- しきい値ベースではなく token 推定の精度向上
- 試験フェーズ単位の分割
- packet ごとの chart 参照情報追加
- bundle を 1 テキストではなく複数ファイルへ出力する機能
