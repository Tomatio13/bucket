from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class CollectionPhase3Tests(unittest.TestCase):
    def test_collect_script_requests_extended_metrics(self) -> None:
        content = (ROOT / "sar-analyze" / "scripts" / "collect-sar.sh").read_text(encoding="utf-8")

        self.assertIn("-n DEV,EDEV,TCP,ETCP,SOCK,SOFT", content)
        self.assertIn("-q ALL", content)
        self.assertIn("-B", content)
        self.assertIn("-W", content)

    def test_export_script_requests_extended_metrics(self) -> None:
        content = (ROOT / "sar-analyze" / "scripts" / "export-raw-sar.sh").read_text(encoding="utf-8")

        self.assertIn("-n DEV,EDEV,TCP,ETCP,SOCK,SOFT", content)
        self.assertIn("-q ALL", content)
        self.assertIn("-B", content)
        self.assertIn("-W", content)

    def test_io_module_requests_extended_metrics(self) -> None:
        content = (ROOT / "sar-analyze" / "scripts" / "sar_analyze" / "io.py").read_text(encoding="utf-8")

        self.assertIn("DEV,EDEV,TCP,ETCP,SOCK,SOFT", content)
        self.assertIn("\"ALL\"", content)


if __name__ == "__main__":
    unittest.main()
