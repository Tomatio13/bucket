from __future__ import annotations

import sys
from pathlib import Path
import unittest
import warnings

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sar-analyze" / "scripts"))

from sar_analyze.io import LoadedDataset
from sar_analyze.preprocess import preprocess_dataset


class PreprocessPhase2Tests(unittest.TestCase):
    def test_metric_aliases_are_normalized_for_device_columns(self) -> None:
        frame = pd.DataFrame(
            {
                "timestamp": ["2026-04-12T00:00:00Z", "2026-04-12T00:00:10Z"],
                "%usr": [10, 20],
                "%sys": [5, 6],
                "sda__avgqu-sz": [0.5, 2.0],
                "sdb__avgqu-sz": [0.7, 1.5],
            }
        )
        dataset = LoadedDataset(
            path=Path("dummy.tsv"),
            format="sadf-d",
            frame=frame,
            notes=[],
        )

        result = preprocess_dataset(dataset, resample_rule="")

        self.assertIn("%user", result.frame.columns)
        self.assertIn("%system", result.frame.columns)
        self.assertIn("aqu-sz", result.frame.columns)
        self.assertEqual([0.7, 2.0], [round(float(value), 1) for value in result.frame["aqu-sz"].tolist()])

    def test_new_numeric_candidates_are_kept_numeric(self) -> None:
        frame = pd.DataFrame(
            {
                "timestamp": [
                    "2026-04-12T00:00:00Z",
                    "2026-04-12T00:00:10Z",
                ],
                "%steal": ["1.5", "2.0"],
                "%irq": ["0.3", "0.4"],
                "%soft": ["0.8", "1.2"],
                "majflt/s": ["0", "3"],
                "pswpin/s": ["0", "1"],
                "pswpout/s": ["0", "2"],
            }
        )
        dataset = LoadedDataset(path=Path("dummy.tsv"), format="sadf-d", frame=frame, notes=[])

        result = preprocess_dataset(dataset, resample_rule="")

        for column in ["%steal", "%irq", "%soft", "majflt/s", "pswpin/s", "pswpout/s"]:
            self.assertTrue(pd.api.types.is_numeric_dtype(result.frame[column]))

    def test_preprocess_does_not_emit_fragmentation_warning_for_missing_flags(self) -> None:
        frame = pd.DataFrame(
            {
                "timestamp": ["2026-04-12T00:00:00Z", "2026-04-12T00:00:10Z"],
                **{f"metric_{idx}": [idx, idx + 1] for idx in range(50)},
                "%idle": [90, 91],
                "majflt/s": [0, 1],
            }
        )
        dataset = LoadedDataset(path=Path("dummy.tsv"), format="sadf-d", frame=frame, notes=[])

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            preprocess_dataset(dataset, resample_rule="")

        messages = [str(item.message) for item in caught]
        self.assertFalse(any("highly fragmented" in message for message in messages))


if __name__ == "__main__":
    unittest.main()
