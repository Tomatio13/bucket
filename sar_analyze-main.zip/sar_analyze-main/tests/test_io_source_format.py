from __future__ import annotations

import sys
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sar-analyze" / "scripts"))

from sar_analyze.io import load_dataset


class LoadDatasetSourceFormatTests(unittest.TestCase):
    def test_sadf_p_export_can_preserve_raw_sar_source_note(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            export_path = Path(temp_dir) / "capture.tsv"
            export_path.write_text("placeholder\n", encoding="utf-8")

            frame = pd.DataFrame(
                {
                    "hostname": ["host"],
                    "interval": ["1"],
                    "timestamp": ["2026-04-12T00:00:00Z"],
                    "device": ["all"],
                    "field": ["%idle"],
                    "value": ["90.0"],
                }
            )

            with patch("sar_analyze.io._read_sadf_p_file", return_value=frame):
                dataset = load_dataset(export_path, fmt="sadf-p", source_format="raw-sar")

        self.assertEqual("sadf-p", dataset.format)
        self.assertEqual("raw-sar", dataset.source_format)
        self.assertEqual(
            "Loaded raw sar binary via sadf -p export with expanded metric options.",
            dataset.notes[0],
        )


if __name__ == "__main__":
    unittest.main()
