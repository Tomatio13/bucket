from __future__ import annotations

import sys
from pathlib import Path
import unittest

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sar-analyze" / "scripts"))

from sar_analyze.analysis import AnalysisResult
from sar_analyze.preprocess import PreprocessResult
from sar_analyze.report import build_compact_report_payload, render_report


class ReportHypothesisMetadataTests(unittest.TestCase):
    def test_compact_payload_preserves_hypothesis_metadata(self) -> None:
        preprocessed = PreprocessResult(
            frame=pd.DataFrame({"cpu_busy": [10.0]}, index=pd.to_datetime(["2026-04-12T00:00:00Z"])),
            notes=[],
            derived_columns=[],
            missing_columns=[],
            sampling_interval="60s",
        )
        analysis = AnalysisResult(
            summary={"correlations": [], "lag_analysis": [], "granger": [], "anomalies": [], "change_points": {}},
            bottleneck_hypotheses=[
                {
                    "type": "cpu",
                    "confidence": "medium",
                    "reason": "test",
                    "score": 0.74,
                    "evidence": {"cpu_busy_p95": 91.2},
                }
            ],
            method_notes=[],
        )

        payload = build_compact_report_payload(preprocessed, analysis)

        self.assertEqual(0.74, payload["hypotheses"][0]["score"])
        self.assertEqual({"cpu_busy_p95": 91.2}, payload["hypotheses"][0]["evidence"])

    def test_render_report_includes_score_and_evidence(self) -> None:
        preprocessed = PreprocessResult(
            frame=pd.DataFrame({"cpu_busy": [10.0]}, index=pd.to_datetime(["2026-04-12T00:00:00Z"])),
            notes=[],
            derived_columns=[],
            missing_columns=[],
            sampling_interval="60s",
        )
        analysis = AnalysisResult(
            summary={"correlations": [], "lag_analysis": [], "granger": [], "anomalies": [], "change_points": {}},
            bottleneck_hypotheses=[
                {
                    "type": "cpu",
                    "confidence": "medium",
                    "reason": "cpu high",
                    "score": 0.74,
                    "evidence": {"cpu_busy_p95": 91.2},
                }
            ],
            method_notes=[],
        )

        report = render_report(preprocessed, analysis)

        self.assertIn("score=0.740", report)
        self.assertIn("根拠指標: cpu_busy_p95=91.2", report)


if __name__ == "__main__":
    unittest.main()
