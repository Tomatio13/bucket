from __future__ import annotations

import sys
from pathlib import Path
import unittest

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "sar-analyze" / "scripts"))

from sar_analyze.analysis import _build_hypotheses


def build_summary() -> dict:
    return {"correlations": []}


class BuildHypothesesPhase1Tests(unittest.TestCase):
    def test_runqueue_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "runq-sz": [0.2, 0.3, 0.4, 0.5, 4.5, 5.0],
                "cpu_busy": [20, 22, 24, 26, 70, 72],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("runqueue-high", {item["type"] for item in hypotheses})
        runqueue = next(item for item in hypotheses if item["type"] == "runqueue-high")
        self.assertIn("score", runqueue)
        self.assertIn("evidence", runqueue)
        self.assertIn("runq_p95", runqueue["evidence"])

    def test_blocked_tasks_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "blocked": [0, 0, 0, 1, 3, 4],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("blocked-tasks-high", {item["type"] for item in hypotheses})

    def test_loadavg_high_with_low_runq_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "ldavg-1": [0.8, 1.0, 1.2, 2.2, 2.8, 3.1],
                "runq-sz": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
                "blocked": [0, 0, 1, 1, 2, 2],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("loadavg-high-with-low-runq", {item["type"] for item in hypotheses})

    def test_cpu_system_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%system": [5, 6, 7, 8, 22, 24],
                "%user": [6, 7, 7, 8, 18, 19],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-system-high", {item["type"] for item in hypotheses})

    def test_context_switch_storm_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "cswch/s": [100, 120, 140, 160, 1800, 2200],
                "runq-sz": [0.3, 0.4, 0.5, 0.6, 1.5, 2.0],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("context-switch-storm", {item["type"] for item in hypotheses})

    def test_cpu_user_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%user": [12, 14, 16, 18, 48, 55],
                "runq-sz": [0.3, 0.4, 0.5, 0.7, 1.2, 1.5],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-user-high", {item["type"] for item in hypotheses})

    def test_short_series_falls_back_to_undetermined(self) -> None:
        numeric = pd.DataFrame(
            {
                "runq-sz": [0.1, 4.0, 4.5, 5.0],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertEqual(["undetermined"], [item["type"] for item in hypotheses])
        self.assertEqual(0.2, hypotheses[0]["score"])

    def test_cpu_steal_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%steal": [0.5, 0.8, 1.0, 1.2, 7.0, 8.5],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-steal-high", {item["type"] for item in hypotheses})

    def test_cpu_irq_storm_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%irq": [0.2, 0.3, 0.4, 0.5, 3.5, 4.2],
                "%system": [3.0, 4.0, 4.5, 5.0, 6.5, 7.0],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-irq-storm", {item["type"] for item in hypotheses})

    def test_cpu_softirq_storm_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%soft": [0.4, 0.5, 0.7, 0.9, 5.5, 6.3],
                "net_bytes_s": [1000, 1200, 1500, 1800, 5000, 7000],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-softirq-storm", {item["type"] for item in hypotheses})

    def test_disk_queue_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "aqu-sz": [0.1, 0.2, 0.3, 0.4, 2.5, 3.2],
                "await": [5, 6, 7, 8, 15, 18],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("disk-queue-high", {item["type"] for item in hypotheses})

    def test_major_faults_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "majflt/s": [0, 1, 1, 2, 12, 18],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("major-faults-high", {item["type"] for item in hypotheses})

    def test_swap_inout_high_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "pswpin/s": [0, 0, 0, 1, 2, 3],
                "pswpout/s": [0, 0, 1, 1, 2, 4],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("swap-inout-high", {item["type"] for item in hypotheses})

    def test_cpu_pressure_stall_is_reported(self) -> None:
        numeric = pd.DataFrame({"%scpu": [1, 2, 3, 4, 12, 18]})

        hypotheses = _build_hypotheses(numeric, build_summary())

        self.assertIn("cpu-pressure-stall", {item["type"] for item in hypotheses})

    def test_io_pressure_and_swap_thrash_are_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%sio": [1, 2, 3, 4, 12, 16],
                "%fio": [0, 0, 1, 2, 8, 10],
                "pswpin/s": [0, 0, 0, 1, 2, 3],
                "pswpout/s": [0, 0, 1, 1, 2, 4],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())
        types = {item["type"] for item in hypotheses}

        self.assertIn("io-pressure-some", types)
        self.assertIn("io-pressure-full", types)
        self.assertIn("swap-thrashing-suspected", types)

    def test_memory_pressure_is_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "%smem": [1, 1, 2, 3, 9, 11],
                "%fmem": [0, 0, 0, 1, 4, 5],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())
        types = {item["type"] for item in hypotheses}

        self.assertIn("mem-pressure-stall-some", types)
        self.assertIn("mem-pressure-stall-full", types)

    def test_network_error_hypotheses_are_reported(self) -> None:
        numeric = pd.DataFrame(
            {
                "rxdrop/s": [0, 0, 0, 1, 3, 5],
                "txdrop/s": [0, 0, 0, 1, 1, 2],
                "rxerr/s": [0, 0, 0, 0, 1, 1],
                "txerr/s": [0, 0, 0, 0, 1, 2],
                "retrans/s": [0, 0, 1, 1, 3, 5],
                "dropd/s": [0, 0, 0, 0, 2, 3],
                "squeezd/s": [0, 0, 0, 0, 1, 1],
                "blg_len": [0, 0, 0, 1, 10, 14],
            }
        )

        hypotheses = _build_hypotheses(numeric, build_summary())
        types = {item["type"] for item in hypotheses}

        self.assertIn("net-drops-high", types)
        self.assertIn("net-errors-high", types)
        self.assertIn("tcp-retrans-high", types)
        self.assertIn("softnet-backlog-overflow", types)


if __name__ == "__main__":
    unittest.main()
