---
name: sar-analyze
description: End-to-end SAR analysis orchestrator for Linux performance investigations. Use this whenever the user wants to analyze sar/sadf files, compare Linux system activity over time, find bottlenecks from sysstat data, or turn sar-derived CSV into an SRE-style report with evidence and follow-up actions.
compatibility: Requires Python 3.10+, sysstat (sar/sadf), and access to the scripts bundled inside this skill directory.
---

# SAR Analyze

This skill is the entry point for the SAR analysis workflow. It coordinates export, preprocessing, analysis, visualization, and LLM-ready reporting.

This is the only supported skill entry point in this repository.

## Use this skill when

- The user wants an end-to-end analysis from `saDD`, `saYYYYMMDD`, `sadf -d`, or `sadf -p` data.
- The user asks for Linux performance diagnosis from sar/sysstat metrics.
- The user wants bottleneck hypotheses with evidence and next investigation steps.
- The user wants a report rather than only a single chart or single statistic.

## Workflow

1. Identify the input form.
   If the user has no capture yet, run `scripts/collect-sar.sh`.
   If the user already has a `.bin`, `sadf -d`, or `sadf -p` file, continue directly.
2. Produce the standard artifacts with `scripts/analyze-sar.sh`.
   This writes:
   `*.md`, `*.json`, `*.compact.json`, `*.prompt.txt`, `*_charts/*.png`
3. If the user asked for analysis in natural language, ingest the generated `*.prompt.txt` back into the agent context and use it to produce the final narrative summary.
4. If the user only wants one stage, use the corresponding script inside this skill directory.

## Script resolution

- Resolve every relative path in this file relative to the `sar-analyze/` skill directory that contains this `SKILL.md`, not relative to the user's current working directory.
- If the agent runtime already provides the path to this `SKILL.md` or the installed skill directory, treat that path as authoritative. Do not try to rediscover the skill by scanning the filesystem.
- `scripts/analyze-sar.sh` means the script shipped with this skill under the active agent's skill installation root.
- Do not use broad filesystem searches such as `find / ...`, `Glob **/sar-analyze/**`, or similar discovery probes just to locate this skill. They are slow and may select stale copies from unrelated workspaces.
- If direct file-reading tools are restricted to the current working directory, use the already-known installed skill path with shell commands such as `ls` or `cat` instead of guessing another copy.
- Do not scaffold a new `scripts/` directory or a new `sar_analyze/` package inside the user's capture directory when the bundled skill scripts already exist.
- Use the user's working directory only for inputs and generated outputs such as reports and charts. Prefer a shared `.venv` under the active skill bundle root.

## Setup

Before running this skill, always check whether a shared `.venv` exists in the active skill bundle root.

If it does not exist, create and activate it first:

```bash
test -d ../.venv || python -m venv ../.venv
. ../.venv/bin/activate
```

Then install the required Python dependency:

```bash
pip install pandas
```

If you also need chart generation or richer statistical analysis:

```bash
pip install matplotlib statsmodels
```

## Standard commands

- Collect a multi-metric binary:
  `scripts/collect-sar.sh 5 120 my_capture.bin`
- Analyze a raw sar binary:
  `scripts/analyze-sar.sh my_capture.bin 5s my_capture_report raw-sar`
- Analyze an existing `sadf -d` export:
  `scripts/analyze-sar.sh export.csv 1min export_report sadf-d`
- Analyze an existing `sadf -p` export:
  `scripts/analyze-sar.sh export.tsv 1min export_report sadf-p`
- Export raw sar only:
  `scripts/export-raw-sar.sh my_capture.bin sadf-p`
- Generate charts only:
  `python scripts/generate_charts.py my_capture.bin --format raw-sar --resample 5s --output-dir charts`
- Build only the LLM handoff prompt:
  `python scripts/build_llm_prompt.py my_capture_report.compact.json --output my_capture_report.prompt.txt`

## Operating rules

- Treat preprocessing policy as shared infrastructure. Do not let each analysis invent its own timezone, missing-value, or unit rules.
- Prefer evidence over narrative. Report which metrics moved together, which moved earlier or later, and where uncertainty remains.
- Do not claim causality from correlation, CCF, or Granger alone.
- If the input is incomplete, state exactly what is missing and what can still be inferred safely.
- Do not paste `sadf` raw rows into the agent conversation unless the user explicitly asks for them. Keep raw exports in files and surface only counts, time range, schema, and derived findings.
- For `raw-sar` inputs, export once and reuse that file across charts and report generation instead of rerunning `sadf` for each stage.
- Prefer invoking the shipped workflow script over ad-hoc script generation. Only write new code when the bundled workflow is missing or proven broken.
- When a human-readable answer is requested, do not stop at writing `*.prompt.txt`. Read that prompt file and use it as the direct input to the final agent-side synthesis step.
- Prefer the installed skill copy that the current agent actually loaded. Ignore duplicate copies under unrelated workspaces unless the user explicitly points to one.

## Output expectations

Produce a concise report with:

- Input summary
- Preprocessing policy used
- Top bottleneck hypotheses
- Evidence by metric or method
- Immediate next checks
- Longer-term remediation candidates
- The human-readable Markdown report must be written in Japanese.
- If charts are available, embed the generated PNG files directly in the Markdown report with relative paths.
- If the user wants LLM handoff, prefer `*.compact.json` and `*.prompt.txt` over the full JSON.

## References

This skill is intentionally self-contained; prefer the scripts above over extra wrapper files.
