#!/usr/bin/env bash
set -euo pipefail

INPUT_PATH="${1:?input .bin is required}"
MODE="${2:-sadf-p}"

case "${MODE}" in
  sadf-p)
    exec sadf -p "${INPUT_PATH}" -- -u ALL -r ALL -S -b -d -n DEV -q LOAD -w -I SUM
    ;;
  sadf-d)
    exec sadf -d "${INPUT_PATH}" -- -u ALL -r ALL -S -b -d -n DEV -q LOAD -w -I SUM
    ;;
  *)
    echo "unsupported mode: ${MODE}. use sadf-p or sadf-d" >&2
    exit 1
    ;;
esac
