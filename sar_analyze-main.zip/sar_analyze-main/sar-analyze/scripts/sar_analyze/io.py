from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess
from io import StringIO
import tempfile
from typing import Literal

import pandas as pd

SadfFormat = Literal["sadf-d", "sadf-p", "raw-sar"]


@dataclass(slots=True)
class LoadedDataset:
    path: Path
    format: SadfFormat
    frame: pd.DataFrame
    notes: list[str]
    source_format: SadfFormat | None = None


def detect_format(path: Path) -> SadfFormat:
    if path.suffix in {".bin", ".sar"}:
        return "raw-sar"
    sample = path.read_text(encoding="utf-8", errors="ignore").splitlines()[:5]
    if any(";" in line for line in sample):
        return "sadf-d"
    return "sadf-p"


def load_dataset(
    path: str | Path,
    fmt: SadfFormat | None = None,
    *,
    source_format: SadfFormat | None = None,
) -> LoadedDataset:
    resolved = Path(path).expanduser().resolve()
    if not resolved.exists():
        raise FileNotFoundError(f"input file not found: {resolved}")

    dataset_format = fmt or detect_format(resolved)
    effective_source_format = source_format or dataset_format
    notes: list[str] = []

    if dataset_format == "raw-sar":
        with tempfile.TemporaryDirectory(prefix="sar-analyze-") as temp_dir:
            export_path = Path(temp_dir) / f"{resolved.stem}.sadf-p.tsv"
            _export_raw_sar_to_path(resolved, export_path)
            frame = _read_sadf_p_file(export_path)
        notes.append("Loaded raw sar binary via sadf -p export with expanded metric options.")
    elif dataset_format == "sadf-d":
        frame = _read_sadf_d_text(resolved.read_text(encoding="utf-8", errors="ignore"))
        notes.append("Loaded as sadf -d style semicolon-delimited data.")
    else:
        frame = _read_sadf_p_file(resolved)
        if effective_source_format == "raw-sar":
            notes.append("Loaded raw sar binary via sadf -p export with expanded metric options.")
        else:
            notes.append("Loaded as sadf -p style tidy/tab-delimited data.")

    return LoadedDataset(
        path=resolved,
        format=dataset_format,
        source_format=effective_source_format,
        frame=frame,
        notes=notes,
    )


def _export_raw_sar_to_path(input_path: Path, output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8") as handle:
        subprocess.run(
            [
                "sadf",
                "-p",
                str(input_path),
                "--",
                "-u",
                "ALL",
                "-r",
                "ALL",
                "-S",
                "-B",
                "-W",
                "-b",
                "-d",
                "-n",
                "DEV,EDEV,TCP,ETCP,SOCK,SOFT",
                "-q",
                "ALL",
                "-w",
                "-I",
                "SUM",
            ],
            check=True,
            stdout=handle,
            text=True,
        )


def _read_sadf_p_file(path: Path) -> pd.DataFrame:
    return pd.read_csv(
        path,
        sep="\t",
        header=None,
        names=["hostname", "interval", "timestamp", "device", "field", "value"],
    )


def _read_sadf_d_text(text: str) -> pd.DataFrame:
    lines = text.splitlines()
    if lines and lines[0].startswith("# "):
        lines[0] = lines[0][2:]
    normalized = "\n".join(lines)
    return pd.read_csv(StringIO(normalized), sep=";")


def pivot_sadf_p(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"hostname", "interval", "timestamp", "device", "field", "value"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"sadf -p frame is missing columns: {sorted(missing)}")

    normalized = frame.assign(device=frame["device"].fillna("all").astype(str))
    normalized["metric_name"] = normalized.apply(_build_metric_name, axis=1)

    pivoted = (
        normalized.pivot_table(
            index=["hostname", "interval", "timestamp"],
            columns="metric_name",
            values="value",
            aggfunc="first",
        )
        .reset_index()
    )
    pivoted.columns.name = None
    return pivoted


def _build_metric_name(row: pd.Series) -> str:
    device = str(row["device"])
    field = str(row["field"])
    if device in {"all", "-", "-1", "CPU*", ""}:
        return field
    return f"{device}__{field}"
