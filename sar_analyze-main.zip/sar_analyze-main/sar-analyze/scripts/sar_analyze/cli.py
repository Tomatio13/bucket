from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analysis import analyze_dataset
from .io import load_dataset
from .preprocess import preprocess_dataset, summarize_preprocessing
from .report import build_compact_report_payload, build_report_payload, render_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sar-analyze")
    parser.add_argument("input", help="Path to a sadf -d/-p export file.")
    parser.add_argument("--format", choices=["sadf-d", "sadf-p", "raw-sar"], default=None)
    parser.add_argument(
        "--source-format",
        choices=["sadf-d", "sadf-p", "raw-sar"],
        default=None,
        help="Original input format when the provided file is an intermediate export.",
    )
    parser.add_argument("--resample", default="1min", help="Pandas resample rule.")
    parser.add_argument("--report", choices=["text", "json"], default="text")
    parser.add_argument("--json-profile", choices=["full", "compact"], default="full")
    parser.add_argument(
        "--chart",
        action="append",
        default=[],
        help="Optional chart path to embed into the Markdown report. Can be specified multiple times.",
    )
    parser.add_argument("--output", default=None, help="Optional output file path.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    dataset = load_dataset(args.input, fmt=args.format, source_format=args.source_format)
    preprocessed = preprocess_dataset(dataset, resample_rule=args.resample)
    analysis = analyze_dataset(preprocessed)

    if args.report == "json":
        if args.json_profile == "compact":
            payload = build_compact_report_payload(preprocessed, analysis)
        else:
            payload = build_report_payload(preprocessed, analysis)
        payload["preprocessing_summary"] = summarize_preprocessing(preprocessed)
        content = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        content = render_report(preprocessed, analysis, chart_paths=args.chart)

    if args.output:
        Path(args.output).write_text(content, encoding="utf-8")
    else:
        print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
