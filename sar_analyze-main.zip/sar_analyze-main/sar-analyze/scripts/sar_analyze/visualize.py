from __future__ import annotations

from pathlib import Path

try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover - optional dependency
    plt = None

import pandas as pd

from .preprocess import PreprocessResult

CHART_STYLE = {
    "figure.facecolor": "#f8fafc",
    "axes.facecolor": "#ffffff",
    "axes.edgecolor": "#cbd5e1",
    "axes.labelcolor": "#0f172a",
    "axes.titleweight": "bold",
    "axes.titlesize": 13,
    "axes.labelsize": 10,
    "grid.color": "#dbe4f0",
    "grid.linestyle": "--",
    "grid.linewidth": 0.8,
    "xtick.color": "#334155",
    "ytick.color": "#334155",
    "font.size": 10,
    "legend.frameon": False,
    "savefig.facecolor": "#f8fafc",
    "savefig.bbox": "tight",
    "savefig.dpi": 160,
}

SERIES_STYLE = {
    "cpu_busy": {"label": "CPU Busy (%)", "color": "#2563eb"},
    "%iowait": {"label": "CPU I/O Wait (%)", "color": "#dc2626"},
    "%user": {"label": "CPU User (%)", "color": "#0f766e"},
    "%system": {"label": "CPU System (%)", "color": "#7c3aed"},
    "kbavail": {"label": "Mem Available (KiB)", "color": "#0891b2"},
    "kbswpused": {"label": "Swap Used (KiB)", "color": "#ea580c"},
    "await": {"label": "Disk Await (ms)", "color": "#b91c1c"},
    "%util": {"label": "Disk Util (%)", "color": "#92400e"},
    "io_bytes_s": {"label": "Disk Throughput (B/s)", "color": "#475569"},
    "net_bytes_s": {"label": "Network Throughput (B/s)", "color": "#059669"},
    "runq-sz": {"label": "Run Queue", "color": "#4338ca"},
    "blocked": {"label": "Blocked Tasks", "color": "#be123c"},
}

TIMESERIES_PANELS = [
    {
        "title": "CPU",
        "ylabel": "percent",
        "columns": ["cpu_busy", "%iowait", "%user", "%system"],
    },
    {
        "title": "Memory",
        "ylabel": "KiB",
        "columns": ["kbavail", "kbswpused"],
    },
    {
        "title": "Storage I/O",
        "ylabel": "mixed",
        "columns": ["await", "%util", "io_bytes_s"],
    },
    {
        "title": "Network / Scheduler",
        "ylabel": "mixed",
        "columns": ["net_bytes_s", "runq-sz", "blocked"],
    },
]

HEATMAP_COLUMNS = [
    "cpu_busy",
    "%iowait",
    "%user",
    "%system",
    "await",
    "%util",
    "io_bytes_s",
    "kbavail",
    "kbswpused",
    "net_bytes_s",
    "runq-sz",
    "blocked",
]


def generate_basic_charts(preprocessed: PreprocessResult, output_dir: str | Path) -> list[str]:
    if plt is None:
        raise RuntimeError("matplotlib is not available. Install matplotlib to generate charts.")

    frame = preprocessed.frame.copy()
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    generated: list[str] = []

    with plt.rc_context(CHART_STYLE):
        timeseries_path = _generate_timeseries_chart(frame, outdir)
        if timeseries_path is not None:
            generated.append(str(timeseries_path))

        heatmap_path = _generate_correlation_heatmap(frame, outdir)
        if heatmap_path is not None:
            generated.append(str(heatmap_path))

    return generated


def _generate_timeseries_chart(frame: pd.DataFrame, outdir: Path) -> Path | None:
    panel_specs = [
        panel
        for panel in TIMESERIES_PANELS
        if any(column in frame.columns for column in panel["columns"])
    ]
    if not panel_specs:
        return None

    fig, axes = plt.subplots(
        nrows=len(panel_specs),
        ncols=1,
        figsize=(14, 2.8 * len(panel_specs) + 1.2),
        sharex=True,
    )
    if hasattr(axes, "flatten"):
        axes = list(axes.flatten())
    else:
        axes = [axes]

    for ax, panel in zip(axes, panel_specs):
        plotted = False
        for column in panel["columns"]:
            if column not in frame.columns:
                continue
            series = pd.to_numeric(frame[column], errors="coerce")
            if series.dropna().empty:
                continue
            style = SERIES_STYLE[column]
            ax.plot(
                frame.index,
                series,
                label=style["label"],
                color=style["color"],
                linewidth=1.8,
            )
            plotted = True

        ax.set_title(panel["title"], loc="left")
        ax.set_ylabel(panel["ylabel"])
        ax.grid(True, axis="y")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        if plotted:
            ax.legend(loc="upper left", ncol=2)

    axes[-1].set_xlabel("timestamp (UTC)")
    fig.suptitle("SAR Core Metrics Overview", x=0.08, ha="left", y=0.995, fontsize=15, fontweight="bold")
    path = outdir / "timeseries.png"
    fig.savefig(path)
    plt.close(fig)
    return path


def _generate_correlation_heatmap(frame: pd.DataFrame, outdir: Path) -> Path | None:
    corr_columns = [column for column in HEATMAP_COLUMNS if column in frame.columns]
    if len(corr_columns) < 2:
        return None

    corr = frame[corr_columns].apply(pd.to_numeric, errors="coerce").corr()
    labels = [SERIES_STYLE.get(column, {"label": column})["label"] for column in corr_columns]

    fig, ax = plt.subplots(figsize=(10, 7))
    im = ax.imshow(corr, cmap="RdBu_r", aspect="auto", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr_columns)))
    ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.set_yticks(range(len(corr_columns)))
    ax.set_yticklabels(labels)
    ax.set_title("Metric Correlation Heatmap", loc="left")

    for row_idx, row in enumerate(corr.to_numpy()):
        for col_idx, value in enumerate(row):
            text_color = "#e2e8f0" if abs(value) > 0.55 else "#0f172a"
            ax.text(col_idx, row_idx, f"{value:.2f}", ha="center", va="center", fontsize=8, color=text_color)

    colorbar = fig.colorbar(im, ax=ax, shrink=0.9)
    colorbar.set_label("correlation")

    path = outdir / "correlation_heatmap.png"
    fig.savefig(path)
    plt.close(fig)
    return path
