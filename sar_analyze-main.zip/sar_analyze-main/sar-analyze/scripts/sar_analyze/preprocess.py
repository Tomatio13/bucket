from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from .io import LoadedDataset, pivot_sadf_p


@dataclass(slots=True)
class PreprocessResult:
    frame: pd.DataFrame
    notes: list[str]
    derived_columns: list[str]
    missing_columns: list[str]
    sampling_interval: str | None


NUMERIC_CANDIDATES = [
    "%user",
    "%system",
    "%iowait",
    "%idle",
    "kbmemfree",
    "kbmemused",
    "kbcached",
    "kbavail",
    "kbswpfree",
    "kbswpused",
    "bread/s",
    "bwrtn/s",
    "rkB/s",
    "wkB/s",
    "await",
    "%util",
    "tps",
    "rxpck/s",
    "txpck/s",
    "rxkB/s",
    "txkB/s",
    "runq-sz",
    "blocked",
    "cswch/s",
    "ldavg-1",
    "ldavg-5",
    "ldavg-15",
]

COLUMN_ALIASES = {
    "%usr": "%user",
    "%sys": "%system",
}


def preprocess_dataset(
    dataset: LoadedDataset,
    *,
    resample_rule: str = "1min",
    timezone: str = "UTC",
) -> PreprocessResult:
    notes = list(dataset.notes)
    derived_columns: list[str] = []

    frame = dataset.frame.copy()
    if dataset.format in {"sadf-p", "raw-sar"}:
        frame = pivot_sadf_p(frame)
        notes.append("Pivoted sadf -p tidy data into a wide table.")

    frame = frame.rename(columns=COLUMN_ALIASES)
    renamed = [src for src, dest in COLUMN_ALIASES.items() if src in dataset.frame.columns or src in frame.columns]
    if renamed:
        notes.append(f"Normalized metric aliases: {', '.join(sorted(renamed))}")

    if "timestamp" not in frame.columns:
        raise ValueError("input dataset must contain a timestamp column")

    frame["timestamp"] = pd.to_datetime(frame["timestamp"], errors="coerce", utc=True)
    frame = frame.dropna(subset=["timestamp"]).sort_values("timestamp")
    frame = frame.set_index("timestamp")
    notes.append(f"Normalized timestamps to {timezone}.")

    aggregate_notes = _aggregate_device_metrics(frame)
    notes.extend(aggregate_notes)

    for column in NUMERIC_CANDIDATES:
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")

    missing_columns = [column for column in NUMERIC_CANDIDATES if column not in frame.columns]
    if missing_columns:
        notes.append(f"Metrics missing from input: {', '.join(missing_columns)}")

    if "%idle" in frame.columns:
        frame["cpu_busy"] = 100.0 - frame["%idle"]
        derived_columns.append("cpu_busy")
    if {"bread/s", "bwrtn/s"}.intersection(frame.columns):
        frame["io_bytes_s"] = (
            _series_or_zero(frame, "bread/s") + _series_or_zero(frame, "bwrtn/s")
        ) * 512.0
        derived_columns.append("io_bytes_s")
    if {"rxkB/s", "txkB/s"}.intersection(frame.columns):
        frame["net_bytes_s"] = (
            _series_or_zero(frame, "rxkB/s") + _series_or_zero(frame, "txkB/s")
        ) * 1024.0
        derived_columns.append("net_bytes_s")
    if {"%system", "%user"}.issubset(frame.columns):
        denom = (frame["%system"] + frame["%user"]).replace(0, pd.NA)
        frame["sys_ratio"] = frame["%system"] / denom
        derived_columns.append("sys_ratio")
    if {"kbavail", "kbmemused"}.issubset(frame.columns):
        denom = (frame["kbavail"] + frame["kbmemused"]).replace(0, pd.NA)
        frame["mem_avail_ratio"] = frame["kbavail"] / denom
        derived_columns.append("mem_avail_ratio")
    if {"kbswpused", "kbswpfree"}.issubset(frame.columns):
        denom = (frame["kbswpused"] + frame["kbswpfree"]).replace(0, pd.NA)
        frame["swap_used_ratio"] = frame["kbswpused"] / denom
        derived_columns.append("swap_used_ratio")

    frame["missing_input"] = False
    for column in NUMERIC_CANDIDATES:
        if column in frame.columns:
            frame[f"{column}_missing"] = frame[column].isna()

    sampling_interval = _estimate_sampling_interval(frame.index)
    if sampling_interval:
        notes.append(f"Estimated raw sampling interval: {sampling_interval}")

    numeric_columns = frame.select_dtypes(include=["number", "bool"]).columns.tolist()
    non_numeric_columns = [col for col in frame.columns if col not in numeric_columns]

    if resample_rule:
        resampled_numeric = frame[numeric_columns].resample(resample_rule).mean()
        resampled_non_numeric = frame[non_numeric_columns].resample(resample_rule).ffill()
        frame = pd.concat([resampled_non_numeric, resampled_numeric], axis=1)
        notes.append(f"Resampled dataset to {resample_rule}.")

    frame["hour_of_day"] = frame.index.hour
    frame["day_of_week"] = frame.index.dayofweek
    derived_columns.extend(["hour_of_day", "day_of_week"])

    return PreprocessResult(
        frame=frame,
        notes=notes,
        derived_columns=sorted(set(derived_columns)),
        missing_columns=missing_columns,
        sampling_interval=sampling_interval,
    )


def _estimate_sampling_interval(index: pd.Index) -> str | None:
    if len(index) < 2:
        return None
    diffs = pd.Series(index[1:] - index[:-1])
    if diffs.empty:
        return None
    mode = diffs.mode()
    value = mode.iloc[0] if not mode.empty else diffs.median()
    if pd.isna(value):
        return None
    seconds = int(value.total_seconds())
    if seconds <= 0:
        return None
    return f"{seconds}s"


def _series_or_zero(frame: pd.DataFrame, column: str) -> pd.Series:
    if column in frame.columns:
        return frame[column].fillna(0)
    return pd.Series(0, index=frame.index, dtype="float64")


def _aggregate_device_metrics(frame: pd.DataFrame) -> list[str]:
    notes: list[str] = []

    sum_metrics = ["rkB/s", "wkB/s", "tps", "rxpck/s", "txpck/s", "rxkB/s", "txkB/s"]
    max_metrics = ["await", "%util"]

    for metric in sum_metrics:
        cols = _candidate_metric_columns(frame, metric)
        if cols and metric not in frame.columns:
            numeric = frame[cols].apply(pd.to_numeric, errors="coerce")
            frame[metric] = numeric.sum(axis=1, min_count=1)
            notes.append(f"Aggregated {metric} from {len(cols)} device/interface columns.")

    for metric in max_metrics:
        cols = _candidate_metric_columns(frame, metric)
        if cols and metric not in frame.columns:
            numeric = frame[cols].apply(pd.to_numeric, errors="coerce")
            frame[metric] = numeric.max(axis=1)
            notes.append(f"Aggregated {metric} from {len(cols)} device/interface columns using max().")

    return notes


def _candidate_metric_columns(frame: pd.DataFrame, metric: str) -> list[str]:
    cols = [col for col in frame.columns if col.endswith(f"__{metric}")]
    if not cols:
        return []

    if metric in {"rxpck/s", "txpck/s", "rxkB/s", "txkB/s"}:
        filtered = [
            col
            for col in cols
            if not col.startswith(("lo__", "docker", "br-", "veth", "virbr", "tun"))
        ]
        return filtered or cols

    if metric in {"rkB/s", "wkB/s", "tps", "await", "%util"}:
        filtered = [
            col
            for col in cols
            if not col.startswith(("loop", "ram", "fd"))
        ]
        return filtered or cols

    return cols


def summarize_preprocessing(result: PreprocessResult) -> dict[str, Any]:
    return {
        "row_count": int(len(result.frame)),
        "columns": result.frame.columns.tolist(),
        "derived_columns": result.derived_columns,
        "missing_columns": result.missing_columns,
        "sampling_interval": result.sampling_interval,
        "notes": result.notes,
    }
