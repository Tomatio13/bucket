from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from .preprocess import PreprocessResult

try:
    from statsmodels.tsa.stattools import ccf as statsmodels_ccf
    from statsmodels.tsa.stattools import grangercausalitytests
except Exception:  # pragma: no cover - optional dependency
    statsmodels_ccf = None
    grangercausalitytests = None


@dataclass(slots=True)
class AnalysisResult:
    summary: dict[str, Any]
    bottleneck_hypotheses: list[dict[str, Any]]
    method_notes: list[str]


def analyze_dataset(preprocessed: PreprocessResult, *, max_lag: int = 10) -> AnalysisResult:
    frame = preprocessed.frame.copy()
    method_notes: list[str] = []

    numeric = frame.select_dtypes(include=["number"]).copy()
    summary: dict[str, Any] = {
        "window": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "rows": int(len(frame)),
        },
        "correlations": {},
        "lag_analysis": {},
        "granger": {},
        "change_points": {},
        "anomalies": {},
    }

    correlations = _top_correlations(numeric)
    summary["correlations"] = correlations

    lag_analysis = _run_ccf(numeric, max_lag=max_lag)
    if lag_analysis:
        summary["lag_analysis"] = lag_analysis
    else:
        method_notes.append("statsmodels が利用できない、または必要な列が不足しているため CCF をスキップしました。")

    granger = _run_granger(numeric, max_lag=max_lag)
    if granger:
        summary["granger"] = granger
    else:
        method_notes.append("statsmodels が利用できない、または必要な列が不足しているため Granger をスキップしました。")

    summary["change_points"] = _simple_change_points(numeric)
    summary["anomalies"] = _simple_anomaly_windows(numeric)

    hypotheses = _build_hypotheses(numeric, summary)

    return AnalysisResult(summary=summary, bottleneck_hypotheses=hypotheses, method_notes=method_notes)


def _top_correlations(numeric: pd.DataFrame) -> list[dict[str, Any]]:
    columns = [c for c in ["cpu_busy", "%iowait", "await", "kbavail", "net_bytes_s", "runq-sz"] if c in numeric.columns]
    if len(columns) < 2:
        return []
    corr = numeric[columns].corr().stack().reset_index()
    corr.columns = ["left", "right", "value"]
    corr = corr[corr["left"] < corr["right"]]
    corr = corr.reindex(corr["value"].abs().sort_values(ascending=False).index)
    return corr.head(5).to_dict(orient="records")


def _run_ccf(numeric: pd.DataFrame, *, max_lag: int) -> list[dict[str, Any]]:
    pairs = [("await", "%iowait"), ("net_bytes_s", "%system"), ("cpu_busy", "runq-sz")]
    results: list[dict[str, Any]] = []
    for left, right in pairs:
        if left not in numeric.columns or right not in numeric.columns:
            continue
        aligned = numeric[[left, right]].dropna()
        if len(aligned) < max_lag + 2:
            continue
        if statsmodels_ccf is not None:
            values = statsmodels_ccf(aligned[left], aligned[right], adjusted=False)[: max_lag + 1]
        else:
            values = _manual_ccf(aligned[left], aligned[right], max_lag=max_lag)
        best_lag = int(pd.Series(values).abs().idxmax())
        results.append(
            {
                "left": left,
                "right": right,
                "best_lag": best_lag,
                "correlation": float(values[best_lag]),
            }
        )
    return results


def _run_granger(numeric: pd.DataFrame, *, max_lag: int) -> list[dict[str, Any]]:
    if grangercausalitytests is None:
        return []
    pairs = [("%iowait", "await"), ("runq-sz", "cpu_busy")]
    results: list[dict[str, Any]] = []
    for target, source in pairs:
        if target not in numeric.columns or source not in numeric.columns:
            continue
        aligned = numeric[[target, source]].dropna()
        if len(aligned) < (max_lag * 3):
            continue
        try:
            output = grangercausalitytests(
                aligned[[target, source]].to_numpy(),
                maxlag=max_lag,
                addconst=True,
                verbose=False,
            )
        except Exception:
            continue
        best_lag = None
        best_p = None
        for lag, tests in output.items():
            p_value = tests[0]["ssr_ftest"][1]
            if best_p is None or p_value < best_p:
                best_p = float(p_value)
                best_lag = int(lag)
        if best_lag is not None:
            results.append(
                {
                    "source": source,
                    "target": target,
                    "best_lag": best_lag,
                    "p_value": best_p,
                }
            )
    return results


def _simple_change_points(numeric: pd.DataFrame) -> dict[str, Any]:
    tracked = [c for c in ["cpu_busy", "await", "kbavail", "net_bytes_s", "runq-sz"] if c in numeric.columns]
    results: dict[str, Any] = {}
    for column in tracked:
        series = numeric[column].dropna()
        if len(series) < 5:
            continue
        deltas = series.diff().abs().dropna()
        if deltas.empty:
            continue
        threshold = deltas.quantile(0.95)
        points = deltas[deltas >= threshold].head(5).index.astype(str).tolist()
        results[column] = points
    return results


def _simple_anomaly_windows(numeric: pd.DataFrame) -> list[dict[str, Any]]:
    tracked = [c for c in ["cpu_busy", "await", "kbavail", "net_bytes_s"] if c in numeric.columns]
    results: list[dict[str, Any]] = []
    for column in tracked:
        series = numeric[column].dropna()
        if len(series) < 10:
            continue
        std = series.std()
        if pd.isna(std) or std == 0:
            continue
        zscores = ((series - series.mean()) / std).abs()
        spikes = zscores[zscores >= 3].head(3)
        for timestamp, score in spikes.items():
            results.append({"metric": column, "timestamp": str(timestamp), "zscore": round(float(score), 3)})
    return results


def _build_hypotheses(numeric: pd.DataFrame, summary: dict[str, Any]) -> list[dict[str, Any]]:
    hypotheses: list[dict[str, Any]] = []
    correlations = _correlation_lookup(summary.get("correlations", []))

    if {"cpu_busy", "runq-sz"}.issubset(numeric.columns):
        cpu_busy_p95 = numeric["cpu_busy"].quantile(0.95)
        cpu_busy_median = numeric["cpu_busy"].median(skipna=True)
        runq_p95 = numeric["runq-sz"].quantile(0.95)
        iowait = numeric["%iowait"].median(skipna=True) if "%iowait" in numeric.columns else None
        if (
            pd.notna(cpu_busy_p95)
            and pd.notna(cpu_busy_median)
            and cpu_busy_p95 > max(85, cpu_busy_median * 1.35)
            and pd.notna(runq_p95)
            and runq_p95 >= 2
            and (iowait is None or iowait < 8)
        ):
            hypotheses.append(
                {
                    "type": "cpu",
                    "confidence": "medium",
                    "reason": "cpu_busy が平常時より大きく跳ね、run queue も増えている一方で iowait は比較的低く、ストレージ待ちより CPU 飽和の特徴に近い状態です。",
                }
            )

    if {"%iowait", "await"}.issubset(numeric.columns):
        iowait_median = numeric["%iowait"].median(skipna=True)
        await_p95 = numeric["await"].quantile(0.95)
        util_p95 = numeric["%util"].quantile(0.95) if "%util" in numeric.columns else None
        if (
            pd.notna(iowait_median)
            and pd.notna(await_p95)
            and iowait_median > 10
            and await_p95 > 20
            and (util_p95 is None or util_p95 > 60)
        ):
            hypotheses.append(
                {
                    "type": "io",
                    "confidence": "medium",
                    "reason": "iowait が継続的に高く、デバイス遅延や utilization も跳ねており、ストレージ待ち行列の圧迫と整合します。",
                }
            )
        elif pd.notna(iowait_median) and pd.notna(await_p95) and iowait_median > 15 and await_p95 < 5:
            hypotheses.append(
                {
                    "type": "io-wait-mixed",
                    "confidence": "low",
                    "reason": "iowait は高い一方で block device の await は低く、停止要因がストレージ装置自体の外側にあるか、ワークロード特性で薄まっている可能性があります。",
                }
            )

    if {"kbavail", "kbswpused"}.issubset(numeric.columns):
        kbavail_p05 = numeric["kbavail"].quantile(0.05)
        kbavail_median = numeric["kbavail"].median(skipna=True)
        kbswpused = numeric["kbswpused"].median(skipna=True)
        if (
            pd.notna(kbavail_p05)
            and pd.notna(kbavail_median)
            and pd.notna(kbswpused)
            and kbavail_p05 < kbavail_median * 0.9
            and kbswpused > 0
        ):
            hypotheses.append(
                {
                    "type": "memory",
                    "confidence": "low",
                    "reason": "利用可能メモリが平常時より明確に下がり、swap も使用されているため、メモリ圧迫が疑われます。",
                }
            )

    if {"net_bytes_s", "%system"}.issubset(numeric.columns):
        net_p95 = numeric["net_bytes_s"].quantile(0.95)
        net_median = numeric["net_bytes_s"].median(skipna=True)
        system_p95 = numeric["%system"].quantile(0.95)
        net_cpu_corr = correlations.get(tuple(sorted(("cpu_busy", "net_bytes_s"))))
        if (
            pd.notna(net_p95)
            and pd.notna(net_median)
            and net_median > 0
            and net_p95 > net_median * 2
            and ((net_cpu_corr is not None and abs(net_cpu_corr) > 0.6) or (pd.notna(system_p95) and system_p95 > 8))
        ):
            hypotheses.append(
                {
                    "type": "network",
                    "confidence": "low",
                    "reason": "ネットワークスループットが平常時を大きく上回って跳ね、CPU 活動とも連動しているため、通信起因の処理負荷またはバーストトラフィックが疑われます。",
                }
            )

    if not hypotheses:
        hypotheses.append(
            {
                "type": "undetermined",
                "confidence": "low",
                "reason": "ルールベースのボトルネック判定は既定のしきい値を超えませんでした。相関、ラグ分析、変化点を使って追加確認してください。",
            }
        )

    return hypotheses


def _correlation_lookup(items: list[dict[str, Any]]) -> dict[tuple[str, str], float]:
    result: dict[tuple[str, str], float] = {}
    for item in items:
        left = item.get("left")
        right = item.get("right")
        value = item.get("value")
        if isinstance(left, str) and isinstance(right, str) and isinstance(value, (int, float)):
            result[tuple(sorted((left, right)))] = float(value)
    return result


def _manual_ccf(left: pd.Series, right: pd.Series, *, max_lag: int) -> list[float]:
    values: list[float] = []
    for lag in range(max_lag + 1):
        shifted = right.shift(-lag)
        aligned = pd.concat([left, shifted], axis=1).dropna()
        if len(aligned) < 3:
            values.append(0.0)
            continue
        corr = aligned.iloc[:, 0].corr(aligned.iloc[:, 1])
        values.append(0.0 if pd.isna(corr) else float(corr))
    return values
