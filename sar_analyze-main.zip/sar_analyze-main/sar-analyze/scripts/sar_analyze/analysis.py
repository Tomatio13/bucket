from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from .preprocess import PreprocessResult

try:
    from statsmodels.tsa.stattools import ccf as statsmodels_ccf
    from statsmodels.tsa.stattools import grangercausalitytests
except Exception:  # pragma: no cover - optional dependency
    statsmodels_ccf = None
    grangercausalitytests = None


@dataclass(slots=True)
class AnalysisResult:
    summary: dict[str, Any]
    bottleneck_hypotheses: list[dict[str, Any]]
    method_notes: list[str]


MIN_RULE_SAMPLES = 5


def analyze_dataset(preprocessed: PreprocessResult, *, max_lag: int = 10) -> AnalysisResult:
    frame = preprocessed.frame.copy()
    method_notes: list[str] = []

    numeric = frame.select_dtypes(include=["number"]).copy()
    summary: dict[str, Any] = {
        "window": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "rows": int(len(frame)),
        },
        "correlations": {},
        "lag_analysis": {},
        "granger": {},
        "change_points": {},
        "anomalies": {},
    }

    correlations = _top_correlations(numeric)
    summary["correlations"] = correlations

    lag_analysis = _run_ccf(numeric, max_lag=max_lag)
    if lag_analysis:
        summary["lag_analysis"] = lag_analysis
    else:
        method_notes.append("statsmodels が利用できない、または必要な列が不足しているため CCF をスキップしました。")

    granger = _run_granger(numeric, max_lag=max_lag)
    if granger:
        summary["granger"] = granger
    else:
        method_notes.append("statsmodels が利用できない、または必要な列が不足しているため Granger をスキップしました。")

    summary["change_points"] = _simple_change_points(numeric)
    summary["anomalies"] = _simple_anomaly_windows(numeric)

    hypotheses = _build_hypotheses(numeric, summary)

    return AnalysisResult(summary=summary, bottleneck_hypotheses=hypotheses, method_notes=method_notes)


def _top_correlations(numeric: pd.DataFrame) -> list[dict[str, Any]]:
    columns = [c for c in ["cpu_busy", "%iowait", "await", "kbavail", "net_bytes_s", "runq-sz"] if c in numeric.columns]
    if len(columns) < 2:
        return []
    corr = numeric[columns].corr().stack().reset_index()
    corr.columns = ["left", "right", "value"]
    corr = corr[corr["left"] < corr["right"]]
    corr = corr.reindex(corr["value"].abs().sort_values(ascending=False).index)
    return corr.head(5).to_dict(orient="records")


def _run_ccf(numeric: pd.DataFrame, *, max_lag: int) -> list[dict[str, Any]]:
    pairs = [("await", "%iowait"), ("net_bytes_s", "%system"), ("cpu_busy", "runq-sz")]
    results: list[dict[str, Any]] = []
    for left, right in pairs:
        if left not in numeric.columns or right not in numeric.columns:
            continue
        aligned = numeric[[left, right]].dropna()
        if len(aligned) < max_lag + 2:
            continue
        if statsmodels_ccf is not None:
            values = statsmodels_ccf(aligned[left], aligned[right], adjusted=False)[: max_lag + 1]
        else:
            values = _manual_ccf(aligned[left], aligned[right], max_lag=max_lag)
        best_lag = int(pd.Series(values).abs().idxmax())
        results.append(
            {
                "left": left,
                "right": right,
                "best_lag": best_lag,
                "correlation": float(values[best_lag]),
            }
        )
    return results


def _run_granger(numeric: pd.DataFrame, *, max_lag: int) -> list[dict[str, Any]]:
    if grangercausalitytests is None:
        return []
    pairs = [("%iowait", "await"), ("runq-sz", "cpu_busy")]
    results: list[dict[str, Any]] = []
    for target, source in pairs:
        if target not in numeric.columns or source not in numeric.columns:
            continue
        aligned = numeric[[target, source]].dropna()
        if len(aligned) < (max_lag * 3):
            continue
        try:
            output = grangercausalitytests(
                aligned[[target, source]].to_numpy(),
                maxlag=max_lag,
                addconst=True,
                verbose=False,
            )
        except Exception:
            continue
        best_lag = None
        best_p = None
        for lag, tests in output.items():
            p_value = tests[0]["ssr_ftest"][1]
            if best_p is None or p_value < best_p:
                best_p = float(p_value)
                best_lag = int(lag)
        if best_lag is not None:
            results.append(
                {
                    "source": source,
                    "target": target,
                    "best_lag": best_lag,
                    "p_value": best_p,
                }
            )
    return results


def _simple_change_points(numeric: pd.DataFrame) -> dict[str, Any]:
    tracked = [c for c in ["cpu_busy", "await", "kbavail", "net_bytes_s", "runq-sz"] if c in numeric.columns]
    results: dict[str, Any] = {}
    for column in tracked:
        series = numeric[column].dropna()
        if len(series) < 5:
            continue
        deltas = series.diff().abs().dropna()
        if deltas.empty:
            continue
        threshold = deltas.quantile(0.95)
        points = deltas[deltas >= threshold].head(5).index.astype(str).tolist()
        results[column] = points
    return results


def _simple_anomaly_windows(numeric: pd.DataFrame) -> list[dict[str, Any]]:
    tracked = [c for c in ["cpu_busy", "await", "kbavail", "net_bytes_s"] if c in numeric.columns]
    results: list[dict[str, Any]] = []
    for column in tracked:
        series = numeric[column].dropna()
        if len(series) < 10:
            continue
        std = series.std()
        if pd.isna(std) or std == 0:
            continue
        zscores = ((series - series.mean()) / std).abs()
        spikes = zscores[zscores >= 3].head(3)
        for timestamp, score in spikes.items():
            results.append({"metric": column, "timestamp": str(timestamp), "zscore": round(float(score), 3)})
    return results


def _build_hypotheses(numeric: pd.DataFrame, summary: dict[str, Any]) -> list[dict[str, Any]]:
    hypotheses: list[dict[str, Any]] = []
    correlations = _correlation_lookup(summary.get("correlations", []))
    confidence_scores = {"low": 0.4, "medium": 0.7, "high": 0.9}

    def has_samples(*columns: str) -> bool:
        if not set(columns).issubset(numeric.columns):
            return False
        aligned = numeric[list(columns)].dropna()
        return len(aligned) >= MIN_RULE_SAMPLES

    def clean_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
        cleaned: dict[str, Any] = {}
        for key, value in evidence.items():
            if value is None:
                continue
            if isinstance(value, float):
                if pd.isna(value):
                    continue
                cleaned[key] = round(float(value), 6)
            elif isinstance(value, list):
                cleaned[key] = value
            else:
                cleaned[key] = value
        return cleaned

    def add_hypothesis(
        hypothesis_type: str,
        confidence: str,
        reason: str,
        *,
        evidence: dict[str, Any] | None = None,
        score: float | None = None,
    ) -> None:
        hypotheses.append(
            {
                "type": hypothesis_type,
                "confidence": confidence,
                "reason": reason,
                "score": round(float(score if score is not None else confidence_scores.get(confidence, 0.3)), 3),
                "evidence": clean_evidence(evidence or {}),
            }
        )

    if {"cpu_busy", "runq-sz"}.issubset(numeric.columns):
        cpu_busy_p95 = numeric["cpu_busy"].quantile(0.95)
        cpu_busy_median = numeric["cpu_busy"].median(skipna=True)
        runq_p95 = numeric["runq-sz"].quantile(0.95)
        iowait = numeric["%iowait"].median(skipna=True) if "%iowait" in numeric.columns else None
        if (
            pd.notna(cpu_busy_p95)
            and pd.notna(cpu_busy_median)
            and cpu_busy_p95 > max(85, cpu_busy_median * 1.35)
            and pd.notna(runq_p95)
            and runq_p95 >= 2
            and (iowait is None or iowait < 8)
        ):
            add_hypothesis(
                "cpu",
                "medium",
                "cpu_busy が平常時より大きく跳ね、run queue も増えている一方で iowait は比較的低く、ストレージ待ちより CPU 飽和の特徴に近い状態です。",
                evidence={"cpu_busy_p95": cpu_busy_p95, "cpu_busy_median": cpu_busy_median, "runq_p95": runq_p95, "iowait_median": iowait},
                score=0.74,
            )

    if has_samples("%system"):
        system_p95 = numeric["%system"].quantile(0.95)
        system_median = numeric["%system"].median(skipna=True)
        user_p95 = numeric["%user"].quantile(0.95) if "%user" in numeric.columns else None
        if (
            pd.notna(system_p95)
            and pd.notna(system_median)
            and system_p95 > max(20, system_median * 1.4)
            and (user_p95 is None or system_p95 >= user_p95 * 0.8)
        ):
            add_hypothesis(
                "cpu-system-high",
                "low",
                "%system が平常時より大きく伸びており、ユーザー空間の計算よりもカーネル処理や割り込み処理の比率が高まっています。",
                evidence={"system_p95": system_p95, "system_median": system_median, "user_p95": user_p95},
                score=0.48,
            )

    if has_samples("%steal"):
        steal_p95 = numeric["%steal"].quantile(0.95)
        steal_median = numeric["%steal"].median(skipna=True)
        if pd.notna(steal_p95) and pd.notna(steal_median) and steal_p95 > max(5, steal_median * 1.5):
            add_hypothesis(
                "cpu-steal-high",
                "medium",
                "%steal が高く、仮想化ホスト側で CPU を取り合っている可能性があります。",
                evidence={"steal_p95": steal_p95, "steal_median": steal_median},
                score=0.78,
            )

    if has_samples("%irq"):
        irq_p95 = numeric["%irq"].quantile(0.95)
        irq_median = numeric["%irq"].median(skipna=True)
        system_p95 = numeric["%system"].quantile(0.95) if "%system" in numeric.columns else None
        if (
            pd.notna(irq_p95)
            and pd.notna(irq_median)
            and irq_p95 > max(3, irq_median * 1.8)
            and (system_p95 is None or system_p95 >= 5)
        ):
            add_hypothesis(
                "cpu-irq-storm",
                "low",
                "%irq が跳ねており、デバイス割り込み処理の偏りや突発的な割り込み増加が疑われます。",
                evidence={"irq_p95": irq_p95, "irq_median": irq_median, "system_p95": system_p95},
                score=0.46,
            )

    if has_samples("%soft"):
        soft_p95 = numeric["%soft"].quantile(0.95)
        soft_median = numeric["%soft"].median(skipna=True)
        net_p95 = numeric["net_bytes_s"].quantile(0.95) if "net_bytes_s" in numeric.columns else None
        net_median = numeric["net_bytes_s"].median(skipna=True) if "net_bytes_s" in numeric.columns else None
        if (
            pd.notna(soft_p95)
            and pd.notna(soft_median)
            and soft_p95 > max(5, soft_median * 1.8)
            and (net_p95 is None or net_median is None or net_median <= 0 or net_p95 > net_median * 1.5)
        ):
            add_hypothesis(
                "cpu-softirq-storm",
                "low",
                "%soft が跳ねており、ネットワーク処理などの softirq 負荷が増えている可能性があります。",
                evidence={"soft_p95": soft_p95, "soft_median": soft_median, "net_p95": net_p95, "net_median": net_median},
                score=0.49,
            )

    if has_samples("%scpu"):
        cpu_psi_p95 = numeric["%scpu"].quantile(0.95)
        if pd.notna(cpu_psi_p95) and cpu_psi_p95 > 10:
            add_hypothesis(
                "cpu-pressure-stall",
                "medium",
                "CPU PSI が高く、CPU 使用率だけでは見えにくい実行待ちの遅延が発生しています。",
                evidence={"cpu_psi_p95": cpu_psi_p95},
                score=0.82,
            )

    if has_samples("%user"):
        user_p95 = numeric["%user"].quantile(0.95)
        user_median = numeric["%user"].median(skipna=True)
        runq_p95 = numeric["runq-sz"].quantile(0.95) if "runq-sz" in numeric.columns else None
        if (
            pd.notna(user_p95)
            and pd.notna(user_median)
            and user_p95 > max(40, user_median * 1.35)
            and (runq_p95 is None or runq_p95 >= 1)
        ):
            add_hypothesis(
                "cpu-user-high",
                "low",
                "%user が平常時より大きく伸びており、アプリケーション実行や計算処理の負荷が前面に出ています。",
                evidence={"user_p95": user_p95, "user_median": user_median, "runq_p95": runq_p95},
                score=0.47,
            )

    if {"%iowait", "await"}.issubset(numeric.columns):
        iowait_median = numeric["%iowait"].median(skipna=True)
        await_p95 = numeric["await"].quantile(0.95)
        util_p95 = numeric["%util"].quantile(0.95) if "%util" in numeric.columns else None
        if (
            pd.notna(iowait_median)
            and pd.notna(await_p95)
            and iowait_median > 10
            and await_p95 > 20
            and (util_p95 is None or util_p95 > 60)
        ):
            add_hypothesis(
                "io",
                "medium",
                "iowait が継続的に高く、デバイス遅延や utilization も跳ねており、ストレージ待ち行列の圧迫と整合します。",
                evidence={"iowait_median": iowait_median, "await_p95": await_p95, "util_p95": util_p95},
                score=0.76,
            )
        elif pd.notna(iowait_median) and pd.notna(await_p95) and iowait_median > 15 and await_p95 < 5:
            add_hypothesis(
                "io-wait-mixed",
                "low",
                "iowait は高い一方で block device の await は低く、停止要因がストレージ装置自体の外側にあるか、ワークロード特性で薄まっている可能性があります。",
                evidence={"iowait_median": iowait_median, "await_p95": await_p95},
                score=0.42,
            )

    if {"kbavail", "kbswpused"}.issubset(numeric.columns):
        kbavail_p05 = numeric["kbavail"].quantile(0.05)
        kbavail_median = numeric["kbavail"].median(skipna=True)
        kbswpused = numeric["kbswpused"].median(skipna=True)
        if (
            pd.notna(kbavail_p05)
            and pd.notna(kbavail_median)
            and pd.notna(kbswpused)
            and kbavail_p05 < kbavail_median * 0.9
            and kbswpused > 0
        ):
            add_hypothesis(
                "memory",
                "low",
                "利用可能メモリが平常時より明確に下がり、swap も使用されているため、メモリ圧迫が疑われます。",
                evidence={"kbavail_p05": kbavail_p05, "kbavail_median": kbavail_median, "kbswpused_median": kbswpused},
                score=0.45,
            )

    if has_samples("%sio"):
        sio_p95 = numeric["%sio"].quantile(0.95)
        if pd.notna(sio_p95) and sio_p95 > 10:
            add_hypothesis(
                "io-pressure-some",
                "medium",
                "I/O PSI some が高く、少なくとも一部のタスクで I/O 待ちによる遅延が継続しています。",
                evidence={"sio_p95": sio_p95},
                score=0.8,
            )

    if has_samples("%fio"):
        fio_p95 = numeric["%fio"].quantile(0.95)
        if pd.notna(fio_p95) and fio_p95 > 5:
            add_hypothesis(
                "io-pressure-full",
                "high",
                "I/O PSI full が高く、非 idle タスク全体が I/O 待ちで止まる時間が増えています。",
                evidence={"fio_p95": fio_p95},
                score=0.92,
            )

    if has_samples("aqu-sz"):
        queue_p95 = numeric["aqu-sz"].quantile(0.95)
        queue_median = numeric["aqu-sz"].median(skipna=True)
        await_p95 = numeric["await"].quantile(0.95) if "await" in numeric.columns else None
        if (
            pd.notna(queue_p95)
            and pd.notna(queue_median)
            and queue_p95 > max(1.5, queue_median * 1.8)
            and (await_p95 is None or await_p95 >= 10)
        ):
            add_hypothesis(
                "disk-queue-high",
                "medium",
                "ディスクキュー長が平常時より増えており、I/O 要求が装置側で滞留している可能性があります。",
                evidence={"queue_p95": queue_p95, "queue_median": queue_median, "await_p95": await_p95},
                score=0.73,
            )

    if has_samples("%smem"):
        smem_p95 = numeric["%smem"].quantile(0.95)
        if pd.notna(smem_p95) and smem_p95 > 8:
            add_hypothesis(
                "mem-pressure-stall-some",
                "medium",
                "メモリ PSI some が高く、メモリ reclaim などに起因する待ちが継続しています。",
                evidence={"smem_p95": smem_p95},
                score=0.79,
            )

    if has_samples("%fmem"):
        fmem_p95 = numeric["%fmem"].quantile(0.95)
        if pd.notna(fmem_p95) and fmem_p95 > 3:
            add_hypothesis(
                "mem-pressure-stall-full",
                "high",
                "メモリ PSI full が高く、非 idle タスク全体がメモリ待ちで停止する時間が増えています。",
                evidence={"fmem_p95": fmem_p95},
                score=0.91,
            )

    if has_samples("runq-sz"):
        runq_p95 = numeric["runq-sz"].quantile(0.95)
        runq_median = numeric["runq-sz"].median(skipna=True)
        if pd.notna(runq_p95) and pd.notna(runq_median) and runq_p95 >= max(3, runq_median * 2):
            add_hypothesis(
                "runqueue-high",
                "medium",
                "run queue が平常時より明確に増えており、CPU 実行待ちやスレッド過多が起きている可能性があります。",
                evidence={"runq_p95": runq_p95, "runq_median": runq_median},
                score=0.72,
            )

    if has_samples("blocked"):
        blocked_p95 = numeric["blocked"].quantile(0.95)
        blocked_median = numeric["blocked"].median(skipna=True)
        if pd.notna(blocked_p95) and pd.notna(blocked_median) and blocked_p95 >= max(2, blocked_median * 2):
            add_hypothesis(
                "blocked-tasks-high",
                "medium",
                "I/O 完了待ちの blocked タスクが増えており、ストレージや外部 I/O 待ちが詰まりとして現れている可能性があります。",
                evidence={"blocked_p95": blocked_p95, "blocked_median": blocked_median},
                score=0.71,
            )

    if has_samples("majflt/s"):
        major_fault_p95 = numeric["majflt/s"].quantile(0.95)
        major_fault_median = numeric["majflt/s"].median(skipna=True)
        if (
            pd.notna(major_fault_p95)
            and pd.notna(major_fault_median)
            and major_fault_p95 > max(10, max(1.0, major_fault_median) * 2)
        ):
            add_hypothesis(
                "major-faults-high",
                "low",
                "major page fault が増えており、ディスクを伴うページイン待ちが増加している可能性があります。",
                evidence={"major_fault_p95": major_fault_p95, "major_fault_median": major_fault_median},
                score=0.5,
            )

    if has_samples("pswpin/s", "pswpout/s"):
        swap_in_p95 = numeric["pswpin/s"].quantile(0.95)
        swap_out_p95 = numeric["pswpout/s"].quantile(0.95)
        if pd.notna(swap_in_p95) and pd.notna(swap_out_p95) and swap_in_p95 > 0 and swap_out_p95 > 0:
            add_hypothesis(
                "swap-inout-high",
                "medium",
                "swap-in と swap-out が同時に発生しており、メモリ圧迫やスラッシングの兆候が見られます。",
                evidence={"swap_in_p95": swap_in_p95, "swap_out_p95": swap_out_p95},
                score=0.77,
            )
            fio_p95 = numeric["%fio"].quantile(0.95) if "%fio" in numeric.columns else None
            await_p95 = numeric["await"].quantile(0.95) if "await" in numeric.columns else None
            iowait_median = numeric["%iowait"].median(skipna=True) if "%iowait" in numeric.columns else None
            if (
                (pd.notna(fio_p95) and fio_p95 > 5)
                or (pd.notna(await_p95) and await_p95 > 20)
                or (pd.notna(iowait_median) and iowait_median > 10)
            ):
                add_hypothesis(
                    "swap-thrashing-suspected",
                    "high",
                    "swap 入出力に加えて I/O 待ちも悪化しており、スワップスラッシングが疑われます。",
                    evidence={"swap_in_p95": swap_in_p95, "swap_out_p95": swap_out_p95, "fio_p95": fio_p95, "await_p95": await_p95, "iowait_median": iowait_median},
                    score=0.94,
                )

    if has_samples("ldavg-1", "runq-sz"):
        load_p95 = numeric["ldavg-1"].quantile(0.95)
        runq_median = numeric["runq-sz"].median(skipna=True)
        blocked_p95 = numeric["blocked"].quantile(0.95) if "blocked" in numeric.columns else None
        if (
            pd.notna(load_p95)
            and pd.notna(runq_median)
            and load_p95 >= 2
            and runq_median < 1.5
            and (blocked_p95 is None or blocked_p95 >= 1)
        ):
            add_hypothesis(
                "loadavg-high-with-low-runq",
                "low",
                "load average は高い一方で run queue は目立って増えておらず、CPU 実行待ち以外の待機要因が load を押し上げている可能性があります。",
                evidence={"load_p95": load_p95, "runq_median": runq_median, "blocked_p95": blocked_p95},
                score=0.43,
            )

    if {"net_bytes_s", "%system"}.issubset(numeric.columns):
        net_p95 = numeric["net_bytes_s"].quantile(0.95)
        net_median = numeric["net_bytes_s"].median(skipna=True)
        system_p95 = numeric["%system"].quantile(0.95)
        net_cpu_corr = correlations.get(tuple(sorted(("cpu_busy", "net_bytes_s"))))
        if (
            pd.notna(net_p95)
            and pd.notna(net_median)
            and net_median > 0
            and net_p95 > net_median * 2
            and ((net_cpu_corr is not None and abs(net_cpu_corr) > 0.6) or (pd.notna(system_p95) and system_p95 > 8))
        ):
            add_hypothesis(
                "network",
                "low",
                "ネットワークスループットが平常時を大きく上回って跳ね、CPU 活動とも連動しているため、通信起因の処理負荷またはバーストトラフィックが疑われます。",
                evidence={"net_p95": net_p95, "net_median": net_median, "system_p95": system_p95, "net_cpu_corr": net_cpu_corr},
                score=0.44,
            )

    if has_samples("rxdrop/s") or has_samples("txdrop/s"):
        rxdrop = numeric["rxdrop/s"] if "rxdrop/s" in numeric.columns else pd.Series(0, index=numeric.index)
        txdrop = numeric["txdrop/s"] if "txdrop/s" in numeric.columns else pd.Series(0, index=numeric.index)
        drop_p95 = (rxdrop.fillna(0) + txdrop.fillna(0)).quantile(0.95)
        if pd.notna(drop_p95) and drop_p95 > 0:
            add_hypothesis(
                "net-drops-high",
                "high",
                "ネットワークの drop が発生しており、バッファ不足や受送信の詰まりが疑われます。",
                evidence={"drop_p95": drop_p95},
                score=0.9,
            )

    error_columns = [column for column in ["rxerr/s", "txerr/s", "rxfram/s", "rxfifo/s", "txfifo/s", "txcarr/s"] if column in numeric.columns]
    if error_columns:
        error_frame = numeric[error_columns].fillna(0)
        if len(error_frame) >= MIN_RULE_SAMPLES:
            error_p95 = error_frame.sum(axis=1).quantile(0.95)
            if pd.notna(error_p95) and error_p95 > 0:
                add_hypothesis(
                    "net-errors-high",
                    "high",
                    "ネットワークエラー系カウンタが増えており、NIC・リンク・FIFO 周辺の問題が疑われます。",
                    evidence={"error_p95": error_p95, "error_columns": error_columns},
                    score=0.88,
                )

    if has_samples("retrans/s"):
        retrans_p95 = numeric["retrans/s"].quantile(0.95)
        if pd.notna(retrans_p95) and retrans_p95 > 1:
            add_hypothesis(
                "tcp-retrans-high",
                "medium",
                "TCP 再送が増えており、輻輳やパケット損失の可能性があります。",
                evidence={"retrans_p95": retrans_p95},
                score=0.75,
            )

    if has_samples("dropd/s") or has_samples("squeezd/s") or has_samples("blg_len"):
        dropd_p95 = numeric["dropd/s"].quantile(0.95) if "dropd/s" in numeric.columns else None
        squeezd_p95 = numeric["squeezd/s"].quantile(0.95) if "squeezd/s" in numeric.columns else None
        blg_len_p95 = numeric["blg_len"].quantile(0.95) if "blg_len" in numeric.columns else None
        if (
            (pd.notna(dropd_p95) and dropd_p95 > 0)
            or (pd.notna(squeezd_p95) and squeezd_p95 > 0)
            or (pd.notna(blg_len_p95) and blg_len_p95 > 0)
        ):
            add_hypothesis(
                "softnet-backlog-overflow",
                "high",
                "softnet backlog 指標が悪化しており、softirq 側でパケット処理が追いついていません。",
                evidence={"dropd_p95": dropd_p95, "squeezd_p95": squeezd_p95, "blg_len_p95": blg_len_p95},
                score=0.89,
            )

    if has_samples("cswch/s"):
        cswch_p95 = numeric["cswch/s"].quantile(0.95)
        cswch_median = numeric["cswch/s"].median(skipna=True)
        runq_p95 = numeric["runq-sz"].quantile(0.95) if "runq-sz" in numeric.columns else None
        if (
            pd.notna(cswch_p95)
            and pd.notna(cswch_median)
            and cswch_median > 0
            and cswch_p95 > max(1000, cswch_median * 2)
            and (runq_p95 is None or runq_p95 >= 1)
        ):
            add_hypothesis(
                "context-switch-storm",
                "low",
                "コンテキストスイッチが平常時より急増しており、スレッド過多や待機と実行の切り替え過多が疑われます。",
                evidence={"cswch_p95": cswch_p95, "cswch_median": cswch_median, "runq_p95": runq_p95},
                score=0.46,
            )

    if not hypotheses:
        add_hypothesis(
            "undetermined",
            "low",
            "ルールベースのボトルネック判定は既定のしきい値を超えませんでした。相関、ラグ分析、変化点を使って追加確認してください。",
            score=0.2,
        )

    return sorted(hypotheses, key=lambda item: (-float(item.get("score", 0.0)), item["type"]))


def _correlation_lookup(items: list[dict[str, Any]]) -> dict[tuple[str, str], float]:
    result: dict[tuple[str, str], float] = {}
    for item in items:
        left = item.get("left")
        right = item.get("right")
        value = item.get("value")
        if isinstance(left, str) and isinstance(right, str) and isinstance(value, (int, float)):
            result[tuple(sorted((left, right)))] = float(value)
    return result


def _manual_ccf(left: pd.Series, right: pd.Series, *, max_lag: int) -> list[float]:
    values: list[float] = []
    for lag in range(max_lag + 1):
        shifted = right.shift(-lag)
        aligned = pd.concat([left, shifted], axis=1).dropna()
        if len(aligned) < 3:
            values.append(0.0)
            continue
        corr = aligned.iloc[:, 0].corr(aligned.iloc[:, 1])
        values.append(0.0 if pd.isna(corr) else float(corr))
    return values
