from __future__ import annotations

from typing import Any

from .analysis import AnalysisResult
from .preprocess import PreprocessResult

ESSENTIAL_COLUMNS = [
    "cpu_busy",
    "%user",
    "%system",
    "%iowait",
    "%idle",
    "kbavail",
    "kbswpused",
    "bread/s",
    "bwrtn/s",
    "rkB/s",
    "wkB/s",
    "await",
    "%util",
    "rxpck/s",
    "txpck/s",
    "rxkB/s",
    "txkB/s",
    "net_bytes_s",
    "io_bytes_s",
    "runq-sz",
    "blocked",
    "ldavg-1",
    "ldavg-5",
    "ldavg-15",
    "cswch/s",
]


def build_report_payload(preprocessed: PreprocessResult, analysis: AnalysisResult) -> dict[str, Any]:
    frame = preprocessed.frame
    compact_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    return {
        "input_data": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "row_count": int(len(frame)),
            "columns": frame.columns.tolist(),
            "essential_columns": compact_columns,
        },
        "preprocessing": {
            "notes": preprocessed.notes,
            "derived_columns": preprocessed.derived_columns,
            "missing_columns": preprocessed.missing_columns,
        },
        "findings": analysis.summary,
        "hypotheses": analysis.bottleneck_hypotheses,
        "method_notes": analysis.method_notes,
        "llm_summary": build_llm_summary(preprocessed, analysis),
    }


def build_compact_report_payload(preprocessed: PreprocessResult, analysis: AnalysisResult) -> dict[str, Any]:
    frame = preprocessed.frame
    essential_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    metric_snapshot = {
        column: _series_snapshot(frame[column])
        for column in essential_columns
        if column in frame.columns
    }
    return {
        "input_data": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "row_count": int(len(frame)),
            "essential_columns": essential_columns,
        },
        "preprocessing": {
            "notes": preprocessed.notes,
            "derived_columns": preprocessed.derived_columns,
            "missing_columns": preprocessed.missing_columns,
        },
        "hypotheses": analysis.bottleneck_hypotheses,
        "evidence": {
            "correlations": analysis.summary.get("correlations", []),
            "lag_analysis": analysis.summary.get("lag_analysis", []),
            "granger": analysis.summary.get("granger", []),
            "anomalies": analysis.summary.get("anomalies", []),
            "change_points": analysis.summary.get("change_points", {}),
            "metric_snapshot": metric_snapshot,
        },
        "method_notes": analysis.method_notes,
        "llm_summary": build_llm_summary(preprocessed, analysis),
    }


def render_report(
    preprocessed: PreprocessResult,
    analysis: AnalysisResult,
    chart_paths: list[str] | None = None,
) -> str:
    payload = build_report_payload(preprocessed, analysis)
    lines: list[str] = []
    lines.append("# SAR 分析レポート")
    lines.append("")
    lines.append("## 入力データ")
    lines.append(f"- 期間: {payload['input_data']['start']} から {payload['input_data']['end']}")
    lines.append(f"- サンプリング間隔: {payload['input_data']['sampling_interval']}")
    lines.append(f"- 行数: {payload['input_data']['row_count']}")
    lines.append("")
    lines.append("## 前処理")
    for note in payload["preprocessing"]["notes"]:
        lines.append(f"- {note}")
    if payload["preprocessing"]["derived_columns"]:
        lines.append(f"- 派生列: {', '.join(payload['preprocessing']['derived_columns'])}")
    if payload["preprocessing"]["missing_columns"]:
        lines.append(f"- 欠損しているメトリクス: {', '.join(payload['preprocessing']['missing_columns'])}")
    lines.append("")
    lines.append("## 仮説")
    for hypothesis in payload["hypotheses"]:
        lines.append(
            f"- {_hypothesis_type_label(hypothesis['type'])} ({_confidence_label(hypothesis['confidence'])}): {hypothesis['reason']}"
        )
    lines.append("")
    lines.append("## 根拠")
    correlations = payload["findings"].get("correlations", [])
    if correlations:
        for item in correlations:
            lines.append(f"- 相関: {item['left']} と {item['right']} = {item['value']:.3f}")
    for item in payload["findings"].get("lag_analysis", []):
        lines.append(
            f"- CCF: {item['left']} -> {item['right']} の最良ラグは {item['best_lag']}、相関は {item['correlation']:.3f}"
        )
    for item in payload["findings"].get("granger", []):
        lines.append(
            f"- Granger 候補: {item['source']} -> {item['target']}、ラグ {item['best_lag']}、p={item['p_value']:.4f}"
        )
    anomalies = payload["findings"].get("anomalies", [])
    for item in anomalies:
        lines.append(
            f"- 異常値: {item['metric']}、時刻 {item['timestamp']}、|z|={item['zscore']}"
        )
    lines.append("")
    lines.append("## 不確実性")
    if payload["method_notes"]:
        for note in payload["method_notes"]:
            lines.append(f"- {note}")
    else:
        lines.append("- 相関、ラグ、ルールベースの根拠はいずれも示唆的なものであり、確定的な因果関係として扱わないこと。")
    lines.append("")
    if chart_paths:
        lines.append("## 参考グラフ")
        for chart_path in chart_paths:
            lines.append(f"![{_chart_alt_text(chart_path)}]({chart_path})")
            lines.append("")
    lines.append("## LLM 利用時のガードレール")
    lines.append("- 要約に存在しない事実は断定しないこと。推測は推測として明示すること。")
    return "\n".join(lines)


def _chart_alt_text(chart_path: str) -> str:
    name = chart_path.rsplit("/", 1)[-1]
    if name == "timeseries.png":
        return "主要メトリクスの時系列グラフ"
    if name == "correlation_heatmap.png":
        return "主要メトリクスの相関ヒートマップ"
    return name


def _hypothesis_type_label(value: str) -> str:
    labels = {
        "cpu": "CPU",
        "io": "I/O",
        "io-wait-mixed": "I/O 待ち混在",
        "memory": "メモリ",
        "network": "ネットワーク",
        "undetermined": "判定保留",
    }
    return labels.get(value, value)


def _confidence_label(value: str) -> str:
    labels = {
        "high": "高",
        "medium": "中",
        "low": "低",
    }
    return labels.get(value, value)


def build_llm_summary(preprocessed: PreprocessResult, analysis: AnalysisResult) -> dict[str, Any]:
    frame = preprocessed.frame
    essential_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    return {
        "constraints": [
            "Do not assert facts absent from the summary.",
            "Mark speculation as speculation.",
            "Treat correlation and lag evidence as suggestive, not definitive causality.",
        ],
        "input_overview": {
            "time_range": {
                "start": frame.index.min().isoformat() if not frame.empty else None,
                "end": frame.index.max().isoformat() if not frame.empty else None,
            },
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "essential_columns": essential_columns,
            "preprocessing_notes": preprocessed.notes,
        },
        "key_findings": {
            "hypotheses": analysis.bottleneck_hypotheses,
            "correlations": analysis.summary.get("correlations", []),
            "lag_analysis": analysis.summary.get("lag_analysis", []),
            "anomalies": analysis.summary.get("anomalies", []),
        },
        "follow_up_prompt": "Rank the most likely bottleneck hypotheses, cite the supporting metrics, call out uncertainty, and list the next no-downtime checks.",
    }


def _series_snapshot(series: Any) -> dict[str, float] | None:
    clean = series.dropna()
    if clean.empty:
        return None
    return {
        "min": round(float(clean.min()), 6),
        "median": round(float(clean.median()), 6),
        "p95": round(float(clean.quantile(0.95)), 6),
        "max": round(float(clean.max()), 6),
    }
