from __future__ import annotations

from typing import Any

from .analysis import AnalysisResult
from .llm_partition import LLMPartitionConfig, build_llm_input_payload
from .preprocess import PreprocessResult

ESSENTIAL_COLUMNS = [
    "cpu_busy",
    "%user",
    "%system",
    "%iowait",
    "%idle",
    "kbavail",
    "kbswpused",
    "majflt/s",
    "pswpin/s",
    "pswpout/s",
    "bread/s",
    "bwrtn/s",
    "rkB/s",
    "wkB/s",
    "await",
    "%util",
    "%scpu",
    "%sio",
    "%fio",
    "%smem",
    "%fmem",
    "rxpck/s",
    "txpck/s",
    "rxkB/s",
    "txkB/s",
    "%ifutil",
    "rxdrop/s",
    "txdrop/s",
    "rxerr/s",
    "txerr/s",
    "retrans/s",
    "dropd/s",
    "squeezd/s",
    "blg_len",
    "net_bytes_s",
    "io_bytes_s",
    "runq-sz",
    "blocked",
    "ldavg-1",
    "ldavg-5",
    "ldavg-15",
    "cswch/s",
]


def build_report_payload(preprocessed: PreprocessResult, analysis: AnalysisResult) -> dict[str, Any]:
    frame = preprocessed.frame
    compact_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    return {
        "input_data": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "row_count": int(len(frame)),
            "columns": frame.columns.tolist(),
            "essential_columns": compact_columns,
        },
        "preprocessing": {
            "notes": preprocessed.notes,
            "derived_columns": preprocessed.derived_columns,
            "missing_columns": preprocessed.missing_columns,
        },
        "findings": analysis.summary,
        "hypotheses": analysis.bottleneck_hypotheses,
        "method_notes": analysis.method_notes,
        "llm_summary": build_llm_summary(preprocessed, analysis),
    }


def build_compact_report_payload(
    preprocessed: PreprocessResult,
    analysis: AnalysisResult,
    *,
    llm_partition_config: LLMPartitionConfig | None = None,
) -> dict[str, Any]:
    frame = preprocessed.frame
    essential_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    metric_snapshot = {
        column: _series_snapshot(frame[column])
        for column in essential_columns
        if column in frame.columns
    }
    payload = {
        "input_data": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "row_count": int(len(frame)),
            "essential_columns": essential_columns,
        },
        "preprocessing": {
            "notes": preprocessed.notes,
            "derived_columns": preprocessed.derived_columns,
            "missing_columns": preprocessed.missing_columns,
        },
        "hypotheses": analysis.bottleneck_hypotheses,
        "evidence": {
            "correlations": analysis.summary.get("correlations", []),
            "lag_analysis": analysis.summary.get("lag_analysis", []),
            "granger": analysis.summary.get("granger", []),
            "anomalies": analysis.summary.get("anomalies", []),
            "change_points": analysis.summary.get("change_points", {}),
            "metric_snapshot": metric_snapshot,
        },
        "method_notes": analysis.method_notes,
        "llm_summary": build_llm_summary(preprocessed, analysis),
    }
    if llm_partition_config is not None:
        payload["llm_input"] = build_llm_input_payload(
            preprocessed,
            analysis,
            payload,
            config=llm_partition_config,
        )
    return payload


def render_report(
    preprocessed: PreprocessResult,
    analysis: AnalysisResult,
    chart_paths: list[str] | None = None,
) -> str:
    payload = build_report_payload(preprocessed, analysis)
    resource_sections = _build_resource_sections(preprocessed, analysis)
    notable_events = _collect_notable_events(payload["findings"])
    overall_assessment = _overall_assessment_text(analysis.bottleneck_hypotheses)
    immediate_actions = _build_actions(analysis.bottleneck_hypotheses, immediate=True)
    long_term_actions = _build_actions(analysis.bottleneck_hypotheses, immediate=False)
    lines: list[str] = []
    lines.append("# 性能測定・長時間安定化試験 リソース分析レポート")
    lines.append("")
    lines.append("## 1. エグゼクティブサマリー")
    lines.append(f"- 総合所見: {overall_assessment}")
    lines.append(f"- 評価対象期間: {payload['input_data']['start']} から {payload['input_data']['end']}")
    lines.append(f"- 収集サンプリング間隔: {payload['input_data']['sampling_interval']}")
    lines.append(f"- 評価対象データ件数: {payload['input_data']['row_count']}")
    lines.append("")
    lines.append("## 2. 分析対象と前提条件")
    lines.append(f"- 期間: {payload['input_data']['start']} から {payload['input_data']['end']}")
    lines.append(f"- サンプリング間隔: {payload['input_data']['sampling_interval']}")
    lines.append(f"- 行数: {payload['input_data']['row_count']}")
    essential_columns = payload["input_data"].get("essential_columns") or []
    if essential_columns:
        lines.append(f"- 主な評価対象メトリクス: {', '.join(essential_columns)}")
    lines.append("")
    lines.append("## 3. 前処理と集計条件")
    for note in payload["preprocessing"]["notes"]:
        lines.append(f"- {note}")
    if payload["preprocessing"]["derived_columns"]:
        lines.append(f"- 派生列: {', '.join(payload['preprocessing']['derived_columns'])}")
    if payload["preprocessing"]["missing_columns"]:
        lines.append(f"- 欠損しているメトリクス: {', '.join(payload['preprocessing']['missing_columns'])}")
    lines.append("")
    lines.append("## 4. リソース観点別の分析結果")
    for section in resource_sections:
        lines.append(f"### {section['title']}")
        lines.append(f"- 評価: {section['status']}")
        lines.append(f"- 所見: {section['summary']}")
        if section["highlights"]:
            lines.append(f"- 指標要約: {' / '.join(section['highlights'])}")
        if section["related_hypotheses"]:
            lines.append(f"- 参考所見: {' / '.join(section['related_hypotheses'])}")
        lines.append("")
    lines.append("## 5. 特記事項")
    if notable_events:
        for item in notable_events:
            lines.append(f"- {item}")
    else:
        lines.append("- 解析上、顕著なスパイクや急変点は限定的でした。")
    lines.append("")
    lines.append("## 6. 解析根拠")
    correlations = payload["findings"].get("correlations", [])
    if correlations:
        for item in correlations:
            lines.append(f"- 相関: {item['left']} と {item['right']} = {item['value']:.3f}")
    for item in payload["findings"].get("lag_analysis", []):
        lines.append(
            f"- CCF: {item['left']} -> {item['right']} の最良ラグは {item['best_lag']}、相関は {item['correlation']:.3f}"
        )
    for item in payload["findings"].get("granger", []):
        lines.append(
            f"- Granger 候補: {item['source']} -> {item['target']}、ラグ {item['best_lag']}、p={item['p_value']:.4f}"
        )
    anomalies = payload["findings"].get("anomalies", [])
    for item in anomalies:
        lines.append(
            f"- 異常値: {item['metric']}、時刻 {item['timestamp']}、|z|={item['zscore']}"
        )
    lines.append("")
    lines.append("## 7. 推奨アクション")
    if immediate_actions:
        lines.append("### 7.1 追加確認")
        for action in immediate_actions:
            lines.append(f"- {action}")
    else:
        lines.append("### 7.1 追加確認")
        lines.append("- 現時点では追加確認の優先度が高い懸念は限定的です。試験条件と業務要件に照らしてしきい値超過の有無を確認してください。")
    lines.append("")
    if long_term_actions:
        lines.append("### 7.2 改善候補")
        for action in long_term_actions:
            lines.append(f"- {action}")
    else:
        lines.append("### 7.2 改善候補")
        lines.append("- 継続監視のしきい値整備、試験条件の再現性確保、平常時データとの比較基準整備を優先してください。")
    lines.append("")
    lines.append("## 8. 不確実性と留意事項")
    if payload["method_notes"]:
        for note in payload["method_notes"]:
            lines.append(f"- {note}")
    else:
        lines.append("- 相関、ラグ、ルールベースの根拠はいずれも示唆的なものであり、確定的な因果関係として扱わないこと。")
    lines.append("")
    if chart_paths:
        lines.append("## 9. 参考グラフ")
        for chart_path in chart_paths:
            lines.append(f"![{_chart_alt_text(chart_path)}]({chart_path})")
            lines.append("")
    lines.append("## 10. LLM 利用時のガードレール")
    lines.append("- 要約に存在しない事実は断定しないこと。推測は推測として明示すること。")
    return "\n".join(lines)


def _chart_alt_text(chart_path: str) -> str:
    name = chart_path.rsplit("/", 1)[-1]
    if name == "timeseries.png":
        return "主要メトリクスの時系列グラフ"
    if name == "correlation_heatmap.png":
        return "主要メトリクスの相関ヒートマップ"
    return name


def _hypothesis_type_label(value: str) -> str:
    labels = {
        "cpu": "CPU",
        "cpu-system-high": "CPU カーネル処理偏重",
        "cpu-user-high": "CPU ユーザー処理偏重",
        "cpu-steal-high": "CPU steal 増加",
        "cpu-irq-storm": "IRQ 負荷増加",
        "cpu-softirq-storm": "softirq 負荷増加",
        "cpu-pressure-stall": "CPU PSI 高止まり",
        "io": "I/O",
        "io-wait-mixed": "I/O 待ち混在",
        "disk-queue-high": "ディスクキュー増加",
        "io-pressure-some": "I/O PSI some 高止まり",
        "io-pressure-full": "I/O PSI full 高止まり",
        "memory": "メモリ",
        "major-faults-high": "major page fault 増加",
        "mem-pressure-stall-some": "メモリ PSI some 高止まり",
        "mem-pressure-stall-full": "メモリ PSI full 高止まり",
        "swap-inout-high": "swap 入出力増加",
        "swap-thrashing-suspected": "swap スラッシング疑い",
        "network": "ネットワーク",
        "net-drops-high": "ネットワークドロップ増加",
        "net-errors-high": "ネットワークエラー増加",
        "tcp-retrans-high": "TCP 再送増加",
        "softnet-backlog-overflow": "softnet backlog 溢れ",
        "runqueue-high": "ランキュー増加",
        "blocked-tasks-high": "blocked タスク増加",
        "loadavg-high-with-low-runq": "load 高止まりと run queue 非連動",
        "context-switch-storm": "コンテキストスイッチ急増",
        "undetermined": "判定保留",
    }
    return labels.get(value, value)


def _confidence_label(value: str) -> str:
    labels = {
        "high": "高",
        "medium": "中",
        "low": "低",
    }
    return labels.get(value, value)


def build_llm_summary(preprocessed: PreprocessResult, analysis: AnalysisResult) -> dict[str, Any]:
    frame = preprocessed.frame
    essential_columns = [column for column in ESSENTIAL_COLUMNS if column in frame.columns]
    return {
        "constraints": [
            "Do not assert facts absent from the summary.",
            "Mark speculation as speculation.",
            "Treat correlation and lag evidence as suggestive, not definitive causality.",
        ],
        "input_overview": {
            "time_range": {
                "start": frame.index.min().isoformat() if not frame.empty else None,
                "end": frame.index.max().isoformat() if not frame.empty else None,
            },
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "essential_columns": essential_columns,
            "preprocessing_notes": preprocessed.notes,
        },
        "key_findings": {
            "hypotheses": analysis.bottleneck_hypotheses,
            "correlations": analysis.summary.get("correlations", []),
            "lag_analysis": analysis.summary.get("lag_analysis", []),
            "anomalies": analysis.summary.get("anomalies", []),
        },
        "follow_up_prompt": "Produce a customer-facing Japanese test report that summarizes resource utilization trends, notable risks, supporting metrics, recommended follow-up checks, and long-term improvement candidates without overstating causality.",
    }


def _series_snapshot(series: Any) -> dict[str, float] | None:
    clean = series.dropna()
    if clean.empty:
        return None
    return {
        "min": round(float(clean.min()), 6),
        "median": round(float(clean.median()), 6),
        "p95": round(float(clean.quantile(0.95)), 6),
        "max": round(float(clean.max()), 6),
    }


def _build_resource_sections(preprocessed: PreprocessResult, analysis: AnalysisResult) -> list[dict[str, Any]]:
    frame = preprocessed.frame
    hypotheses_by_group = {
        "cpu": _collect_group_hypotheses(analysis.bottleneck_hypotheses, {"cpu", "cpu-system-high", "cpu-user-high", "cpu-steal-high", "cpu-irq-storm", "cpu-softirq-storm", "cpu-pressure-stall", "runqueue-high", "context-switch-storm"}),
        "memory": _collect_group_hypotheses(analysis.bottleneck_hypotheses, {"memory", "major-faults-high", "mem-pressure-stall-some", "mem-pressure-stall-full", "swap-inout-high", "swap-thrashing-suspected"}),
        "io": _collect_group_hypotheses(analysis.bottleneck_hypotheses, {"io", "io-wait-mixed", "io-pressure-some", "io-pressure-full", "disk-queue-high", "blocked-tasks-high", "loadavg-high-with-low-runq"}),
        "network": _collect_group_hypotheses(analysis.bottleneck_hypotheses, {"network", "net-drops-high", "net-errors-high", "tcp-retrans-high", "softnet-backlog-overflow"}),
    }
    return [
        _build_resource_section(
            title="4.1 CPU・スケジューラ",
            metrics=_format_metric_highlights(frame, ["cpu_busy", "%user", "%system", "%iowait", "runq-sz", "ldavg-1", "cswch/s"]),
            hypotheses=hypotheses_by_group["cpu"],
            normal_summary="CPU 使用率と実行待ちの観点では、明確な飽和が継続しているとは断定しにくい状態です。",
        ),
        _build_resource_section(
            title="4.2 メモリ・スワップ",
            metrics=_format_metric_highlights(frame, ["kbavail", "kbswpused", "majflt/s", "pswpin/s", "pswpout/s", "%smem", "%fmem"]),
            hypotheses=hypotheses_by_group["memory"],
            normal_summary="利用可能メモリとスワップの観点では、顕著な逼迫が継続しているとは断定しにくい状態です。",
        ),
        _build_resource_section(
            title="4.3 ストレージ・I/O",
            metrics=_format_metric_highlights(frame, ["%iowait", "await", "%util", "aqu-sz", "rkB/s", "wkB/s", "blocked"]),
            hypotheses=hypotheses_by_group["io"],
            normal_summary="I/O 待ち、待ち行列、デバイス利用率の観点では、顕著なボトルネックが継続しているとは断定しにくい状態です。",
        ),
        _build_resource_section(
            title="4.4 ネットワーク",
            metrics=_format_metric_highlights(frame, ["net_bytes_s", "rxkB/s", "txkB/s", "%ifutil", "retrans/s", "rxdrop/s", "txdrop/s"]),
            hypotheses=hypotheses_by_group["network"],
            normal_summary="ネットワーク帯域、再送、ドロップの観点では、顕著な異常が継続しているとは断定しにくい状態です。",
        ),
    ]


def _build_resource_section(
    *,
    title: str,
    metrics: list[str],
    hypotheses: list[dict[str, Any]],
    normal_summary: str,
) -> dict[str, Any]:
    status = _section_status(hypotheses)
    if hypotheses:
        summary = " / ".join(hypothesis["reason"] for hypothesis in hypotheses[:2])
    else:
        summary = normal_summary
    return {
        "title": title,
        "status": status,
        "summary": summary,
        "highlights": metrics,
        "related_hypotheses": [_hypothesis_type_label(h["type"]) for h in hypotheses[:3]],
    }


def _collect_group_hypotheses(hypotheses: list[dict[str, Any]], types: set[str]) -> list[dict[str, Any]]:
    return [hypothesis for hypothesis in hypotheses if hypothesis.get("type") in types]


def _section_status(hypotheses: list[dict[str, Any]]) -> str:
    confidences = [hypothesis.get("confidence") for hypothesis in hypotheses]
    if "high" in confidences:
        return "要注意"
    if "medium" in confidences:
        return "監視推奨"
    return "概ね安定"


def _format_metric_highlights(frame: Any, columns: list[str]) -> list[str]:
    highlights: list[str] = []
    for column in columns:
        if column not in frame.columns:
            continue
        snapshot = _series_snapshot(frame[column])
        if not snapshot:
            continue
        highlights.append(
            f"{column}: median={snapshot['median']}, p95={snapshot['p95']}, max={snapshot['max']}"
        )
    return highlights[:4]


def _collect_notable_events(findings: dict[str, Any]) -> list[str]:
    events: list[str] = []
    for metric, points in (findings.get("change_points") or {}).items():
        if points:
            events.append(f"{metric} に急変点候補: {', '.join(points[:3])}")
    for item in (findings.get("anomalies") or [])[:5]:
        events.append(
            f"{item['metric']} で外れ値候補: {item['timestamp']} (|z|={item['zscore']})"
        )
    return events[:8]


def _overall_assessment_text(hypotheses: list[dict[str, Any]]) -> str:
    if not hypotheses:
        return "観測範囲では、明確な資源逼迫や継続的な異常は限定的でした。"
    high_count = sum(1 for hypothesis in hypotheses if hypothesis.get("confidence") == "high")
    medium_count = sum(1 for hypothesis in hypotheses if hypothesis.get("confidence") == "medium")
    if high_count:
        return "一部リソースで注意を要する兆候があり、試験結果の解釈時に重点確認が必要です。"
    if medium_count:
        return "継続監視が望ましい兆候はあるものの、直ちに重大障害を示すとは断定できません。"
    return "大きな異常の兆候は限定的ですが、局所的な変動は継続監視が必要です。"


def _build_actions(hypotheses: list[dict[str, Any]], *, immediate: bool) -> list[str]:
    actions: list[str] = []
    types = {hypothesis.get("type") for hypothesis in hypotheses}
    if immediate:
        if {"cpu", "cpu-system-high", "runqueue-high"} & types:
            actions.append("CPU 使用率上昇区間のアプリケーション処理内容、スレッド数、実行待ちキュー長を突合してください。")
        if {"io", "io-pressure-full", "disk-queue-high", "blocked-tasks-high"} & types:
            actions.append("I/O 待ちが高い時間帯について、対象デバイスのキュー長、レイテンシ、マウント先ごとの負荷分布を確認してください。")
        if {"memory", "swap-inout-high", "swap-thrashing-suspected", "mem-pressure-stall-full"} & types:
            actions.append("メモリ消費上位プロセス、ページング発生状況、試験シナリオ切替点との関係を確認してください。")
        if {"network", "net-drops-high", "net-errors-high", "tcp-retrans-high", "softnet-backlog-overflow"} & types:
            actions.append("通信量増加区間の再送、ドロップ、NIC 統計、対向装置側の輻輳有無を確認してください。")
        return actions

    if {"cpu", "cpu-system-high", "runqueue-high"} & types:
        actions.append("CPU ボトルネックが再現する場合は、スレッド設計、並列度、割り込み分散、処理配置の見直しを検討してください。")
    if {"io", "io-pressure-full", "disk-queue-high", "blocked-tasks-high"} & types:
        actions.append("I/O レイテンシが継続する場合は、ストレージ階層、I/O パターン、キャッシュ方針、ファイル配置の見直しを検討してください。")
    if {"memory", "swap-inout-high", "swap-thrashing-suspected", "mem-pressure-stall-full"} & types:
        actions.append("メモリ逼迫が再現する場合は、メモリ割当量、キャッシュ戦略、不要プロセス削減、ヒープ使用量の見直しを検討してください。")
    if {"network", "net-drops-high", "net-errors-high", "tcp-retrans-high", "softnet-backlog-overflow"} & types:
        actions.append("通信起因の劣化が継続する場合は、帯域設計、NIC 設定、キュー設定、パケット処理能力の見直しを検討してください。")
    return actions
