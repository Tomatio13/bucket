from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

from .analysis import AnalysisResult, analyze_dataset
from .preprocess import PreprocessResult

DIMENSION_METRICS = {
    "cpu": ["cpu_busy", "%user", "%system", "%iowait", "%idle", "runq-sz", "ldavg-1", "ldavg-5", "ldavg-15", "cswch/s"],
    "memory": ["kbavail", "kbswpused", "majflt/s", "pswpin/s", "pswpout/s", "%smem", "%fmem"],
    "io": ["await", "%util", "aqu-sz", "rkB/s", "wkB/s", "bread/s", "bwrtn/s", "blocked"],
    "network": ["net_bytes_s", "rxkB/s", "txkB/s", "%ifutil", "retrans/s", "rxdrop/s", "txdrop/s", "rxerr/s", "txerr/s"],
}

DIMENSION_HYPOTHESIS_TYPES = {
    "cpu": {"cpu", "cpu-system-high", "cpu-user-high", "cpu-steal-high", "cpu-irq-storm", "cpu-softirq-storm", "cpu-pressure-stall", "runqueue-high", "context-switch-storm"},
    "memory": {"memory", "major-faults-high", "mem-pressure-stall-some", "mem-pressure-stall-full", "swap-inout-high", "swap-thrashing-suspected"},
    "io": {"io", "io-wait-mixed", "io-pressure-some", "io-pressure-full", "disk-queue-high", "blocked-tasks-high", "loadavg-high-with-low-runq"},
    "network": {"network", "net-drops-high", "net-errors-high", "tcp-retrans-high", "softnet-backlog-overflow"},
}

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "assets" / "llm_partition_config.json"


@dataclass(slots=True)
class LLMPartitionConfig:
    split_mode: str = "auto"
    time_window: str = "1h"
    max_rows_no_split: int = 5000
    max_duration_no_split_hours: float = 6.0
    max_prompt_chars: int = 40000
    enable_dimension_split: bool = True
    dimensions: list[str] = field(default_factory=lambda: ["cpu", "memory", "io", "network"])


def load_llm_partition_config(config_path: str | None = None) -> LLMPartitionConfig:
    resolved_path = config_path or os.environ.get("SAR_ANALYZE_LLM_CONFIG")
    if not resolved_path:
        resolved_path = str(DEFAULT_CONFIG_PATH)

    path = Path(resolved_path)
    if not path.exists():
        return LLMPartitionConfig()

    raw = json.loads(path.read_text(encoding="utf-8"))
    valid_fields = {field_name for field_name in LLMPartitionConfig.__dataclass_fields__}
    filtered = {key: value for key, value in raw.items() if key in valid_fields}
    return LLMPartitionConfig(**filtered)


def build_llm_input_payload(
    preprocessed: PreprocessResult,
    analysis: AnalysisResult,
    compact_payload: dict[str, Any],
    *,
    config: LLMPartitionConfig,
) -> dict[str, Any]:
    decision = decide_llm_partition(preprocessed, compact_payload, config=config)
    if decision["strategy"] == "single":
        return {
            "strategy": "single",
            "decision": decision,
        }

    return {
        "strategy": "partitioned",
        "decision": decision,
        "global_context": _build_global_context(preprocessed, analysis, config=config),
        "dimension_packets": _build_dimension_packets(preprocessed, config=config),
        "final_report_requirements": _build_final_report_requirements(),
    }


def decide_llm_partition(
    preprocessed: PreprocessResult,
    compact_payload: dict[str, Any],
    *,
    config: LLMPartitionConfig,
) -> dict[str, Any]:
    frame = preprocessed.frame
    if frame.empty:
        return {
            "strategy": "single",
            "mode": config.split_mode,
            "reasons": ["empty_dataset"],
            "time_window": config.time_window,
            "dimension_split": False,
            "estimated_prompt_chars": 0,
        }

    estimated_prompt_chars = len(json.dumps(compact_payload, ensure_ascii=False))
    duration_hours = _duration_hours(frame.index)
    reasons: list[str] = []

    if config.split_mode == "always":
        reasons.append("split_mode=always")
    elif config.split_mode == "auto":
        if len(frame) > config.max_rows_no_split:
            reasons.append("row_count_exceeded")
        if duration_hours > config.max_duration_no_split_hours:
            reasons.append("duration_exceeded")
        if estimated_prompt_chars > config.max_prompt_chars:
            reasons.append("prompt_size_exceeded")

    should_split = config.split_mode == "always" or (config.split_mode == "auto" and bool(reasons))
    strategy = "partitioned" if should_split else "single"
    return {
        "strategy": strategy,
        "mode": config.split_mode,
        "reasons": reasons or ["within_threshold"],
        "time_window": config.time_window,
        "dimension_split": should_split and config.enable_dimension_split,
        "estimated_prompt_chars": estimated_prompt_chars,
        "row_count": int(len(frame)),
        "duration_hours": round(duration_hours, 3),
    }


def _build_global_context(
    preprocessed: PreprocessResult,
    analysis: AnalysisResult,
    *,
    config: LLMPartitionConfig,
) -> dict[str, Any]:
    frame = preprocessed.frame
    return {
        "input_overview": {
            "start": frame.index.min().isoformat() if not frame.empty else None,
            "end": frame.index.max().isoformat() if not frame.empty else None,
            "row_count": int(len(frame)),
            "sampling_interval": preprocessed.sampling_interval or "unknown",
            "time_window": config.time_window,
        },
        "preprocessing": {
            "notes": preprocessed.notes,
            "derived_columns": preprocessed.derived_columns,
            "missing_columns": preprocessed.missing_columns,
        },
        "overall_hypotheses": analysis.bottleneck_hypotheses,
        "overall_evidence": {
            "correlations": analysis.summary.get("correlations", []),
            "lag_analysis": analysis.summary.get("lag_analysis", []),
            "granger": analysis.summary.get("granger", []),
            "anomalies": analysis.summary.get("anomalies", []),
            "change_points": analysis.summary.get("change_points", {}),
        },
        "constraints": [
            "JSON に無い事実を断定しないこと。",
            "推測は推測と明記すること。",
            "相関、lag、Granger は因果の証明として扱わないこと。",
        ],
    }


def _build_dimension_packets(
    preprocessed: PreprocessResult,
    *,
    config: LLMPartitionConfig,
) -> list[dict[str, Any]]:
    packets: list[dict[str, Any]] = []
    frame = preprocessed.frame
    if not config.enable_dimension_split:
        metrics = []
        for dimension in config.dimensions:
            metrics.extend(metric for metric in DIMENSION_METRICS.get(dimension, []) if metric in frame.columns)
        unique_metrics = list(dict.fromkeys(metrics))
        if unique_metrics:
            return [
                {
                    "dimension": "all",
                    "metrics": unique_metrics,
                    "window_summaries": _build_window_summaries(
                        preprocessed,
                        metrics=unique_metrics,
                        dimension="all",
                        config=config,
                    ),
                }
            ]

    for dimension in config.dimensions:
        metrics = [metric for metric in DIMENSION_METRICS.get(dimension, []) if metric in frame.columns]
        if not metrics:
            continue
        window_summaries = _build_window_summaries(preprocessed, metrics=metrics, dimension=dimension, config=config)
        packets.append(
            {
                "dimension": dimension,
                "metrics": metrics,
                "window_summaries": window_summaries,
            }
        )
    return packets


def _build_window_summaries(
    preprocessed: PreprocessResult,
    *,
    metrics: list[str],
    dimension: str,
    config: LLMPartitionConfig,
) -> list[dict[str, Any]]:
    frame = preprocessed.frame
    summaries: list[dict[str, Any]] = []
    for window_start, window_frame in frame.groupby(pd.Grouper(freq=config.time_window)):
        if window_frame.empty or window_frame[metrics].dropna(how="all").empty:
            continue
        window_preprocessed = PreprocessResult(
            frame=window_frame.copy(),
            notes=preprocessed.notes,
            derived_columns=preprocessed.derived_columns,
            missing_columns=preprocessed.missing_columns,
            sampling_interval=preprocessed.sampling_interval,
        )
        window_analysis = analyze_dataset(window_preprocessed, max_lag=min(5, max(len(window_frame) // 4, 1)))
        filtered_hypotheses = [
            item
            for item in window_analysis.bottleneck_hypotheses
            if dimension == "all" or item.get("type") in DIMENSION_HYPOTHESIS_TYPES.get(dimension, set())
        ]
        anomalies = [
            item
            for item in window_analysis.summary.get("anomalies", [])
            if item.get("metric") in metrics
        ]
        change_points = {
            metric: points
            for metric, points in (window_analysis.summary.get("change_points") or {}).items()
            if metric in metrics
        }
        summaries.append(
            {
                "window": {
                    "start": window_start.isoformat(),
                    "end": window_frame.index.max().isoformat(),
                    "rows": int(len(window_frame)),
                },
                "metric_snapshot": {
                    metric: _series_snapshot(window_frame[metric])
                    for metric in metrics
                    if metric in window_frame.columns and _series_snapshot(window_frame[metric]) is not None
                },
                "hypotheses": filtered_hypotheses,
                "events": {
                    "anomalies": anomalies[:5],
                    "change_points": change_points,
                },
            }
        )
    return summaries


def _build_final_report_requirements() -> dict[str, Any]:
    return {
        "target_sections": [
            "1. エグゼクティブサマリー",
            "2. 分析対象と前提条件",
            "3. 前処理と集計条件",
            "4. リソース観点別の分析結果",
            "5. 特記事項",
            "6. 解析根拠",
            "7. 推奨アクション",
            "8. 不確実性と留意事項",
        ],
        "style": "顧客向け、日本語、断定し過ぎない",
    }


def _duration_hours(index: pd.Index) -> float:
    if len(index) < 2:
        return 0.0
    duration = index.max() - index.min()
    return float(duration.total_seconds() / 3600.0)


def _series_snapshot(series: pd.Series) -> dict[str, float] | None:
    clean = series.dropna()
    if clean.empty:
        return None
    return {
        "min": round(float(clean.min()), 6),
        "median": round(float(clean.median()), 6),
        "p95": round(float(clean.quantile(0.95)), 6),
        "max": round(float(clean.max()), 6),
    }


def config_to_dict(config: LLMPartitionConfig) -> dict[str, Any]:
    return asdict(config)
