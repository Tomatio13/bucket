#!/usr/bin/env bash

set -euo pipefail

INPUT_PATH="${1:?input .bin or sadf export is required}"
RESAMPLE_RULE="${2:-5s}"
OUTPUT_PREFIX="${3:-sar_report}"
INPUT_FORMAT="${4:-raw-sar}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHONPATH_DIR="${SCRIPT_DIR}"
PROMPT_SCRIPT="${SCRIPT_DIR}/build_llm_prompt.py"
CHART_SCRIPT="${SCRIPT_DIR}/generate_charts.py"
EXPORT_SCRIPT="${SCRIPT_DIR}/export-raw-sar.sh"
CHART_DIR="${OUTPUT_PREFIX}_charts"
WORK_INPUT="${INPUT_PATH}"
WORK_FORMAT="${INPUT_FORMAT}"

TEMP_EXPORT=""
cleanup() {
  if [ -n "${TEMP_EXPORT}" ] && [ -f "${TEMP_EXPORT}" ]; then
    rm -f "${TEMP_EXPORT}"
  fi
}
trap cleanup EXIT

echo "[analyze_sar] input=${INPUT_PATH} format=${INPUT_FORMAT} resample=${RESAMPLE_RULE} prefix=${OUTPUT_PREFIX}"

if [ "${INPUT_FORMAT}" = "raw-sar" ]; then
  TEMP_EXPORT="$(mktemp "${TMPDIR:-/tmp}/sar-analyze-XXXXXX.tsv")"
  "${EXPORT_SCRIPT}" "${INPUT_PATH}" sadf-p > "${TEMP_EXPORT}"
  WORK_INPUT="${TEMP_EXPORT}"
  WORK_FORMAT="sadf-p"
  echo "[analyze_sar] exported raw-sar to ${TEMP_EXPORT} for workflow reuse"
fi

CHART_ARGS=()
if PYTHONPATH="${PYTHONPATH_DIR}" python "${CHART_SCRIPT}" "${WORK_INPUT}" \
  --format "${WORK_FORMAT}" \
  --source-format "${INPUT_FORMAT}" \
  --resample "${RESAMPLE_RULE}" \
  --output-dir "${CHART_DIR}"; then
  if [ -f "${CHART_DIR}/timeseries.png" ]; then
    CHART_ARGS+=(--chart "${CHART_DIR}/timeseries.png")
  fi
  if [ -f "${CHART_DIR}/correlation_heatmap.png" ]; then
    CHART_ARGS+=(--chart "${CHART_DIR}/correlation_heatmap.png")
  fi
else
  echo "[analyze_sar] chart generation skipped"
fi

PYTHONPATH="${PYTHONPATH_DIR}" python -m sar_analyze "${WORK_INPUT}" \
  --format "${WORK_FORMAT}" \
  --source-format "${INPUT_FORMAT}" \
  --resample "${RESAMPLE_RULE}" \
  --report text \
  "${CHART_ARGS[@]}" \
  --output "${OUTPUT_PREFIX}.md"

PYTHONPATH="${PYTHONPATH_DIR}" python -m sar_analyze "${WORK_INPUT}" \
  --format "${WORK_FORMAT}" \
  --source-format "${INPUT_FORMAT}" \
  --resample "${RESAMPLE_RULE}" \
  --report json \
  --output "${OUTPUT_PREFIX}.json"

PYTHONPATH="${PYTHONPATH_DIR}" python -m sar_analyze "${WORK_INPUT}" \
  --format "${WORK_FORMAT}" \
  --source-format "${INPUT_FORMAT}" \
  --resample "${RESAMPLE_RULE}" \
  --report json \
  --json-profile compact \
  --output "${OUTPUT_PREFIX}.compact.json"

python "${PROMPT_SCRIPT}" \
  "${OUTPUT_PREFIX}.compact.json" \
  --output "${OUTPUT_PREFIX}.prompt.txt"

echo "[analyze_sar] wrote ${OUTPUT_PREFIX}.md, ${OUTPUT_PREFIX}.json, ${OUTPUT_PREFIX}.compact.json, and ${OUTPUT_PREFIX}.prompt.txt"
