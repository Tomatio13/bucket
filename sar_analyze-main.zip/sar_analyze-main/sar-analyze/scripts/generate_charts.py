from __future__ import annotations

import argparse

from sar_analyze.io import load_dataset
from sar_analyze.preprocess import preprocess_dataset
from sar_analyze.visualize import generate_basic_charts


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="generate_charts")
    parser.add_argument("input", help="Path to raw sar binary or sadf export.")
    parser.add_argument("--format", choices=["sadf-d", "sadf-p", "raw-sar"], default="raw-sar")
    parser.add_argument(
        "--source-format",
        choices=["sadf-d", "sadf-p", "raw-sar"],
        default=None,
        help="Original input format when the provided file is an intermediate export.",
    )
    parser.add_argument("--resample", default="5s")
    parser.add_argument("--output-dir", default="charts")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    dataset = load_dataset(args.input, fmt=args.format, source_format=args.source_format)
    preprocessed = preprocess_dataset(dataset, resample_rule=args.resample)
    generated = generate_basic_charts(preprocessed, args.output_dir)
    for path in generated:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
