from __future__ import annotations

import argparse
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    script_dir = Path(__file__).resolve().parent
    default_template = script_dir / "assets" / "llm_prompt_template.txt"
    parser = argparse.ArgumentParser(prog="build_llm_prompt")
    parser.add_argument("compact_json", help="Path to compact analysis JSON.")
    parser.add_argument("--template", default=str(default_template), help="Prompt template path.")
    parser.add_argument("--output", default=None, help="Optional output prompt file path.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    compact_path = Path(args.compact_json)
    template_path = Path(args.template)

    compact_json = compact_path.read_text(encoding="utf-8")
    template = template_path.read_text(encoding="utf-8")
    content = template.replace("{{COMPACT_JSON}}", compact_json)

    if args.output:
        Path(args.output).write_text(content, encoding="utf-8")
    else:
        print(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
