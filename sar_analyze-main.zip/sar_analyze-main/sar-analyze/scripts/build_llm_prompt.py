from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def build_parser() -> argparse.ArgumentParser:
    script_dir = Path(__file__).resolve().parent
    default_template = script_dir / "assets" / "llm_prompt_template.txt"
    parser = argparse.ArgumentParser(prog="build_llm_prompt")
    parser.add_argument("compact_json", help="Path to compact analysis JSON.")
    parser.add_argument("--template", default=str(default_template), help="Prompt template path.")
    parser.add_argument("--output", default=None, help="Optional output prompt file path.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    compact_path = Path(args.compact_json)
    compact_payload = json.loads(compact_path.read_text(encoding="utf-8"))
    llm_input = compact_payload.get("llm_input")
    if llm_input and llm_input.get("strategy") == "partitioned":
        content = build_partitioned_prompt_bundle(llm_input)
    else:
        template_path = Path(args.template)
        compact_json = json.dumps(compact_payload, ensure_ascii=False, indent=2)
        template = template_path.read_text(encoding="utf-8")
        content = template.replace("{{COMPACT_JSON}}", compact_json)

    if args.output:
        Path(args.output).write_text(content, encoding="utf-8")
    else:
        print(content)
    return 0

def build_partitioned_prompt_bundle(llm_input: dict[str, Any]) -> str:
    decision = llm_input.get("decision", {})
    lines = [
        "# LLM Prompt Bundle",
        "",
        "この bundle はローカル LLM へ順に入力するための分割済みプロンプトです。",
        f"- strategy: {decision.get('strategy')}",
        f"- reasons: {', '.join(decision.get('reasons', []))}",
        f"- time_window: {decision.get('time_window')}",
        "",
        "## 実行順",
        "1. 観点別プロンプトを CPU / メモリ / I/O / ネットワークの順に実行する",
        "2. 各出力を保存する",
        "3. 最後に統合プロンプトへ各観点の要約結果を貼り付ける",
        "",
    ]

    for index, packet in enumerate(llm_input.get("dimension_packets", []), start=1):
        lines.extend(
            [
                f"## Prompt {index}: {packet['dimension']}",
                "",
                build_dimension_prompt(llm_input.get("global_context", {}), packet),
                "",
            ]
        )

    lines.extend(
        [
            f"## Prompt {len(llm_input.get('dimension_packets', [])) + 1}: final-integration",
            "",
            build_final_prompt(
                llm_input.get("global_context", {}),
                llm_input.get("final_report_requirements", {}),
                [packet["dimension"] for packet in llm_input.get("dimension_packets", [])],
            ),
            "",
        ]
    )
    return "\n".join(lines)


def build_dimension_prompt(global_context: dict[str, Any], packet: dict[str, Any]) -> str:
    dimension = packet["dimension"]
    payload = {
        "global_context": global_context,
        "dimension_packet": packet,
    }
    return "\n".join(
        [
            f"あなたは {dimension} 観点の性能解析担当です。",
            "以下の JSON は、長時間 sar データを時間窓単位で集約した結果です。",
            "この観点に無関係な主張は書かず、JSON にない事実は断定しないでください。",
            "出力は日本語で、次の 4 項目のみを含めてください。",
            "1. 全体傾向",
            "2. 時間帯ごとの特記事項",
            "3. 根拠指標",
            "4. 追加確認事項",
            "",
            json.dumps(payload, ensure_ascii=False, indent=2),
        ]
    )


def build_final_prompt(
    global_context: dict[str, Any],
    final_requirements: dict[str, Any],
    dimensions: list[str],
) -> str:
    placeholders = "\n".join(
        f"<<{dimension.upper()}_SUMMARY>>" for dimension in dimensions
    )
    payload = {
        "global_context": global_context,
        "final_report_requirements": final_requirements,
    }
    return "\n".join(
        [
            "あなたはSRE/性能解析の専門家です。",
            "以下の全体コンテキストと、先に作成した観点別要約を統合して顧客向けレポートを作成してください。",
            "JSON に無い事実を断定せず、観点別要約間で矛盾があれば不確実性として明記してください。",
            "出力は日本語の Markdown としてください。",
            "",
            "### 全体コンテキスト",
            json.dumps(payload, ensure_ascii=False, indent=2),
            "",
            "### ここに観点別要約を貼り付ける",
            placeholders,
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
