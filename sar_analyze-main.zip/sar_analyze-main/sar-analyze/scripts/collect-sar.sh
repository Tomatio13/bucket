#!/usr/bin/env bash

set -euo pipefail

INTERVAL="${1:-5}"
COUNT="${2:-12}"
OUTPUT_PATH="${3:-sar_capture_$(date +%Y%m%d_%H%M%S).bin}"

if ! command -v sar >/dev/null 2>&1; then
  echo "sar command not found. Install sysstat first." >&2
  exit 1
fi

cat <<EOF
[collect_sar] interval=${INTERVAL}s count=${COUNT} output=${OUTPUT_PATH}
[collect_sar] metrics=CPU, memory, swap, io transfer, block device, network(dev/errors/tcp/soft), load/psi, context switches, interrupts
EOF

exec sar \
  -u ALL \
  -r ALL \
  -S \
  -B \
  -W \
  -b \
  -d \
  -n DEV,EDEV,TCP,ETCP,SOCK,SOFT \
  -q ALL \
  -w \
  -I SUM \
  "${INTERVAL}" \
  "${COUNT}" \
  -o "${OUTPUT_PATH}"
