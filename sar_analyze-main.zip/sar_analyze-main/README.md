# sar_analyze skills

Linux `sar` / `sadf` の収集・前処理・分析・可視化・LLM レポート生成を行う Agent Skill です。

このリポジトリは `sar-analyze/` だけを配布対象とする前提です。  
トップレベルには `README.md`、`.gitignore`、そして `sar-analyze/` だけを置きます。

## 使い方

このリポジトリを clone したら、`sar-analyze/` をそのまま利用中の agent の skill ディレクトリへコピーします。

```bash
cp -R sar-analyze <agent-skill-root>/
```

## このリポジトリの構成

```text
.
├── README.md
├── .gitignore
└── sar-analyze/
```

`sar-analyze/` の中は概ね次の構成です。

```text
<skill-bundle-root>/
├── .venv/       # 推奨: skill 共有 virtualenv
└── sar-analyze/
    ├── SKILL.md
    └── scripts/
```

`SKILL.md` が入口です。  
実行コマンドや依存パッケージ、参照すべき補助資料は `sar-analyze/` の中で閉じるようにしています。

相対パスは **skill ディレクトリ基準** です。  
たとえば `sar-analyze/SKILL.md` にある `scripts/analyze-sar.sh` は、ユーザーの作業用ディレクトリに新しく `scripts/` を作る意味ではなく、skill 同梱の `sar-analyze/scripts/analyze-sar.sh` を指します。

agent runtime がこの skill のインストール先パスをすでに持っているなら、そのパスを正として使ってください。  
`find / ...` や `Glob **/sar-analyze/**` のような広い探索で skill の場所を探し直さないでください。古いコピーや別 workspace のコピーを誤って拾う原因になります。

Python 依存は、可能なら **skill と同じ配置ルートにある共有 `.venv`** に入れてください。  
ユーザーの作業ディレクトリごとに `.venv` を量産するより、同じ skill を使う複数 agent から再利用できる構成を優先します。

## `sar-analyze`

全体の入口です。  
収集、解析、Markdown / JSON / compact JSON / prompt.txt 生成までをまとめて扱います。

主なファイル:

- `sar-analyze/SKILL.md`
- `sar-analyze/scripts/analyze-sar.sh`
- `sar-analyze/scripts/export-raw-sar.sh`
- `sar-analyze/scripts/collect-sar.sh`
- `sar-analyze/scripts/generate_charts.py`
- `sar-analyze/scripts/build_llm_prompt.py`

## まず何を使えばいいか

迷ったら `sar-analyze` だけ見れば足ります。

典型フローはこれです。

```bash
sar-analyze/scripts/collect-sar.sh 5 120 my_capture.bin
sar-analyze/scripts/analyze-sar.sh my_capture.bin 5s my_capture_report raw-sar
```

入力ファイルと出力先はユーザーの作業ディレクトリでよいですが、実行するコード自体は skill 同梱スクリプトを使う想定です。解析のためにユーザー作業ディレクトリへ新しい `scripts/` や `sar_analyze/` を scaffold しないでください。

`raw-sar` 入力では workflow 内で `sadf -p` を 1 回だけ実行し、その TSV を各段の処理で再利用します。生の `sadf` 行を agent との会話へ流し込むのではなく、ファイルに閉じ込めて集計結果だけを返す前提です。

このとき実処理は中間の `sadf-p` TSV を使いますが、生成される report の前処理ノートでは元入力が `raw-sar` だったことを保持します。

これで次の成果物が生成されます。

- `my_capture_report.md`
- `my_capture_report.json`
- `my_capture_report.compact.json`
- `my_capture_report.prompt.txt`
- `my_capture_report_charts/timeseries.png`
- `my_capture_report_charts/correlation_heatmap.png`

自然言語での最終説明が必要な場合は、agent は `my_capture_report.prompt.txt` を自分の最終要約生成に使う前提です。  
`prompt.txt` を作るだけで終わらせず、その内容を agent 側へ再投入して最終の説明文を出してください。

## ケース別の使い分け

既存の `.bin` から export だけ作りたい:

```bash
sar-analyze/scripts/export-raw-sar.sh my_capture.bin sadf-p > export.tsv
```

グラフだけ作りたい:

```bash
python sar-analyze/scripts/generate_charts.py my_capture.bin --format raw-sar --resample 5s --output-dir charts
```

中間の `sadf-p` TSV を直接処理するが、元入力が `raw-sar` だったことも残したい:

```bash
python -m sar_analyze export.tsv --format sadf-p --source-format raw-sar --resample 5s --report text
```

LLM に渡す prompt だけ作りたい:

```bash
python sar-analyze/scripts/build_llm_prompt.py my_capture_report.compact.json --output my_capture_report.prompt.txt
```

## セットアップ

共通の基本手順は次の通りです。作業ディレクトリではなく、skill bundle root の共有 `.venv` を優先してください。

```bash
test -d <skill-bundle-root>/.venv || python -m venv <skill-bundle-root>/.venv
. <skill-bundle-root>/.venv/bin/activate
pip install pandas
```

追加依存:

- 可視化するなら `pip install matplotlib`
- `statsmodels` ベースの Granger を使うなら `pip install statsmodels`

システム側では `sar` と `sadf` が必要です。

## 生成物

標準 workflow は次を作ります。

| ファイル | 内容 |
|----------|------|
| `report.md` | 人間向け要約 |
| `report.json` | 完全な機械可読データ |
| `report.compact.json` | LLM 投入向け軽量 JSON |
| `report.prompt.txt` | compact JSON を埋め込んだ prompt |
| `report_charts/timeseries.png` | 主要メトリクスの時系列グラフ |
| `report_charts/correlation_heatmap.png` | 主要メトリクスの相関ヒートマップ |

## 制約

- `statsmodels` が無いと Granger は使えません
- `matplotlib` が無いと可視化は使えません
- device / NIC 集約はヒューリスティックなので、環境ごとの微調整余地があります
