# sar-analyze

Linux `sar` / `sadf` データを前処理し、可視化、分析、顧客向けレポート、LLM 向け入力を生成する skill bundle です。

この README はリポジトリ直下に置く前提でまとめています。  
実装本体は [`sar-analyze/`](sar-analyze) 配下にあります。

## 概要

- `raw-sar` バイナリまたは `sadf -d/-p` のエクスポートを入力にできます。
- 前処理で時刻を `Asia/Tokyo` 基準に正規化し、メトリクス名正規化、派生列生成、リサンプリングを行います。
- Markdown レポート、JSON レポート、compact JSON、LLM prompt を生成します。
- 長時間データでは、Python 側で自動判定して LLM 入力を分割できます。

## リポジトリ構成

```text
.
├── README.md
├── docs/
│   └── design.md
└── sar-analyze/
    ├── SKILL.md
    ├── scripts/
    └── tests/
```

主なファイル:

- [`sar-analyze/SKILL.md`](sar-analyze/SKILL.md)
- [`sar-analyze/scripts/analyze-sar.sh`](sar-analyze/scripts/analyze-sar.sh)
- [`sar-analyze/scripts/export-raw-sar.sh`](sar-analyze/scripts/export-raw-sar.sh)
- [`sar-analyze/scripts/collect-sar.sh`](sar-analyze/scripts/collect-sar.sh)
- [`sar-analyze/scripts/generate_charts.py`](sar-analyze/scripts/generate_charts.py)
- [`sar-analyze/scripts/build-llm-handoff.sh`](sar-analyze/scripts/build-llm-handoff.sh)
- [`sar-analyze/scripts/build_llm_prompt.py`](sar-analyze/scripts/build_llm_prompt.py)

## セットアップ

共有 `.venv` を使う構成を推奨します。

```bash
test -d <skill-bundle-root>/.venv || python -m venv <skill-bundle-root>/.venv
. <skill-bundle-root>/.venv/bin/activate
pip install pandas
```

追加依存:

- 可視化するなら `pip install matplotlib`
- `statsmodels` ベースの Granger を使うなら `pip install statsmodels`

システム側では `sar` と `sadf` が必要です。

## 使い方

### まとめて実行

```bash
sar-analyze/scripts/analyze-sar.sh my_capture.bin 5s my_capture_report raw-sar
```

`raw-sar` の代わりに `sadf-d` または `sadf-p` も指定できます。

典型フロー:

```bash
sar-analyze/scripts/collect-sar.sh 5 120 my_capture.bin
sar-analyze/scripts/analyze-sar.sh my_capture.bin 5s my_capture_report raw-sar
```

レポートを生成せず、LLM に渡す compact JSON と prompt だけ作りたい:

```bash
sar-analyze/scripts/build-llm-handoff.sh my_capture.bin 5s my_capture_prompt raw-sar
```

### JSON / Markdown を個別生成

```bash
PYTHONPATH=sar-analyze/scripts python -m sar_analyze export.tsv \
  --format sadf-p \
  --resample 1min \
  --timezone Asia/Tokyo \
  --report json \
  --json-profile compact \
  --output report.compact.json
```

```bash
PYTHONPATH=sar-analyze/scripts python -m sar_analyze export.tsv \
  --format sadf-p \
  --resample 1min \
  --timezone Asia/Tokyo \
  --report text \
  --output report.md
```

### ケース別

既存の `.bin` から export だけ作りたい:

```bash
sar-analyze/scripts/export-raw-sar.sh my_capture.bin sadf-p > export.tsv
```

グラフだけ作りたい:

```bash
python sar-analyze/scripts/generate_charts.py my_capture.bin \
  --format raw-sar \
  --resample 5s \
  --timezone Asia/Tokyo \
  --output-dir charts
```

中間の `sadf-p` TSV を直接処理するが、元入力が `raw-sar` だったことも残したい:

```bash
PYTHONPATH=sar-analyze/scripts python -m sar_analyze export.tsv \
  --format sadf-p \
  --source-format raw-sar \
  --resample 5s \
  --report text
```

LLM に渡す prompt だけ作りたい:

```bash
python sar-analyze/scripts/build_llm_prompt.py \
  my_capture_report.compact.json \
  --output my_capture_report.prompt.txt
```

## 主な出力

- `*.md`: 顧客向け Markdown レポート
- `*.json`: 詳細 JSON レポート
- `*.compact.json`: LLM 向け compact JSON
- `*.prompt.txt`: 単発 prompt または分割 prompt bundle
- `*_charts/*.png`: 時系列グラフや相関ヒートマップ

標準 workflow では次の成果物が生成されます。

- `my_capture_report.md`
- `my_capture_report.json`
- `my_capture_report.compact.json`
- `my_capture_report.prompt.txt`
- `my_capture_report_charts/timeseries.png`
- `my_capture_report_charts/correlation_heatmap.png`

## LLM 入力分割

長時間データや大きな prompt では、`compact.json` に `llm_input` が追加されます。  
[`sar-analyze/scripts/build_llm_prompt.py`](sar-analyze/scripts/build_llm_prompt.py) はこれを見て、以下のどちらかを出力します。

- 小規模データ: 1 回で投入する単発 prompt
- 長時間データ: 時分割 + 観点別 prompt + 最終統合 prompt を含む bundle

分割要否は Python 側で自動判定します。判定基準と分割単位は config で変更できます。

### 設定ファイル

既定値は [`sar-analyze/scripts/assets/llm_partition_config.json`](sar-analyze/scripts/assets/llm_partition_config.json) です。

```json
{
  "split_mode": "auto",
  "time_window": "1h",
  "max_rows_no_split": 5000,
  "max_duration_no_split_hours": 6.0,
  "max_prompt_chars": 40000,
  "enable_dimension_split": true,
  "dimensions": ["cpu", "memory", "io", "network"]
}
```

### config パラメータ詳細

- `split_mode`
  - LLM 入力分割の基本動作を決めます。
  - `auto`: 行数、時間幅、prompt 推定サイズが閾値を超えたときだけ分割します。
  - `always`: 常に分割します。長時間データを必ず段階投入したいときに使います。
  - `never`: 常に非分割です。LLM の入力上限に余裕がある前提で使います。

- `time_window`
  - 時分割するときの時間窓です。
  - `pandas` の resample / Grouper と同様の表記を想定しています。例: `30min`, `1h`, `3h`, `6h`
  - 短くすると局所的な異常を拾いやすくなり、長くすると全体傾向を見やすくなります。

- `max_rows_no_split`
  - `split_mode=auto` のとき、非分割を許容する最大行数です。
  - 前処理後の DataFrame 行数で判定します。
  - この値を超えると分割候補になります。

- `max_duration_no_split_hours`
  - `split_mode=auto` のとき、非分割を許容する最大時間幅です。
  - 前処理後データの先頭時刻から末尾時刻までの時間差で判定します。
  - たとえば `6.0` なら、6 時間を超えた時点で分割候補になります。

- `max_prompt_chars`
  - `split_mode=auto` のとき、compact JSON の推定文字数上限です。
  - `compact.json` をそのまま prompt に埋めた場合の概算サイズで判定します。
  - 行数や時間幅が閾値以内でも、メトリクス数やイベント数が多い場合はこの条件で分割されます。

- `enable_dimension_split`
  - `true` の場合、時分割した後に `cpu` / `memory` / `io` / `network` の観点別 packet に分けます。
  - `false` の場合、観点別には分けず、時間窓だけ分割した `all` packet を 1 本作ります。
  - 観点ごとに LLM を複数回回したいなら `true`、単一の長文要約に寄せたいなら `false` が向いています。

- `dimensions`
  - 観点別分割を有効にしたときの対象観点と順序です。
  - 既定値は `["cpu", "memory", "io", "network"]` です。
  - この並びは prompt bundle の出力順にも使われます。
  - 現在サポートしている値は `cpu`, `memory`, `io`, `network` です。

### 調整の目安

- 短時間の性能確認で 1 回で投げたい:
  - `split_mode: auto`
  - `max_duration_no_split_hours` をやや大きめにする

- 72 時間級の長時間試験をローカル LLM で段階投入したい:
  - `split_mode: auto` または `always`
  - `time_window: 1h` または `3h`
  - `enable_dimension_split: true`

- モデルの入力上限は厳しいが、多段の観点別実行は避けたい:
  - `split_mode: auto`
  - `time_window: 1h`
  - `enable_dimension_split: false`

### 設定の差し替え

CLI で指定:

```bash
PYTHONPATH=sar-analyze/scripts python -m sar_analyze export.tsv \
  --format sadf-p \
  --report json \
  --json-profile compact \
  --llm-config /path/to/llm_partition_config.json \
  --output report.compact.json
```

シェルスクリプトで指定:

```bash
SAR_ANALYZE_LLM_CONFIG=/path/to/llm_partition_config.json \
sar-analyze/scripts/analyze-sar.sh my_capture.bin 5s my_capture_report raw-sar
```

## 制約

- `statsmodels` が無いと Granger は使えません
- `matplotlib` が無いと可視化は使えません
- device / NIC 集約はヒューリスティックなので、環境ごとの微調整余地があります

## テスト

```bash
cd sar-analyze
python -m unittest discover -s tests -v
python -m compileall scripts tests
```

## ドキュメント

- 設計書: [docs/design.md](docs/design.md)
