---
marp: true
title: Video Pitch Deck Template
paginate: false
html: true
theme: default
style: |
  section {
    position: relative;
    overflow: hidden;
    width: 100%;
    height: 100%;
    color: #fff;
    background: #030303;
    font-family: 'Plus Jakarta Sans', 'Noto Sans JP', sans-serif;
    padding: 4% 5.2% 3.5%;
  }

  section .bg-video {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 0;
    pointer-events: none;
  }

  section .layer {
    position: relative;
    z-index: 10;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  .header {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    align-items: center;
    font-size: clamp(12px, 1.05vw, 20px);
    opacity: 0.8;
  }

  .header .left { justify-self: start; }
  .header .center { justify-self: center; }
  .header .right { justify-self: end; }

  .logo {
    width: 129px;
    height: 40px;
    border: 1px solid rgba(255,255,255,0.65);
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    letter-spacing: 0.08em;
    font-weight: 700;
  }

  .glass {
    position: relative;
    border: 1px solid rgba(255,255,255,0.12);
    background: linear-gradient(145deg, rgba(255,255,255,0.08), rgba(255,255,255,0.03));
    backdrop-filter: blur(24px) saturate(1.4);
    border-radius: 22px;
    overflow: hidden;
  }

  .glass::before {
    content: '';
    position: absolute;
    left: -14%;
    top: -26%;
    width: 72%;
    height: 72%;
    border-radius: 9999px;
    background: radial-gradient(circle, rgba(255,255,255,0.17), rgba(255,255,255,0));
    pointer-events: none;
  }

  .cover-main {
    flex: 1;
    display: grid;
    place-items: center;
    transform: translateY(-3%);
    text-align: center;
  }

  .cover-title {
    font-size: clamp(32px, 5.6vw, 96px);
    line-height: 1.05;
    letter-spacing: -0.02em;
    font-weight: 700;
    margin: 0;
    opacity: 0.9;
  }

  .cover-sub {
    font-size: clamp(20px, 2.8vw, 48px);
    margin-top: 1.5%;
    opacity: 0.9;
  }

  .cover-author {
    font-size: clamp(14px, 1.35vw, 24px);
    margin-top: 2%;
    opacity: 0.75;
  }

  .cover-foot {
    text-align: center;
    font-size: clamp(12px, 1.05vw, 20px);
    opacity: 0.6;
  }

  .intro-title,
  .analytics-title,
  .quote-text,
  .outro-title {
    letter-spacing: -0.02em;
    line-height: 1.05;
    margin: 0;
  }

  .intro-title { font-size: clamp(28px, 4vw, 64px); margin-top: 5%; max-width: 58%; }

  .intro-cols {
    margin-top: 3.5%;
    display: flex;
    gap: 4%;
    align-items: stretch;
  }

  .intro-c1 { flex: 0 0 22%; }
  .intro-c2 { flex: 0 0 38%; }
  .intro-c3 { flex: 0 0 20%; display: flex; flex-direction: column; justify-content: space-between; }

  .body-text {
    font-size: clamp(13px, 1.1vw, 20px);
    line-height: 1.5;
    opacity: 0.9;
    margin: 0;
  }

  .big-stat {
    font-size: clamp(28px, 3.6vw, 64px);
    line-height: 1;
    font-weight: 700;
    margin: 0;
  }

  .analytics-wrap {
    margin-top: 4%;
    text-align: center;
  }

  .analytics-sub {
    font-size: clamp(14px, 1.3vw, 24px);
    opacity: 0.9;
    margin: 0;
  }

  .analytics-title {
    font-size: clamp(28px, 4vw, 64px);
    margin-top: 0.4%;
    font-weight: 700;
  }

  .grid-wrap {
    margin-top: 3.3%;
    height: 66%;
    display: flex;
    flex-direction: column;
    gap: clamp(10px, 1.35vw, 27px);
  }

  .grid-3 {
    height: 50%;
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: clamp(10px, 1.35vw, 27px);
  }

  .grid-2 {
    height: 50%;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: clamp(10px, 1.25vw, 25px);
  }

  .card-body {
    position: relative;
    z-index: 2;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: clamp(20px, 2.6vw, 48px);
  }

  .card-icon {
    font-size: clamp(26px, 2vw, 40px);
    line-height: 1;
  }

  .card-title {
    font-size: clamp(18px, 2.2vw, 36px);
    margin-top: 6%;
    font-weight: 700;
  }

  .card-desc {
    margin-top: 4%;
    font-size: clamp(12px, 1.05vw, 20px);
    opacity: 0.8;
    line-height: 1.4;
  }

  .quote-wrap {
    height: 100%;
    display: grid;
    place-items: center;
    text-align: center;
  }

  .quote-box {
    max-width: 70%;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .quote-author {
    font-size: clamp(14px, 1.3vw, 20px);
    opacity: 0.9;
  }

  .quote-text {
    font-size: clamp(28px, 4vw, 64px);
    line-height: 1.15;
    font-weight: 700;
  }

  .outro-main {
    margin-top: auto;
    margin-bottom: auto;
    text-align: left;
  }

  .outro-title {
    font-size: clamp(28px, 4vw, 64px);
    font-weight: 700;
    max-width: 56%;
  }

  .outro-desc {
    margin-top: 3%;
    max-width: 38%;
    font-size: clamp(13px, 1.1vw, 20px);
    line-height: 1.5;
    opacity: 0.9;
  }

  .contact-list {
    margin-top: 3%;
    display: flex;
    flex-direction: column;
    gap: clamp(12px, 1vw, 19px);
  }

  .contact-item {
    display: flex;
    align-items: center;
    gap: 1.2%;
    font-size: clamp(13px, 1.1vw, 20px);
  }

  .contact-icon {
    width: clamp(24px, 1.65vw, 32px);
    text-align: center;
  }

  .foot-right {
    margin-top: auto;
    text-align: right;
    font-size: clamp(12px, 1.05vw, 20px);
    opacity: 0.6;
  }
---

<!-- Layout 1: Cover -->
<video class="bg-video" src="{{VIDEO_SRC}}" autoplay muted loop playsinline></video>
<div class="layer">
  <div class="header" style="grid-template-columns: 1fr 1fr;">
    <div class="left"><span class="logo">{{LOGO}}</span></div>
    <div class="right"></div>
  </div>
  <div class="cover-main">
    <div>
      <h1 class="cover-title">{{SLIDE_TITLE}}</h1>
      <div class="cover-sub">{{SLIDE_SUBTITLE}}</div>
      <div class="cover-author">{{SLIDE_META}}</div>
    </div>
  </div>
  <div class="cover-foot">{{PAGE_NUM}}</div>
</div>

---

<!-- Layout 2: Intro 3 columns -->
<video class="bg-video" src="{{VIDEO_SRC}}" autoplay muted loop playsinline></video>
<div class="layer">
  <div class="header">
    <div class="left"><span class="logo">{{LOGO}}</span></div>
    <div class="center">Pitch Deck</div>
    <div class="right">Page {{PAGE_NUM}}</div>
  </div>
  <h2 class="intro-title">{{SLIDE_TITLE}}</h2>
  <div class="intro-cols">
    <div class="intro-c1"><p class="body-text">{{SLIDE_TEXT_SHORT}}</p></div>
    <div class="intro-c2"><p class="body-text">{{SLIDE_TEXT}}</p></div>
    <div class="intro-c3">
      <div>
        <p class="big-stat">{{SLIDE_STAT}}</p>
        <p style="margin-top:4%;font-size:clamp(13px,1.05vw,20px);opacity:0.8;line-height:1.4;">{{SLIDE_TEXT_SHORT}}</p>
      </div>
    </div>
  </div>
  <div class="foot-right">{{SLIDE_TITLE}}</div>
</div>

---

<!-- Layout 3: Grid cards -->
<video class="bg-video" src="{{VIDEO_SRC}}" autoplay muted loop playsinline></video>
<div class="layer">
  <div class="header">
    <div class="left"><span class="logo">{{LOGO}}</span></div>
    <div class="center">Pitch Deck</div>
    <div class="right">Page {{PAGE_NUM}}</div>
  </div>
  <div class="analytics-wrap">
    <p class="analytics-sub">Transforming Data into Intelligence with</p>
    <h2 class="analytics-title">{{SLIDE_TITLE}}</h2>
  </div>
  <div class="grid-wrap">
    <div class="grid-3">
      <div class="glass"><div class="card-body"><div class="card-title">Key Point 1</div><div class="card-desc">{{SLIDE_TEXT_SHORT}}</div></div></div>
      <div class="glass"><div class="card-body"><div class="card-title">Key Point 2</div><div class="card-desc">{{SLIDE_TEXT_SHORT}}</div></div></div>
      <div class="glass"><div class="card-body"></div><div class="card-title">Key Point 3</div><div class="card-desc">{{SLIDE_TEXT_SHORT}}</div></div></div>
    </div>
    <div class="grid-2">
      <div class="glass"><div class="card-body"><div class="card-title">Key Point 4</div><div class="card-desc">{{SLIDE_TEXT_SHORT}}</div></div></div>
      <div class="glass"><div class="card-body"><div class="card-title">Key Point 5</div><div class="card-desc">{{SLIDE_TEXT_SHORT}}</div></div></div>
    </div>
  </div>
</div>

---

<!-- Layout 4: Quote -->
<video class="bg-video" src="{{VIDEO_SRC}}" autoplay muted loop playsinline></video>
<div class="layer">
  <div class="quote-wrap">
    <div class="quote-box">
      <div class="quote-author">{{SLIDE_META}}</div>
      <div class="quote-text">{{SLIDE_TITLE}}</div>
    </div>
  </div>
</div>

---

<!-- Layout 5: Outro -->
<video class="bg-video" src="{{VIDEO_SRC}}" autoplay muted loop playsinline></video>
<div class="layer">
  <div class="header">
    <div class="left"><span class="logo">{{LOGO}}</span></div>
    <div class="center">Pitch Deck</div>
    <div class="right">Page {{PAGE_NUM}}</div>
  </div>
  <div class="outro-main">
    <h2 class="outro-title">{{SLIDE_TITLE}}</h2>
    <p class="outro-desc">{{SLIDE_TEXT}}</p>
    <div class="contact-list">
      <div class="contact-item"><span class="contact-icon">◎</span><span>{{CONTACT_1}}</span></div>
      <div class="contact-item"><span class="contact-icon">f</span><span>{{CONTACT_2}}</span></div>
      <div class="contact-item"><span class="contact-icon">☎</span><span>{{CONTACT_3}}</span></div>
      <div class="contact-item"><span class="contact-icon">✉</span><span>{{CONTACT_4}}</span></div>
      <div class="contact-item"><span class="contact-icon">⌖</span><span>{{CONTACT_5}}</span></div>
    </div>
  </div>
</div>
