<h1 align="center">🛠️ トラブルシューティング</h1>

## プロンプトが Codex に表示されない
- `~/.codex/prompts` にコピー済みか確認
- 初回のみ `cp -Ri ./.codex/prompts/ ~/.codex/prompts/`
- プロジェクト直下の `./.codex/prompts` は削除（Codex はホーム配下を見る想定）

## `/prompts:kiro-spec-impl` に進めない
- `.kiro/specs/<feature>/spec.json` を確認
  - `approvals.tasks.approved: true`
  - `ready_for_implementation: true`
- 2.0.0alpha では再生成でフラグが変化することあり。レビューの上、必要なら手動で整合

## npx が失敗する / ネットワーク不調
- Node.js v18+ を推奨、`npx --version` を確認
- 企業プロキシ環境では `HTTPS_PROXY`/`HTTP_PROXY` を設定
- ターミナルを再起動して環境変数を反映

## Mermaid がレンダリングされない
- ビューワ側の対応状況を確認（拡張やプレビュー機能）
- GitHub では多くの Mermaid がそのまま表示可能

## Windows/WSL のパス問題
- WSL 内で作業し、Linux パスで統一
- 改行コード差分に注意（Git 設定で `core.autocrlf=input` 推奨）

## 生成物を誤って上書きした
- Git で差分を確認し、必要に応じて `git restore`/`git checkout` で復旧
- テンプレートは `kiro/settings/templates/` をソース・オブ・トゥルースにする

## `.kiro/steering/` が参照されない
- `/prompts:kiro-steering` を実行して最新化
- 翻訳/追記したローカル編集は尊重されるため、再生成後も残ることを確認


