# Codex CLI 利用ガイド

本章は Codex CLI を利用する場合の補助資料であり、現在の推奨フロー（RooCode + sdd-mcp）で不足がある場合に参照する。Codex CLI を主軸にした旧運用から移行するチーム向けの情報として保持する。

## 1. Codex CLI 概要

Codex CLI は複数のAIエージェントを統合的に利用できるCLIツールであり、`~/.codex/prompts/` に配置したプロンプトをカスタムコマンドとして呼び出せる。Spec駆動開発では `kiro-*` 系のプロンプトが主に使用される。

主な特徴:

- 複数モデル（GPT-5-Codex等）の切り替え
- セッション履歴の保存・要約 (`/compact`)
- カスタムプロンプトによる Spec 操作 (`/prompts:kiro-*`)

## 2. 導入手順（補遺）

```bash
npm install -g @openai/codex@latest
codex
```

初回起動時に「Sign in with ChatGPT」で認証する。詳細なインストール手順や環境構築は章02「クイックスタート」で説明しているため、本章では運用に必要なコマンドを中心に紹介する。

## 3. セッション操作

| コマンド | 説明 |
| --- | --- |
| `/init` | 初期化テンプレートの読み込み |
| `/new` | 新しい会話に切り替え（履歴リセット） |
| `/model` | モデルを切り替え（例: `gpt-5-codex-high`） |
| `/compact` | 会話履歴を要約し、コンテキストを圧縮 |
| `/help` | ヘルプ表示 |
| `/quit` | セッション終了 |

過去のセッションを再開する場合:

```bash
codex resume --last        # 直近のセッション
codex resume <SESSION_ID>  # 任意のセッション
```

## 4. カスタムプロンプト

`~/.codex/prompts/` に配置された Markdown ファイルがカスタムコマンドとして利用できる。cc-sdd を導入すると以下のファイルが生成され、`/prompts:kiro-*` コマンドとして呼び出せる。

- `kiro-spec-init.md`
- `kiro-spec-requirements.md`
- `kiro-spec-design.md`
- `kiro-spec-tasks.md`
- `kiro-spec-impl.md`
- `kiro-spec-status.md`
- `kiro-validate-design.md` など

テンプレートを編集する際は `kiro/settings/templates/` と合わせて管理し、生成物のフォーマットがチームのレビュー基準に沿うよう調整する。

## 5. `AGENTS.md` とローカルコンテキスト

Codex CLI は起動時に `AGENTS.md` を読み込み、エージェントの振る舞いを制御する。リポジトリのルートにある `AGENTS.md` に加え、サブディレクトリに同名ファイルがある場合は近い階層が優先される。

記述例:

```markdown
# Codex AGENTS

## Objectives
- Spec駆動開発の承認フローを遵守
- テンプレートに沿った生成物を提案

## Guardrails
- ステアリングと矛盾する提案を行わない
- 過剰な削除や破壊的操作を避ける
```

`AGENTS.md` を編集することで、Codex CLI の提案内容やレビュー観点を調整できる。

## 6. 補足：Codex CLI を併用する場合のワークフロー

RooCode + sdd-mcp が利用できない環境や CLI ベースで運用したい場合にのみ、以下のフローを採用する。

1. `/prompts:kiro-*` コマンドで Spec を生成・更新する。
2. 実装中は `/compact` で履歴を整理しつつエージェントと対話する。
3. 実装完了後は `/prompts:kiro-validate-*` で検証を行い、`spec.json` の承認を整える。
4. PR 作成時に `codex resume` でコンテキストを再利用し、レビューコメントを生成することも可能。

## 7. cc-sdd 利用のヒント
- **サポートしているツール**: `cc-sdd` は `codex` を使用しています。`codex` は、 Claude Code / Cursor IDE / Gemini CLI / Codex CLI / GitHub Copilot / Qwen Code をサポートしています。
- **多言語対応**: `--lang` フラグで日本語を含む複数言語を選択できます。本資料は日本語運用を前提にまとめています。
- **AI-DLC ワークフロー**: ステアリング整備を起点とし、Requirements → Design → Tasks → Implementation の承認プロセスを前提とします。
- **テンプレートカスタマイズ**: `{{KIRO_DIR}}/settings/templates/` を更新すると、生成される仕様書やステアリングをチーム固有の形式に合わせられます。
- **バージョン注意**: ドキュメントは `2.0.0alpha` 時点の挙動を基にしているため、正式版との差異は公式リポジトリのリリースノートで確認してください。


## 8. トラブルシューティング（抜粋）

- **プロンプトが表示されない**: `~/.codex/prompts` にコピーされているか確認。プロジェクト直下の `.codex/prompts` は削除する。
- **npx 実行時にエラー**: Node.js v18+ を利用し、ネットワークやプロキシ設定を確認する。
- **Mermaid 図がレンダリングされない**: ビューワが対応しているか確認し、必要なら外部ツールでプレビューする。

詳細なFAQやトラブル対応は章09「運用ハンドブック」を参照する。

## 9. 参考リンク（Codex 関連）

- Codex 公式ドキュメント: <https://github.com/openai/codex>
- `docs/config.md`: AGENTS.md やプロンプトの設定項目

Codex CLI は Spec駆動開発の主要インターフェースであり、`AGENTS.md` とプロンプトの整備によってチームの標準と AI の振る舞いを結びつける。
