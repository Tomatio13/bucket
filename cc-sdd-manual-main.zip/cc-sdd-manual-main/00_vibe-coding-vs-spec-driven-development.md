---
marp: true
theme: default
paginate: true
backgroundColor: #ffffff
color: #333333
header: ''
footer: '© Vibe Codingとspec起動開発の比較'
style: |
  section {
    font-family: 'Arial', 'Helvetica', sans-serif;
    background: linear-gradient(to bottom, #ffffff 0%, #f8f9fa 100%);
  }
  h1 {
    color: #4285F4;
    border-bottom: 3px solid #4285F4;
    padding-bottom: 10px;
  }
  h2 {
    color: #333333;
    font-size: 1.5em;
  }
  strong { color: #4285F4; }
  em { color: #EA4335; }
  mark { background-color: #FBBC04; }
  code { background-color: #f5f5f5; }
  .columns { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
  .cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
  .card { 
    border: 1px solid #dadce0; 
    padding: 15px; 
    border-radius: 8px;
    background: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  }
  .timeline { position: relative; padding: 20px 0; }
  .progress-bar { 
    background: #e8eaed; 
    height: 25px; 
    border-radius: 12px;
    overflow: hidden;
  }
  .progress-fill { 
    background: linear-gradient(90deg, #34A853 0%, #4285F4 100%);
    height: 100%; 
    border-radius: 12px;
    transition: width 0.3s ease;
  }
  section.section {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  section.section h1 {
    color: white;
    border: none;
    font-size: 2.5em;
  }
---

# Vibe Codingとspec駆動開発の比較
## 開発手法の使い分けと補完関係

### 2025年10月6日

<!-- 
本日はお集まりいただきありがとうございます。
今回は、現代のソフトウェア開発において注目されている2つの開発手法について詳しく比較し、
それぞれの特徴と適用場面について解説いたします。
-->

---

# アジェンダ

- **第1章**: Vibe Codingとは何か
- **第2章**: spec駆動開発の概要
- **第3章**: 代表的なツールの紹介
- **第4章**: 両手法の使い分けと補完関係
- **まとめ**: 実践的な活用指針
- **Appendix**: TDD（テスト駆動開発）の役割

<!-- 
本日は4つの章に分けて、2つの開発手法を段階的にご説明し、
最後に実際の開発現場での活用方法をお話しします。
TDDについては補足資料として最後にご紹介します。
-->

---

<!-- _class: section -->
# 第1章
## Vibe Codingとは何か

<!-- 
まず最初に、近年注目を集めているVibe Codingという開発手法について詳しく見ていきましょう。
-->

---

# Vibe Codingの定義

<div style="background: #f0f7ff; padding: 30px; border-radius: 12px; margin: 20px 0;">
<h2 style="color: #4285F4; margin-top: 0;">💡 Vibe Codingとは</h2>

**AIペアプログラミングやライブコーディングセッションなど、会話と直観を中心にアイデアを素早く形にする開発スタイル**

- 仕様書よりも開発者の洞察と対話で方向性を更新
- 創造性と柔軟性を重視したアプローチ
- リアルタイムでのフィードバックと改善

</div>

<!-- 
Vibe Codingは、従来の厳格な仕様書に基づく開発とは対照的に、
開発者の直感と創造性を活かした柔軟な開発手法です。
特にAIとのペアプログラミングが普及した現在、注目を集めています。
-->

---

# Vibe Codingのメリット

<div class="cards">
  <div class="card">
    <h3 style="color: #34A853;">🚀 高速な立ち上げ</h3>
    <p>新規アイデアの立ち上げが速く、AIの提案を活用して多様なパターンを短時間で検証できる</p>
  </div>
  <div class="card">
    <h3 style="color: #FBBC04;">✨ 創造性の発揮</h3>
    <p>制約が少ないため創造性が発揮されやすく、モチベーションを保ちやすい</p>
  </div>
  <div class="card">
    <h3 style="color: #EA4335;">🔄 短いフィードバックループ</h3>
    <p>フィードバックループが短く、ファシリテーションが容易</p>
  </div>
</div>

<!-- 
Vibe Codingの最大の強みは、そのスピードと柔軟性にあります。
特に新しいアイデアを素早く形にしたい場面や、
創造的な解決策を模索する際に威力を発揮します。
-->

---

# Vibe Codingのデメリット

<div style="background: #fff4e6; padding: 30px; border-radius: 12px; margin: 20px 0;">

## ⚠️ 注意すべき課題

- **仕様の明文化が遅れ**、ナレッジ共有や長期保守の負債を生みやすい
- **開発者の感覚に依存**するため品質や再現性にばらつきが出やすい
- **スコープ管理が曖昧**になり、ステークホルダーとの期待値調整が難しい

</div>

<!-- 
一方で、Vibe Codingには明確な課題も存在します。
特に長期的な保守性や品質の一貫性において問題が生じやすく、
チーム開発や大規模プロジェクトでは注意が必要です。
-->

---

<!-- _class: section -->
# 第2章
## spec駆動開発の概要

<!-- 
続いて、Vibe Codingとは対照的なアプローチである、
spec駆動開発について詳しく見ていきましょう。
-->

---

# spec駆動開発の定義

<div style="background: #e8f5e8; padding: 30px; border-radius: 12px; margin: 20px 0;">
<h2 style="color: #34A853; margin-top: 0;">📋 spec駆動開発とは</h2>

**実装前に仕様（Spec）を明文化し、仕様を基準に開発・レビュー・検証を進める手法**

</div>

## 典型的なプロセス

要件整理→仕様化→仕様レビュー→実装→仕様準拠テスト→リリース判定

<!-- 
spec駆動開発は、事前の計画と文書化を重視した開発手法です。
実装に入る前に仕様を明確にすることで、品質と一貫性を確保します。
-->

---

# spec駆動開発のメリット・デメリット

<div class="columns">
<div style="background: #e8f5e8; padding: 20px; border-radius: 8px;">

### <span style="color: #34A853;">✅ メリット</span>
- **要件の曖昧さを減らし**、関係者間で共通理解を築きやすい
- **仕様を軸にレビューやテストを自動化**しやすく、品質保証が体系化される
- **新メンバーが仕様書から背景を学べる**ため、オンボーディングが効率的

</div>
<div style="background: #fff4e6; padding: 20px; border-radius: 8px;">

### <span style="color: #EA4335;">⚠️ デメリット</span>
- **仕様策定の初期コストが高く**、短期スプリントでは重荷になり得る
- **仕様変更のたびに文書更新が必要**で、運用体制が弱いと形骸化しやすい
- **創造的な探索が抑制**され、柔軟な方向転換が遅れる可能性

</div>
</div>

<!-- 
spec駆動開発は品質と一貫性に優れる一方で、
初期コストの高さと柔軟性の制約という課題があります。
プロジェクトの性質に応じた適切な選択が重要です。
-->

---

<!-- _class: section -->
# 第3章
## 代表的なツールの紹介

<!-- 
次に、spec駆動開発を支援する代表的なツールについて、
それぞれの特徴と活用方法をご紹介します。
-->

---

# spec駆動開発ツール比較

<div class="cards">
  <div class="card">
    <h3 style="color: #FF9900;">🔧 Kiro (AWS)</h3>
    <p><strong>2025年7月15日プレビュー公開</strong><br>
    SpecsとHooksが要件・設計・タスクを自動生成。MCP対応で外部リソース連携可能</p>
  </div>
  <div class="card">
    <h3 style="color: #333;">🐙 Spec Kit (GitHub)</h3>
    <p><strong>GitHub公式OSS</strong><br>
    `specify` CLIが4段階フロー（仕様→計画→タスク→実装）をAIエージェントで定着</p>
  </div>
  <div class="card">
    <h3 style="color: #4285F4;">⚡ cc-sdd (個人開発)</h3>
    <p><strong>軽量導入型</strong><br>
    `npx cc-sdd@latest`で導入。Kiro互換の10スラッシュコマンドを提供</p>
  </div>
</div>

<!-- 
現在、spec駆動開発を支援するツールが急速に発展しています。
AWSのKiroは注目度が高く、GitHubのSpec Kitは公式サポートが魅力、
cc-sddは手軽に導入できる点が特徴です。
-->

---

# Kiro (AWS) の特徴

<div style="background: #fff3cd; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 👻 AWS公式の仕様駆動型IDE

- **2025年7月15日にプレビュー公開**され、数日で利用が殺到
- **日次利用制限と新規待機リスト**が導入される人気ぶり
- **SpecsとHooks**が要件・設計・タスクを自動生成
- **MCP対応**によりAWS API MCPやAWS Knowledge MCPサーバーなどの外部リソースと連携
- **VS CodeベースのIDE**として配布

### 🔗 リンク: https://kiro.dev/


<!-- 
KiroはAWSが開発したspec駆動開発ツールで、
プレビュー公開直後から大きな注目を集めています。
特にMCP対応による外部連携機能が強力です。
-->

---

# Spec Kit (GitHub) の特徴

<div style="background: #f6f8fa; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 🐙 GitHub公式のCLI用プロンプト集

- **`specify` CLI**が`constitution.md`やテンプレート一式を生成
- **4段階フロー**: 仕様→計画→タスク→実装
- **11種類以上のエージェント対応**: Claude Code、GitHub Copilot、Gemini CLI、Cursor、Qwen Code、Windsurfなど
- **クイックスタートチュートリアル**でフォトアルバム管理アプリを題材に操作例を提供

### 🔗 リンク: https://github.com/github/spec-kit  

<!-- 
Spec KitはGitHubが公式に提供するOSSツールで、
多様なAIエージェントに対応している点が大きな特徴です。
チュートリアルも充実しており、導入しやすい設計になっています。
-->

---

# cc-sdd (個人開発) の特徴

<div style="background: #e3f2fd; padding: 30px; border-radius: 12px; margin: 20px 0;">

## ⚡ Kiroの操作をCLIで再現するプロンプト集

- **`npx cc-sdd@latest`**で即座に導入可能
- **Kiro互換の10スラッシュコマンド**を提供
- **多言語対応**: 英語/日本語/繁体字/中国語/スペイン語/ポルトガル語/ドイツ語/フランス語/ロシア語/イタリア語/韓国語/アラビア語
- **`spec.json`による進捗トラッキング**でフェーズ管理を支援
- **Vibe Codingで得た知見をプロダクション向け仕様に整理**する場面で使いやすい
### 🔗 リンク: https://github.com/gotalab/cc-sdd



<!-- 
cc-sddは個人開発者によるツールですが、
軽量で導入が簡単な点が魅力です。
特にVibe Codingからspec駆動への移行に適しています。
-->


---

<!-- _class: section -->
# 第4章
## 両手法の使い分けと補完関係

<!-- 
最後に、Vibe Codingとspec駆動開発をどのように使い分け、
どう組み合わせるかについて詳しく解説します。
-->

---

# 使い分けの指針

<div class="columns">
<div style="background: #f0f7ff; padding: 20px; border-radius: 8px;">

### <span style="color: #4285F4;">🎨 Vibe Codingが向く場面</span>
- **アイデア探索**
- **PoC（概念実証）**
- **未知領域の調査**
- **速度と柔軟性を重視**
- **軽量なメモや録画で知見共有**

</div>
<div style="background: #e8f5e8; padding: 20px; border-radius: 8px;">

### <span style="color: #34A853;">📋 spec駆動開発が向く場面</span>
- **長期運用が前提のプロダクト**
- **法規制や外部レビューが必要**
- **チーム規模が大きいケース**
- **品質保証と一貫性を重視**
- **体系的なドキュメント管理**

</div>
</div>

<!-- 
両手法にはそれぞれ適した場面があります。
プロジェクトの性質、チーム規模、品質要件などを総合的に判断して
適切な手法を選択することが重要です。
-->

---

# 補完アプローチの実践

1. <strong>初期探索をVibe Codingで進め</strong>、方向性が固まった段階で仕様に落とし込む

2. <strong>Vibe Codingのセッションログ</strong>をspec化のインプットとして活用

3. <strong>spec駆動のフレームを基盤</strong>にしつつ、余白部分でVibe Codingによる改善案を試作

4. <strong>段階的な移行</strong>により、Vibe Codingで得た知見を体系的にspec駆動の仕様に昇華

<!-- 
最も効果的なのは、両手法を補完的に活用することです。
探索フェーズではVibe Coding、安定化フェーズではspec駆動開発を活用する
段階的なアプローチが有効です。
-->

---

# 実践的なハイブリッド戦略

<div style="background: #f0f7ff; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 🔄 2つの手法を組み合わせた開発フロー

**Phase 1**: Vibe Codingで探索・プロトタイピング 
**Phase 2**: Spec駆動で仕様化・安定化

この段階的アプローチにより、創造性と品質保証を両立できます。

</div>

<!-- 
探索フェーズではVibe Coding、安定化フェーズではspec駆動開発を活用する
ハイブリッドアプローチが効果的です。
-->

---

# 組織成熟度別の選択指針

| 成熟度レベル | 推奨アプローチ | 理由 |
|-------------|---------------|------|
| **スタートアップ初期** | Vibe Coding中心 | 速度と柔軟性を最優先 |
| **成長期** | ハイブリッド運用 | 探索と安定化のバランス |
| **成熟期** | spec駆動開発中心 | 品質保証と一貫性を重視 |
| **大企業** | spec駆動開発 + TDD | 厳格な品質管理が必要 |

<!-- 
組織の成熟度によっても最適なアプローチは変わります。
スタートアップでは速度を、大企業では品質を重視した選択が重要です。
-->

---

# まとめ

<!-- 
最後に、今日お話しした内容をまとめて、
実践的な活用指針をお示しします。
-->

---

# 実践的な活用指針

<div class="cards">
  <div class="card">
    <h3 style="color: #4285F4;">🎯 適材適所の選択</h3>
    <p>Vibe Codingはスピードと創造性、spec駆動開発は整合性と品質保証に強みがある</p>
  </div>
  <div class="card">
    <h3 style="color: #34A853;">🔄 段階的移行</h3>
    <p>探索から仕様化への段階的移行により、創造性と品質保証を両立</p>
  </div>
  <div class="card">
    <h3 style="color: #FBBC04;">⚖️ バランスの取れた運用</h3>
    <p>組織の成熟度・プロジェクトのライフサイクル・リスク許容度に応じて手法を選択</p>
  </div>
</div>

<!-- 
重要なのは、どちらか一方を選ぶのではなく、
プロジェクトの特性に応じて適切に使い分けることです。
段階的なアプローチにより、両手法の良いところを組み合わせることができます。
-->

---

# Thank You!

<div style="text-align: center; margin-top: 50px;">
  <h2 style="color: #4285F4;">ご質問はありますか？</h2>
  
  <div style="margin-top: 40px; font-size: 1.1em;">
    <p><strong>🚀 Vibe Coding</strong> × <strong>📋 spec駆動開発</strong></p>
    <p style="color: #666;">適切な使い分けで開発効率と品質を両立</p>
  </div>
  
</div>

<!-- 
以上でプレゼンテーションを終了いたします。
Vibe Codingとspec駆動開発、それぞれの特徴を理解し、
適切に使い分けることで、より効果的な開発が可能になります。
ご清聴ありがとうございました。何かご質問がございましたら、お気軽にお声がけください。
-->

---

<!-- _class: section -->
# Appendix
## TDD（テスト駆動開発）の役割

<!-- 
補足資料として、Vibe Codingとspec駆動開発を橋渡しする
テスト駆動開発（TDD）について詳しく解説します。
-->

---

# TDDとは何か

<div style="background: #f0f7ff; padding: 30px; border-radius: 12px; margin: 20px 0;">
<h2 style="color: #4285F4; margin-top: 0;">🔄 テスト駆動開発（TDD）</h2>

**テストを先に書いてから実装を行う開発手法**

- **Red**: 失敗するテストを書く
- **Green**: テストを通す最小限の実装
- **Refactor**: コードを改善する

</div>

## TDDの基本サイクル

🔴Red→🟢Green→🟡Refactor

<!-- 
TDDは、テストファーストの考え方で開発を進める手法です。
このサイクルを短時間で繰り返すことで、品質の高いコードを作成できます。
-->

---

# t-wada（和田卓人）について

<div style="background: #f8f9fa; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 👨‍💻 日本のTDD第一人者

- **和田卓人(わだ たくと)** 氏
- **TDD（テスト駆動開発）の日本における第一人者**
- **『テスト駆動開発』（オーム社）の翻訳者**
- **多数の技術書籍の翻訳・執筆**
- **技術カンファレンスでの講演多数**
- **最近のLLMだと「t-wadaのTDDに従って」で通じる**

</div>

<!-- 
t-wadaさんは、日本のソフトウェア開発界においてTDDの普及に大きく貢献された方です。
Kent Beckの名著『テスト駆動開発』の翻訳をはじめ、多くの技術書籍の翻訳・執筆を手がけています。
-->

---

# t-wadaのTDD実践ポイント

<div class="cards">
  <div class="card">
    <h3 style="color: #4285F4;">🔄 小さなループ</h3>
    <p><strong>Red→Green→Refactor</strong>を数分単位で繰り返し、仕様にしたい振る舞いをテストで先に宣言</p>
  </div>
  <div class="card">
    <h3 style="color: #34A853;">📝 テストリスト運用</h3>
    <p>取り組む仕様候補を<strong>テストリスト</strong>に書き出し、気づきを随時<strong>TODO</strong>に追加・消込み</p>
  </div>
  <div class="card">
    <h3 style="color: #FBBC04;">📖 動作する仕様書</h3>
    <p><strong>テスト名に意図を記述</strong>し、Pull Requestやレビューで仕様の証拠として提示</p>
  </div>
</div>

<!-- 
t-wadaさんが提唱するTDDの実践ポイントは、
単なるテスト手法を超えて、設計手法としての側面を重視しています。
-->

---

# TDDがVibe CodingとSpec駆動開発を繋ぐ理由

<div class="columns">
<div style="background: #f0f7ff; padding: 20px; border-radius: 8px;">

### <span style="color: #4285F4;">🎨 Vibe Codingとの親和性</span>
- **短いフィードバックループ**
- **探索的な開発スタイル**
- **リアルタイムでの方向修正**
- **創造性を保ちながら品質確保**

</div>
<div style="background: #e8f5e8; padding: 20px; border-radius: 8px;">

### <span style="color: #34A853;">📋 Spec駆動開発との親和性</span>
- **テストが動作する仕様書**
- **要件の明文化**
- **品質保証の体系化**
- **チーム間での共通理解**

</div>
</div>

<!-- 
TDDは、Vibe Codingの柔軟性とspec駆動開発の厳密性を
両立させる優れた手法です。
-->

---

# TDDによる段階的仕様化

<div style="background: #fff3cd; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 🌉 探索から仕様への橋渡し

1. **Vibe Codingで得た洞察**をテストとして文章化
2. **探索的な仮説**を安全にプロダクション要件へ橋渡し
3. **未確定の仕様**はテストリストを暫定仕様として扱い
4. **チーム合意後**に正式なSpecへ昇格
5. **TDDのフィードバックサイクル**を仕様策定プロセスに組み込み

</div>

<!-- 
TDDを活用することで、Vibe Codingで得た創造的なアイデアを
段階的に仕様として固めていくことができます。
-->

---

# TDDの実践における注意点

<div style="background: #fff4e6; padding: 30px; border-radius: 12px; margin: 20px 0;">

## ⚠️ 成功のためのポイント

- **細かなコミットとGreen維持**: 各段階で小さくコミットし、Refactor中もGreenを保つ
- **テスト名の重要性**: テスト名で仕様の意図を明確に表現する
- **過度な設計の回避**: 必要最小限の実装でGreenにする
- **チーム全体での理解**: TDDの価値をチーム全体で共有する

</div>

<!-- 
TDDを成功させるためには、技術的な側面だけでなく、
チーム文化や運用面での配慮も重要です。
-->

---

# 3つの手法の統合戦略

<div style="background: #f0f7ff; padding: 30px; border-radius: 12px; margin: 20px 0;">

## 🔄 統合的な開発フロー

**Phase 1**: Vibe Codingで探索 → **Phase 2**: TDDで仕様化 → **Phase 3**: Spec駆動で安定化

この3段階のアプローチにより、創造性・品質・保守性を全て確保できます。

</div>

<!-- 
TDDを媒介とすることで、Vibe Codingの創造性とspec駆動開発の厳密性を
効果的に組み合わせることができます。
-->
