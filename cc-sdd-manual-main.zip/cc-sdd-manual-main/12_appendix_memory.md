# 🧠 AIエージェントの記憶モデルと cc-sdd の対応
AIエージェントの主要な4種の記憶[^agentic-memory]に対し、cc-sdd がどの機能で支援しているかの対応です。

- **1. ワーキングメモリ（Working Memory）: 現在の会話・作業文脈**
  - `/prompts:kiro-spec-status` の出力（現在フェーズ/進捗）
  - `.kiro/specs/<feature>/spec.json` の現在値（`phase`/`approvals`/`ready_for_implementation`）
  - `requirements.md` / `design.md` / `tasks.md` の内容

- **2. エピソード記憶（Episodic Memory）: 過去の出来事の履歴**
  - `spec.json` の `created_at`/`updated_at` と承認フラグの推移
  - `.kiro/specs/<feature>/*` の版管理（Git 履歴）

- **3. 意味記憶（Semantic Memory）: 事実・知識のストック**
  - `.kiro/steering/*.md`（`product.md`/`tech.md`/`structure.md`）
  - `AGENTS.md`（エージェント向けプロジェクトメモリ）
  - `kiro/settings/templates/*`（仕様テンプレの標準形）
  - `00_vibe-coding-vs-spec-driven-development.md`（位置づけと用語の整理）
- **4. 手続き記憶（Procedural Memory）: 行動規則・How to**
  - `/prompts:kiro-*` 一連のコマンド（Requirements → Design → Tasks → Impl → Validate）
  - `01_codex-usage.md`（Codex 運用・MCP設定・CI 実行の実践）

**要点:** cc-sdd は「意味記憶と手続き記憶」を配布し、成果物と `spec.json` で「エピソード記憶」を残し、`spec-status` と編集中ファイルで「ワーキングメモリ」を補完します。

**補足:** Spec は「人とAIの共通記憶の器」であり、cc-sdd は4種の記憶に対応する器と手順を配布します。

[^agentic-memory]: [agentic-memory](https://github.com/ALucek/agentic-memory/tree/main)

