# 要件定義書

## プロジェクト概要（入力）
{{PROJECT_DESCRIPTION}}

## 要件
<!-- /kiro:spec-requirements フェーズで生成されます -->
