<h1 align="center">📘 EARS構文ガイド</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>


## ✅ クイックチェック
1. 責任主体となるシステム（The ...）を特定しているか
2. While / When / Where / If のいずれかで条件とトリガーを表現しているか
3. `shall` で観測可能な応答を 1 文 1 挙動で記述しているか
4. あいまい語を避け、定量または具体的な指標を盛り込んでいるか

## 🧭 EARSとは
EARS（Easy Approach to Requirements Syntax）は、要求仕様を自然言語で記述する際のあいまいさを減らすために開発された軽量な記述規則です。要求文の構造とキーワードを揃えることで、読んだ人が意図を誤解しにくくなり、後工程での手戻りを抑制できます。[EARS公式解説][ears]

## 🧱 基本構文
EARSでは要求文を以下の順序で組み立てます。要素は必要に応じて省略可能ですが、順番は変えません。

```
While <前提条件>, when <トリガー>, the <システム名> shall <応答>
```

- `While` は継続的に成り立つ前提条件
- `When` は要求を発動させるイベント
- `<システム名>` は責任主体（システム、サービス、プロセスなど）
- `shall` は必ず実行すべき振る舞い（必須要求）

この骨組みを基に、目的に応じたパターンを選びます。

## 🗺️ 構造イメージ
EARSで登場するキーワードがどのようにつながり、最終的にシステムの振る舞いに到達するかをフローチャート化した例です。正の要求（Shall）と禁止要求（Shall Not）の両方を視覚的に捉えられます。

```mermaid
graph LR
    W1[When] --> E1[イベント]
    Wh1[While] --> S1[状態]
    We1[Where] --> C1[条件]
    If1[If] --> C2[条件]
    C2 --> T1[Then]

    E1 --> Cx[複合条件]
    S1 --> Cx
    Cx --> Sys

    E1 --> Sys
    S1 --> Sys
    C1 --> Sys
    T1 --> Sys

    Sys["The<br/>[システム]"] --> Shall[Shall]
    Sys --> ShallNot["Shall<br/>Not"]

    Shall --> Act[動作]
    ShallNot -.->|禁止| Act

    classDef trigger fill:#e8f1ff,stroke:#1c4e80,color:#1c4e80;
    classDef complex fill:#f3e5ff,stroke:#7a3eb1,color:#3d1f5f,font-weight:bold;
    classDef system fill:#fff3d9,stroke:#d17a22,color:#4a2f0b,font-weight:bold;
    classDef action fill:#e4f7d2,stroke:#5c8d2a,color:#2f4f1f,font-weight:bold;

    class W1,Wh1,We1,If1,E1,S1,C1,C2,T1 trigger;
    class Cx complex;
    class Sys system;
    class Shall,ShallNot,Act action;

    linkStyle 13 stroke:#d1495b,stroke-width:2px;
    linkStyle 15 stroke:#d1495b,stroke-width:2px,stroke-dasharray:4 2;
```

**凡例**
- 水色ノード: 事象や状態など、要求を引き起こすトリガー／条件
- 紫色ノード: 複数の条件を組み合わせる複合パターン
- クリーム色ノード: 要求の責任主体となるシステムまたはプロセス
- 黄緑色ノード: システムがとる振る舞い（実行／禁止）
- 赤色の矢印: 禁止要求（Shall Not）の経路

## 🧪 パターン別解説と例

### 📍 常時要求（Ubiquitous）
- **構文**: `The <システム名> shall <応答>`
- **用途**: 恒常的に満たすべき制約や品質
- **例**: `The モバイルアプリ shall 完全起動まで5秒以内にローディング画面を表示する`

### 🔁 状態駆動要求（State-Driven）
- **構文**: `While <前提条件>, the <システム名> shall <応答>`
- **用途**: 特定の状態が続く間の振る舞い
- **例**: `While ユーザーが未ログインである, the 認証UI shall ログインボタンを表示する`

### ⚡ 事象駆動要求（Event-Driven）
- **構文**: `When <トリガー>, the <システム名> shall <応答>`
- **用途**: イベント発生時の応答
- **例**: `When ユーザーが「購入する」ボタンを押す, the 注文サービス shall カート内商品を検証する`

### 🎛️ 任意機能要求（Optional Feature）
- **構文**: `Where <適用条件>, the <システム名> shall <応答>`
- **用途**: オプション機能が有効な場合のみ適用
- **例**: `Where テナントがポイント機能を利用している, the 決済サービス shall ポイント残高を決済画面に表示する`

### 🚨 望ましくない事象への要求（Unwanted Behaviour）
- **構文**: `If <異常トリガー>, then the <システム名> shall <応答>`
- **用途**: エラーや例外への対処
- **例**: `If 不正なカード番号が入力される, then the 決済フォーム shall 「カード番号を確認してください」と表示する`

### 🧩 複合要求（Complex）
- **構文**: `While <前提条件>, when <トリガー>, the <システム名> shall <応答>`
- **用途**: 継続条件とイベントが同時に関わる要求
- **例1（状態＋イベント）**: `While システムが保守モードである, when 管理者が診断を開始する, the ログ収集サービス shall 詳細ログを出力する`
- **例2（前提＋異常イベント）**: `While セッションがアクティブである, if 多要素認証が失敗した, then the 認証サービス shall セッションを即時終了する`
- **ポイント**: キーワードを増やすほど文が長くなるため、必要最小限の組み合わせにとどめる。複合条件を列挙する場合は `and` などで接続しても良いが、読み手が理解できる粒度まで分割することを優先する。

## ✍️ EARS記述の手順
1. **責任主体を明確化**: 要求を満たすシステムまたは役割を特定する。
2. **トリガーと前提を洗い出す**: 状態・イベント・例外などの切り口で考える。
3. **適切なパターンを選択**: 上記パターンから最も単純なものを採用する。
4. **応答を具体化**: 観測可能でテスト可能な行動を `shall` で記述する。
5. **レビュー**: 文が一意に解釈できるか、他者と読み合わせて確認する。

## 🧾 品質チェックリスト
- `shall` を用いて必須要求とする（任意の場合は `should` を明示）
- 1文につき1つの挙動に限定し、複数の動作は文を分割する
- 曖昧語（「早く」「十分に」など）は避け、定量または具体的表現に言い換える
- 受動態や多義的な代名詞を避け、主語を明記する
- 用語はプロジェクトの定義と整合するかを確認する

## 🔄 よくある改善ポイント
- **複数条件を無理に1文へ詰め込む** → 条件ごとに文を分け、複合パターンは最小限にする
- **システム名が抽象的** → `UI` ではなく `注文画面` など具体的な主体名を用いる
- **テスト不能な表現** → `shall 成功するようにする` ではなく `shall 200レスポンスを返す` のように観測指標を記す

## 📚 参考資料
- [EARS公式解説（Alistair Mavin）][ears]
- [見えるかする要求仕様（Businesss Garage）](https://www.bgarage.co.jp/news/946/)
  
[ears]: https://alistairmavin.com/ears/

---

## 🧪 Do/Don't（短い対比）

### Do（良い例）
```
When ユーザーが「購入」ボタンを押す, the 注文サービス shall カート内商品を検証し200を返す
```

### Don't（悪い例）
```
When ユーザーが購入操作をする, the システム shall 正しく処理する
```

差分: 主体が具体的、観測可能な結果（200）を明示、曖昧語なし。

## ✍️ 1問演習
次の文を EARS で改善してください。

```
ログインに失敗したらエラーを適切に表示する
```

例解（1つの解）

```
If パスワードが不一致である, then the 認証UI shall 「メールまたはパスワードが正しくありません」を表示する
```