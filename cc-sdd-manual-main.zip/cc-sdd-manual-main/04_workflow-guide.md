# Spec駆動ワークフローガイド

## イントロダクション

Spec駆動開発の中心は「要件→設計→タスク→実装→検証」の反復である。本章では、各フェーズの成果物、承認基準、AIエージェントの活用方法を整理する。章02のクイックスタートを済ませ、`spec.json` とステアリング文書が整備された状態を前提とする。

## Specのライフサイクルと `spec.json`

`spec.json` は仕様の状態管理ファイルであり、以下の情報を保持する。

- `phase`: 現在のフェーズ（requirements/design/tasks/implementation/validation）
- `approvals.<phase>.approved`: 各フェーズの承認フラグ（true/false）
- `ready_for_implementation`: 実装に進める準備が整ったか
- `history`: 生成・承認・更新のタイムスタンプ

Specを生成・更新した後は、承認フラグを確認し、必要に応じてレビューを行う。承認済みのフェーズのみ実装へ進める。

以下、sdd-mcpを利用したワークフローを説明します。

## フェーズ別ガイド

### 1. 要件（Requirements）

- MCP ツール: 
  - `spec-init`（例: `Use MCP tool: spec-init ユーザ認証をJWTとリフレッシュトークン回転で実装`）
  - `spec-requirements`（例: `Use MCP tool: spec-requirements user-authentication`）
- 成果物: `requirements.md`
- 承認基準:
  - 各要件が EARS 形式（When/If… shall …）で記述されている
  - 曖昧語が排除され、観測可能な条件と期待結果が明確
  - ステアリング（product/tech/structure）と矛盾しない
- レビューのポイント:
  - トレーサビリティを意識し、IDや分類を付与しておく
  - ユースケース／非機能要件（性能・セキュリティなど）を漏らさない
- 承認後: `approvals.requirements.approved` を true に設定し、次フェーズへ進む

### 2. 設計（Design）

- MCP ツール: `spec-design`（例: `Use MCP tool: spec-design user-authentication`）
- 成果物: `design.md`
- 承認基準:
  - 要件→設計の対応表が整備されている
  - データフロー、API、状態遷移などが図表または文章で説明されている
  - 非機能要件（エラー処理、性能、セキュリティ、テスト方針）が明記されている
- レビューのポイント:
  - ステアリングの原則（命名規則、アーキテクチャ制約）に沿っているか
  - 再生成時に差分が生じた場合の扱いをチームで合意する

### 3. タスク（Tasks）

- MCP ツール: `spec-tasks`（例: `Use MCP tool: spec-tasks user-authentication`）
- 成果物: `tasks.md`
- 承認基準:
  - タスクとサブタスクの粒度が 1〜3時間程度を目安に分割されている
  - 各サブタスクに `_要件: x.x` などトレーサビリティ表記が付与されている
  - 依存関係が明示され、実装の順序が明らか
- レビューのポイント:
  - 実装担当が迷わないレベルの詳細度か
  - 自動化できる部分（テスト生成など）がタスクとして明示されているか

### 4. 実装（Implementation）

- MCP ツール: `spec-impl`（例: `Use MCP tool: spec-impl user-authentication`、特定タスクのみなら `Use MCP tool: spec-impl user-authentication 1,2,3`）
- 成果物: コード、テスト、修正された Spec（必要に応じて）
- 承認基準:
  - 対象タスクの要件を満たし、テストが成功している
  - コード変更が Spec とステアリングに整合している
  - 実装に伴う Spec やステアリングの更新が必要であれば反映されている
- レビューのポイント:
  - TDD を前提に、テストを先に作成してから実装する
  - PR では Spec との対応関係、承認フラグの整合を確認

### 5. 検証（Validation）

- MCP ツール: `validate-design` / `validate-gap`
    （例: `Use MCP tool: validate-design {"feature_name":"user-authentication"}`、`Use MCP tool: validate-gap {"feature_name":"user-authentication"}`）
- 成果物: テスト結果、ログ、エビデンス
- 承認基準:
  - 受け入れ基準に対応するテストが実行され、証跡が残っている
  - `spec.json` の `approvals.validation.approved` が true
  - リグレッションテストやCIステータスが問題ない
- レビューのポイント:
  - 自動テストに加えて、必要な手動確認を実施
  - 受け入れ基準のエビデンス（スクリーンショット、ログなど）をPRに添付

## 再生成と承認フローの注意点

- Specを再生成すると `approvals` がリセットされる場合がある。差分をレビューし、必要に応じて承認フラグを再設定する。
- `ready_for_implementation` が false の場合、タスクや承認が未完了である可能性が高い。整合性を確認してから実装へ進む。
- 大規模な仕様改訂時は、ステアリングと Spec を同時に更新し、AIエージェントのプロンプトと整合させる。

## PR運用とレビューのチェックリスト

- Specの変更（requirements/design/tasks）が PR に含まれている。
- `spec.json` の `phase` と `approvals` が最新状態を反映している。
- `_要件: x.x` などトレーサビリティ表記が最新の要件番号と一致している。
- テスト結果・ログなどのエビデンスが PR に添付されている。
- ステアリング（product/tech/structure/custom）が必要に応じて更新されている。

## ツール連携のポイント

- MCP クライアント（sdd-mcp）では `Use MCP tool: spec-...` 形式で Spec を操作する。履歴が長くなる場合はクライアント側の会話整理機能（例: `Use MCP tool: spec-status {"feature_name":"..."}`）を活用する。
- Codex CLI など CLI ベースで運用する場合は従来どおり `/prompts:*` を利用できるが、MCP と併用する際は成果物と承認フラグの同期に注意する。
- CI/CD と連携する場合、`spec.json` の状態や承認情報を利用して自動ゲーティングのトリガとするのが一般的である。

## まとめ

Spec駆動ワークフローは、ドキュメント生成だけでなく承認フローとトレーサビリティを通じて品質を担保する仕組みである。
