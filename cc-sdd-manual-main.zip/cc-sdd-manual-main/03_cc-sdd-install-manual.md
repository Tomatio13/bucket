<h1 align="center">🚀 cc-sdd インストールマニュアル</h1>


<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>

## 🧭 cc-sddの導入方法

### ✅ 前提条件

| 項目 | 推奨/要件 |
| --- | --- |
| Node.js | v18+（LTS 推奨） |
| npx | Node 付属版 |
| OS | Linux/WSL2/macOS（Windows は WSL2 推奨） |
| モデル | GPT-5-Codex 系 |
| ネットワーク | 企業プロキシ下は `HTTPS_PROXY`/`HTTP_PROXY` 設定 |

> Windows ネイティブ環境ではパス/改行差で不整合が出る場合があるため、WSL2 を推奨します。

> ⚠️ **注意事項** 2.0.0alphaのため、正式版では手順が異なる可能性があります。

新規プロジェクトを開始する場合は、ディレクトリを作成・移動後に、
以下のコマンドでインストールできます。

**🆕 新規プロジェクトの場合**
```bash
mkdir projectX # プロジェクト名のディレクトリを作成
cd projectX # ディレクトリに移動
```
**⬇️ cc-sddをインストール**

```bash
npx cc-sdd@next --lang ja --codex
```

- codex以外のツールを利用する際には、`--codex`を変更してください。
- 言語を変更する際には、`--lang`を変更してください。


**📦 インストール結果**
```bash
$ npx cc-sdd@next --lang ja --codex
Planned changes:
  • Commands (.codex/prompts/) — new (11 file(s))
  • Project Memory document (AGENTS.md) — new (1 file(s))
  • Settings templates and rules (.kiro/settings/) — new (23 file(s))

✅ Setup completed: written=35, skipped=0

== Recommended models ==
  • GPT-5-Codex (e.g. gpt-5-codex medium, gpt-5-codex high)

== Next steps ==
  1. Move Codex Custom prompts to ~/.codex/prompts by running:
    mkdir -p ~/.codex/prompts \
      && cp -Ri ./.codex/prompts/ ~/.codex/prompts/ \
      && printf '\n==== COPY PHASE DONE ====\n' \
      && printf 'Remove original ./.codex/prompts ? [y/N]: ' \
      && IFS= read -r a \
      && case "$a" in [yY]) rm -rf ./.codex/prompts && echo 'Removed.' ;; *) echo 'Kept original.' ;; esac
  2. Launch Codex CLI and run `/prompts:kiro-spec-init <what-to-build>` to create a new specification.
  3. Tip: Steering holds persistent project knowledge—patterns, standards, and org-wide policies. Kick off `/prompts:kiro-steering` (essential for existing projects) and  `/prompts:kiro-steering-custom`. Maintain Regularly
  4. Tip: Update `{{KIRO_DIR}}/settings/templates/` like `requirements.md`, `design.md`, and `tasks.md` so the generated steering and specs follow your team's and project's development process.
```
**🛠️ 初回実施のみ**
サーバ・端末でのnpxコマンド初回実施時にのみ、以下の操作を実施して下さい。
以下を実施することで、codexのプロンプトに表示されるようになります。
```bash
mkdir -p ~/.codex/prompts
cp -Ri ./.codex/prompts/ ~/.codex/prompts/
```
**♻️ 毎回実施**
プロジェクト配下の.codex/promptsディレクトリは不要なので削除して下さい。
```bash
rm -rf ./.codex/prompts
```

**🗂️ プロジェクト配下のディレクトリ構成**
プロジェクト配下に以下のディレクトリ構成が作成されます。
```bash
├── .kiro
│   └── settings
│       ├── rules
│       │   ├── design-discovery-full.md
│       │   ├── design-discovery-light.md
│       │   ├── design-principles.md
│       │   ├── design-review.md
│       │   ├── ears-format.md
│       │   ├── gap-analysis.md
│       │   ├── steering-principles.md
│       │   └── tasks-generation.md
│       └── templates
│           ├── specs
│           │   ├── design.md
│           │   ├── init.json
│           │   ├── requirements-init.md
│           │   ├── requirements.md
│           │   └── tasks.md
│           ├── steering
│           │   ├── product.md
│           │   ├── structure.md
│           │   └── tech.md
│           └── steering-custom
│               ├── api-standards.md
│               ├── authentication.md
│               ├── database.md
│               ├── deployment.md
│               ├── error-handling.md
│               ├── security.md
│               └── testing.md
└── AGENTS.md
```

**🏠 ~/.codex/prompts配下のディレクトリ構成**
~/.codex/prompts配下に以下のディレクトリ構成になります。
```bash
~/.codex/prompts
├── kiro-spec-design.md
├── kiro-spec-impl.md
├── kiro-spec-init.md
├── kiro-spec-requirements.md
├── kiro-spec-status.md
├── kiro-spec-tasks.md
├── kiro-steering-custom.md
├── kiro-steering.md
├── kiro-validate-design.md
├── kiro-validate-gap.md
└── kiro-validate-impl.md
```

**🖥️ codexのプロンプト**
codex起動後に、以下のプロンプトが表示されます。

![codexのプロンプト](./assets/install/codex_prompts.png)
