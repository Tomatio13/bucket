<h1 align="center">📖 cc-sdd プロンプト総覧</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>

## 🧭 0. 目的
`kiro/` ディレクトリ配下に格納されたプロンプト資産とテンプレート群を把握し、`cc-sdd` が提供する Spec-Driven Development ワークフローを自分たちのプロジェクトへ適用・拡張するための手引きです。公式が提供する 11 種類の `/prompts:kiro-*` コマンドとテンプレートの関係性を整理し、再生成時の注意点もまとめます[^cc-sdd].

[^cc-sdd]: `https://github.com/gotalab/cc-sdd`

---

## 🗂️ 1. `kiro/` ディレクトリ構成
ルート直下の `kiro/` は、`npx cc-sdd` 実行後に各エージェントへ配布されるプロンプトとテンプレートのアーカイブです。当マニュアルでは Linux / Codex 環境で生成される日本語版を収録しています。

```
kiro/
 ├─ prompts/                  # Slash コマンド本体（日本語訳）
 │   ├─ kiro-spec-design_jp.md
 │   ├─ kiro-spec-impl_jp.md
 │   ├─ ...
 │   └─ kiro-validate-impl_jp.md
 └─ settings/
     ├─ rules/                # ワークフロー運用ルール
     │   ├─ design-discovery-full_jp.md
     │   ├─ ...
     │   └─ tasks-generation_jp.md
     └─ templates/
         ├─ specs/            # 要件・設計・タスク用テンプレート
         │   ├─ design.md / design_jp.md
         │   ├─ init.json
         │   ├─ requirements_jp.md
         │   └─ tasks_jp.md
         ├─ steering/         # コア・ステアリング（product / tech / structure）
         └─ steering-custom/  # ドメイン別追加ステアリング
```

### 🧾 1.1 `prompts/`
- `/prompts:kiro-steering` 〜 `/prompts:kiro-validate-impl` の 11 コマンドを網羅し、それぞれが以下のメタ情報を保持します。
  - `<meta>`: コマンドの概要・引数ヒント
  - `<background_information>`: 目的や成功条件
  - `<instructions>`: 実行手順、フェーズ切り替え条件
  - `<output>`: 生成されるファイル/構造

---

## 🧮 2. プロンプト一覧と役割（テンプレ対応表）

| フェーズ | プロンプト | 主な出力/操作対象 | 主テンプレ |
| --- | --- | --- | --- |
| ステアリング整備 | `/prompts:kiro-steering` | `.kiro/steering/product.md` ほか | `templates/steering/*.md` |
| ステアリング拡張 | `/prompts:kiro-steering-custom` | ドメイン別ガイド追加 | `templates/steering-custom/*.md` |
| 仕様初期化 | `/prompts:kiro-spec-init` | `.kiro/specs/<feature>/spec.json`/`requirements.md(初期)` | `specs/init.json`/`requirements-init_jp.md` |
| 要件定義 | `/prompts:kiro-spec-requirements` | `requirements.md (EARS)` | `specs/requirements_jp.md` |
| ギャップ分析 | `/prompts:kiro-validate-gap` | 既存コード vs 要件 差分レポート | なし |
| 設計 | `/prompts:kiro-spec-design` | `design.md` | `specs/design_jp.md` |
| 設計レビュー | `/prompts:kiro-validate-design` | 設計レビュー/GO-NOGO | なし |
| タスク分解 | `/prompts:kiro-spec-tasks` | `tasks.md` | `specs/tasks_jp.md` |
| 実装支援 | `/prompts:kiro-spec-impl` | 実装フロー提案(TDD) | なし |
| 実装レビュー | `/prompts:kiro-validate-impl` | 実装の整合検証 | なし |
| 進捗確認 | `/prompts:kiro-spec-status` | フェーズ/進捗レポート | なし |

> 再実行はキャッチアップに有効ですが、`spec.json` の `approvals`/`phase` が変化し得ます。承認後の再生成はレビュー手順を必ず通してください。

---

## 🛠️ 3. カスタマイズ手順
- `.kiro/steering/*.md` を編集してプロジェクト固有の原則を明文化
- `kiro/settings/templates/specs/*.md` を編集すると以後の生成に反映
- `steering-custom` は必要なテンプレのみ `.kiro/steering/` に採用

---

## 📝 4. 運用ヒント
- 初回は `/prompts:kiro-steering` を実行してから要件へ進む
- 仕様フェーズは Requirements → Design → Tasks を順序維持
- `spec.json` の `ready_for_implementation` が false の場合、承認フラグの不足を確認

---

## 5. 関連ドキュメント
- `02_cc-sdd-usage.md`（ワークフロー詳細）
- `03_ears_format.md`（良い要件のための EARS）
- `10_checklists.md`（GO/NO-GO チェック）


