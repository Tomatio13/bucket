# 付録・参考リソース

## 1. リンク集

- cc-sdd 公式リポジトリ: <https://github.com/gotalab/cc-sdd>
- Kiro 公式サイト: <https://kiro.dev>
- sdd-mcp GitHub: <https://github.com/yuki-yano/sdd-mcp>
- Spec Kit (GitHub): <https://github.com/github/spec-kit>
- EARS 手法解説: <https://alistairmavin.com/ears/>

## 2. 推奨資料

- Spec駆動開発と Vibe Coding の比較（章00スライド）
- t-wada『テスト駆動開発』日本語版（TDDの参考）
- GitHub Copilot / Claude Code / Cursor IDE の公式ドキュメント

## 3. 用語と翻訳ポリシー

- Spec, Steering, Project Memory など固有名詞はカタカナと英語を併記（例: Spec（仕様））。
- `shall` は「〜すべき」ではなく「〜しなければならない」など明確な表現を用いる。
- ステアリング文書は原則として日本語で統一し、必要に応じて英語訳を併記する。

## 4. 変更履歴（抜粋）

- 2025-10-XX: ドキュメント体系を Spec駆動中心へ再編（本リポジトリ）
- 2025-07-15: Kiro プレビュー公開（AWS）
- 2024-XX: GitHub Spec Kit 公開

## 5. 追加タスク（残課題）

- 用語の表記揺れを統一するスタイルガイドの整備
- マークダウンの lint / フォーマット統一
- 章00スライドの文章版リライト検討
- 章06-08 の各ツールガイドにスクリーンショットを追加

## 6. コントリビュート方法

- Issue / Pull Request で誤記修正や加筆を提案する。
- テンプレートの改善案は `kiro/settings/templates/` と併せて PR で提示する。
- Spec駆動開発の実践例や Best Practice を共有する場合は、章09 のベストプラクティス節に追記する形で提案する。

## 7. ライセンス

- 本資料は MIT ライセンスで公開されている。詳細は `LICENSE` を参照。
- 引用時はリポジトリURLと章番号を明記すると参照しやすい。

