<h1 align="center">⚡ はじめての cc-sdd（5分クイックスタート）</h1>

## 🎯 目的
最短経路で cc-sdd の全体像と「要件 → 設計 → タスク → 実装 → 検証」の流れを一周します。既存 IDE/CLI 環境で Kiro スタイルの Spec 駆動形開発を体験するための最小手順です。

## ✅ 前提条件（推奨）

| 項目 | 推奨/要件 |
| --- | --- |
| Node.js | v18+（LTS 推奨） |
| npx | Node 付属版 |
| OS | Linux/WSL2/macOS |
| モデル | GPT-5-Codex 系 |
| ネットワーク | 企業プロキシ環境では HTTP(S)_PROXY を設定 |

> 企業プロキシ下では `HTTPS_PROXY` などを適宜設定してください。

## 🚀 セットアップ（1分）

```bash
mkdir cc-sdd-hello
cd cc-sdd-hello
npx cc-sdd@next --lang ja --codex

# 初回のみ（Codex のカスタムプロンプトを読み込ませる）
mkdir -p ~/.codex/prompts
cp -Ri ./.codex/prompts/ ~/.codex/prompts/

# 毎回（プロジェクト配下の ./.codex/prompts は削除）
rm -rf ./.codex/prompts
```

生成物（抜粋）

```text
.kiro/settings/  # 仕様テンプレートとルール
AGENTS.md        # エージェント向けプロジェクトメモリ
```

## 🧭 ステアリング整備（30秒）
```bash
/prompts:kiro-steering
/prompts:kiro-steering-custom
```
`.kiro/steering/` に `product.md` `tech.md` `structure.md` などが作成されます。プロジェクトの「航海図」として以後の仕様生成が参照します。

## 📝 仕様初期化と要件（1分）
```bash
/prompts:kiro-spec-init hello-feature
/prompts:kiro-spec-requirements hello-feature
```
生成物（抜粋）

```text
.kiro/specs/hello-feature/
  requirements.md
  spec.json
```

## 🏗️ 設計とタスク（1分）
```bash
/prompts:kiro-spec-design hello-feature -y
/prompts:kiro-spec-tasks hello-feature -y
```

> メモ: 一部バージョンでは `spec.json` の `approvals`/`ready_for_implementation` が実行可否に影響します。承認フラグの状態を必ず確認してください。

## 🔧 最小実装と検証（1分）
```bash
# タスク全体または一部だけを指定して実行
/prompts:kiro-spec-impl hello-feature 1.1
/prompts:kiro-validate-impl hello-feature
```

## 📊 進捗の可視化（10秒）
```bash
/prompts:kiro-spec-status hello-feature
```

## 🧩 次のステップ
- `kiro/settings/templates/` をチーム標準に合わせて調整
- 生成された `.kiro/steering/*.md` をプロジェクト規約としてレビュー/承認
- 以後は「要件→設計→タスク→実装→検証」を PR 単位で回す

## 🔗 参考
- `01_cc-sdd-install-manual.md`（詳細インストール）
- `02_cc-sdd-usage.md`（各フェーズの実務手順）
- `03_ears_format.md`（良い要件の書き方）
- `10_checklists.md`（GO/NO-GO チェックリスト）


