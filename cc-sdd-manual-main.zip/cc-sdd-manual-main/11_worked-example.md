<h1 align="center">🧪 作例: hello-feature を一周</h1>

## 1. セットアップ
```bash
mkdir hello && cd hello
npx cc-sdd@next --lang ja --codex
mkdir -p ~/.codex/prompts && cp -Ri ./.codex/prompts/ ~/.codex/prompts/ && rm -rf ./.codex/prompts
```

## 2. ステアリング
```bash
/prompts:kiro-steering
/prompts:kiro-steering-custom
```

## 3. 要件
```bash
/prompts:kiro-spec-init hello-feature
/prompts:kiro-spec-requirements 未来にメッセージを送信する機能
```

## 4. 設計とタスク
```bash
/prompts:kiro-spec-design hello-feature -y
/prompts:kiro-spec-tasks hello-feature -y
```

## 5. 実装（タスク 1.1 のみ）
```bash
/prompts:kiro-spec-impl hello-feature 1.1
```

## 6. 検証と進捗
```bash
/prompts:kiro-validate-impl hello-feature
/prompts:kiro-spec-status hello-feature
```

> 期待物: `.kiro/specs/hello-feature/` に `requirements.md` `design.md` `tasks.md` `spec.json`。PR でレビューし、承認後に次タスクへ。


