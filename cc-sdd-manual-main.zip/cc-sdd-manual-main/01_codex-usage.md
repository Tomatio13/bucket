# Codex CLI 利用ガイド

本資料は、OpenAIがOSSとして公開していローカルコンピュータ上で動作するコーディングエージェントの利用方法を説明した資料です。

![codex-github](./assets/codex_github.png)


ターミナルでCodexを起動すると、以下のような画面が表示されます。

![codex-cli](./assets/codex_start.png)

**注意：** 本資料は 2025 年 10 月 13 日時点のCodexの機能をベースに、Codex CLI をチーム開発で活用するための要点を整理したものです。バージョンアップに伴い機能変更されている可能性があります。

## 1. 導入手順

**必要条件:** Node.js 18 以上、`npm` 

**グローバルインストール:** `npm install -g @openai/codex`
- 最新版をインストールする場合は、`@latest`を付けてください。
    ```bash
    npm install -g @openai/codex@latest
    ```

**ワークディレクトリで以下のコマンドを実行。**

```bash
# codex login か最初に対話セッションをはじめると「Sign in with ChatGPT」が表示
codex
```


## 2. セッション管理過去のセッション(会話)を再開したい場合

過去のセッション(会話)を再開したい場合は以下のコマンドで実行

```bash
codex resume # 対象のセッションを選択

codex resume --last  #　最新のセッションで起動

codex resume <SESSION_ID> # 指定したセッションで起動
```

## 3. セッション内コマンドとモード

`codex`のセッション内で実行できるコマンドでよく使うものです。

```bash
/init # 初期化テンプレートや設定のブートストラップ

/new # 新しい会話に切り替え(セッション状態のクリア)

/model # AIモデルの切り替え

/compact # これまでの会話履歴のトークンを要約・圧縮

/help # ヘルプを表示

/quit # セッション(codex)を終了
```

## 4. AGENTS.md とローカルコンテキスト

Codex は起動時に AGENTS.md を読み込み、ふるまいの基準として使う。
(Claude Code の CLAUDE.md に近いもののようです)

- リポジトリのルート：AGENTS.md は自動検出・読み込みの対象。
- 作業中ディレクトリ/サブフォルダ：同名ファイルがあれば併用可。近いものが優先。
- ~/.codex/AGENTS.md: 全てのプロジェクトで共通の設定になります。
- 複数見つかった場合は、近い階層が優先しつつマージされます。

[Config Reference](https://github.com/openai/codex/blob/main/docs/config.md#config-reference)


## 5. カスタムプロンプト

カスタムプロンプトは、毎回入力する定型的な指示を短いコマンドで呼び出せる機能です。

`~/.codex/prompts/` (`$CODEX_HOME/prompts/`) にマークダウンファイル(.md)を設置すると、カスタムコマンドとして設置されます。

セクション#3で記述されているコマンドのように、`/`から始まるプロンプトを独自に追加することができます。
ただし、プロジェクト固有の prompts ディレクトリは用意されていないので全プロジェクト共通のカスタムコマンドになります。

何度も繰り返し入力するような内容をあらかじめマークダウンとして登録しておくと便利です。


## 7. 設定ファイル

- `~/.codex/config.toml` でデフォルトモード、承認ポリシー、ツール設定を管理。
- 例:

```toml
model = "gpt-5-codex"
model_verbosity = "medium" # 詳細な応答の冗長さ（情報量の多さ）
sandbox_mode = "read-only"  # 最も安全（必要時のみ緩める）

# コマンド実行を承認するかどうかをプロンプトで確認すべきタイミング
# - untrusted: 「信頼済み」でないコマンド（危険操作など）は実行前に都度承認を求め
# - on-request: モデル（Codex）が判断して承認を要求する場合
# - on-failure: コマンドが失敗した場合のみ承認にエスカレート
# - never: いかなる場合も承認を求めず、すべての操作を自動で実行
approval_policy = "untrusted"

file_opener = "cursor" # or vscode
notify = ["bash","-lc","afplay /System/Library/Sounds/Ping.aiff"]

# trueにすると、npmのインストールや外部APIへのリクエストが可能 (デフォルトは false)
network_access = false

[tui]
#　デスクトップ通知に関する設定
# - "agent-turn-complete": エージェントの１ターン処理が完了した際に通知
# - "approval-requested": ユーザーの操作や承認が必要な時に通知
notifications = ["agent-turn-complete","approval-requested"]

[shell_environment_policy]
inherit = "core"
include_only = ["PATH","HOME","USER"]
exclude = ["AWS_*","AZURE_*","*TOKEN*","*SECRET*","*KEY*"]
}

[tools]
web_search = true # Web 検索を許可 (デフォルトは false)
```

詳細は、[Config Reference](https://github.com/openai/codex/blob/main/docs/config.md#config-reference)を参照してください。

## 8. MCP (Model Context Protocol) 連携
### 8.1 設定方法
設定方法は２種類有ります。

1. 設定ファイルに記述する
- Codex は MCP クライアントを内蔵しており、`~/.codex/config.toml` にサーバー設定を記述する。
- サーバー定義例:

  ```toml
  [mcp_servers.context7]
  command = "npx"
  args = ["-y", "@upstash/context7-mcp@latest"]
  ```
2. cliで登録する。

    ```bash
    # 登録
    codex mcp add <id> -- <command> <args...>

    # 確認
    codex mcp list
    ```


### 8.2 推奨 MCP サーバー

- GitHub MCP: GitHub のリポジトリ/Issue/PR へのクエリや操作。
- Context7: 外部ライブラリのドキュメント検索を高速化。
- Markitdown: Web ページや PDF を Markdown 変換して参照。
- Chrome DevTools / Playwright / Playground: ブラウザ操作や UI テストの自動化。

## 9. 操作のヒント

Codex のセッション内でのキーバインドです。

- セッション内での改行 -> Ctrl + J
- 進行している処理の途中終了 -> Ctrl + C

## 10. CI(GitHub Actions等)での実行
- CI では API キーでログインして実行（codex login --api-key ...）。
- 解析のみなら既定の read-only のまま、変更を書き込む場合は --config sandbox_mode="workspace-write" を付与。
- GitHub Actions（例）
  ```yaml
  - name: Update changelog via Codex
    run: |
      npm install -g @openai/codex
      codex login --api-key "${{ secrets.OPENAI_KEY }}"
      codex exec --full-auto --model gpt-5-codex \
        --config sandbox_mode="workspace-write" \
        "update CHANGELOG for next release"
  ```
- 詳細は[非対話モード(CIモード)](https://github.com/openai/codex/blob/main/docs/advanced.md#non-interactive--ci-mode)を参照
## 11. 参考

- Zenn: Codex で Spec-Driven Development を加速する CLI の全貌 (2025-09-30 公開)

