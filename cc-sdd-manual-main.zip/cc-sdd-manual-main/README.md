<h1 align="center">cc-sdd マニュアルリポジトリ</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>

## 📦 概要（対象読者・到達目標）
Spec-Driven Development 支援ツール `cc-sdd` の導入とワークフロー運用を日本語で解説した資料セットです。
CLI の詳細や最新版は公式リポジトリ `gotalab/cc-sdd` を参照してください[^cc-sdd]。
Kiro は AWS が提供する AI と人間が協調して進める Spec-Driven Development のための設計思想・テンプレート体系であり、AI IDE として仕様策定から実装支援までを統合的に提供します[^kiro-dev]。
`cc-sdd` は Kiro の AI-DLC ワークフローを CLI で再現し、既存の開発環境へステアリングと仕様テンプレートを配布・同期する仕組みを担います。Kiro と cc-sdd の関係は下記のとおりです。

[^cc-sdd]: [cc-sdd 公式リポジトリ](https://github.com/gotalab/cc-sdd)
[^kiro-dev]: [Kiro 公式サイト](https://kiro.dev/)

**対象読者**
- 仕様駆動での開発フローを学びたい初学者/チーム導入担当
- 既存 IDE/CLI で Kiro スタイルを再現したい開発者

**到達目標**
- 5 分のクイックスタートで「要件→設計→タスク→実装→検証」を一周できる
- `spec.json` の状態（phase/approvals）を理解し運用判断ができる
- テンプレートを自チーム標準に合わせて安全にカスタマイズできる

### 🔍 Kiro の主な特徴

![kiro](./assets/kiro.png)

- **仕様駆動の開発体験**: プロンプトから要求仕様・システム設計・タスク分解までを一気通貫で整備し、複雑な開発でも意図を保ったまま進められます。
- **エージェントフックによる自動化**: 「ファイル保存」などのトリガーで AI エージェントを実行し、テスト生成やドキュメント更新を自動化できます。
- **豊富なコンテキスト管理**: ステアリングや仕様を活用し、過去の判断やコードベースの意図を踏まえた提案を行います。
- **MCP 連携による拡張性**: ドキュメント・データソース・API と IDE を接続し、開発中に必要な情報へ即アクセスできます。
- **エンタープライズ対応**: セキュリティとプライバシーを考慮した環境で、マルチモーダルな入力や自動操縦モードを備えています。

### 🧩 cc-sdd の主な特徴

![cc-sdd CLI](./assets/codex.png)

- **Kiro 互換の Slash コマンド群**: `/prompts:kiro-steering` から `/prompts:kiro-validate-impl` まで 11 種類のコマンドを CLI から呼び出し、仕様策定〜実装検証までのフローを生成できます[^cc-sdd]。
- **プロジェクトメモリの整備**: `.kiro/steering/` と `AGENTS.md` を自動配置し、AI エージェントが参照するプロジェクト共通知識を共有できます[^cc-sdd]。
- **複数エージェント対応**: Claude Code / Cursor IDE / Gemini CLI / Codex CLI / GitHub Copilot / Qwen Code など、各エージェント専用テンプレートを自動生成します[^cc-sdd]。
- **テンプレートのカスタマイズ性**: `requirements.md` や `design.md` などのテンプレートを編集し、チーム固有の仕様書形式に合わせられます[^cc-sdd]。
- **多言語サポート**: `--lang` フラグで日本語を含む複数言語に切り替え可能で、生成ドキュメントも指定言語で出力されます[^cc-sdd]。

### 🔗 Kiro と cc-sdd の役割分担
- **Kiro = IDE / 体験基盤**: Kiro IDE はプロンプトから要求・設計・タスク分解を生成し、エージェントフックや MCP 連携で自動化された開発体験を提供します[^kiro-dev]。
- **cc-sdd = Kiro ワークフローの移植ツール**: `npx cc-sdd` を実行すると、Kiro と同じステアリング文書や `/prompts:kiro-*` コマンド群が CLI 経由で既存プロジェクトに展開され、Claude Code や Codex CLI などのエージェントでも Kiro スタイルの開発プロセスを再現できます[^cc-sdd]。
- **利用シナリオ**: Kiro を IDE として利用する場合はそのまま IDE 上で実行し、既存 IDE / CLI で同じプロセスを取り入れたい場合は cc-sdd でテンプレートとコマンドを導入します。

Kiro 本体は「プロトタイプから本番までを一つの IDE で支える」ことを掲げ、仕様駆動での要件・設計・タスク生成から、エージェントフックによる自動化、MCP 連携による外部データ活用までを統合した AI IDE を提供します[^kiro-dev]。

> 注意事項：本リポジトリでは Codex CLI での運用を前提に解説しています。他エージェントで利用する際は、生成されるプロンプトや設定ファイルを環境に合わせて読み替えてください。



## 📚 収録ドキュメント
- `00_vibe-coding-vs-spec-driven-development.md`
  - Vibe Coding と Spec 駆動開発の比較スライド。位置づけと使い分けを理解。
- `01_codex-usage.md`
  - Codex CLI の導入・操作ガイド（セッション運用、MCP設定、CI実行の要点）。
- `02_getting-started.md`
  - 5分クイックスタート。最短で一周するための手順と留意点。
- `03_cc-sdd-install-manual.md`
  - `npx cc-sdd@next --lang ja --codex` を例に、セットアップ結果と生成ディレクトリ構成をスク
  リーンショット付きで説明します。
  - 初回だけ必要な `~/.codex/prompts` へのコピー手順、推奨モデル、生成物一覧を記載していま
  す。
- `04_cc-sdd-usage.md`
  - `/prompts:kiro-*` コマンドによる「ステアリング → 要件 → 設計 → タスク → 実装 → 検証」フロ
  ーを、レビュー観点と注意点と合わせて整理しています。
  - 各フェーズで生成されるファイルやディレクトリ構造、確認ポイントを示しています。
- `05_ears_format.md`
  - EARS形式での要件定義を行うためのガイドラインを示しています。
- `06_cc-sdd-prompts.md`
  - `cc-sdd` が生成するプロンプトの一覧とテンプレ対応表、再生成時の注意点を示しています。
- `07_troubleshooting.md`
  - よくある詰まりどころの対処。
- `08_faq.md`
  - 運用判断のよくある質問集。
- `09_glossary.md`
  - 用語集と概念の最小整理。
- `10_best-practices.md`
  - チーム運用の勘所とアンチパターン。
- `11_worked-example.md`
  - 最小作例で仕様から検証まで通す。
- `12_checklists.md`
  - フェーズ別 GO/NO-GO チェックリスト。

## 🧰 補助ファイルとディレクトリ
- `kiro/`
  - `cc-sdd` が生成するテンプレートとプロンプトを日本語化した参照用アーカイブです。
  - `prompts/` には `/prompts:kiro-*` の日本語訳、`settings/` にはテンプレートと運用ルール一式が含まれます。
  - `cc-sdd`のプロンプトや手法を学習したり、変更を行う場合に参照して下さい。
- `sample/`
  - 生成物のサンプル（`AGENTS.md` や `.kiro/steering/` など）を格納しています。

## 🧭 推奨読み進め方（Spec駆動中心の導線）
1. **考え方を把握**: `00_vibe-coding-vs-spec-driven-development.md` で Spec 駆動の意義と使い分けを理解。
2. **ツール準備**: `01_codex-usage.md` を参照して Codex CLI をセットアップ（必要なら MCP も設定）。
3. **プロジェクトへ適用**: `npx cc-sdd@latest --lang ja --codex` 等でテンプレートを導入（詳細は cc-sdd 公式[^cc-sdd] を参照）。
4. **ステアリング整備→仕様化**: `/prompts:kiro-steering` から Requirements → Design → Tasks → Impl → Validate を順に実行。
5. **テンプレート調整**: `kiro/settings/templates/` と `kiro/settings/rules/` をチーム標準に合わせて編集。

## 💡 cc-sdd 利用のヒント
- **サポートしているツール**: `cc-sdd` は `codex` を使用しています。`codex` は、 Claude Code / Cursor IDE / Gemini CLI / Codex CLI / GitHub Copilot / Qwen Code をサポートしています。
- **多言語対応**: `--lang` フラグで日本語を含む複数言語を選択できます。本資料は日本語運用を前提にまとめています。
- **AI-DLC ワークフロー**: ステアリング整備を起点とし、Requirements → Design → Tasks → Implementation の承認プロセスを前提とします。
- **テンプレートカスタマイズ**: `{{KIRO_DIR}}/settings/templates/` を更新すると、生成される仕様書やステアリングをチーム固有の形式に合わせられます。
- **バージョン注意**: ドキュメントは `2.0.0alpha` 時点の挙動を基にしているため、正式版との差異は公式リポジトリのリリースノートで確認してください。

## 🧠 AIエージェントの記憶モデルと cc-sdd の対応
AIエージェントの主要な4種の記憶[^agentic-memory]に対し、cc-sdd がどの機能で支援しているかの対応です。

- **1. ワーキングメモリ（Working Memory）: 現在の会話・作業文脈**
  - `/prompts:kiro-spec-status` の出力（現在フェーズ/進捗）
  - `.kiro/specs/<feature>/spec.json` の現在値（`phase`/`approvals`/`ready_for_implementation`）
  - `requirements.md` / `design.md` / `tasks.md` の内容

- **2. エピソード記憶（Episodic Memory）: 過去の出来事の履歴**
  - `spec.json` の `created_at`/`updated_at` と承認フラグの推移
  - `.kiro/specs/<feature>/*` の版管理（Git 履歴）

- **3. 意味記憶（Semantic Memory）: 事実・知識のストック**
  - `.kiro/steering/*.md`（`product.md`/`tech.md`/`structure.md`）
  - `AGENTS.md`（エージェント向けプロジェクトメモリ）
  - `kiro/settings/templates/*`（仕様テンプレの標準形）
  - `00_vibe-coding-vs-spec-driven-development.md`（位置づけと用語の整理）
- **4. 手続き記憶（Procedural Memory）: 行動規則・How to**
  - `/prompts:kiro-*` 一連のコマンド（Requirements → Design → Tasks → Impl → Validate）
  - `01_codex-usage.md`（Codex 運用・MCP設定・CI 実行の実践）

**要点:** cc-sdd は「意味記憶と手続き記憶」を配布し、成果物と `spec.json` で「エピソード記憶」を残し、`spec-status` と編集中ファイルで「ワーキングメモリ」を補完します。

**補足:** Spec は「人とAIの共通記憶の器」であり、cc-sdd は4種の記憶に対応する器と手順を配布します。

[^agentic-memory]: [agentic-memory](https://github.com/ALucek/agentic-memory/tree/main)

## 🤝 貢献・問い合わせ
誤記修正や加筆の提案は Issue / Pull Request で歓迎します。
`cc-sdd` CLI 本体に関する質問は公式リポジトリのドキュメントや Issue を参照してください。

## 謝辞
cc-sddの作者に感謝します。

## ライセンス
本資料は MIT ライセンスの下で公開されています。詳細は [LICENSE](LICENSE) を参照してください。

## 参照リポジトリ
- [cc-sdd公式リポジトリ](https://github.com/gotalab/cc-sdd)
- [Kiroの仕様書駆動開発プロセスをClaude Codeで徹底的に再現した](https://zenn.dev/gotalab/articles/3db0621ce3d6d2)
- [Claude Codeは仕様駆動の夢を見ない](https://speakerdeck.com/gotalab555/claude-codehashi-yang-qu-dong-nomeng-wojian-nai)
- [kiro公式サイト](https://kiro.dev)
- [EARS](https://alistairmavin.com/ears/)
- [見えるかする要求仕様（Businesss Garage）](https://www.bgarage.co.jp/news/946/)
- [agentic-memory](https://github.com/ALucek/agentic-memory/tree/main)
