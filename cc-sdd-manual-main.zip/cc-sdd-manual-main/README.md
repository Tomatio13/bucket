<h1 align="center">Spec-Driven Development リポジトリ</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>

## 📦 概要（対象読者・到達目標）
Spec-Driven Development 支援ツール `cc-sdd`、`sdd-mcp` の導入とワークフロー運用を日本語で解説した資料セットです。
CLI の詳細や最新版は公式リポジトリ `gotalab/cc-sdd` を参照してください[^cc-sdd]。
Kiro は AWS が提供する AI と人間が協調して進める Spec-Driven Development のための設計思想・テンプレート体系であり、AI IDE として仕様策定から実装支援までを統合的に提供します[^kiro-dev]。
`cc-sdd` は Kiro の AI-DLC ワークフローを CLI で再現し、既存の開発環境へステアリングと仕様テンプレートを配布・同期する仕組みを担います。
`sdd-mcp` は `cc-sdd`のプロンプトを MCP サーバとして提供し、IDE から Spec を操作できるようにするツールです。詳細は公式リポジトリ `yuki-yano/sdd-mcp` を参照してください[^sdd-mcp]。

[^cc-sdd]: [cc-sdd 公式リポジトリ](https://github.com/gotalab/cc-sdd)
[^kiro-dev]: [Kiro 公式サイト](https://kiro.dev/)
[^sdd-mcp]: [sdd-mcp 公式リポジトリ](https://github.com/yuki-yano/sdd-mcp)

**対象読者**
- 仕様駆動での開発フローを学びたい初学者/チーム導入担当
- 既存 IDE/CLI で Kiro スタイルを再現したい開発者

**到達目標**
- 5 分のクイックスタートで「要件→設計→タスク→実装→検証」を一周できる
- `spec.json` の状態（phase/approvals）を理解し運用判断ができる
- テンプレートを自チーム標準に合わせて安全にカスタマイズできる

### 🔍 Kiro の主な特徴

![kiro](./assets/kiro.png)

- **仕様駆動の開発体験**: プロンプトから要求仕様・システム設計・タスク分解までを一気通貫で整備し、複雑な開発でも意図を保ったまま進められます。
- **エージェントフックによる自動化**: 「ファイル保存」などのトリガーで AI エージェントを実行し、テスト生成やドキュメント更新を自動化できます。
- **豊富なコンテキスト管理**: ステアリングや仕様を活用し、過去の判断やコードベースの意図を踏まえた提案を行います。
- **MCP 連携による拡張性**: ドキュメント・データソース・API と IDE を接続し、開発中に必要な情報へ即アクセスできます。
- **エンタープライズ対応**: セキュリティとプライバシーを考慮した環境で、マルチモーダルな入力や自動操縦モードを備えています。

### 🧩 cc-sdd の主な特徴

![cc-sdd CLI](./assets/codex.png)

- **Kiro 互換の Slash コマンド群**: `/prompts:kiro-steering` から `/prompts:kiro-validate-impl` まで 11 種類のコマンドを CLI から呼び出し、仕様策定〜実装検証までのフローを生成できます[^cc-sdd]。
- **プロジェクトメモリの整備**: `.kiro/steering/` と `AGENTS.md` を自動配置し、AI エージェントが参照するプロジェクト共通知識を共有できます[^cc-sdd]。
- **複数エージェント対応**: Claude Code / Cursor IDE / Gemini CLI / Codex CLI / GitHub Copilot / Qwen Code など、各エージェント専用テンプレートを自動生成します[^cc-sdd]。
- **テンプレートのカスタマイズ性**: `requirements.md` や `design.md` などのテンプレートを編集し、チーム固有の仕様書形式に合わせられます[^cc-sdd]。
- **多言語サポート**: `--lang` フラグで日本語を含む複数言語に切り替え可能で、生成ドキュメントも指定言語で出力されます[^cc-sdd]。
- **MCP ファースト運用**: `sdd-mcp` を通じて RooCode など MCP 対応 IDE から同じ Spec ワークフローを利用し、ローカル CLI に依存せず開発を進められます。

### 🛠️ RooCode + sdd-mcp（MCP サーバ連携）

`sdd-mcp` は cc-sdd の Slash コマンドを MCP ツールとして提供し、RooCode などの MCP 対応 IDE から Spec ワークフローを直接呼び出せるようにするサーバです。公式リポジトリ: [yuki-yano/sdd-mcp](https://github.com/yuki-yano/sdd-mcp)

- **Specification Management**: `spec-init` から `spec-feedback` まで一連の仕様操作を提供
- **TDD Implementation Support**: `spec-impl` でタスク単位の実装とテスト支援
- **Design Validation / Gap Analysis**: `validate-design` や `validate-gap` でレビューを自動支援
- **Steering Documents**: `steering` / `steering-custom` で `.kiro/steering/` を最新化
- **Workflow Example**: README に「steering → spec-init → requirements → design → tasks → spec-impl → spec-status → spec-feedback」の手順が掲載

**RooCode からの利用例**
1. ターミナルで `npx sdd-mcp@latest` を実行し MCP サーバを起動（終了までプロセスを保持）。
2. RooCode の *Settings → MCP Servers → Add* で以下を登録: `command: npx`, `args: ["sdd-mcp@latest"]`。
3. RooCode のコマンドパレットまたは MCP パネルから `spec-init` などのツールを選択し、パラメータを入力して実行。
4. 生成された成果物は `.kiro/` 配下に反映されるため、IDE上のエディタでレビュー・編集し、承認フローを進行。

詳細なツールリストと実行例は `05_tooling_sdd-mcp.md` にまとめている。



## 📚 収録ドキュメント
- `00_spec-driven-overview.md` — Spec駆動開発の全体像とVibe Codingとの位置づけ
- `01_spec-driven-principles.md` — 基本概念、プロジェクトメモリ、用語集
- `02_quickstart.md` — 5分クイックスタートと環境準備
- `03_cc-sdd-usage.md` — cc-sddのコマンドとワークフローの使い方
- `04_workflow-guide.md` — 要件→設計→タスク→実装→検証の運用フロー
- `05_tooling_sdd-mcp.md` — sdd-mcpサーバの設定とMCPツール一覧と使い方
- `06_ears_format.md` — EARSによる要件記述
- `07_cc-sdd-prompts.md` — cc-sddのプロンプトの構成
- `08_appendix_resources.md` — 付録、外部リソース、残課題
- `09_appendix_cc-sddd-install-manual.md` — Codex CLIのセットアップと運用
- `10_appendix_tooling_codex-cli.md` — cc-sddのプロンプト/テンプレ一覧とカスタマイズ
- `11_appendix_operations-handbook.md` — FAQ、トラブルシューティング、ベストプラクティス、チェックリスト
- `12_appendix_memory.md` — AIエージェントの記憶モデルと cc-sdd の対応

## 🧰 補助ファイルとディレクトリ
- `kiro/`
  - `cc-sdd` が生成するテンプレートとプロンプトを日本語化した参照用アーカイブです。
  - `prompts/` には `/prompts:kiro-*` の日本語訳、`settings/` にはテンプレートと運用ルール一式が含まれます。
  - `cc-sdd`のプロンプトや手法を学習したり、変更を行う場合に参照して下さい。
- `sample/`
  - 生成物のサンプル（`AGENTS.md` や `.kiro/steering/` など）を格納しています。

## 🤝 貢献・問い合わせ
誤記修正や加筆の提案は Issue / Pull Request で歓迎します。
`cc-sdd` CLI 本体に関する質問は公式リポジトリのドキュメントや Issue を参照してください。
`sdd-mcp` に関する質問は公式リポジトリのドキュメントや Issue を参照してください。

## 謝辞
cc-sdd, sdd-mcpの作者に感謝します。

## ライセンス
本資料は MIT ライセンスの下で公開されています。詳細は [LICENSE](LICENSE) を参照してください。

## 参照リポジトリ
- [cc-sdd公式リポジトリ](https://github.com/gotalab/cc-sdd)
- [sdd-mcp公式リポジトリ](https://github.com/yuki-yano/sdd-mcp)
- [Kiroの仕様書駆動開発プロセスをClaude Codeで徹底的に再現した](https://zenn.dev/gotalab/articles/3db0621ce3d6d2)
- [Claude Codeは仕様駆動の夢を見ない](https://speakerdeck.com/gotalab555/claude-codehashi-yang-qu-dong-nomeng-wojian-nai)
- [kiro公式サイト](https://kiro.dev)
- [EARS](https://alistairmavin.com/ears/)
- [見えるかする要求仕様（Businesss Garage）](https://www.bgarage.co.jp/news/946/)
- [agentic-memory](https://github.com/ALucek/agentic-memory/tree/main)
