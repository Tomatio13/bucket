# Basic Arithmetic CLI

Basic Arithmetic CLIは、四則演算をコマンドラインから即時に実行できる参考実装です。`uv` を用いて仮想環境と依存を管理し、仕様駆動の開発フローに沿って実装されています。

## クイックスタート

```bash
uv venv .venv
source .venv/bin/activate  # Windowsは .venv\Scripts\activate
uv pip install -r requirements.txt
uv run python -m src.commands.basic_arithmetic.cli calc 2 + 3
uv run python -m src.commands.basic_arithmetic.cli calc "(2 + 2) * 4"
```

## 品質チェック

このリポジトリでは `pyproject.toml` に以下の品質関連設定をまとめています。

- `tool.pytest.ini_options` で `pythonpath = [".", "src"]` および `testpaths = ["tests"]` を指定し、`tests/` 配下のテストが自動的に検出され、`src/` をモジュール解決パスに追加します。
- `tool.ruff` セクションでコード整形・静的解析のルールセットを定義しています。

品質チェックは `scripts/quality.py` で一括実行でき、内部で `ruff check` と `pytest` を順番に呼び出します。`uv run` を通すことで仮想環境と同じ解決系が利用されます。

```bash
UV_CACHE_DIR=$(pwd)/.uv-cache uv run python -m scripts.quality
```

個別に実行する場合は次のコマンドを利用してください。

```bash
UV_CACHE_DIR=$(pwd)/.uv-cache uv run ruff check
UV_CACHE_DIR=$(pwd)/.uv-cache uv run pytest
```

## ライセンス

MITライセンス想定（必要に応じて更新してください）。
