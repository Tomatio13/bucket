from typer.testing import CliRunner

from src.commands.basic_arithmetic.cli import app

runner = CliRunner()


def test_cli_success() -> None:
    result = runner.invoke(app, ["calc", "2", "+", "3"])
    assert result.exit_code == 0
    assert "5" in result.stdout


def test_cli_zero_division() -> None:
    result = runner.invoke(app, ["calc", "2", "/", "0"])
    assert result.exit_code != 0
    assert "0による除算" in result.stderr


def test_cli_version_option() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.stdout
