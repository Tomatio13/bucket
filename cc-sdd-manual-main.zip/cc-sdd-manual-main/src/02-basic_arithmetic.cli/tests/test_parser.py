from decimal import Decimal

import pytest

from src.shared.evaluator import EvaluatorService
from src.shared.exceptions import UnsupportedTokenError, ValidationError
from src.shared.parser import ParserService, normalize_tokens


@pytest.fixture()
def parser() -> ParserService:
    return ParserService()


def test_normalize_tokens_handles_signed_and_exponent() -> None:
    tokens = normalize_tokens(["-1.5e2", "+", "3"])
    assert tokens == ["-1.5e2", "+", "3"]


def test_normalize_tokens_with_compact_expression() -> None:
    tokens = normalize_tokens(["(2+3)*4"])
    assert tokens == ["(", "2", "+", "3", ")", "*", "4"]


def test_parser_creates_ast(parser: ParserService) -> None:
    tokens = normalize_tokens(["2", "+", "3", "*", "4"])
    ast = parser.parse(tokens)
    evaluator = EvaluatorService()
    assert evaluator.evaluate(ast) == Decimal("14")


def test_parser_rejects_trailing_operator(parser: ParserService) -> None:
    tokens = normalize_tokens(["2", "+"])
    with pytest.raises(ValidationError):
        parser.parse(tokens)


def test_tokenize_raises_on_invalid_symbol(parser: ParserService) -> None:
    with pytest.raises(UnsupportedTokenError):
        normalize_tokens(["2", "%", "3"])
