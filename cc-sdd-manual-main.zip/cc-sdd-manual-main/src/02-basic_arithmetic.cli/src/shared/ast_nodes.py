"""AST node definitions for arithmetic expressions."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


@dataclass(slots=True)
class NumberNode:
    """Represents a numeric literal."""

    value: Decimal


@dataclass(slots=True)
class BinaryOperationNode:
    """Represents a binary arithmetic operation."""

    operator: str
    left: NumberNode | BinaryOperationNode
    right: NumberNode | BinaryOperationNode
