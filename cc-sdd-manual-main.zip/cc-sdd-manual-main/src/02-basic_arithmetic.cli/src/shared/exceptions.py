"""Domain-specific exceptions for expression parsing and evaluation."""

from __future__ import annotations

from dataclasses import dataclass


class ExpressionError(Exception):
    """Base exception for all expression-related errors."""


class TokenizationError(ExpressionError):
    """Raised when input tokens cannot be processed."""


class UnsupportedTokenError(TokenizationError):
    """Raised when unsupported symbols appear in the expression."""


class SyntaxViolation(ExpressionError):
    """Raised when the syntactic structure of the expression is invalid."""


class ValidationError(SyntaxViolation):
    """Raised when validation of token ordering or balancing fails."""


class EvaluationError(ExpressionError):
    """Raised when evaluation of the AST fails."""


class ZeroDivisionEvaluationError(EvaluationError):
    """Raised when a division by zero is attempted."""


class OverflowEvaluationError(EvaluationError):
    """Raised when evaluation result exceeds supported numeric range."""


@dataclass(slots=True)
class ExitPayload:
    """Payload describing the CLI exit behaviour."""

    code: int
    message: str | None = None
    rich: bool = False
