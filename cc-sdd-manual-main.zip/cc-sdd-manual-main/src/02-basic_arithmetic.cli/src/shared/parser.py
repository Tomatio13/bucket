"""Tokenization and parsing utilities for arithmetic expressions."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from decimal import Decimal

from .ast_nodes import BinaryOperationNode, NumberNode
from .exceptions import UnsupportedTokenError, ValidationError

_SUPPORTED_OPERATORS = {"+", "-", "*", "/"}


def tokenize(expression: str) -> list[str]:
    """Split an expression string into syntactic tokens.

    Raises:
        UnsupportedTokenError: If invalid characters are discovered.
    """

    tokens: list[str] = []
    buffer: list[str] = []
    previous_token: str | None = None
    index = 0

    def flush_buffer() -> None:
        nonlocal previous_token
        if buffer:
            token = "".join(buffer)
            tokens.append(token)
            previous_token = token
            buffer.clear()

    while index < len(expression):
        char = expression[index]
        if char.isspace():
            flush_buffer()
            index += 1
            continue

        if char in "+-":
            if buffer:
                flush_buffer()
                tokens.append(char)
                previous_token = char
                index += 1
                continue
            next_char = expression[index + 1] if index + 1 < len(expression) else ""
            is_unary_position = (
                previous_token is None
                or previous_token in _SUPPORTED_OPERATORS
                or previous_token == "("
            )
            if is_unary_position and (next_char.isdigit() or next_char == "."):
                buffer.append(char)
                index += 1
                continue
            flush_buffer()
            tokens.append(char)
            previous_token = char
            index += 1
            continue

        if char.isdigit() or char == ".":
            buffer.append(char)
            index += 1
            continue

        if char in "eE":
            if not buffer:
                raise UnsupportedTokenError(f"Unsupported token near: '{expression[index:]}'")
            buffer.append(char)
            index += 1
            if index < len(expression) and expression[index] in "+-":
                buffer.append(expression[index])
                index += 1
            continue

        flush_buffer()
        if char in _SUPPORTED_OPERATORS or char in "()":
            tokens.append(char)
            previous_token = char
            index += 1
            continue

        raise UnsupportedTokenError(f"Unsupported token near: '{expression[index:]}'")

    flush_buffer()
    return tokens


class SyntaxValidator:
    """Validates token ordering and structural balance."""

    @staticmethod
    def validate(tokens: Sequence[str]) -> None:
        if not tokens:
            raise ValidationError("式が空です。少なくとも1つのトークンが必要です。")

        balance = 0
        previous: str | None = None
        for token in tokens:
            if token == "(":
                balance += 1
            elif token == ")":
                balance -= 1
                if balance < 0:
                    raise ValidationError("括弧の対応が不正です。")

            if token in _SUPPORTED_OPERATORS:
                if previous is None or previous in _SUPPORTED_OPERATORS or previous == "(":
                    raise ValidationError("演算子の配置が不正です。")
            elif token == ")":
                if previous in _SUPPORTED_OPERATORS or previous is None:
                    raise ValidationError("閉じ括弧の位置が不正です。")
            else:  # token is number or '('
                if previous == ")":
                    raise ValidationError("閉じ括弧の直後に数値または開き括弧が必要です。")
            previous = token

        if balance != 0:
            raise ValidationError("括弧の数が一致しません。")
        if tokens[-1] in _SUPPORTED_OPERATORS:
            raise ValidationError("式の末尾に演算子が存在します。")
        if not any(
            token not in _SUPPORTED_OPERATORS and token not in {"(", ")"}
            for token in tokens
        ):
            raise ValidationError("数値トークンが含まれていません。")


class ParserService:
    """Converts a sequence of tokens into an AST."""

    def __init__(self, validator: SyntaxValidator | None = None) -> None:
        self._validator = validator or SyntaxValidator()

    def parse(self, tokens: Sequence[str]) -> BinaryOperationNode | NumberNode:
        self._validator.validate(tokens)
        self._tokens = list(tokens)
        self._position = 0
        node = self._parse_expression()
        if self._position != len(self._tokens):
            raise ValidationError("式の解析が完了しませんでした。")
        return node

    def _parse_expression(self) -> BinaryOperationNode | NumberNode:
        node = self._parse_term()
        while self._current_token in {"+", "-"}:
            operator = self._current_token
            self._advance()
            right = self._parse_term()
            node = BinaryOperationNode(operator=operator, left=node, right=right)
        return node

    def _parse_term(self) -> BinaryOperationNode | NumberNode:
        node = self._parse_factor()
        while self._current_token in {"*", "/"}:
            operator = self._current_token
            self._advance()
            right = self._parse_factor()
            node = BinaryOperationNode(operator=operator, left=node, right=right)
        return node

    def _parse_factor(self) -> BinaryOperationNode | NumberNode:
        token = self._current_token
        if token == "(":
            self._advance()
            node = self._parse_expression()
            if self._current_token != ")":
                raise ValidationError("閉じ括弧が欠落しています。")
            self._advance()
            return node
        if token is None:
            raise ValidationError("式が不完全です。")
        self._advance()
        try:
            value = Decimal(token)
        except Exception as exc:  # noqa: BLE001
            raise ValidationError(f"数値を解釈できません: {token}") from exc
        return NumberNode(value=value)

    @property
    def _current_token(self) -> str | None:
        if self._position >= len(self._tokens):
            return None
        return self._tokens[self._position]

    def _advance(self) -> None:
        self._position += 1


def normalize_tokens(tokens: Iterable[str]) -> list[str]:
    """Join tokens and re-tokenize for consistent parsing rules."""

    expression = " ".join(tokens)
    return tokenize(expression)
