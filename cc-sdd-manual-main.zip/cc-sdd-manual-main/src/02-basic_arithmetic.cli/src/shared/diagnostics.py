"""Diagnostics helpers for translating domain errors to user-facing messages."""

from __future__ import annotations

from dataclasses import dataclass, field

from rich.console import Console

from .exceptions import (
    EvaluationError,
    ExitPayload,
    ExpressionError,
    OverflowEvaluationError,
    TokenizationError,
    UnsupportedTokenError,
    ValidationError,
    ZeroDivisionEvaluationError,
)


@dataclass(slots=True)
class DiagnosticsService:
    """Handles error presentation and exit codes."""

    stdout: Console = field(default_factory=Console)
    stderr: Console = field(default_factory=lambda: Console(stderr=True))

    def emit_error(self, error: ExpressionError) -> ExitPayload:
        if isinstance(error, ZeroDivisionEvaluationError):
            message = "0による除算はできません。入力を見直してください。"
            code = 2
        elif isinstance(error, OverflowEvaluationError):
            message = "計算結果が扱える範囲を超過しました。式を簡略化してください。"
            code = 3
        elif isinstance(error, ValidationError):
            message = f"構文エラー: {error}"
            code = 1
        elif isinstance(error, UnsupportedTokenError):
            message = f"未対応の記号が含まれています: {error}"
            code = 1
        elif isinstance(error, TokenizationError):
            message = f"入力の解釈に失敗しました: {error}"
            code = 1
        elif isinstance(error, EvaluationError):
            message = f"計算に失敗しました: {error}"
            code = 4
        else:
            message = "想定外のエラーが発生しました。"
            code = 5
        self.stderr.print(f"[bold red]Error:[/bold red] {message}")
        self.stderr.print("再入力手順: 式の記法、括弧、演算子を確認してください。", style="yellow")
        self.stderr.print("詳細は --help でヘルプを参照できます。", style="cyan")
        return ExitPayload(code=code, message=message, rich=True)

    def emit_success(self, result: str) -> ExitPayload:
        self.stdout.print(result, style="green", highlight=False)
        return ExitPayload(code=0, message=result, rich=True)
