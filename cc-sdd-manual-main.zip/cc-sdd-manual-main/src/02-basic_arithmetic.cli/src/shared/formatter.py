"""Formatting utilities for CLI output."""

from __future__ import annotations

from decimal import Decimal


def format_decimal(value: Decimal) -> str:
    """Format Decimal values removing trailing zeros while preserving integers."""

    normalized = value.normalize()
    if normalized == normalized.to_integral():
        return str(normalized.quantize(Decimal(1)))
    text = format(normalized, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"
