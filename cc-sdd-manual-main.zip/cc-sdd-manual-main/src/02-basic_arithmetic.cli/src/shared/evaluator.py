"""Evaluation utilities for arithmetic ASTs."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation, Overflow
from typing import Protocol

from .ast_nodes import BinaryOperationNode, NumberNode
from .exceptions import EvaluationError, OverflowEvaluationError, ZeroDivisionEvaluationError


class SupportsEvaluation(Protocol):
    def evaluate(self, node: BinaryOperationNode | NumberNode) -> Decimal: ...


class EvaluatorService:
    """Evaluates arithmetic AST nodes with Decimal precision."""

    def __init__(self, *, context: Decimal | None = None) -> None:
        self._context = context

    def evaluate(self, node: BinaryOperationNode | NumberNode) -> Decimal:
        return self._evaluate_node(node)

    def _evaluate_node(self, node: BinaryOperationNode | NumberNode) -> Decimal:
        if isinstance(node, NumberNode):
            return node.value
        left = self._evaluate_node(node.left)
        right = self._evaluate_node(node.right)

        try:
            if node.operator == "+":
                return left + right
            if node.operator == "-":
                return left - right
            if node.operator == "*":
                return left * right
            if node.operator == "/":
                if right == 0:
                    raise ZeroDivisionEvaluationError("0で除算することはできません。")
                return left / right
        except ZeroDivisionEvaluationError:
            raise
        except Overflow:
            raise OverflowEvaluationError("計算結果が許容範囲を超えました。") from None
        except InvalidOperation as exc:
            raise EvaluationError("計算に失敗しました。式を確認してください。") from exc
        raise EvaluationError(f"未対応の演算子です: {node.operator}")
