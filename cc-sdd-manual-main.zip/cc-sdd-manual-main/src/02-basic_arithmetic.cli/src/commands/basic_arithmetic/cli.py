"""Typer entry point for the Basic Arithmetic CLI."""

from __future__ import annotations

from collections.abc import Sequence

import typer

from src.shared.diagnostics import DiagnosticsService
from src.shared.evaluator import EvaluatorService
from src.shared.exceptions import ExitPayload, ExpressionError, ValidationError
from src.shared.formatter import format_decimal
from src.shared.parser import ParserService, normalize_tokens

diagnostics_service = DiagnosticsService()
parser_service = ParserService()
evaluator_service = EvaluatorService()


class CommandEntry:
    """Coordinates CLI execution between parser, evaluator, and diagnostics."""

    def __init__(
        self,
        parser: ParserService,
        evaluator: EvaluatorService,
        diagnostics: DiagnosticsService,
    ) -> None:
        self._parser = parser
        self._evaluator = evaluator
        self._diagnostics = diagnostics

    def run(self, raw_tokens: Sequence[str]) -> ExitPayload:
        self._ensure_environment()
        try:
            tokens = normalize_tokens(raw_tokens)
            ast = self._parser.parse(tokens)
            result = self._evaluator.evaluate(ast)
            output = format_decimal(result)
            return self._diagnostics.emit_success(output)
        except ExpressionError as error:
            return self._diagnostics.emit_error(error)
        except Exception as error:  # noqa: BLE001
            return self._diagnostics.emit_error(
                ValidationError(f"予期しないエラーが発生しました: {error}")
            )

    def _ensure_environment(self) -> None:
        """Perform lightweight diagnostics before executing the command."""

        if self._parser is None or self._evaluator is None or self._diagnostics is None:
            raise ValidationError("初期化に失敗しました。依存サービスを確認してください。")


app = typer.Typer(help="四則演算式を評価し、結果を標準出力へ返すCLIツール。")


def _version_callback(value: bool | None) -> bool | None:
    if not value:
        return value
    from . import __version__

    typer.echo(__version__)
    raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        flag_value=True,
        callback=_version_callback,
        help="バージョン情報を表示します。",
        is_eager=True,
    ),
) -> None:
    """Root callback invoked before executing subcommands."""
    if ctx.invoked_subcommand is None and not ctx.args:
        typer.echo(ctx.get_help())
        raise typer.Exit()
    del version


@app.command("calc")
def calculate(
    expression: list[str] = typer.Argument(
        ..., metavar="EXPRESSION...", help="空白区切りのトークンで四則演算式を指定します。"
    ),
) -> None:
    runner = CommandEntry(parser_service, evaluator_service, diagnostics_service)
    payload = runner.run(expression)
    raise typer.Exit(code=payload.code)


def run() -> None:
    """Entry point for `python -m` execution."""

    app()


if __name__ == "__main__":
    run()
