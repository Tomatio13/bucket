# Project Structure

## Organization Philosophy

仕様ファーストでCLIコマンドを育てるため、`.kiro/` に仕様資産を集約しつつ、実装は `src/commands/<feature>` に機能単位で配置する。各機能は独立したモジュールとしてテストとヘルプを同梱する。

## Directory Patterns

### Specs as Source of Truth
**Location**: `.kiro/specs/<feature>/`
**Purpose**: 要件・設計・タスクを保持し、フェーズごとの承認状態を明示する。
**Example**: `.kiro/specs/basic-arithmetic-cli/requirements.md`

### Commands Modules
**Location**: `src/commands/<feature>/`
**Purpose**: CLIエントリポイントとドメインロジックを分離した実装を配置する。
**Example**: `src/commands/basic_arithmetic/__init__.py`（計算処理と入出力を分割）

### Shared Utilities
**Location**: `src/shared/`
**Purpose**: 数値計算や入出力整形などコマンド間で共通利用するユーティリティを提供する。
**Example**: `src/shared/parser.py`（トークン解析と構文検証を担当）

## Naming Conventions

- **Directories**: 機能名はケバブケース（例: `basic-arithmetic-cli`）、Pythonパッケージはスネークケース。
- **ファイル**: Pythonモジュールはスネークケース、テストは `test_<target>.py`。
- **関数**: 動詞から始めるスネークケース（例: `evaluate_expression`）。

## Import Organization

```python
# 共通ユーティリティは shared から絶対インポート
from src.shared.parser import tokenize

# 同一コマンド内は相対インポートで疎結合を維持
from .executor import evaluate
```

**Path Aliases**:
- `src.shared`: コアユーティリティ
- `src.commands`: 機能別コマンド

## Code Organization Principles

- 仕様書のAcceptance Criteriaをテストケースとして先に作成する。
- コマンドは副作用を最小化し、入出力と計算ロジックを別モジュールに分割する。
- エラー通知メッセージは一箇所に集約し、CLIの振る舞いを一貫させる。

---
_パターンを記録し、新しいコマンドが既存構造に従えば追記不要とする_
