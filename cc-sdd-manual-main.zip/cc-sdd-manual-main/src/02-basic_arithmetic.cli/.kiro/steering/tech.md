# Technology Stack

## Architecture

仕様フェーズで確定したCLI単位の要件を小さな実行可能ツールとして提供するシンプルなアーキテクチャを採用する。各コマンドは独立デプロイ可能なユーティリティとして設計し、共通の入出力規約とエラーハンドリングポリシーを共有する。

## Core Technologies

- **Language**: Python 3.11+ を推奨（型ヒントと豊富なCLIエコシステムを活用）。
- **Framework**: `typer` または `click` による宣言的CLI構築を標準とする。
- **Runtime**: CPython 3.11 以上での動作を前提とし、venvでの環境分離を行う。

## Key Libraries

- `typer` (または `click`): CLIコマンドとオプション宣言を簡潔に記述。
- `rich`: エラー表示やヘルプ出力の整形に使用。
- `pytest`: 受け入れ条件を検証するテストフレームワーク。

## Development Standards

### Type Safety
- Pythonの型ヒントを必須とし、`mypy` での型検証をCIに組み込む。

### Code Quality
- `ruff` による静的解析とフォーマットチェックを実施する。
- コマンド毎にモジュール分割し、副作用の少ない関数設計を徹底する。
- `scripts/quality.py` を `uv run python -m scripts.quality` で実行し、`ruff` と `pytest` を一括で回すワークフローを標準とする（`UV_CACHE_DIR=$(pwd)/.uv-cache` を併用しキャッシュをプロジェクト内に固定）。

### Testing
- 単体テストでEARS要件をカバーし、CLIテストは `pytest` + `CliRunner` を用いる。
- クリティカルな数値ケース（ゼロ除算、境界値）は必ずテスト化する。

## Development Environment

### Required Tools
- Python 3.11+
- `uv`（仮想環境構築とパッケージ管理を統一）

### Common Commands
```bash
# 仮想環境構築
uv venv .venv

# 仮想化環境の有効化
source .venv/bin/activate

# 依存インストール（requirements.txt がある場合）
uv pip install -r requirements.txt

# ライブラリ追加
uv pip install <library>

# 静的解析
uv run ruff check

# テスト実行
uv run pytest
```

## Key Technical Decisions

- CLI出力はデフォルトでUTF-8、標準出力/標準エラーを明確に使い分ける。
- 除算や浮動小数点演算のブレを避けるため、`decimal` モジュールを優先的に利用する。
- 仕様フェーズで定義したエラーメッセージ文言を実装に反映し、国際化を見越してメッセージ管理をモジュール化する。
- 依存ライブラリ管理は `uv` を唯一のエントリーポイントとし、仮想環境作成から `uv pip install <library>` まで統一する。

---
_主要な技術選定と基準のみを記録し、詳細な依存関係一覧は別途管理する_
