# Design Document

## Overview
Basic Arithmetic CLIは、コマンドライン利用者が外部ツールに頼らず即時に四則演算結果を得られる体験を提供する。要件で定義した標準出力・標準エラーの振る舞いを統一し、再利用しやすい構造で複数のCLI機能へ拡張可能な土台を築く。
主要な利用者は、スクリプトやCI上で単純な数値計算を自動化したい開発者および運用担当者であり、基盤となるエラーハンドリングとヘルプ提示により日常フローへ容易に組み込めるようにする。結果として、仕様駆動のプロジェクト記憶と整合したCLIコマンドを迅速に追加できるよう既存スタックと整合する設計を行う。

### Goals
- 四則演算式を構文解析し、順序性と型混在を考慮した評価を行う。
- エラー条件を分類し、利用者に可観測かつ再入力可能なフィードバックを返す。
- `uv` を基盤とするPython CLIパターンに適合させ、今後のコマンド追加へ再利用できる構造を提示する。

### Non-Goals
- GUI/UIクライアントや永続化を含む高度なインターフェースの提供。
- 代数的簡略化や複数式ファイルの一括処理など高度な数式エンジン機能。
- 多言語対応メッセージの実装（将来の国際化に備えた設計のみ）。

## Architecture

### High-Level Architecture
```mermaid
graph TD
    CLIUser[CLI User] --> CLIEntry[Command Entry]
    CLIEntry --> Parser[Expression Parser]
    Parser --> Validator[Syntax Validator]
    Validator --> Evaluator[Arithmetic Evaluator]
    Evaluator --> Formatter[Result Formatter]
    CLIEntry --> Diagnostics[Diagnostics Handler]
    Formatter --> OutputStreams[Stdout]
    Diagnostics --> ErrorStream[Stderr]
```

### Technology Stack and Design Decisions
- **CLIレイヤ**: `typer` を用いたサブコマンド定義。宣言的なオプション管理と`CliRunner`によるテスト互換性を確保し、仕様で定義したヘルプ/バージョン要件を自動化する。
- **構文解析**: 標準ライブラリ`shlex`によるトークン化と、独自の再帰下降パーサで括弧・演算子優先度を処理。外部依存を避け、要件に沿った軽量構成を維持する。
- **数値評価**: `decimal.Decimal` を使用し桁落ちや丸め誤差を抑制。ゼロ除算など演算例外を明示的に捕捉し、Diagnosticsへ委譲する。
- **実行環境**: `uv` による仮想環境・依存管理を前提とし、`uv run` 経由でlint/testコマンドを統一。

#### Key Design Decisions
1. **Decision**: `typer` ベースのCLIフレームワークを採用。
   - **Context**: 要件4で定義されたヘルプとバージョン表示を一貫性のあるAPIで実装する必要がある。
   - **Alternatives**: `argparse`（標準だがヘルプ構成を都度実装）、`click`（柔軟だがtyperより宣言的記述が冗長）、`fire`（ヘルプ制御が限定的）。
   - **Selected Approach**: `typer` の`@app.command()`デコレータで単一コマンドを定義し、help/versionを自動生成。
   - **Rationale**: 型ヒント連動のドキュメント生成とテスト互換性が高く、構文解析との責任分離が容易。
   - **Trade-offs**: 依存追加が必要になるが、CLI拡張時の再利用性を向上。
2. **Decision**: `decimal.Decimal` による演算。
   - **Context**: 要件1・2で小数混在の計算精度が求められ、ゼロ除算を検知する必要がある。
   - **Alternatives**: `float`（浮動小数誤差）、`fractions.Fraction`（性能低下と指数表記対応が複雑）、`sympy`（過剰機能）。
   - **Selected Approach**: `decimal` コンテキストを初期化し、文字列入力から精度を保ったまま評価。
   - **Rationale**: 指数表記を含む入力でも精度管理が容易で、ゼロ除算は例外で検知可能。
   - **Trade-offs**: Decimal変換コストがあるが、CLI用途では許容範囲。
3. **Decision**: 構文解析と評価を分割した二層構成。
   - **Context**: 要件2で構文検証、要件3でエラー検出の責務を分離する必要がある。
   - **Alternatives**: `eval` の直接利用（安全性欠如）、単一パス評価（責務が錯綜）、外部ライブラリ（依存増加）。
   - **Selected Approach**: Parserが抽象構文木(AST)を生成し、EvaluatorがASTを走査。
   - **Rationale**: エラー箇所・メッセージの明確化と今後の演算拡張（累乗や関数）への拡張余地を確保。
   - **Trade-offs**: 実装ステップが増えるが、テスト容易性が向上。

## System Flows
```mermaid
flowchart TD
    Start([Start]) --> Tokens[トークン化]
    Tokens --> Validate[構文検証]
    Validate -->|OK| BuildAST[AST生成]
    Validate -->|NG| ReportError[エラー通知]
    BuildAST --> Eval[Decimal演算]
    Eval -->|成功| FormatOut[結果整形]
    Eval -->|失敗| ReportError
    FormatOut --> Output[標準出力]
    ReportError --> ErrorOut[標準エラーと終了コード]
```

## Components and Interfaces

### CLIレイヤ

#### CommandEntry
**Responsibility & Boundaries**
- **Primary Responsibility**: CLI引数の受領とサブコマンドの実行を統括し、処理結果を標準出力へ返す。
- **Domain Boundary**: ユーザーインタフェース層。
- **Data Ownership**: CLIオプションと引数の生データ。
- **Transaction Boundary**: 単一コマンド実行をトランザクションとみなし、完了まで状態を共有しない。

**Dependencies**
- **Outbound**: ParserService, EvaluatorService, DiagnosticsService。
- **External**: `typer`、`uv`実行環境。

**Service Interface（擬似）**
```
CommandEntry.run(expression_tokens: list[str]) -> int
```
- **Preconditions**: `expression_tokens` が空でない。
- **Postconditions**: 成功時は0を返し標準出力へ結果文字列を書き込む。
- **Invariants**: 実行中は単一式のみ扱う。

#### HelpPresenter
- **Primary Responsibility**: ヘルプ/バージョン表示テンプレートを提供。
- **Dependencies**: `typer` の自動生成機能、DiagnosticsService。
- **Contract**: `render_help()`／`render_version()` は副作用のみで戻り値なし。

### 解析レイヤ

#### ParserService
- **Primary Responsibility**: コマンド引数列をトークン化し、構文木へ変換。
- **Domain Boundary**: 構文解析。
- **Data Ownership**: ASTノード（演算子、リテラル、サブ式）。

**Dependencies**
- **Outbound**: SyntaxValidator。
- **External**: `decimal`, `shlex`。

**Service Interface（擬似）**
```
ParserService.parse(tokens: list[str]) -> AST
```
- **Preconditions**: トークン配列が事前にUTF-8で解釈可能。
- **Postconditions**: 構文エラー時はSyntaxError例外でDiagnosticsへ伝播。

#### SyntaxValidator
- **Primary Responsibility**: トークン列が要件2で定義された演算子配置ルールを満たすか検査。
- **Outbound Dependencies**: DiagnosticsService。
- **Contract**: `validate(ast)` は失敗時にValidationErrorを発生させ、エラー分類情報を付与。

### 評価レイヤ

#### EvaluatorService
- **Primary Responsibility**: ASTを走査して演算を行い、`Decimal`結果を返却。
- **Domain Boundary**: 数値評価。
- **Data Ownership**: 計算中の中間結果。
- **Dependencies**: DiagnosticsService（例外処理）。
- **Contract**: `evaluate(ast, context)` はゼロ除算時に`EvaluationError`を通知。

#### ResultFormatter
- **Primary Responsibility**: `Decimal`結果を仕様に沿って文字列化し、標準出力形式に整える。
- **Contract**: `format(value: Decimal) -> str`。

### 診断レイヤ

#### DiagnosticsService
- **Primary Responsibility**: 構文/評価エラーを分類し、ユーザーに再入力手順を提示。
- **Dependencies**: CommandEntry（終了コード設定）, HelpPresenter（再案内メッセージ）。
- **Contract**: `emit(error: DomainError) -> ExitPayload`（終了コードとメッセージを保持）。
- **Error Categories**: UnsupportedToken, ZeroDivision, Overflow, InternalFailure。

## Error Handling
- **Error Strategy**: 入力検証段階で可能な限り早く失敗させ、DiagnosticsServiceがエラー種別に応じて標準エラーへメッセージと再入力手順を出力する。ゼロ除算・オーバーフローは評価層から例外として伝播し、Diagnosticsでユーザー向けメッセージへ変換する。
- **User Errors (4xx相当)**: UnsupportedToken, InvalidStructure。再入力例とヘルプ参照を提示し、終了コード1。
- **System Errors (5xx相当)**: 内部例外やDecimalコンテキストエラー。ログ出力を想定しつつ、利用者へ再実行指示を返す。
- **Monitoring**: 標準エラーへ識別子付きログ行を出力し、将来的なロギング統合に備えて構造化メッセージ形式（JSONライン）を採用予定。

## Testing Strategy
- **Unit Tests**: ParserServiceの演算子優先度処理、EvaluatorServiceのDecimal計算、DiagnosticsServiceのエラーメッセージ生成を個別に検証。
- **Integration Tests**: `CliRunner` を用いた end-to-end テストで、正常系とゼロ除算・構文エラーケースを評価。
- **Regression Tests**: 指数表記や大きな整数など境界値を含むシナリオを追加し、要件3のオーバーフロー検知を継続確認。
- **Documentation Tests**: ヘルプ表示やサンプルコマンドの出力が仕様と一致するか `--help` / `--version` を自動検証。

## Performance & Scalability
- 対象は単発のCLI実行であり高負荷想定はないが、AST構築とDecimal演算はO(n)でスケール。長大な式によるパフォーマンス低下が検出された場合はトークン数に比例したベンチマークを`pytest-benchmark`で取得する。

## Security Considerations
- 外部入力はCLI引数のみであり、`eval` を使用しない設計でコードインジェクションを防ぐ。
- エラーメッセージに入力値をそのまま表示する際はトークン化後の安全な表現を利用し、潜在的な制御文字を除去する。
