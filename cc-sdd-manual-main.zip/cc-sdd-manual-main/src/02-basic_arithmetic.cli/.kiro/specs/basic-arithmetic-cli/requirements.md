# Requirements Document

## Introduction
Basic Arithmetic CLIはCLI利用者が単純な数値計算を即時に実行できるよう、四則演算式を解釈して結果を返すコマンドラインツールである。

## Requirements

### Requirement 1: 四則演算の実行
**Objective:** CLI利用者として、複数の四則演算を素早く計算したい。なぜなら、外部ツールに頼らずに結果を得たいからである。

#### Acceptance Criteria
1. WHEN 利用者が二項の加算・減算・乗算・除算式を入力すると THEN Basic Arithmetic CLI SHALL 対応する演算結果を標準出力する。
2. IF 入力が整数と小数を含む THEN Basic Arithmetic CLI SHALL それらを混在した数値として計算する。
3. IF 式に括弧が含まれる THEN Basic Arithmetic CLI SHALL 四則演算の優先順位を適用して評価する。

### Requirement 2: 入力構文と解析
**Objective:** CLI利用者として、決められた形式で式を渡したい。なぜなら、意図した演算が正しく解釈されると確信したいからである。

#### Acceptance Criteria
1. WHEN 利用者がコマンドライン引数として空白で区切られた数値と演算子の列を指定すると THEN Basic Arithmetic CLI SHALL その引数を式として解析する。
2. IF 式に複数の演算子が連続する THEN Basic Arithmetic CLI SHALL 演算子とオペランドの並びを検証して構文エラーを検出する。
3. WHERE 入力に先頭の符号や指数表記が含まれる THE Basic Arithmetic CLI SHALL それらを有効な数値として解釈する。

### Requirement 3: エラー検知と通知
**Objective:** CLI利用者として、無効な入力条件を直ちに把握したい。なぜなら、正しい式に修正できるようにしたいからである。

#### Acceptance Criteria
1. WHEN 入力がサポート外の記号や空トークンを含む THEN Basic Arithmetic CLI SHALL 処理を中断してエラーメッセージを標準エラー出力する。
2. IF 入力に0での除算が含まれる THEN Basic Arithmetic CLI SHALL 結果を計算せずに除算不能であると通知する。
3. IF 計算結果が内部で扱える数値範囲を超過する THEN Basic Arithmetic CLI SHALL オーバーフローを通知して非ゼロの終了ステータスを返す。

### Requirement 4: 利用案内と操作性
**Objective:** CLI利用者として、コマンドの使い方をいつでも確認したい。なぜなら、適切な構文やオプションを迷わずに選びたいからである。

#### Acceptance Criteria
1. WHEN 利用者がヘルプオプションを指定すると THEN Basic Arithmetic CLI SHALL 受け付ける演算子・数値形式・使用例を表示する。
2. WHERE エラー通知が行われる THE Basic Arithmetic CLI SHALL 対応する再入力手順や利用例への参照を同時に案内する。
3. WHEN 利用者がバージョン情報を要求すると THEN Basic Arithmetic CLI SHALL 現行バージョンと依存要件を表示する。
