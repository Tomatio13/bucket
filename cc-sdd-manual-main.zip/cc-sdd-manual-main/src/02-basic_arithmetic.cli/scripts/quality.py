"""Run linting and tests in a single command."""

from __future__ import annotations

import subprocess
import sys


def run_command(command: list[str]) -> int:
    process = subprocess.run(command, check=False)
    return process.returncode


def main() -> None:
    steps = [
        ("Ruff lint", ["ruff", "check"]),
        ("Pytest", ["pytest"]),
    ]
    failures: list[tuple[str, int]] = []
    for name, command in steps:
        print(f"\n>> Running {name}: {' '.join(command)}")
        code = run_command(command)
        if code != 0:
            failures.append((name, code))
    if failures:
        for name, code in failures:
            print(f"{name} failed with exit code {code}")
        sys.exit(failures[-1][1])
    print("\nAll quality checks passed.")


if __name__ == "__main__":
    main()
