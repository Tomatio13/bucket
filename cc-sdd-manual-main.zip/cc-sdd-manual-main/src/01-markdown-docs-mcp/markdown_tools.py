"""Manual Markdown tool definitions for the MCP server."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

DOCS_ROOT = Path(__file__).parent.joinpath("docs")


@dataclass(frozen=True)
class DocumentToolDefinition:
    """Represents a manually curated Markdown tool entry."""

    tool_id: str
    title: str
    path: Path
    summary: str
    tags: Tuple[str, ...]
    last_modified: datetime

    @property
    def relative_path(self) -> str:
        return str(self.path)


def _read_last_modified(path: Path) -> datetime:
    mtime = path.stat().st_mtime
    return datetime.fromtimestamp(mtime, tz=timezone.utc)


TOOL_DEFINITIONS: List[DocumentToolDefinition] = [
    DocumentToolDefinition(
        tool_id="operations-guide",
        title="Operations Guide",
        path=DOCS_ROOT / "operations-guide.md",
        summary="Markdown Docs MCP Serverの運用手順とツール追加時の確認事項をまとめたガイド",
        tags=("operations", "guide", "manual"),
        last_modified=_read_last_modified(DOCS_ROOT / "operations-guide.md"),
    ),
]


def _format_description(definition: DocumentToolDefinition) -> str:
    tags = ", ".join(definition.tags)
    return (
        f"{definition.title}\n"
        f"Summary: {definition.summary}\n"
        f"Path: {definition.relative_path}\n"
        f"Tags: {tags}\n"
        f"Updated: {definition.last_modified.isoformat()}"
    )


def register_tools(app: object) -> List[DocumentToolDefinition]:
    """Register manual Markdown tools onto the FastMCP application."""

    registered: List[DocumentToolDefinition] = []
    metadata = getattr(app, "metadata", None)
    if isinstance(metadata, dict):
        metadata["manual_tools"] = []
    for definition in TOOL_DEFINITIONS:
        description = _format_description(definition)

        @app.tool(name=definition.tool_id)
        def manual_markdown_tool(defn: DocumentToolDefinition = definition) -> Dict[str, object]:
            request_id = f"manual-{defn.tool_id}-{datetime.now(tz=timezone.utc).timestamp()}"
            content = defn.path.read_text(encoding="utf-8")
            stats = defn.path.stat()
            log_entries = [
                {
                    "level": "info",
                    "message": "markdown_read",
                    "tool_id": defn.tool_id,
                    "path": str(defn.path),
                }
            ]
            return {
                "path": str(defn.path),
                "content": content,
                "size_bytes": stats.st_size,
                "last_modified": datetime.fromtimestamp(stats.st_mtime, tz=timezone.utc).isoformat(),
                "fetched_at": datetime.now(tz=timezone.utc).isoformat(),
                "request_id": request_id,
                "log_entries": log_entries,
            }

        manual_markdown_tool.__name__ = definition.tool_id.replace("-", "_")  # type: ignore[attr-defined]
        manual_markdown_tool.__doc__ = description  # type: ignore[attr-defined]

        tools_attr = getattr(app, "tools", None)
        if isinstance(tools_attr, dict):
            tools_attr[definition.tool_id]["description"] = description

        metadata = getattr(app, "metadata", None)
        if isinstance(metadata, dict):
            manual = metadata.setdefault("manual_tools", [])
            manual.append(
                {
                    "tool_id": definition.tool_id,
                    "title": definition.title,
                    "summary": definition.summary,
                    "path": definition.relative_path,
                    "tags": list(definition.tags),
                }
            )

        registered.append(definition)

    return registered


def iter_manual_paths() -> Iterable[Path]:
    for definition in TOOL_DEFINITIONS:
        yield definition.path
