# Design Document

## Overview
Markdown Docs MCP Serverは、FastMCPを用いて手動定義されたMarkdownドキュメント用ツールを公開する最小構成のMCPサーバである。AIクライアントはハンドシェイクで提供されるツール一覧から目的のドキュメントを選択し、ツールを呼び出すことでMarkdown本文を取得できる。
**Purpose**: この機能は、LLMクライアントが限定的なMarkdownドキュメントセットを安全かつ確定的に読み出す手段を提供する。
**Users**: 内部AIエージェント開発者およびオペレーション担当者が、ドキュメント参照タスクの自動化に利用する。
**Impact**: 個別のAPI開発を不要にし、最小工数でドキュメント共有チャネルを整備する。

### Goals
- MCPクライアントがサーバ能力（ツール、プロンプト）をプロトコル準拠で取得できること
- Markdownファイルごとに定義されたツールから、descriptionで概要を把握し本文を取得できること
- 手戻りを最小化するための堅牢なログ・バリデーション境界の定義

### Non-Goals
- Markdownドキュメントの自動検出やツールの自動生成
- ドキュメントの更新・作成・削除等の変更系操作
- Markdownコンテンツの整形や要約などの加工処理

## Architecture

### Existing Architecture Analysis (if applicable)
本機能は新規追加であり既存のMCPサーバは存在しない。将来的な自動生成機構に備えてコード構成は疎結合を意識するが、現段階では手動定義を前提とする。

### High-Level Architecture
FastMCPインスタンス内に手動で登録したツール群を保持し、各ツールは固定のMarkdownファイルを読み込んで返却する。ツール定義はPythonモジュールで管理し、descriptionにメタデータを埋め込む。ファイル読み込みはUTF-8で行い、レスポンスにメタ情報を付与する。

```mermaid
graph TD
    McpClient[MCP Client]
    McpServer[Markdown Docs MCP Server]
    ManualTools[Manual Markdown Tool Definitions]
    FileSystem[File System]

    McpClient --> McpServer
    McpServer --> ManualTools
    ManualTools --> FileSystem
```

**Architecture Integration**:
- Existing patterns preserved: ローカルファイルのみを対象とした単純構成
- New components rationale: ツール定義モジュールを導入し、手動追加時の変更箇所を限定
- Technology alignment: FastMCPとPython 3.11を用いて公式プロトコルを準拠実装
- Steering compliance: プロジェクト共通ステアリングは未設定のため、AI-DLCガイドライン（安全性、ログ整備）に準拠

## Technology Stack and Design Decisions

### Technology Stack
- **Application Layer**: FastMCPサーバ（Python 3.11）。STDIOトランスポートでクライアントと通信。
- **Tool Definition Layer**: `markdown_tools.py`（仮）に手動で`@mcp.tool`を付与した関数を定義し、descriptionへメタデータを記述。
- **Execution Layer**: MarkdownFileReaderが指定パスをUTF-8で読み取り、`pydantic`モデルでレスポンスを整形。
- **Infrastructure**: `pathlib`によるファイル操作と`structlog`/`logging`のJSONハンドラによる構造化ログ。

### Key Design Decisions
- **Decision**: FastMCPの標準機能でツールとハンドシェイクを管理
  - **Context**: MCP準拠を最小の工数で実装したい。
  - **Alternatives**: 独自JSON-RPC実装、他エージェントフレームワーク利用
  - **Selected Approach**: FastMCPのデコレータでツールを定義し、`mcp.run()`を利用。
  - **Rationale**: 公式仕様との互換性と保守性を確保。
  - **Trade-offs**: フレームワーク依存が残る。
- **Decision**: ツール定義を手動管理
  - **Context**: 現段階では対象Markdownが限定的であり、開発者の明示管理が要件。
  - **Alternatives**: 自動スキャン、設定ファイル駆動
  - **Selected Approach**: 各Markdownに対応するツール関数を直接コードで定義。
  - **Rationale**: 実装コストを最小化し、メタデータ記述を開発者が明示的に制御できる。
  - **Trade-offs**: ファイル追加時のコード修正が必要。
- **Decision**: descriptionへメタデータを含める
  - **Context**: LLMがツール一覧から適切なドキュメントを選択する必要がある。
  - **Alternatives**: 別途リソースAPIでメタデータ提供、プロンプトで説明
  - **Selected Approach**: description内にタイトル・概要・最終更新日時を記述。
  - **Rationale**: 追加エンドポイントなしで選択支援が可能。
  - **Trade-offs**: descriptionの整合性は開発者の運用に依存。

## System Flows

### ハンドシェイクおよびツールディスカバリフロー
```mermaid
sequenceDiagram
    participant Client as MCPClient
    participant Server as MarkdownDocsServer
    Client->>Server: handshake()
    Server-->>Client: handshakeResponse(protocol, tools)
    Client->>Server: listTools()
    Server-->>Client: toolList(with descriptions)
```

### ツール実行フロー
```mermaid
sequenceDiagram
    participant Client as MCPClient
    participant Server as MarkdownDocsServer
    participant Reader as MarkdownFileReader
    participant Fs as FileSystem
    Client->>Server: invokeTool(markdown_doc_tool)
    Server->>Reader: loadMarkdown(path)
    Reader->>Fs: open(path)
    Fs-->>Reader: markdownContent
    Reader-->>Server: markdownPayload
    Server-->>Client: markdownPayload
```

## Requirements Traceability
- **R1.1–R1.4**: MarkdownDocsServerのハンドシェイク実装と手動定義されたツール一覧で満たす。
- **R3.1–R3.4**: 各ツール関数とMarkdownFileReaderでファイル読み込み・メタデータ付与を行う。

## Components and Interfaces

### Application Layer

#### MarkdownDocsServer
**Responsibility & Boundaries**
- Primary Responsibility: FastMCPサーバの初期化、ハンドシェイク、ツール登録、各種リクエストのディスパッチ。
- Domain Boundary: MCPサーバアプリケーション。
- Data Ownership: ツール定義リスト、レスポンス生成。
- Transaction Boundary: リクエスト単位。

**Dependencies**
- Inbound: MCPクライアント。
- Outbound: MarkdownToolDefinitions、MarkdownFileReader、StructuredLogger。
- External: FastMCP。

**Interfaces & Contracts**
- `register_tools(mcp: FastMCP) -> None`：手動定義ツールを登録。
- `provide_handshake() -> HandshakePayload`：プロトコル情報とツール一覧を返却。
- `invoke_tool(tool_id: str) -> MarkdownPayload`：対応する関数を実行。
- `run()`：`mcp.run()`でSTDIOトランスポートを起動。

### Tool Definition Layer

#### MarkdownToolDefinitions
**Responsibility & Boundaries**
- Primary Responsibility: Markdownファイルとツール関数の対応を手動で保持し、descriptionにメタデータを記述する。
- Domain Boundary: ツール管理。
- Data Ownership: ファイルパス、タイトル、概要、最終更新日時などの静的情報。
- Transaction Boundary: 読み取り専用。

**Dependencies**
- Inbound: MarkdownDocsServer。
- Outbound: MarkdownFileReader（メタデータ取得時に利用可能）。
- External: なし。

**Interfaces & Contracts**
- `TOOL_DEFINITIONS: list[DocumentToolDefinition]`：手動定義のリスト。
- `register(mcp: FastMCP) -> None`：各定義を`@mcp.tool`関数として登録。

### Infrastructure Layer

#### MarkdownFileReader
**Responsibility & Boundaries**
- Primary Responsibility: 指定されたMarkdownファイルをUTF-8で読み込み、メタデータ付きレスポンスを生成する。
- Domain Boundary: IO層。
- Data Ownership: 読み込み結果。
- Transaction Boundary: ツール呼び出し単位。

**Dependencies**
- Inbound: MarkdownDocsServer、MarkdownToolDefinitions。
- Outbound: OSファイルシステム。
- External: `pathlib`, `pydantic`。

**Interfaces & Contracts**
- `load(path: Path) -> MarkdownPayload`：ファイル内容とメタデータを返却。
- `build_description(definition: DocumentToolDefinition) -> str`：description文字列を生成。

## Data Models

### Logical Data Model
| Entity | Attributes | Notes |
|--------|------------|-------|
| DocumentToolDefinition | `tool_id: str`, `title: str`, `path: Path`, `summary: str`, `tags: list[str]`, `last_modified: datetime` | 手動定義されるツール情報 |
| ToolDescriptor | `tool_id: str`, `name: str`, `description: str`, `arguments_schema: dict` | ハンドシェイクおよびlistToolsレスポンス |
| MarkdownPayload | `content: str`, `path: str`, `size_bytes: int`, `last_modified: datetime`, `fetched_at: datetime` | ツール応答 |

### Data Contracts & Integration
- **Handshake Payload**: `{ "name": str, "version": str, "protocol": str, "tools": [ToolDescriptor] }`。
- **Tool Description**: タイトル、サマリ、相対パス、タグ、最終更新日時を自然言語で含める。
- **Tool Execution Response**: `{ "content": str, "path": str, "size_bytes": int, "last_modified": ISO8601, "fetched_at": ISO8601 }`。

## Error Handling

### Error Strategy
- ハンドシェイク: 未対応プロトコルバージョンには`ProtocolError`を返却し詳細をログ。
- ツール解決: 未登録のツールIDや引数不備には`ToolNotFoundError`あるいは`InvalidToolInvocation`を返却。
- ファイルアクセス: 読み込み失敗時は`MarkdownReadFailure`を返却し、詳細を監査ログへ記録。

### Error Categories and Responses
- **User Errors (4xx)**: 無効なツール呼び出し→`ToolNotFoundError`。必須パラメータ未指定→`InvalidToolInvocation`。
- **System Errors (5xx)**: ファイルシステムエラー→`MarkdownReadFailure`。ツール登録時の例外→`ToolRegistrationError`。
- **Business Logic Errors (422)**: description生成に必要なメタ情報欠落→警告ログを出しつつdescriptionから該当情報を除外。

### Monitoring
- 構造化ログで`request_id`, `tool_id`, `duration_ms`, `file_path`（マスク済み）を記録。
- 致命的エラー発生時は通知フック（将来のMCP通知に連携）を準備。

## Testing Strategy

### Unit Tests
- MarkdownToolDefinitionsが期待通りの数のツールを登録する。
- MarkdownFileReaderが指定パスのMarkdownをUTF-8で読み込み、メタデータを付与する。
- description生成ロジックがタイトル・概要・最終更新日時を含める。

### Integration Tests
- FastMCP経由のハンドシェイク応答に全ツールが含まれる。
- 任意のツール呼び出しでMarkdown本文とメタデータが戻る。
- 読み取り不能ファイルのツール呼び出しが適切なエラーを返す。

### Performance/Load Tests
- 手動登録ツール数が多い（例: 200件）場合のハンドシェイク応答サイズと時間（目標 < 1秒）。
- 同一ツールへの高頻度呼び出し時にファイル読み込みレイテンシが閾値（< 300ms）を満たす。

## Security Considerations
- ハンドシェイクおよびツール呼び出しはゲートウェイ層でAPIキー／トークン認証を要求。
- ファイルパス正規化によりルート外アクセスを防止。
- ツールレスポンスに絶対パスや機密情報を含めない。

## Performance & Scalability
- ツール定義はコード内で管理し、更新はサーバ再起動で反映する。
- ファイル読み込みはOSキャッシュに依存しつつ、必要に応じてストリーミング返却を検討。
- ドキュメント数増加時はdescriptionの記載量を調整しハンドシェイク負荷を抑制。
