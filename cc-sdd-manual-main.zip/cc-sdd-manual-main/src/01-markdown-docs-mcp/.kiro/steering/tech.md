# Technology Stack

## Architecture

単一プロセスのFastMCPサーバがSTDIOトランスポートでLLMクライアントと通信する構成。手動で定義されたツール関数がMarkdownファイルを読み込み、ペイロード整形用のユーティリティがレスポンスを作成する。将来的なHTTP/WebSocket拡張に備え、トランスポート初期化部は抽象化する。

## Core Technologies

- **Language**: Python 3.11+（型ヒント必須）
- **Framework**: FastMCP（公式実装）
- **Runtime**: 標準Python実行環境（STDIO経由で起動）

## Key Libraries

- `fastmcp`: MCPツール登録とサーバ起動
- `pydantic`: レスポンスペイロードのバリデーションとシリアライズ
- `python-frontmatter` + `markdown-it-py`（任意）: description生成時のメタデータ抽出
- `structlog` or 標準`logging` JSONハンドラ: 監査ログの構造化出力

## Development Standards

### Type Safety
- 全関数で型ヒントを定義し、`mypy --strict`相当のチェックを通す
- ツールレスポンスは`pydantic`モデルで厳格に検証

### Code Quality
- `ruff`で静的解析と自動整形を行う（E/F/W違反ゼロを目標）
- DocstringはGoogleスタイルまたはreStructuredTextで統一

### Testing
- `pytest`でユニット／統合テストを実行
- ハンドシェイクとツール実行のゴールデンレスポンスをフィクスチャ化し、回帰検知を容易にする

## Development Environment

### Required Tools
- Python 3.11
- `uv` CLI（仮想環境作成と依存管理を一元化）
- MCPクライアント（Claude Desktopなど）での動作確認環境

### Common Commands
```bash
# 仮想環境作成
uv venv

# 仮想環境を有効化
source .venv/bin/activate

# 依存関係インストール
uv pip install -r requirements.txt

# サーバ実行 (STDIO)
python server.py

# テスト
pytest
```

## Key Technical Decisions

- **手動ツール登録**: 自動スキャンではなくコードでツールを宣言し、公開ドキュメントを明示的に制御する
- **description重視のメタデータ設計**: タイトル・概要・タグ・更新日時をdescriptionに含め、LLMがツール選択を誤らないようにする
- **構造化ログ**: すべてのツール呼び出しとエラーをJSONログで記録し、監査やリプレイに備える

---
_Updated: 2025-10-13_
