# Project Structure

## Organization Philosophy

シンプルな単一サービス構成を維持しつつ、役割ごとにモジュールを分離する。エントリポイントは`server.py`に集約し、ツール定義・ファイル読取・共通ユーティリティをそれぞれ専用モジュールへ切り出す。Spec Driven Developmentの成果物は`.kiro/`配下で管理し、実装コードと明確に分離する。

## Directory Patterns

### サーバエントリポイント
**Location**: `/server.py`
**Purpose**: FastMCPインスタンスの初期化、ツール登録呼び出し、`mcp.run()`によるSTDIO起動
**Example**:
```python
from fastmcp import FastMCP
from markdown_tools import register_tools

mcp = FastMCP(name="Markdown Docs MCP Server")
register_tools(mcp)

if __name__ == "__main__":
    mcp.run()
```

### ツール定義モジュール
**Location**: `/markdown_tools.py` または `/markdown_tools/__init__.py`
**Purpose**: `DocumentToolDefinition`リストと`@mcp.tool`関数群を管理し、descriptionにメタデータを埋め込む
**Example**: description末尾に「Tags: ...」「Updated: ...」を記載してLLMが選択しやすい表現にする

### ファイル読み込みユーティリティ
**Location**: `/services/markdown_reader.py`
**Purpose**: MarkdownファイルをUTF-8で読み込み、`MarkdownPayload`を組み立てる
**Example**: ファイルサイズ、`datetime.now(timezone.utc)`による`fetched_at`をレスポンスに含める

### テスト資産
**Location**: `/tests/`
**Purpose**: `pytest`でハンドシェイクとツール呼び出しを検証するフィクスチャ・テストケースを配置
**Example**: `tests/test_handshake.py`でツールdescriptionの必須項目を検査

## Naming Conventions

- **Modules**: `snake_case.py`
- **Classes / Pydantic Models**: `PascalCase`
- **Functions / ツール関数**: `snake_case`（例: `tool_handbook_platform()`）
- **Constants**: `UPPER_SNAKE_CASE`

## Import Organization

```python
# 標準ライブラリ → サードパーティ → プロジェクト内の順でグルーピング
from datetime import datetime, timezone

from fastmcp import FastMCP

from services.markdown_reader import MarkdownFileReader
```

**Path Aliases**:
- 基本は相対インポートで完結させ、トップレベルに`__init__.py`を置いてパッケージ化する

## Code Organization Principles

- 仕様の各フェーズ成果物は`.kiro/specs/<feature>/`に格納し、実装とは分離して管理する
- 新しいツールを追加する場合は定義リストにメタデータを追記し、descriptionの書式（タイトル → 概要 → パス → タグ → 更新日時）を守る
- 例外は標準化したカスタム例外に集約し、サーバ側でエラー分類（ユーザーエラー／システムエラー）を行う
- 監査ログは1リクエスト1レコードで出力し、`request_id`と`tool_id`を必須フィールドとする

---
_Updated: 2025-10-13_
