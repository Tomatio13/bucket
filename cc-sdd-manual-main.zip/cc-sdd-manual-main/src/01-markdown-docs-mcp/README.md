# Markdown Docs MCP Server

手動で定義したMarkdownドキュメントをModel Context Protocol (MCP) 互換クライアントへ公開する軽量サーバです。FastMCPを基盤に、ツールdescription内のメタデータでLLMがドキュメントを選択しやすいよう設計されています。

## 特徴

- FastMCPベースのSTDIOサーバで、手動登録したMarkdownツールを公開
- ツールdescriptionにタイトル・概要・パス・タグ・更新日時を整形
- ツール実行時にMarkdown本文と監査用メタデータ（request_id, log_entries等）を返却
- spec-driven workflow（requirements → design → tasks → implementation）に準拠

## 必要環境

- Python 3.11 以上
- [uv](https://github.com/astral-sh/uv) CLI（仮想環境と依存管理に使用）
- MCPクライアント（例: Claude Desktop）

## セットアップ

```bash
# 仮想環境を作成
uv venv

# 仮想環境を有効化
source .venv/bin/activate

# 依存パッケージをインストール
uv pip install -r requirements.txt
```

## 実行方法

```bash
# 仮想環境を有効化してサーバを起動
source .venv/bin/activate
python server.py
```

STDIOトランスポートで起動するため、MCP対応クライアント側で当該スクリプトを登録することでツールが利用可能になります。

## テスト

```bash
source .venv/bin/activate
python -m unittest discover tests
```

ユニットテストとE2Eテストが含まれており、ハンドシェイクとツール実行の挙動を検証します。

## プロジェクト構成ハイライト

- `server.py` — FastMCPアプリケーション初期化とハンドシェイク骨組み
- `markdown_tools.py` — 手動定義されたMarkdownツールのdescription整形と実装
- `docs/` — 公開対象のMarkdownドキュメント置き場
- `tests/` — ツール定義・ハンドシェイク・E2Eのテスト
- `.kiro/` — Spec Driven Development の成果物（requirements/design/tasks）

## メンテナンスガイド

1. **ドキュメントを追加する**
   - `docs/`にMarkdownファイルを配置
   - `markdown_tools.py` の `TOOL_DEFINITIONS` へ新しい `DocumentToolDefinition` を追加（タイトル・概要・タグ・更新日時整合）
   - description書式（タイトル→Summary→Path→Tags→Updated）を保持すること

2. **依存関係を更新する**
   - `requirements.txt` を編集
   - `uv pip install -r requirements.txt` で再インストール
   - テストを実行して回帰確認

3. **仕様更新時**
   - `.kiro/specs/markdown-docs-mcp/` 配下の requirements/design/tasks を更新
   - `/prompts:kiro-spec-…` コマンドで各フェーズを再実行し、phase/approvalsを整合させる

4. **ログ/監査の確認**
   - ツールレスポンスには `request_id` と `log_entries` が含まれるため、クライアント側でログ出力または保存を行う

## ライセンス

プロジェクトに適したライセンスを追加してください。

