# Operations Guide

このドキュメントはMarkdown Docs MCP Serverの運用手順をまとめています。
- ツールを追加したらサーバを再起動する
- 新しいドキュメントは手動で登録する
