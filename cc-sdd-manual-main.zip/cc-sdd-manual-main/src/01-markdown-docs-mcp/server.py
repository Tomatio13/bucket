"""Entry point for the Markdown Docs MCP Server."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

try:  # pragma: no cover - exercised by runtime when dependency is available
    from fastmcp import FastMCP  # type: ignore
except ImportError:  # pragma: no cover - fallback for offline development
    @dataclass
    class FastMCP:  # type: ignore[override]
        """Minimal fallback stub when fastmcp is unavailable."""

        name: str

        def __post_init__(self) -> None:
            self._tools: Dict[str, Dict[str, Any]] = {}
            self._prompts: Dict[str, Any] = {}

        def tool(self, name: str | None = None) -> Any:
            def decorator(func: Any) -> Any:
                tool_name = name or func.__name__
                self._tools[tool_name] = {
                    "callable": func,
                    "description": func.__doc__ or "",
                }
                return func

            return decorator

        @property
        def tools(self) -> Dict[str, Dict[str, Any]]:
            return self._tools

        def run(self) -> None:
            raise RuntimeError(
                "FastMCP is not installed. Install dependencies via 'uv pip install -r requirements.txt'."
            )


SERVER_METADATA: Dict[str, Any] = {
    "server_name": "Markdown Docs MCP Server",
    "identifier": "markdown-docs-mcp",
    "protocol_version": "1.0",
    "description": "Markdown Docs MCP Server exposes curated Markdown documents via MCP tools.",
}


def create_app() -> FastMCP:
    """Initialise the FastMCP application with project metadata."""
    app = FastMCP(name=SERVER_METADATA["server_name"])
    setattr(app, "metadata", SERVER_METADATA.copy())
    return app


def build_handshake_payload(app: FastMCP) -> Dict[str, Any]:
    """Produce a reusable handshake payload skeleton based on server metadata."""
    metadata = getattr(app, "metadata", SERVER_METADATA)
    tools = metadata.get("manual_tools", [])
    prompts = metadata.get("manual_prompts", [])
    return {
        "name": metadata["server_name"],
        "identifier": metadata["identifier"],
        "protocol": metadata["protocol_version"],
        "description": metadata["description"],
        "tools": tools,
        "prompts": prompts,
    }


def run_stdio(app: FastMCP) -> None:
    """Run the MCP server using the STDIO transport."""
    app.run()


def main() -> None:
    app = create_app()
    run_stdio(app)


if __name__ == "__main__":
    main()
