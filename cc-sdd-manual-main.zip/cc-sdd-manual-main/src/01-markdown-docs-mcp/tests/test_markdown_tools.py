import importlib
import pathlib
import unittest

from server import create_app


class MarkdownToolsTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.tools_module = importlib.import_module("markdown_tools")

    def test_tool_definitions_exist_and_reference_markdown(self) -> None:
        definitions = self.tools_module.TOOL_DEFINITIONS
        self.assertTrue(definitions, "TOOL_DEFINITIONS should contain at least one manual entry")

        for definition in definitions:
            self.assertTrue(definition.title)
            self.assertTrue(definition.summary)
            self.assertEqual(definition.path.suffix, ".md")
            self.assertTrue(definition.path.exists(), f"Markdown file missing: {definition.path}")

    def test_register_tools_registers_manual_entries(self) -> None:
        app = create_app()
        self.tools_module.register_tools(app)

        registered = getattr(app, "tools", {})
        self.assertTrue(registered)

        for definition in self.tools_module.TOOL_DEFINITIONS:
            self.assertIn(definition.tool_id, registered)
            tool_info = registered[definition.tool_id]
            description = tool_info["description"]
            self.assertIn(definition.title, description)
            self.assertIn(str(definition.path), description)
            self.assertIn(definition.summary, description)
            self.assertIn("Tags:", description)
            self.assertIn("Updated:", description)

            tool_callable = tool_info["callable"]
            payload = tool_callable()
            self.assertIn("content", payload)
            self.assertIn("path", payload)
            self.assertIn("size_bytes", payload)
            self.assertIn("last_modified", payload)
            self.assertIn("fetched_at", payload)
            self.assertIn("request_id", payload)
            self.assertIn("log_entries", payload)
            self.assertGreater(payload["size_bytes"], 0)
            self.assertEqual(payload["path"], str(definition.path))


if __name__ == "__main__":
    unittest.main()
