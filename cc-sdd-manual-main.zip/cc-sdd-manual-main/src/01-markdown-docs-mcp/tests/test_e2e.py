import importlib
import unittest

from server import create_app


class EndToEndTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.server = importlib.import_module("server")
        self.tools = importlib.import_module("markdown_tools")

    def test_handshake_and_tool_invocation_flow(self) -> None:
        app = create_app()
        self.tools.register_tools(app)

        payload = self.server.build_handshake_payload(app)
        self.assertGreater(len(payload["tools"]), 0)

        registered_tools = getattr(app, "tools", {})
        for tool_id, tool_info in registered_tools.items():
            tool_callable = tool_info["callable"]
            response = tool_callable()
            self.assertIsInstance(response, dict)
            self.assertIn("content", response)
            self.assertIn("path", response)
            self.assertIn("size_bytes", response)
            self.assertIn("last_modified", response)
            self.assertIn("fetched_at", response)
            self.assertIn("request_id", response)
            self.assertIn("log_entries", response)
            self.assertGreater(response["size_bytes"], 0)


if __name__ == "__main__":
    unittest.main()
