import importlib
import unittest
from unittest import mock


class ServerTestCase(unittest.TestCase):
    def setUp(self):
        self.server = importlib.import_module("server")

    def test_create_app_provides_configured_fastmcp(self):
        app = self.server.create_app()
        self.assertEqual(app.name, "Markdown Docs MCP Server")

        metadata = self.server.SERVER_METADATA
        self.assertEqual(metadata["identifier"], "markdown-docs-mcp")
        self.assertTrue(metadata["protocol_version"].startswith("1."))
        self.assertTrue(metadata["description"].startswith("Markdown Docs MCP Server"))

    def test_build_handshake_payload_uses_metadata(self):
        app = self.server.create_app()
        manual_tools = [
            {
                "tool_id": "operations-guide",
                "title": "Operations Guide",
                "summary": "Markdown Docs MCP Serverの運用手順とツール追加時の確認事項をまとめたガイド",
                "path": "docs/operations-guide.md",
                "tags": ["operations", "guide", "manual"],
            }
        ]
        app.metadata["manual_tools"] = manual_tools
        app.metadata["manual_prompts"] = []

        payload = self.server.build_handshake_payload(app)

        self.assertEqual(payload["name"], self.server.SERVER_METADATA["server_name"])
        self.assertEqual(payload["protocol"], self.server.SERVER_METADATA["protocol_version"])
        self.assertEqual(payload["identifier"], self.server.SERVER_METADATA["identifier"])
        self.assertEqual(payload["tools"], manual_tools)
        self.assertEqual(payload["prompts"], [])

    def test_stdio_runner_invokes_fastmcp_run(self):
        app = self.server.create_app()
        with mock.patch.object(app, "run") as mocked_run:
            self.server.run_stdio(app)
        mocked_run.assert_called_once()


if __name__ == "__main__":
    unittest.main()
