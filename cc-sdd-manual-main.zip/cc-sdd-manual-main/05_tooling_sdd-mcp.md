# sdd-mcp ガイド（MCPサーバ）

`sdd-mcp` は、Spec駆動開発（Kiroスタイル）を RooCode や Cursor などの MCP 対応 IDE から直接実行できるようにする Model Context Protocol (MCP) サーバである。本章では GitHub README と運用ガイド（旧 13 章）の内容を統合し、インストールからワークフロー、開発・トラブル対応までを一括でまとめる。

## 1. 概要

- `/prompts:kiro-*` コマンド相当の操作を MCP ツールとして提供
- ステアリング、仕様生成、設計レビュー、タスク分解、実装支援、フィードバックまでをカバー
- Bun または Node.js 上で動作（Bun 推奨）
- テンプレートエンジンにより frontmatter 付きコマンドテンプレートを展開

## 2. 前提条件

| 項目 | 要件/推奨 |
| --- | --- |
| ランタイム | Bun >= 1.0.0（推奨）または Node.js >= 20 |
| OS | Linux / macOS / WSL2（Windows ネイティブは非対応） |

## 3. インストールと起動

### 3.1 もっとも簡単な起動（推奨）

```bash
# Bun 推奨
bunx sdd-mcp@latest

# Node / npx
npx sdd-mcp@latest
```

### 3.2 ローカル導入（開発・固定バージョン）

```bash
# Bun
bun install sdd-mcp

# npm
npm install sdd-mcp
```

### 3.3 コマンドラインオプション

```bash
# ヘルプ
bunx sdd-mcp@latest --help

# バージョン表示
bunx sdd-mcp@latest --version

# デバッグログを有効化
bunx sdd-mcp@latest --debug
```

## 4. MCP クライアントからの利用

1. ターミナルで MCP サーバを起動し続ける:
   ```bash
   bunx sdd-mcp@latest
   # または npx sdd-mcp@latest
   ```

2. RooCode の場合は *Settings → MCP Servers → Add* で以下を登録:
   ```json
   {
     "type": "sdd-mcp",
     "command": "bunx",
     "args": ["sdd-mcp@latest"],
     "env": {
       "NODE_ENV": "production"
     }
   }
   ```

3. MCP パネルやコマンドパレットから `spec-init` などのツールを呼び出すと、成果物が `.kiro/` 配下に生成される。レビュー・承認は人間が行い、`spec.json` のフラグ整合も忘れずに。

Claude Code や Cursor など他の MCP 対応クライアントも、同等の設定で利用できる。クライアント固有の設定方法は各公式ドキュメントを参照。

## 5. 提供ツール一覧

| 区分 | MCP ツール | 説明 |
| --- | --- | --- |
| ステアリング | `steering` | `product.md` / `tech.md` / `structure.md` の生成・更新 |
|  | `steering-custom` | カスタムステアリング文書の生成 |
| 仕様管理 | `spec-init` | 仕様初期化（`spec.json` を含む） |
|  | `spec-requirements` | 要件定義（EARS 形式） |
|  | `spec-design` | 設計書生成 |
|  | `spec-tasks` | タスク分解 |
|  | `spec-impl` | TDD 支援（タスク番号指定可） |
|  | `spec-status` | フェーズ・承認状況の取得 |
|  | `spec-feedback` | フィードバックのレポート生成・適用 |
| 検証 | `validate-design` | 設計レビューの対話チェック |
|  | `validate-gap` | 要件と実装のギャップ分析 |

各ツールはテンプレート（`commands/*.md`）を展開し、`template_id` や `allowed_tools` 等のメタ情報を返す。詳細は GitHub リポジトリおよび`.kiro/` 配下の出力を参照。

## 🧭 6. 典型ワークフロー（8 ステップ）

> 以降の「Use MCP tool: ...」は MCP クライアントからの呼び出し例です。

### 1. 初回（任意）: ステアリング作成
```
Use MCP tool: steering
```

### 2. 仕様初期化
```
Use MCP tool: spec-init "ユーザ認証をJWTとリフレッシュトークン回転で実装"
```

### 3. 要件定義の生成
```
Use MCP tool: spec-requirements user-authentication
```

### 4. 設計の生成
```
Use MCP tool: spec-design user-authentication
```

### 5. タスク分解の生成
```
Use MCP tool: spec-tasks user-authentication
```

### 6. TDDで実装
```
Use MCP tool: spec-impl user-authentication
# 特定タスクのみ
Use MCP tool: spec-impl user-authentication 1,2,3
```

### 7. ステータス確認
```
Use MCP tool: spec-status user-authentication
```

### 8. フィードバックの収集と適用（任意のタイミング）
```
# レポート生成
Use MCP tool: spec-feedback {"feature_name":"user-authentication","mode":"report"}

# レポート適用
Use MCP tool: spec-feedback {"feature_name":"user-authentication","mode":"apply","report_path":"feedback/20251013-120000-user-authentication-feedback.json"}
```

> ヒント: 各フェーズは人間の承認を前提に段階的に進めます。`-y` オプションに相当する自動承認を行うかはチーム運用ポリシーに従ってください。

フェーズごとに人間の承認が必須（`-y` はチームポリシーに従って使用）。`spec-status` で進捗を可視化し、`validate-design` `validate-gap` でレビューを補完する。

## 7. トラブルシューティング

- 起動しない: Bun / Node のバージョンを確認し、`--debug` でログ取得
- MCP クライアントからツールが見つからない: `command` / `args` / PATH を確認
- CLI と出力が異なる: テンプレートやステアリングの同期状態を確認
- 進捗フラグ不一致: `spec-status` で現状を確認し、`spec.json` を手動調整

## 8. グローバルエージェント向けガイダンス

- 「spec」「impl」「sdd」関連リクエストは可能な限り MCP ツールにマップ
- `spec-init → spec-requirements → spec-design → spec-tasks → spec-impl` の順序を明示
- ステアリングの更新 (`steering` / `steering-custom`) と検証ツール (`validate-*`) を定期的に案内
- `Use MCP tool: spec-impl {"feature_name":"<feature>"}` などコピーしやすい例を提示
- 各フェーズ完了後は `.kiro/` 配下をレビューし、人間承認を必須化

## 9. 参考・謝辞

- GitHub: <https://github.com/yuki-yano/sdd-mcp>
- 本家 cc-sdd に基づく MCP サーバ（MIT ライセンス）
---

MCP を活用することで IDE から Spec の生成・更新・検証をシームレスに進められる。

