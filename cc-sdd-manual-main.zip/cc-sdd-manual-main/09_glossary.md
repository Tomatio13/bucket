<h1 align="center">📚 用語集（Glossary）</h1>

- **Kiro**: Spec 駆動の IDE/設計思想。ステアリングと仕様を中核に、AI と人の協調開発を支える
- **cc-sdd**: Kiro ワークフローを既存 IDE/CLI に配布・同期する CLI ツール
- **ステアリング（Steering）**: `.kiro/steering/` 配下のプロジェクト共通知識（product/tech/structure ほか）
- **ステアリング・カスタム**: ドメイン特化の追加指針（security/testing 等）
- **プロジェクトメモリ**: エージェントが参照する長期知識（ステアリング、`AGENTS.md` 等）
- **仕様（Spec）**: 機能単位の要求/設計/タスクをまとめたセット（`.kiro/specs/<feature>/`）
- **EARS**: 要件記述の軽量規則（When/While/Where/If + shall）
- **`spec.json`**: 仕様の状態管理。`phase`/`approvals`/`ready_for_implementation` 等を保持
- **承認（Approvals）**: 各フェーズの生成と承認の状態。GO/NO-GO 判断の根拠
- **トレーサビリティ**: 要件→設計→タスクの対応関係を明示すること
- **Codex**: 複数エージェントを統合運用する CLI。`~/.codex/prompts` のプロンプトを使用
- **MCP**: 外部ツール連携のプロトコル。ドキュメント/データ/API を IDE に接続


