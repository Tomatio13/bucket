# はじめての Spec駆動開発（5分クイックスタート）

## 目的

cc-sdd と Codex CLI を使って、最小の Spec を作成し「要件→設計→タスク→実装→検証」の流れを一周する。章01で示した原則を実務に移すための導入手順である。

## 前提条件

| 項目 | 推奨/要件 |
| --- | --- |
| Node.js / Bun | Node.js v18+ または Bun 1.0+（Bun推奨） |
| MCP クライアント | RooCode（または Claude Code など MCP 対応 IDE） |
| OS | Linux / macOS / WSL2 |
| ネットワーク | 企業プロキシ環境では `HTTP(S)_PROXY` 設定 |

> Windows ネイティブ環境では WSL2 を推奨

## ステップ1: RooCode + sdd-mcp を接続

1. 別ターミナルで MCP サーバを起動（プロセスは接続中保持）:

   ```bash
   bunx sdd-mcp@latest
   # または
   npx sdd-mcp@latest
   ```

2. RooCode を開き、*Settings → MCP Servers → Add* で以下を登録:

   ```json
   {
     "type": "sdd-mcp",
     "command": "npx",
     "args": ["sdd-mcp@latest"],
     "env": {
       "NODE_ENV": "production"
     }
   }
   ```

3. MCP パネルに `steering` や `spec-init` 等が表示されれば接続完了。

## ステップ2: ステアリング整備（MCP）

```
Use MCP tool: steering
Use MCP tool: steering-custom
```

`.kiro/steering/product.md` `tech.md` `structure.md` などが生成され、以後の仕様判断の基準になる。カスタムステアリングでドメイン固有のポリシーも追加する。

## ステップ3: 仕様初期化（MCP）

```
Use MCP tool: spec-init "hello-feature の概要"
```

- 対象機能の説明を入力すると、`.kiro/specs/hello-feature/spec.json` が作成される。
- `phase` や `approvals` はワークフローの進行状態を保持する。

## ステップ4: 要件定義と設計/タスク分解（MCP）

```
Use MCP tool: spec-requirements hello-feature
Use MCP tool: spec-design hello-feature
Use MCP tool: spec-tasks hello-feature
```

- `requirements.md` には EARS 形式で要件が出力される。
- 設計書とタスク一覧はテンプレートに沿って生成される。
- 再生成時は `spec.json` の承認状態が変化する場合があるため、チームレビューで整合を取る。

## ステップ5: 実装と検証（MCP）

```
Use MCP tool: spec-impl hello-feature 1
Use MCP tool: spec-status hello-feature
Use MCP tool: spec-feedback {"feature_name":"hello-feature","mode":"report"}
```

- `spec-impl` は TDD 方針で実装をガイドし、タスク番号指定で部分実行もできる。
- `spec-status` で承認状況を確認し、必要に応じて `spec-feedback` の `mode:"apply"` でレポート内容を反映する。
- 設計レビューやギャップ分析が必要な場合は `validate-design` / `validate-gap` を利用する。

`spec.json` の承認フラグと readiness を確認し、GO/NO-GO 判断を行う。完了後は PR に成果物をコミットしレビューを受ける。
