<h1 align="center">📖 cc-sdd プロンプト総覧</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>

## 🧭 0. 目的
`kiro/` ディレクトリ配下に格納されたプロンプト資産とテンプレート群を把握し、`cc-sdd` が提供する Spec-Driven Development ワークフローを自分たちのプロジェクトへ適用・拡張するための手引きです。公式リポジトリが提供する 11 種類の `/prompts:kiro-*` コマンドとテンプレートの関係性を整理し、カスタマイズ時の観点もまとめます[^cc-sdd].

[^cc-sdd]: [cc-sdd 公式リポジトリ (gotalab/cc-sdd)](https://github.com/gotalab/cc-sdd)

---

## 🗂️ 1. `kiro/` ディレクトリ構成
ルート直下の `kiro/` は、`npx cc-sdd` 実行後に各エージェントへ配布されるプロンプトとテンプレートのアーカイブです。当マニュアルでは Linux / Codex 環境で生成される日本語版を収録しています。

```
kiro/
 ├─ prompts/                  # Slash コマンド本体（日本語訳）
 │   ├─ kiro-spec-design_jp.md
 │   ├─ kiro-spec-impl_jp.md
 │   ├─ ...
 │   └─ kiro-validate-impl_jp.md
 └─ settings/
     ├─ rules/                # ワークフロー運用ルール
     │   ├─ design-discovery-full_jp.md
     │   ├─ ...
     │   └─ tasks-generation_jp.md
     └─ templates/
         ├─ specs/            # 要件・設計・タスク用テンプレート
         │   ├─ design.md / design_jp.md
         │   ├─ init.json
         │   ├─ requirements_jp.md
         │   └─ tasks_jp.md
         ├─ steering/         # コア・ステアリング（product / tech / structure）
         └─ steering-custom/  # ドメイン別追加ステアリング
```

### 🧾 1.1 `prompts/`
- `/prompts:kiro-steering` 〜 `/prompts:kiro-validate-impl` の 11 コマンドを網羅し、それぞれが以下のメタ情報を保持します。
  - `<meta>`: コマンドの概要・引数ヒント。
  - `<background_information>`: 目的や成功条件。
  - `<instructions>`: 実行ステップ、フェーズ切り替え条件、注意点。
  - `<tools_guidance>` / `<output>`: 内部で使用する MCP ツールや出力形式。

### 📐 1.2 `settings/rules/`
- ステアリングやタスク生成時に守る原則を文章化した参照ドキュメントです。
- 例: `tasks-generation_jp.md` は「自然言語で成果ベースのタスクを書く」「要件トレーサビリティを付与する」などの指針を明文化しています。

### 🧩 1.3 `settings/templates/`
- **specs**: `init.json` と `requirements-init_jp.md` は `/prompts:kiro-spec-init` の初期化フェーズで利用され、`requirements_jp.md` / `design_jp.md` / `tasks_jp.md` は Requirements → Design → Tasks 各フェーズの出力フォーマットを規定します。
- **steering**: `product_jp.md` / `tech_jp.md` / `structure_jp.md` が最小構成。初回ブートストラップ時に生成され、以後は差分を追記していきます。
- **steering-custom**: API 標準、認証、セキュリティなど特定領域の指針テンプレート。必要なものだけを `.kiro/steering/` にコピーして編集します。

---

## 🧮 2. プロンプト一覧と役割
`cc-sdd` のワークフローは「ステアリング → 要件 → 設計 → タスク → 実装 → 検証」を段階的に進める設計です[^cc-sdd]. CLI 上では下記 11 コマンドとして呼び出します。

| フェーズ | プロンプト | 主な出力/操作対象 |
| --- | --- | --- |
| ステアリング整備 | `/prompts:kiro-steering` | `.kiro/steering/product.md` ほかコア文書の作成・同期 |
| ステアリング拡張 | `/prompts:kiro-steering-custom` | カスタム指針（セキュリティ等）の追加 |
| 仕様初期化 | `/prompts:kiro-spec-init` | `.kiro/specs/<feature>/spec.json` / `requirements.md` (初期) |
| 要件定義 | `/prompts:kiro-spec-requirements` | `requirements.md` を EARS 形式で更新 |
| ギャップ分析 | `/prompts:kiro-validate-gap` | 既存コードと要件の差分レポート |
| 設計 | `/prompts:kiro-spec-design` | `design.md` の生成（Mermaid 図や設計判断を含む） |
| 設計レビュー | `/prompts:kiro-validate-design` | 設計書レビュー観点と GO/NO-GO 判定 |
| タスク分解 | `/prompts:kiro-spec-tasks` | `tasks.md`（チェックリスト形式の実装計画） |
| 実装支援 | `/prompts:kiro-spec-impl` | 指定タスクの実装フロー提案 (TDD 推奨) |
| 実装レビュー | `/prompts:kiro-validate-impl` | 実装が要件・設計・タスクに準拠するか評価 |
| 進捗確認 | `/prompts:kiro-spec-status` | `spec.json` をもとにフェーズ/進捗レポート |

> **TIP**: 各プロンプトの再実行はフェーズ進行後のキャッチアップや再生成にも利用できます。`spec.json` の `approvals` フラグは承認ワークフローの状態を保持するため、承認後の再生成時には値を確認してください。

---

## 🛠️ 3. カスタマイズ手順と観点

- **ステアリング文書の調整**
  - `.kiro/steering/*.md` を直接編集し、プロジェクト固有の設計原則や命名規則を追記します。`/prompts:kiro-steering` はユーザー編集部分を尊重し、追記ベースで更新します。
- **テンプレートの改変**
  - `kiro/settings/templates/specs/` の Markdown を編集すると、以後の生成ドキュメントがチーム標準の章立てや表現に合わせて書き出されます。
  - `design_jp.md` では Mermaid 図や設計判断テンプレートを自社流に調整可能です。
- **ドメイン特化ルールの追加**
  - `steering-custom` 配下テンプレートをコピーし、`.kiro/steering/` に配置すると `/prompts:kiro-steering-custom` 実行時に取り込めます。API 標準・認証・セキュリティなど領域別ガイドラインを整備する運用が推奨されます。
- **運用ルールの参照・上書き**
  - `settings/rules/` 群はプロンプト出力には直接反映されませんが、エージェントが遵守すべき原則を文章化したリファレンスとして機能します。必要に応じて自チームのレビュー観点を追加・翻訳してください。

---

## 📑 4. 主なテンプレートの要約

### 🧾 4.1 `requirements_jp.md`
- EARS 形式をベースに、要件ごとに「目的」「受け入れ基準（イベント / 条件 / 継続 / 文脈）」を列挙します。
- 要件の粒度は「要件1」「要件2」のように機能領域ごとに分け、各条件を具体化することが前提です。

### 🏗️ 4.2 `design_jp.md`
- 概要／ゴール／非ゴール／アーキテクチャ／技術選定／コンポーネント／データモデル／エラー処理／テスト戦略など、設計判断を体系的に記述する構造です。
- Mermaid 図の挿入やトレーサビリティ表など、必要に応じて省略可のセクションが明示されています。

### ✅ 4.3 `tasks_jp.md`
- チェックボックス付きの階層（主要タスク → サブタスク）で実装計画を整理します。
- 各タスクに `_要件：1.1, 2.2` のようなトレーサビリティを必須化し、Requirements → Tasks の対応を管理します。

### 🧭 4.4 `steering/*.md`
- `product_jp.md`: 製品のコア価値・主要機能・ユースケースを3〜5項目で整理。
- `tech_jp.md`: 技術選定方針、使用言語、ライブラリ、CI/CD や品質戦略などをまとめる想定。
- `structure_jp.md`: ディレクトリ構成や命名規約など、ソースコードの構造パターンを記述します。

### 🛡️ 4.5 `steering-custom/*.md`
- API 標準、デプロイメント、セキュリティ、テストなどの共通原則をテンプレート化。必要なドキュメントだけを `.kiro/steering/` に採用し、チーム独自のポリシーを加筆して利用します。

---

## 💡 5. 利用上のヒント

- `/prompts:kiro-steering` を初回に実行し、`.kiro/steering/` を最新化してから仕様フェーズへ進むと、要件・設計生成時にプロジェクトメモリが参照されます。
- 仕様フェーズは Requirements → Design → Tasks の順で承認し、`spec.json` の `phase` / `approvals` を確認してください。承認済みでなければ `/prompts:kiro-spec-impl` が実行できない場合があります。
- 多言語対応 (`--lang ja` など) や各エージェント向けテンプレートは公式リポジトリで随時更新されるため、ローカルテンプレートをカスタマイズする際はバージョン差分に注意してください[^cc-sdd].

---

## 📝 6. まとめ
`kiro/` ディレクトリは cc-sdd の心臓部であり、プロンプト（プロセス定義）とテンプレート（成果物フォーマット）、ステアリング（組織知）を結び付ける役割を担います。プロジェクトの文化・品質基準に合わせてテンプレートやルールをメンテナンスしながら、11 コマンドを段階的に活用することで Spec-Driven Development を再現できます。


