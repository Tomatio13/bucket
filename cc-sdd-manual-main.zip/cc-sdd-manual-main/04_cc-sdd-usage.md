<h1 align="center">🚀 cc-sdd 使用方法</h1>


<p align="center">
  <img src="https://img.shields.io/badge/Stack-AI--DLC-blue.svg" alt="AI-DLC Stack" />
  <img src="https://img.shields.io/badge/Spec%20Driven-Kiro%20Style-green.svg" alt="Kiro Style" />
</p>


> ⚠️ **注意事項** 2.0.0alphaのため、正式版では手順が異なる可能性があります。

## 📋 cc-sddのプロンプト
cc-sddのプロンプトは以下の通りです。これらのプロンプトを組み合わせながら開発を進めます。

| 開発工程 | プロンプト | 概要説明 |
| --- | --- | --- |
| ステアリング運用 | /prompts:kiro-steering | プロジェクトの共通ルールや知識を.kiro/steering/に整理して保つ。 |
| カスタム知識整理 | /prompts:kiro-steering-custom | 特定ドメイン向けの追加ルールやガイドを作成し、知識ベースを広げる。 |
| 企画・初期化 | /prompts:kiro-spec-init | 新しいプロジェクト案から仕様フォルダを作り、スタート地点を準備する。 |
| 要件定義 | /prompts:kiro-spec-requirements | プロジェクトの要求をEARS形式で整理し、何を作るかを明確にする。 |
| ギャップ分析 | /prompts:kiro-validate-gap | 既存コードを調べ、要求との差を洗い出して準備不足を見つける。 |
| 設計 | /prompts:kiro-spec-design | 要件に沿った技術設計書を作り、どう作るかを決める。 |
| 設計レビュー | /prompts:kiro-validate-design | 設計書をチェックし、問題点と良い点をまとめてGO/NO-GO判断を出す。 |
| タスク分解 | /prompts:kiro-spec-tasks | 設計を小さな実装タスクに分け、やることリストを作る。 |
| 実装 | /prompts:kiro-spec-impl | TDDでタスクを実装し、テストを先に書きながらコードを仕上げる。 |
| 実装検証 | /prompts:kiro-validate-impl | 実装が要件・設計・タスクに沿っているか、テストも含めて確認する。 |
| 進捗レポート | /prompts:kiro-spec-status | 指定した仕様の状態と進行度をまとめ、次の動きや課題を可視化する。 |


## 🧭 開発フロー

### 🧠 1. プロジェクトメモリとコンテキスト作成(既存プロジェクト：必須)
プロジェクト共通のナレッジを作成する場合は、以下のコマンドを実行します。
```bash
/prompts:kiro-steering # プロジェクトメモリとコンテキストの作成
/prompts:kiro-steering-custom # 専用ドメイン知識の追加
```

このコマンドを実行すると、kiroディレクトリに以下のファイルが生成されます。
プロジェクトに要件/機能を追加した時も再実行して、最新化するようにしてください。

```bash
.kiro/steering
├── product.md     # プロジェクト概要
├── structure.md   # プロジェクト構造
└── tech.md        # 技術スタック
```

#### 🧭 ステアリングとは

> ステアリングは、`.kiro/steering/` に格納するプロジェクト共通の航海図（プロダクトの方向性・技術選定・構造方針など）を整備する活動です。開発メンバーとAIが同じ指針を参照できる状態を作ります。そのうえで、仕様駆動開発の各フェーズ（要件定義→設計→タスク分解→実装）を進める際に、このステアリング文書を基準として判断のぶれを抑え、レビューの質を保つことができます。
> プロジェクト固有のルールを追加したい場合、編集して下さい。
英語で生成されるので、適宜に日本語に変換してください。

#### ✅ GO/NO-GO（ステアリング）
- `product.md`/`tech.md`/`structure.md` が最低限埋まっている
- チーム規約/命名/テック選定の骨子が明記されている

### 📝 2. 要件定義
#### 🚀 2-1. プロジェクトの初期化
要件定義を行います。

```bash
/prompts:kiro-spec-init "プロジェクト概要"
```

以下の例では、`Markdownを読み込んで返却するMCPサーバ`という要件について、要件定義を行います。

例:
```bash
/prompts:kiro-spec-init Markdownを読み込んで返却するMCPサーバ

<省略>

## Project Summary
Markdownを読み込んで返却するMCPサーバの初期仕様セットアップを完了しました。

## Created Files
- .kiro/specs/markdown-mcp-reader/spec.json
- .kiro/specs/markdown-mcp-reader/requirements.md

## Next Step
/prompts:kiro-spec-requirements markdown-mcp-reader

## Notes
この段階では仕様初期化のみを行い、要件・設計・タスク生成は意図的に保留しています。プロジェクトの3段階承認ワークフローに合わせ、次フェーズとなる要件生成を明示的に開始
する必要があります。テンプレートへの入力が済んだため、上記コマンドから要件定義フェーズへ安全に進めます。

```
上記のようにコマンドの最後に、次にどのコマンドを実行すればよいのか、何をすればよいのかが記載されています。

このコマンドを実行すると、kiroディレクトリに以下のファイルが生成されます。

```bash
.kiro/specs
└── markdown-mcp-reader
    ├── requirements.md # 要件定義書
    └── spec.json # メタデータ(ステータス管理などが記述されています)
```

#### 📑 2-2. 要件の定義

次に、AIに要件定義を作成させます。
```bash
/prompts:kiro-spec-requirements "プロジェクト名"
```

2-1の例では、以下のようになります。

例:
```bash
/prompts:kiro-spec-requirements markdown-mcp-reader

<省略>

## 要件サマリー
- Markdown入力受理とレスポンス配信: リクエスト形式の多様性に対応し、解析結果を一貫したレスポンスで返却する基盤要求を定義しました。
- Markdown解析と構造化出力: 文書構造・コードブロック・リンク・フロントマターを機械可読に提供する要件を整備しました。
- バリデーションとエラーハンドリング: サイズ超過や構文不一致、内部障害時の応答方針を明示し、利用者影響を抑制する仕組みを規定しました。

## ドキュメント更新状況
- 要件定義書とメタデータをrequirements-generatedフェーズへ更新済み

.kiro/specs/markdown-mcp-reader/requirements.md
.kiro/specs/markdown-mcp-reader/spec.json

- .kiro/steering/ディレクトリが存在しないため、プロジェクト全体の方針は未参照です。必要に応じて整備をご検討ください。

## 次のアクション
- 生成した要件が期待機能を網羅しているか確認し、修正点があればフィードバックしてください。
- 問題なければ /prompts:kiro-spec-design markdown-mcp-reader -y に進む前に要件承認を表明してください（任意で /prompts:kiro-validate-gap markdown-mcp-reader による
ギャップ分析も利用可能）

```

`requirements.md`に要件が定義されているので、`requirements.md`をレビューしてください。
要件が不足していたり、過剰な場合、プロンプトで修正を依頼してください。

> TIPS: AIが未学習のOSSや言語を使用している場合、要件が不足していることがあります。その場合、参照用のドキュメントを別に用意した上で、プロンプトで修正を依頼してください。

例:
```bash 
要件のxxxをyyyに修正して下さい。
```

#### 📌 重要: 要件の確認とステアリングの再実行
要件を固めたら、ステアリング(/prompts:kiro-steering)を再実行して最新化してください。
特に新規プロジェクトの場合、ステアリングプロンプトで生成される`tech.md`をレビューして、
実行環境や利用する言語などを確認してください。

#### ✅ GO/NO-GO（要件）
- すべて EARS で 1 文 1 挙動
- 曖昧語なし、観測可能性あり
- 用語がステアリングと整合

### 🏗️ 3. 設計

要件が承認されたら、次のコマンドで設計を行います。

```bash
/prompts:kiro-spec-design "プロジェクト名" -y
```

2章の例だと以下のようになります。

例：

```bash
/prompts:kiro-spec-design markdown-mcp-reader -y

-ステータス: .kiro/specs/markdown-mcp-reader/design.md を生成し、spec.json を design-generated フェーズ（requirements承認済み）へ更新しました。
- ディスカバリ種別: フルディスカバリ（MCP公式アーキテクチャ指針とMarkdown解析手法、セキュリティ要件を調査）。
- 主要知見:
    - MCPサーバはHTTP/SSEハンドラとイベント契約を揃えることでクライアント互換性を維持すべきと判明し、公式SDK採用を設計に組み込みました。
    - unified／remarkパイプラインが拡張MarkdownやAST型定義を幅広くサポートし、要求される構造化レスポンスに最適と確認しました。
    - OAuthリソースサーバ相当としてエラートレーシングとレート制御を備えることで外部連携時の認可境界を守れる点を取り込んでいます。
- 次のアクション: 設計書をレビューし、問題なければ /prompts:kiro-validate-design markdown-mcp-reader または /prompts:kiro-spec-design markdown-mcp-reader の再実行で
修正、承認後に /prompts:kiro-spec-tasks markdown-mcp-reader -y へ進んでください（ステアリング未整備のため、必要なら .kiro/steering/ 更新も併せてご検討ください）。
```

このコマンドを実行すると、kiroディレクトリに以下のファイルが生成されます。

```bash
.kiro/specs
└── markdown-mcp-reader
    ├── design.md # 設計書
    ├── requirements.md # 要件定義書
    └── spec.json
```

`design.md`に設計が定義されているので、`design.md`をレビューしてください。
必要に応じて、プロンプトで設計変更を依頼してください。

#### ✅ GO/NO-GO（設計）
- 要件→設計のトレーサビリティ表が埋まっている
- 非機能（エラー処理/性能/セキュリティ/テスト方針）を明記
- Mermaid 図や主要判断の根拠が記載

### 🧱 4. タスク分割
設計を承認したら、次のコマンドでタスク分割を行います。

```bash
/prompts:kiro-spec-tasks "プロジェクト名" -y
```

2章の例だと以下のようになります。

例：
```bash
/prompts:kiro-spec-tasks markdown-mcp-reader -y

<省略>
- ステータス: タスク計画を生成し、spec.json を tasks-generated フェーズへ更新しました。
.kiro/specs/markdown-mcp-reader/tasks.md

- タスク概要: メジャータスク4件・サブタスク13件で構成し、要件1.x〜3.xの12要素すべてをカバー。各サブタスクは1〜3時間規模を想定しています。
- 品質チェック:
    - ✅ 全要件とのトレーサビリティを確認済み
    - ✅ タスク依存関係を順序どおり検証済み
    - ✅ 単体・統合・性能試験タスクを含有
- 次のアクション: 計画内容をレビューし問題なければ承認のうえ、/prompts:kiro-spec-impl markdown-mcp-reader 1.1 などで実装フェーズへ進んでください。
※ .kiro/steering/ ディレクトリは未整備のため、必要に応じてプロジェクト方針をご用意ください。
```

`tasks.md`にタスクが定義されているので、`tasks.md`をレビューしてください。

```bash
.kiro/specs
└── markdown-mcp-reader
    ├── design.md
    ├── requirements.md
    ├── spec.json
    └── tasks.md
```

必要に応じて、プロンプトでタスク変更を依頼してください。

例:
```bash
タスクのxxxをyyyに修正して下さい。
```
**注意事項**： 2.0.0alphaのみの可能性があますが、
spec.jsonのphaseがtasks:approvedにfalseになっている場合、
次の実装に進めないため、手動でtrueにしてください。

spec.json:
```json
{
  "feature_name": "markdown-mcp-reader",
  "created_at": "2025-10-11T02:56:29Z",
  "updated_at": "2025-10-11T04:09:24Z",
  "language": "ja",
  "phase": "tasks-generated",
  "approvals": {
    "requirements": {
      "generated": true,
      "approved": true
    },
    "design": {
      "generated": true,
      "approved": true
    },
    "tasks": {
      "generated": true,
      "approved": true
    }
  },
  "ready_for_implementation": false
}
```

#### ✅ GO/NO-GO（タスク）
- 主要タスクとサブタスクの粒度が 1〜3h 目安
- 各サブタスクに `_要件: x.x` が付与
- 依存関係が明示

### 🔧 5. 実装
タスク分割が問題なければ、次のコマンドで実装を行います。

```bash
/prompts:kiro-spec-impl "プロジェクト名" # 全タスク実行の場合
/prompts:kiro-spec-impl "プロジェクト名" 1.1 # 1.1タスクのみ実行の場合
/prompts:kiro-spec-impl "プロジェクト名" 1,2,3 # 1,2,3のタスクのみ実行の場合
```

2章の例だと以下のようになります。

例：
```bash
/prompts:kiro-spec-impl markdown-mcp-reader
```

### 🔍 6. 検証
実装が完了後に、次のコマンドで検証を行います。

```bash
/prompts:kiro-validate-impl "プロジェクト名"
```

2章の例だと以下のようになります。

例：
```bash
/prompts:kiro-validate-impl markdown-mcp-reader
```

### 📊 7. 作業の状況把握/再開
作業の状況把握や、再開したい場合に次のコマンドを実行します。

```bash
/prompts:kiro-spec-status "プロジェクト名"
```

2章の例だと以下のようになります。

例：
```bash
/prompts:kiro-spec-status markdown-mcp-reader
<省略>
- 🏷️ 機能名: markdown-mcp-reader
- 🔄 現在フェーズ: tasks-generated（タスク策定完了・実装待ち）
- 🕒 最終更新: 2025-10-11 13:09 JST（2025-10-11 04:09 UTC）
- ✅ 実装準備完了フラグ: true

Phase Status
- ✅ 要件 100%（承認済み）: 3件の要件と12件の受入基準を定義済み
- ✅ 設計 100%（承認済み）: アーキテクチャ節・主要コンポーネント解説・Mermaid図を含む詳細設計を掲載
- ⏳ タスク 100%（計画承認済みだが実行0%）: 実装タスクは列挙されているものの着手前

Task Progress
- ⏳ 0 / 17 完了（0%）: 17件すべて未完了。実装タスク群1〜4.3が全て- [ ]のまま

Next Action
- /prompts:kiro-spec-impl markdown-mcp-reader を実行し、実装フェーズへ移行

Issues
- ✅ ブロッカーは確認されていません（実装未着手が唯一の進捗ギャップ）

```

### 📎 `spec.json` の要点（読み方）

- `phase`: 現在のフェーズ（例: `tasks-generated`）
- `approvals`: 各フェーズの `generated/approved` 状態
- `ready_for_implementation`: 実装に進めるかの最終フラグ

> 再生成で `approvals` が変化することがあります。実装前に必ず確認し、必要なら PR レビューで明示的に合意してください。