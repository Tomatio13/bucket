"""Allow running the CLI as: python -m ddaword_cli"""

from .main import cli_main

if __name__ == "__main__":
    cli_main()
