# 必要なライブラリをインポート
import asyncio
import os
from dotenv import load_dotenv
from strands import Agent, tool
from strands_tools import shell,current_time,calculator
from strands.models.openai import OpenAIModel
import datetime 

# .envファイルから環境変数を読み込む
load_dotenv()

# 文字カウント関数をツールとして定義
@tool
def counter(word: str, letter: str):
    return word.lower().count(letter.lower())

def showtime(word :str ):
    print()
    print( datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S.%f')[:-3] + " : " + word + "   ")


load_dotenv()
api_key  = os.environ.get("API_KEY")
base_url = os.environ.get("BASE_URL")
model_id = os.environ.get("MODEL_ID")


model = OpenAIModel(
        client_args={"api_key": api_key, "base_url": base_url},
        model_id=model_id
        )

# エージェントを作成
agent = Agent(
    model=model,
    tools=[counter,shell,current_time]
)

# エージェントを呼び出し
#agent("straberryの中にrはいくつある？")
#showtime("START")
#agent("このディレクトリのファイル一覧を表示して")
#showtime("END")

#showtime("START")
#agent("今の時間を教えて")
#showtime("END")

#showtime("START")
#agent("香港の今の時間を教えて")
#showtime("END")


agent2 = Agent(
	model=model,
    tools=[calculator,current_time],
    callback_handler=None
)

# Async function that iterators over streamed agent events
async def process_streaming_response(prompt: str):
    agent_stream = agent2.stream_async(prompt)
    async for event in agent_stream:
        if "result" in event:
            result = event.get("result")
            print(result)

# Run the agent
showtime("START")
asyncio.run(process_streaming_response("2+2"))
showtime("END")

showtime("START")
asyncio.run(process_streaming_response("今何時?"))
showtime("END")



