from strands import Agent, tool
import asyncio
from dotenv import load_dotenv
from strands.models.ollama import OllamaModel

import os
# .envファイルから環境変数を読み込む
load_dotenv()

# エージェント間通信を可能にするツールを定義
@tool
def ask_agent(agent_name: str, message: str) -> str:
    """
    別のエージェントにメッセージを送信し、応答を取得します。
    
    Args:
        agent_name: メッセージを送信するエージェントの名前
        message: 送信するメッセージ
    
    Returns:
        str: エージェントからの応答
    """
    if agent_name in agent_registry:
        return agent_registry[agent_name](message).message
    else:
        return f"エラー: エージェント '{agent_name}' は存在しません。"

def setup_environment():
    load_dotenv()
    ollama_host = os.getenv("STRANDS_OLLAMA_HOST")
    ollama_model = os.getenv('STRANDS_OLLAMA_MODEL')
    ollama_host_url = f"http://{ollama_host}:11434"
    print(f"Using this server: {ollama_host_url} with this model: {ollama_model}")
    return ollama_host_url, ollama_model

def create_ollama_model(host_url, model_name):
    ollama_model = OllamaModel(
        host=host_url,
        model_id=model_name
    )
    return ollama_model


# エージェントレジストリを作成
agent_registry = {}

# モデルの作成
ollama_host, ollama_model = setup_environment()
ollama_model = create_ollama_model(ollama_host, ollama_model)

# 専門エージェントを作成
math_agent = Agent(
    #model="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
    model=ollama_model,
    tools=[],  # このエージェントは単純な計算に特化しています
    system_prompt="あなたは数学の専門家です。数学の問題や計算に対して、できるだけ簡潔に回答してください。"
)
agent_registry["math_agent"] = math_agent

history_agent = Agent(
    #model="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
    model=ollama_model,
    tools=[],  # このエージェントは歴史に特化しています
    system_prompt="あなたは歴史の専門家です。歴史に関する質問に簡潔に回答してください。"
)
agent_registry["history_agent"] = history_agent

# マスターエージェント（他のエージェントと通信できる）
master_agent = Agent(
    #model="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
    model=ollama_model,
    tools=[ask_agent],  # ask_agentツールを使用して他のエージェントと通信
    system_prompt="""あなたは複数の専門エージェントを調整するマスターエージェントです。
質問内容に応じて、適切な専門エージェントに質問を転送してください。
現在接続できるエージェント:
- math_agent: 数学の問題に対応
- history_agent: 歴史の問題に対応

専門エージェントに質問する場合は、ask_agent関数を使用してください。
"""
)

# A2Aサーバーのメイン関数
def a2a_server(query: str):
    """
    ユーザークエリを処理し、適切なエージェントに転送するA2Aサーバー
    """
    print(f"ユーザークエリ: {query}")
    result = master_agent(query)
    print(f"最終応答: {result.message}")
    return result.message

# 使用例
if __name__ == "__main__":
    # テスト用のクエリ
    queries = [
        "2025年までに残っている日数は？",
        "第二次世界大戦はいつ始まりましたか？",
        "ピタゴラスの定理を説明して、そして三角形の底辺が3で高さが4のとき斜辺の長さを計算してください。"
    ]
    
    for query in queries:
        print("\n" + "="*50)
        a2a_server(query)
        print("="*50)
