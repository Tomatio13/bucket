from strands import Agent
from strands.models import BedrockModel
from strands_tools import calculator
from dotenv import load_dotenv
# .envファイルから環境変数を読み込む
load_dotenv()

model = BedrockModel(
        #    model_id="us.anthropic.claude-sonnet-4-20250514-v1:0"
    model_id="openai.gpt-oss-120b-1:0",
    streaming=False
)
agent = Agent(
    model=model,
    tools=[calculator],
)

agent("Tell me the square root of 42 ^ 3")
