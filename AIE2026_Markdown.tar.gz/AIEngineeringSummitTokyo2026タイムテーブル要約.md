
# AI Engineering Summit Tokyo 2026

## 登壇資料一覧
https://conference.findy-code.io/conferences/aie-tokyo-26summer/26/archives/slides

## タイムテーブル

出典: [AI Engineering Summit Tokyo 2026 Summer - TIMETABLE](https://ai-engineering-summit-tokyo.findy-tools.io/2026-summer/ttable)

**日時:** 2026年6月8日(月)・9日(火) 9:00〜21:00  
**会場:** 浜松町コンベンションホール＆Hybridスタジオ（オフライン / オンライン配信あり）

---

### DAY 1（6月8日 月）

#### 9:15 - 10:10

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | KEYNOTE（会場限定） | Transforming the enterprise with FDE | 水越 将巳（OpenAI Japan / Tech Success Lead）、Ryan Cain（OpenAI Japan / Strategic Delivery Lead (FDE)） |

#### 10:30 - 11:00

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | AI時代のサプライチェーンセキュリティ — 開発を加速させる組織横断ガバナンスの実践 | 佐久間 友樹（株式会社アシュアード / yamoryプロダクトマネージャー） |
| B | SPONSOR | AI時代のソフトウェアテストにどう備えるか ～オリックス生命がテスト自動化で整えた6年間の品質基盤～ | 松井 康浩（オリックス生命保険株式会社）、中新井 恒人（オーティファイ株式会社） |
| C | SPONSOR | Gemini Enterprise Agent Platform で実現する「本番仕様」の AI エージェント開発 | 中村 一成（グーグル・クラウド・ジャパン / Forward Deployed Engineer） |
| D | SPONSOR | 運用を見据えたAIエージェント設計実践 | 真嘉比 愛（ちゅらデータ株式会社 / 代表取締役） |

#### 11:20 - 11:50

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | 分散したコンテキストを統合し、開発フローを加速する | 鏑木 崇之（Glean Technologies, Inc. / ソリューションエンジニア） |
| B | SPONSOR | 組織でAIプロダクトを作るには: AI Enabling Unitの取り組み | 須藤 郁弥（株式会社estie / 不動産AI Lab AIイネーブリングユニット） |
| C | SPONSOR | 新規ゲーム開発におけるAI駆動開発のリアル ― MCPからUnity CLIへの意思決定と、AI前提組織への転換 ― | 趙 訓濟（ENSAPIA Engineering株式会社）、倉 秀一（ENSAPIA Engineering株式会社） |
| D | SPONSOR | ChatworkとBPaaS、異なる特性で学んだAI機能開発のベストプラクティス | 上田 隼也（株式会社kubell / Principal AI Engineer） |

#### 12:10 - 12:40

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | AI同士の通話で実現する音声AIエージェントの品質検証 | 齊藤 慎也（Gen-AX株式会社） |
| B | SPONSOR | noteのレコメンド開発を支えるAIエージェント活用 | 漆山 和樹（note株式会社） |
| C | SPONSOR | ディスカバリーとデリバリーを繋ぐユーザーストーリーのAI化 | 大曲 智久（株式会社ADWAYS DEEE / 取締役CTO） |
| D | SPONSOR | 正気を疑う技術 - bugのないvibe codingを目指して | 橋本 翔（株式会社Helpfeel / Cosense プロダクトマネージャー） |

#### 13:00 - 13:40

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | MUITとClineが語る、AIコーディングエージェント組織展開の現実 | 黒田 雄一（三菱UFJインフォメーションテクノロジー株式会社）、Dominic Cooney（Cline / Software Engineer） |
| B | SPECIAL（会場限定） | AIが実装する時代に、プロダクト価値は誰が生むのか？ ~ エンジニアの役割と組織 ~ | 木村 衆平（株式会社サイバーエージェント / 主席エンジニア AI事業本部 技術統括） |
| C | SPECIAL（会場限定） | 【公募セッション】AIエージェント構築事例 | 高木 詩織（ダイキン工業株式会社）、坂本 一樹（株式会社Algomatic）、京仲 俊樹（NECソリューションイノベータ株式会社） |
| D | SPECIAL（会場限定） | 「気づいたら仕事が終わっている」バクラクAIエージェント本番運用の裏側 | 松村 優也（株式会社LayerX / バクラク事業部 AI・機械学習部 部長） |

#### 14:00 - 14:30

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | TiDB製品群から学ぶAIエージェントが加速するプロダクト開発と組織変革 | 関口 匡稔（PingCAP株式会社）、TONG MU（PingCAP株式会社） |
| B | SPONSOR | AIエージェントのデータガバナンスの最新事情。そしてプロダクトのAIファースト化 | 高橋 誠二（株式会社ベースマキナ / 代表取締役社長） |
| C | SPONSOR | チームで実践する AI-DLC: 思考の軌跡を残すチェックポイント設計 | 福井 達也（株式会社Belong / 執行役員 CTO） |

#### 14:50 - 15:30

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | AIエージェント時代の開発組織の最先端：品質とスピードの向こう側 | 広木 大地（株式会社レクター / 代表取締役）、山崎 聡（エムスリー株式会社 / CPO / CAIO）、佐藤 将高（ファインディ株式会社 / CTO） |
| B | SPECIAL（会場限定） | ベクトルDBでレコメンドをここまで極める — 巨大サービスの裏側から学ぶ | Tyler Shukert（Supabase / DevRel Engineer） |
| C | SPECIAL（会場限定） | 【令和最新版】AWSではじめよう！弊社専用のモダンAIエージェント構築 | 御田 稔（KDDIアジャイル開発センター株式会社 / テックエバンジェリスト） |

#### 15:50 - 16:20

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | 図面・見積・発注を"コードで扱える構造"へ ─ リアル産業の業務モジュール化とAI実装 ─ | 濵田 祐希（株式会社BALLAS / プロダクト本部責任者） |
| B | SPONSOR | 価格.comをAI駆動で全面刷新する — 30年分の技術的負債を返し、次の30年の土台をつくる — | 京和 崇行（株式会社カカクコム / 上級執行役員CTO） |
| C | SPONSOR | AI Editor開発の現場から学ぶ、プロダクト化に向けたAI Agent開発の勘所 | 伊藤 宏樹（テックタッチ株式会社 / Data AI Division 事業部CTO） |
| D | SPONSOR | 児童福祉×生成AI：会員50万人「LITALICO発達ナビ」に生成AIを組み込んだ3つの挑戦と振り返り | 髙崎 歩人（株式会社LITALICO / データ統括部 R&Dグループ） |

#### 16:40 - 17:20

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | 開発チームのキャパシティを10倍にする方法 | シバタ アキラ（Cognition AI / Field CTO） |
| C | SPECIAL（会場限定） | From Monitoring to Self-Improving AI Agents | Sangyoul Jin（Arize AI / General Manager, Korea & Japan） |
| D | SPECIAL（会場限定） | 企業で使えるAIエージェントとは何か— AGENTIC STAR開発から考える"自律"の定義と設計 | 中山 達嗣（ソフトバンク株式会社） |

#### 17:40 - 18:20

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | KEYNOTE（会場限定） | What do you build when you can build anything? | Scott Hanselman（Microsoft / VP, Member of Technical Staff at Microsoft CoreAI/GitHub） |

#### 18:40 - 20:40

懇親会

---

### DAY 2（6月9日 火）

#### 9:30 - 10:10

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | KEYNOTE（会場限定） | Building GenAI Systems that Scale | Edwards Chase（Databricks / Head of AI Forward Deployed Engineering, EMEA） |

#### 10:30 - 11:00

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | AI Agent時代に求められる「統合データアーキテクチャ」 | 北迫 清訓（ClickHouse株式会社 / 最高技術責任者 兼 技術統括本部長） |
| B | SPONSOR | Qwen×Happy Horseに学ぶ、AIコモディティ時代のコスト・性能を両立するAI選定戦略と実装のポイント | 藤川 裕一（アリババクラウド・ジャパンサービス株式会社） |
| C | SPONSOR | What We Learned From Analyzing Five Million Vibecoded PRs | Choi, Soohoon（Greptile / CTO, Co-Founder）、Choi, Jihoon（Greptile / Founding GTM） |
| D | SPONSOR | 〈みずほ〉が進めるAIトランスフォーメーション | 藤井 達人（株式会社みずほフィナンシャルグループ / Chief AI Officer） |

#### 11:20 - 11:50

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | 備えあれば憂いなし: エージェントの意図しない動作からシステムを守る | Justin Rackliffe（Docker / Field CTO）、田淵 義人（エクセルソフト株式会社） |
| B | SPONSOR | Agentic ERPをどう設計するか | 平松 拓（株式会社リチェルカ / CTO）、梅田 脩平（株式会社リチェルカ / プロダクト責任者） |
| C | SPONSOR | 20人で100億円規模コマースアプリ事業を作るE2E AI-Nativeのリアル | 宇佐美 ゆう（株式会社STRACT / シニアプロダクトエンジニア） |
| D | SPONSOR | LLM本来の能力を解き放つサンドボックス技術と、AI民主化への適用 | 小谷 優空（Ubie株式会社 / CTO） |

#### 12:10 - 12:40

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | AI駆動開発が変える、大規模開発の前提 | 外山 英幸（株式会社ビズリーチ / 執行役員 CTO） |
| B | SPONSOR | 記録をかんたんに、提案をパーソナルに。AIであすけんが目指すもの | 山口 将央（株式会社asken / AX推進部 テックリード） |
| C | SPONSOR | AIエージェントはレガシーを攻略できるか：12万社が使う建設SaaSの改修と新規開発で見えたこと | 夏目 伸彦（エムシーディースリー株式会社 / CTO室 室長） |
| D | SPONSOR | 推しのライブを進化させる！ AI駆動開発が生んだ「体験を作るエンジニアリング」への挑戦 | 伊藤 圭史（playground株式会社 / CEO/CPO）、舟口 翔梧（playground株式会社 / テックリード） |

#### 13:00 - 13:40

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | AIエージェントは"作る"から"本番活用"へ ── データ基盤が支える次のステージ | 真嘉比 愛（ちゅらデータ株式会社）、大内山 浩（データブリックス・ジャパン株式会社）、開 功昂（ファインディ株式会社） |
| B | SPECIAL（会場限定） | AI時代における開発組織とは〜エンジニアとPdMの役割再定義〜 | 木村 俊也（株式会社メルカリ / 執行役員 CHRO 兼 CAIO 兼 CTO Japan Business） |
| C | SPECIAL（会場限定） | 【公募セッション】個人利用から組織展開へ、AIエージェント導入事例 | 荒木 慎平（株式会社ログラス）、谷脇 大輔（株式会社JMDC）、福田 龍（株式会社カンリー） |
| D | SPECIAL（会場限定） | Google 検索、Google マップ、ベクトル検索を統合したリアルタイム AI エージェントの開発 | 佐藤 一憲（グーグル合同会社 / デベロッパーアドボケイト） |

#### 14:00 - 14:30

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | データサイロからAIレディネスへ：オープンデータインフラストラクチャによるAI基盤の再構築 | 日向寺 正之（Fivetran / セールスエンジニア） |
| B | SPONSOR | LangfuseによるLLM Observability基盤の構築と実践 〜『MNTSQ AI Agent』を「運用・改善できる」状態にするための取り組み〜 | 清水 健吾（MNTSQ株式会社） |
| C | SPONSOR | 開発フローにAIエージェントを組み込む設計と運用の実際 | 森本 勝哉（株式会社kickflow / エンジニアリングマネージャー） |

#### 14:50 - 15:30

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | みずほFG × Cognition AIが語るAIエージェント開発の現在地 | 藤井 達人（株式会社みずほフィナンシャルグループ）、シバタ アキラ（Cognition AI）、山田 郷（ファインディ株式会社 / 執行役員） |
| B | SPECIAL（会場限定） | SBOAI×OpenAI：AIネイティブ組織への変革〜爆速実装とエンジニアの役割 | 大石 怜史（SB OAI Japan合同会社 / Chief Business Officer）、Ryan Cain（OpenAI Japan） |
| C | SPECIAL（会場限定） | 「AIで開発し、AIを届ける」をEvalでつなぐ ー AIネイティブに始めるプロダクト開発の実践 | 加賀谷 諒（Asterminds株式会社 / 共同創業者・CTO） |
| D | SPECIAL（会場限定） | エージェント時代における推論構造、オープンソースモデルからデータセンターまで | 原 信平（株式会社エーアイ・アンド / Co-Founder & President） |

#### 15:50 - 16:20

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPONSOR | 月2億円の広告予算を自律運用するAIエージェントを、1年かけて現場で作った話 — 1年伴走型FDEのリアルな実装記 | 井上 聖司（株式会社AIX / 代表取締役） |
| B | SPONSOR | AIで実装は速くなった — プロダクトは良くなっただろうか | 村石 恵示（JAPAN AI株式会社 / Engineering Manager） |
| C | SPONSOR | AIを「創る」と「使う」の循環 — HRテックが実践するリアルなAI組織実装 | 佐々木 健人（株式会社HERP / エンジニアリング部責任者） |
| D | SPONSOR | 業界特化AIで「真似できない強み」をどう作るか？ — ドメインの深さをプロダクト価値に繋げる | 富田 晃弘（株式会社Legalscape / エンジニアリングマネージャー） |

#### 16:40 - 17:20

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | SPECIAL（会場限定） | The 5 Layers That Take Agents to Production | Dominic Cooney（Cline / Software Engineer） |
| B | SPECIAL（会場限定） | 実装は速くなった、レビューはどうする？ ― 自身のレビューをAIで再現させるサーヴァントエンジニアリングのすゝめ | 成瀬允宣（なるセミ代表／Findy Freelance顧問） |
| C | SPECIAL（会場限定） | AI駆動開発を文化にする：ボトムアップの熱量とワークショップが生んだ組織の変革 | 平野 敬祐（LINEヤフー株式会社）、井上 雄飛（LINEヤフー株式会社） |
| D | Findy（会場限定） | 「速く作る」から「正しく作る」へ ─ 生成AI時代の開発フロー改革のロードマップと実行 ─ | 戸田 千隼（ファインディ株式会社 / AI推進 テックリードマネージャー） |

#### 17:40 - 18:30

| Room | 種別 | タイトル | 登壇者 |
|------|------|----------|--------|
| A | KEYNOTE（会場限定） | Forward Deployed Engineering at OpenAI | Ryan Cain（OpenAI Japan）、Sean Saito（OpenAI Japan / Forward Deployed Engineer） |

#### 18:40 - 20:40

懇親会