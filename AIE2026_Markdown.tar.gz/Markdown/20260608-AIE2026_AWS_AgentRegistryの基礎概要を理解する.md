# AWS Agent Registry の基礎・概要を理解する

**登壇者:** 鯨田 連也（Renya Kujirada）  
**所属:** アマゾン ウェブ サービス ジャパン合同会社  
**役職:** スペシャリスト ソリューションアーキテクト, AI/ML  
**日付:** 2026/04/23  
**イベント:** AI Engineering Summit Tokyo 2026

---

## はじめに

本資料は、AWS が提供する **Agent Registry** の基礎と概要を解説するセッションの内容です。社内で Agent や MCP サーバーが増えてきたときに発生するスケールの課題に対し、Agent Registry がどのような価値を提供するのかを、全体像・ユーザーペルソナ・エンドツーエンドのフロー・メタデータレコードの種類という観点から説明します。

---

## 自己紹介

**鯨田 連也（Renya Kujirada）**

アマゾン ウェブ サービス ジャパン合同会社  
スペシャリスト ソリューションアーキテクト, AI/ML

前職（NTT DATA）では、データサイエンティストとして深層学習モデル・AI Agent を活用したソリューション開発に従事。

- **興味:** AI Agent 開発, LLM 学習・推論
- **好きなサービス:** Amazon Bedrock, Amazon SageMaker AI

---

## アジェンダ

1. Agent 開発・運用におけるスケールの課題
2. AWS Agent Registry で実現できること
3. Agent Registry の全体像
4. Agent Registry におけるユーザーペルソナ
5. Agent Registry のエンドツーエンドのフロー
6. Agent Registry のメタデータレコードの種類

---

## Agent 開発・運用におけるスケールの課題

数百、数千の Agent や MCP サーバーが社内で構築された際、**可視性・再利用性・制御性**の観点でスケールしづらい課題が発生します。

### 可視性の課題

社内にどのような Agent が存在するか把握できない。

### 再利用性の課題

社内で既存・類似の Agent や MCP サーバーを重複して構築してしまう。

### 制御性の課題

誰が Agent を公開・発見できるか、ガバナンスや品質を審査する正式なプロセスが無い。

---

## AWS Agent Registry で実現できること

Agent Registry は、上記の課題に対して3つの柱で価値を提供します。

### 1. Agent の一元管理

- 全ての Agent, MCP Server, Skills を、ホスト先を問わず一元管理
- MCP または A2A エンドポイントをコンソール or API 経由で指定するだけで登録可能
- MCP / A2A をネイティブサポート。柔軟なカスタムスキーマにも対応

### 2. 既存アセットの発見

- ハイブリッド検索やキーワードフィルタリングが可能
- コンソール、API 経由でアクセス可能。Kiro や Claude Code から MCP サーバーとしてアクセス可能
- OAuth サポートにより、IAM 認証を使わずにチーム独自のカスタム検索 UI を構築可能

### 3. ガバナンス

- `draft` → `pending` → `approved` の承認フローを経てからエージェントが検索可能になる
- バージョニング、非推奨化、廃止、承認プロセス用のフックなどのライフサイクル管理が可能
- IAM ベースで誰が登録・検索・利用できるかをきめ細かくアクセス制御

---

## Agent Registry の全体像

> 組織内で開発した Agent, MCP Server, Skills, カスタムリソースを一元的に登録・承認/管理・検索/再利用可能な、フルマネージドな中央集約型カタログ。

### 入力（登録経路）

| 経路 | 説明 |
|---|---|
| **AWS Console** | 管理コンソールからの操作 |
| **Agents (boto3 SDK)** | SDK 経由でのプログラマティック登録 |
| **RESTful APIs & MCP tool** | API および MCP ツール経由 |

### コア機能（AWS Agent Registry）

| 機能 | 説明 |
|---|---|
| **統合カタログ** | 全アセットを一元的に管理 |
| **Agents & Tools 登録** | Agent やツールの登録 |
| **ハイブリッド & フィルタベース検索** | 自然言語・キーワードなど多様な検索 |
| **メタデータ同期** | メタデータの同期・管理 |
| **ワークフロー承認** | 承認フローの実行 |

### 管理対象リソース

- **A2A Agents** — Agent-to-Agent 連携
- **MCP** — Model Context Protocol サーバー
- **Skills** — Agent Skills
- **Custom resources** — カスタムリソース

### 基盤サービス

| サービス | 役割 |
|---|---|
| **AgentCore Identity** | エージェントのアイデンティティ管理 |
| **AgentCore Observability** | エージェントの可観測性 |
| **IAM & OAuth** | 認証・認可 |

---

## Agent Registry におけるユーザーペルソナ

管理者（Admin）、パブリッシャー（開発者）、コンシューマー（利用者）の3つのペルソナが、それぞれ異なるニーズで Registry を活用します。

### 管理者（Administrator）

レジストリを構築・管理し、品質のガードレールを設け、レジストリの可視性を統制する。

**対象:** IT 管理者、プラットフォームチーム、DevOps エンジニア

### パブリッシャー（Publisher）

社内の他者と共有したい Agent や MCP Server を構築・運用する開発者。

### コンシューマー（Consumer）

既存の Agent や MCP Server を発見し、自身のワークフローに統合する開発者、あるいは自律型 Agent。

---

## Agent Registry のエンドツーエンドのフロー

パブリッシャーが Agent 公開のためにレコードを作成し、管理者が品質レビュー後に承認、コンシューマーが検索して Agent を利用する。

### 公開フロー（パブリッシャー → 管理者）

```
1. パブリッシャー → 2. パブリッシュ → 3. 管理者のレビュー → 4. 管理者の承認
```

| ステップ | 内容 |
|---|---|
| **1. パブリッシャー** | Agent, MCP Server, Skills, またはカスタムリソース登録するためのレコードを作成 |
| **2. パブリッシュ** | レコードがメタデータおよびスキーマ検証とともに承認申請される |
| **3. 管理者のレビュー** | EventBridge が既存パイプラインをトリガー、または管理者が手動でレビュー |
| **4. 管理者の承認** | 管理者が承認 / 却下。承認されたレコードは検索可能になる |

### 発見フロー（コンシューマー）

#### 5. コンシューマーによる発見（人間）

- コンソール、CLI、SDK で検索
- MCP エンドポイント経由で IDE を接続
- 自然言語クエリ
- キーワード完全一致検索

#### 6. コンシューマーによる発見（エージェント）

- エージェントが MCP 経由でツールを発見
- エージェントが他のエージェントを発見
- プログラマティック検索 API
- A2A 連携

---

## メタデータレコードの種類

Agent Registry では、登録するリソースの種類に応じて異なるメタデータスキーマをサポートします。

### MCP（MCP Registry サーバースキーマ）

**レコード例:**

```json
{
  "name": "Order tool",
  "descriptorType": "MCP",
  "recordVersion": "1.0"
}
```

**関連スキーマ:**

| スキーマ | 構造 |
|---|---|
| MCP Registry 公式サーバースキーマ | `{ "server": { "inlineContent": { ... } } }` |
| MCP ツールスキーマ | `{ "tools": { "inlineContent": { ... } } }` |

### A2A（A2A エージェントカードスキーマ）

**レコード例:**

```json
{
  "name": "Pricing Agent",
  "descriptorType": "A2A",
  "recordVersion": "1.0"
}
```

**関連スキーマ:**

| スキーマ | 構造 |
|---|---|
| A2A エージェント公式カードスキーマ | `{ "a2a": { "agentCard": { "inlineContent": { ... } } } }` |

### Agent Skills（Skills.md スキーマ）

**レコード例:**

```json
{
  "name": "Skills",
  "descriptorType": "AGENT_SKILLS",
  "recordVersion": "1.0"
}
```

**関連スキーマ:**

| スキーマ | 構造 |
|---|---|
| Skills.md 公式 | `{ "skillMd": { "inlineContent": { ... } } }` |
| スキル定義 | `{ "skillDefinition": { "repository": { ... }, "packages": { ... } } }` |

### カスタム（有効な JSON）

カスタムリソースは、有効な JSON 形式で登録可能。柔軟なカスタムスキーマに対応。

---

## まとめ

AWS Agent Registry は、組織内で増え続ける Agent・MCP サーバー・Skills を一元管理し、発見・再利用・ガバナンスを実現するフルマネージドの中央集約型カタログです。

| 課題 | Agent Registry の解決策 |
|---|---|
| 可視性 | 統合カタログとハイブリッド検索 |
| 再利用性 | 既存アセットの発見（コンソール / API / MCP / IDE 連携） |
| 制御性 | 承認フロー、ライフサイクル管理、IAM ベースのアクセス制御 |

パブリッシャーがレコードを作成し、管理者がレビュー・承認したうえで、人間や自律型 Agent が検索・利用するというエンドツーエンドのフローが設計されています。MCP、A2A、Agent Skills、カスタム JSON の4種類のメタデータレコードに対応し、AgentCore Identity / Observability および IAM & OAuth を基盤としています。

---

*© 2026, Amazon Web Services, Inc. or its affiliates. All rights reserved.*

*出典: AI Engineering Summit Tokyo 2026 — AWS Agent Registry の基礎・概要を理解する（鯨田 連也 / AWS）*