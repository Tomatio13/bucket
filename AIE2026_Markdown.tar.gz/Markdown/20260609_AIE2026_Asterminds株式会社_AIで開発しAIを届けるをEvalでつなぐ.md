# 「AIで開発し、AIを届ける」をEvalでつなぐ

**AIE2026 Day2 セッション**

**スピーカー:** r.kagaya (@ry0_kaga) / Asterminds株式会社 共同創業者・CTO

**日付:** 2026年6月9日

---

## セッション概要

AIで開発し、AIを届ける。2つのループをEvalでつなぐ実践。AIネイティブに始めるプロダクト開発の実践について、Eval（評価）を中心に据えた開発手法を解説。

---

## 目次

1. [スピーカー紹介](#スピーカー紹介)
2. [Astermindsについて](#astermindsについて)
3. [From AI to AI](#from-ai-to-ai)
4. [Cursor Developer Habits Reportから見る変化](#cursor-developer-habits-reportから見る変化)
5. [受け入れ可能性の自動化](#受け入れ可能性の自動化)
6. [Evalの概念](#evalの概念)
7. [Evalの始め方](#evalの始め方)
8. [AI開発フローへのEvalの適用](#ai開発フローへのevalの適用)
9. [Background Coding Workflow](#background-coding-workflow)
10. [Browser QAへの投資](#browser-qaへの投資)
11. [AI Design System](#ai-design-system)
12. [Verifiability（検証可能性）](#verifiability検証可能性)
13. [まとめ](#まとめ)

---

## スピーカー紹介

### r.kagaya (@ry0_kaga)

- **所属:** Asterminds株式会社 共同創業者・CTO
- **経歴:**
  - 2022年に株式会社ログラスに入社
  - 経営管理SaaSの開発、開発生産性向上に取り組んだのち、生成AI / LLMチームを立ち上げ、新規AIプロダクトの立ち上げに従事
  - 2025年8月に独立・現職
- **著書:** 翻訳を担当した『AIエンジニアリング』がオライリージャパンより出版（2025年8月）

### Astermindsについて

**2026年3月にシードラウンド調達を公開** — 累計1.1億円の資金調達

**企業理念:** 企業の中に眠る**文脈**を、次の**打ち手**に変える

Astermindsは、AIヒアリングを入口に、現場の声・顧客の本音・暗黙知・判断理由を掘り起こし、意思決定と次のアクションにつなげる**コンテキストマイニング**の会社。

| 入力 | 出力 |
|---|---|
| **現場の声** — 日々のやり取りや顧客の本音を捉える | **意思決定** — 根拠ある判断を加速する |
| **暗黙知** — 経験や勘に埋もれた知見を可視化する | **提案** — 顧客に響く提案を生み出す |
| **判断理由** — なぜそう判断したのかを構造化して明らかにする | **業務変革** — 現場に根づく変革を実現する |

---

## From AI to AI

### 問い

**AIに作らせた成果物と、AIとして届けるプロダクト。私たちは何を根拠に受け入れるのか？**

### From AI to AIが現実になっている

AI（生成AI／LLM）は、開発工程とプロダクトの両方で前提となりつつある。AIでプロダクトを作り、そのプロダクト自体もAIが搭載されるようになっている。

| 概念 | 説明 |
|---|---|
| **AIを使って開発する** | AIコーディングやAgentic Engineering。まとまった作業を委任する開発形態へと進んでいる |
| **AIをプロダクトとして届ける** | AIがタスクを遂行し、業務で使える出力を返すAIプロダクト |

---

## Cursor Developer Habits Reportから見る変化

Cursor利用データからAI Codingによる開発者行動の変化を見るリサーチ。

**参照:** https://cursor.com/ja/insights

### AI Codingは「まとまった作業を委任する」へ移っている

より大きい作業単位をAIに任せる方向へ進んでいることを示している。

| 指標 | 変化 | 示唆 |
|---|---|---|
| Lines added / dev / week | 3.6K → **8.6K** | 生成量は増えたが、行数そのものの価値とは見なさない |
| PR p75 lines added | 125.86 → **345.02** | レビュー対象が大きくなり、受け入れ判断の負荷が増える |
| Tool calls / agent session | 113.63 → **145.08** | AIは単発補完ではなく、複数手順の作業を進める |
| Input / Output token ratio | 4.52x → **11.41x** | 書く前に読む量が増え、Context設計の重要性が上がる |

### Cursorの使われ方の進化

Cursorの使われ方は、目の前にコードを書かせるIDE/エディタからSDLC Automationへ進んでいる。

```
1. Manual accept
   人間がIDE上で差分を見て、変更を受け入れる。
        ↓
2. Agent-generated commit
   manual diff acceptanceなしでcommitに到達する変更が増えている。
        ↓
3. Automation
   issue, PR, security reviewをトリガーにagentを動かす。
        ↓
4. SDK workflow
   開発ライフサイクルの一部をagentic workflowとして組み込む。
```

**追加機能:**
- **Cursor Automations** — 作業をイベント起点で進める
- **Security review automation** — review対象の一部を自動で確認する
- **SDK runs** — IDE外のworkflowからagentを実行する

### AIに任せる作業単位が大きくなるほど、成果物をどう受け入れるかが重要に

| 課題 | 詳細 |
|---|---|
| **Bigger PRs / Review load** | PRが大きくなるほど、review対象は広がり、意図と副作用を追う時間が増える |
| **Deeper sessions / Traceability** | agent sessionが深くなるほど、AIが何を見てなぜ変更したのかを追跡する必要がある |
| **More context / Input management** | contextが増えるほど、渡す情報、削る情報、cacheする情報の管理が品質に効く |
| **More automation / Human boundary** | automationが進むほど、どこまでAIに任せ、どこから人間が握るかの境界が重要になる |

---

## 受け入れ可能性の自動化

### 生成の自動化ではなく、受け入れ可能性の自動化

AIが作ること自体は前提になり、差が出るのは、その成果物をどれだけ低い負荷で受け入れられるか？

- 作業速度が上がるほど、人間レビューはボトルネックになる
- 証拠のない成果物は、AIが早いほどレビュー待ちを増やす
- 投資対象は、生成器だけでなく受け入れライン

### 2つのループは同じような形をしている

AIの出力を、何を根拠に信頼するかという似た問題に向かっている。

**『AIエンジニアリングのEvalは、AIに開発を委任するプロセスにも適用できる』**

```
┌──────────────────┐     ┌──────────────────┐
│  AIで開発する     │     │  AIを届ける       │
│                  │     │                  │
│ PR、画面、導線、 │     │ 質問、要約、分析、│
│ ログを、何を根拠 │共通 │ 提案を、何を根拠  │
│ に受け入れるかを │の問い│ にユーザーへ届ける│
│ 決める。         │     │ かを決める。      │
│                  │→   →│                  │
│ 生産物だけでは   │     │ AI出力は業務文脈で│
│ なく、仕様との   │     │ 使えることまで    │
│ 対応と実行証跡が │     │ 評価される。      │
│ 必要になる。     │     │                  │
└──────────────────┘     └──────────────────┘
```

**共通する問い:**
- 期待を定義し、証拠を残し、Graderで判断シグナルにする
- GateとJudgeを分け、失敗を改善先へ戻す

### 受け入れ可能性の自動化：3E（Entry / Exit / Eval）

ソフトウェア開発サイクルの自動化（AI Software Factory）に向かう中で、人間の役割は3E（Entry / Exit / Eval）、ループの設計に移っていく。

| 要素 | 内容 |
|---|---|
| **Entry** | task / spec / scope / context / constraintsを明確にし、何を任せるかを曖昧にしない。AIに課される制約条件も含む |
| **Exit** | evidence / review packet / feedback routeを揃え、何を証拠に受け入れるかを決める |
| **Eval** | acceptance contractとして、入口と出口をつなぐ判断基準を置く |

### 委任条件を定めるということ

信頼して、深く作業を任せるためにも、AIに委任できる条件を設計すること。任される範囲は、モデルの賢さだけでは決まらない。

| 要素 | 説明 |
|---|---|
| **条件** | task, scope, context, constraintsを明確にし、AIが何を任されているかを曖昧にしない |
| **証拠** | screenshot, video, log, AI outputを残し、人間が結果を判断できる形にする |
| **戻し先** | 失敗をその場の手直しで終わらせず、rule, scenario, workflowの改善へ戻す |
| **改善ループ** | EvalはAIを止める仕組みではなく、任せる範囲を広げる仕組みになる |

---

## Evalの概念

### AIエンジニアリングとは何で、何から生まれた？

AIエンジニアリングとは、基盤モデルを用いてアプリケーションを構築すること。AI利用の民主化がもたらした新しいエンジニアリング分野。

| 要因 | 説明 |
|---|---|
| **基盤モデルの登場** | 汎用的にタスクを解ける基盤モデルの登場。インコンテキストトレーニングなど、モデル自体の変更はなしに、モデルの振る舞いを変更することが可能 |
| **Model as a Service** | 一部の専門組織が開発した巨大なAIモデルを、APIを通じて誰もがサービスとして利用できるようになった |

AIアプリケーション開発のハードルの低下による環境の変化が勃興の要因。

### AIエンジニアリングで何が変わる？

モデル作成から始めなくて良くなったが故のサイクルや活動領域の変化。

| 変化 | 説明 |
|---|---|
| **プロダクトファースト** | 今はモデル開発自体は行わずにとも、先にAIアプリケーション開発が行える |
| **モデル構築から適応へ** | モデルの適応（アプリケーション要件にモデルの振る舞いを調整する）の必要性の高まり |
| **評価の固有度の増加** | アプリケーション固有・オープンエンドな出力を前提とする機会が増加。評価の独自度も高めることに |

### AIエンジニアリング ≠ プロンプトエンジニアリング

特に中心になるのは**モデル適応技術**と**評価（Eval）**。

| モデル適応 | 評価 |
|---|---|
| 汎用的な基盤モデルを特定のアプリケーションに"適応"させる | 汎用的な基盤モデルを、いかに特定のアプリケーション要件に適合させるか |
| ・コンテキストの制御（Prompt/Context Engineering） | 「確率的で非決定的な振る舞い」を、許容できる品質、安全性、トーン、専門性の担保まで確認するプロセス |
| ・知識と行動の拡張（RAG & Agents） | |
| ・モデルの専門化（Fine-tuning） | |

### 全ての土台となる評価

**信頼できる評価軸があるからこその体系的な改善**

「この修正で本当にシステムは良くなったか？」に自信を持って答えるためには？

| 問い | 回答 |
|---|---|
| **なぜ難しいのか？** | オープンエンドな出力は正解が一つに収斂しないため。AIエンジニアリングの世界においては、オープンエンドな出力の利用が増える |
| **なぜ重要なのか？** | 評価パイプライン・基準がなければ、開発は単なる「手探りの試行錯誤」に陥る可能性 |

**Vibe Check（雰囲気での確認）には限界がある**

### EvalはAIアプリケーションの品質管理

AIエンジニアリングにおけるEvalは、AIに点数を付ける作業だけではない。AIアプリの品質を測り、回帰を検知し、改善していく確信を持ったための仕組み。

```
1. Evaluate components
   モデル、プロンプト、RAG、ツール、UI、ワークフローのどこで失敗するかを見る
        ↓
2. Create evaluation guideline
   何を良しとするかを言語化し、判断が人によってぶれない基準にする
        ↓
3. Define methods and data
   どう測るか、どのcaseで測るかを決め、評価を再実行できる形にする
        ↓
4. Feed failures back
   失敗を次のcase / rule / system designへ戻し、改善先を明確にする
        ↓
   （ループ）
```

### 評価駆動開発（Eval Driven Development）

AIアプリケーションを作る前に、評価基準とデータセット、採点方法を用意する。TDDがシステム設計に向き合うためのプラクティスだったように、EDDはAIアプリケーションの要求と品質基準に向き合うためのプラクティス。

**参照:** https://vercel.com/blog/eval-driven-development-build-better-ai-faster

### Evalは改善ループ

Evalで集まる「判断・証拠・失敗理由」自体が、改善するための価値のある情報。AI出力を評価するだけでなく、AIシステムを作る・改善するための情報を集める仕組みでもある。

| Evalで集まる情報 | 次に使われる場所 |
|---|---|
| どの入力で失敗したか | Eval Case / Golden Datasetへ戻す |
| 何を良しとしたか | Rubric / Acceptance Criteriaへ戻す |
| 何を証拠に判断したか | Trace / Review Packetへ残す |
| なぜ受け入れなかったか | Judge Guideline / Gateへ戻す |
| どう直したか | Rule / Prompt / Dataset / System Designへ戻す |
| どこへ戻したか | Feedback Loopへ戻す |

---

## Evalの始め方

### Evalは改善ループ（Pipeline設計）

直近の失敗をcase化し、再評価できる形で残すことで、改善ループが回り始める。単発の採点ではなく、Pipelineとして設計する。

```
1. 失敗を見つける
   期待と違う回答、微妙なUI、危険な表現を見逃さない
        ↓
2. caseとして残す
   入力、期待、実際の出力、ダメだった理由を記録する
        ↓
3. 再評価できる形にする
   モデルやプロンプトを変えた後に、同じケースで比較できるようにする
        ↓
4. 次の改善に戻す
   prompt, retrieval, UI, workflow, specのどこを直すか決める
```

### 基準と方法

Evalは基準と方法を分離して、「何を最適化するか」と「どう測るか」の混同を避ける。

| カテゴリ | 内容 | マッピング |
|---|---|---|
| **評価基準** | 何を良しとするかをRubricとして言語化する。correctness, business suitability, instruction adherence, robustness, security, cost, latency | Criteria → **Rubric** |
| **評価方法** | 基準をどう測るかをGraderとして選ぶ。exact match, functional correctness, reference similarity, embedding similarity, AI-as-Judge, human review, user feedback | Methods → **Grader** |
| **評価データ** | どのcaseで判断するかを決める。production logs, synthetic cases, golden dataset, failure cases, edge cases | Data → **Eval Case** |

### 評価方法の種類

評価方法は一枚岩ではない。明確なNGは機械的に止め、曖昧な品質はJudgeと人間の判断に寄せる。

| 方法 | 向いていること | 注意点 |
|---|---|---|
| **Exact / schema** | JSON形式、必須項目、禁止語、構造を見る | 意味品質は見られない |
| **Functional correctness** | ツール実行、API結果、状態遷移、タスク成功を見る | テスト対象の設計が必要 |
| **Reference similarity** | 簡潔さ、カテゴリ、出力の近さを見る | 参照回答の質に依存する |
| **Embedding similarity** | 意味的近さ、検索、RAG評価を見る | 近いが正しいとは限らない |
| **AI-as-Judge** | オープンエンドな品質、エッセイ、比較判断 | バイアスに注意、盲点がある |
| **Human / user feedback** | 最終的な受容性、業務価値を見る | 遅く、高コスト |

```
Deterministic ←→ Semantic ←→ Human
     Gate           Judge        Feedback
```

**AIコードレビューはJudgeの典型**

### Rubric / Grader / Gate / Judge / Calibrationの関係

**Graderは判定シグナルを作る評価関数。Gate/Judgeはシグナルの使い方。**

※ ここではJudgeを、model graderそのものではなく、主にLLMを用いたレビュー役として呼んでいる。

```
┌─────────┐  基準・ルールを定義  ┌─────────┐
│ Rubric  │ ─────────────────→ │ Grader  │
│         │                     │         │
│ 評価軸  │                     │pass/fail│
│ 期待状態│                     │ score   │
│ 失敗例  │                     │ label   │
│ 重要度  │                     │ reason  │
│         │                     │evidence │
└─────────┘                     └───┬──┬──┘
                                    │  │
                       判定を利用    │  │  判定を利用
                     ┌──────────────┘  └──────────────┐
                     ↓                                  ↓
               ┌─────────┐                      ┌─────────┐
               │  Gate   │                      │  Judge  │
               │         │                      │         │
               │自動で止め│                      │改善コメン│
               │明確な違反│                      │品質シグナ│
               └────┬────┘                      └────┬────┘
                    │                                  │
                    │  調整・改善                       │  調整・改善
                    │ （ズレのフィードバック）          │ （ズレのフィードバック）
                    ↓                                  ↓
               ┌─────────────────────────────────────────┐
               │            Calibration                   │
               │                                          │
               │ 人間判断とGraderのズレを直す              │
               │ 安定したJudgeはGateやruleに昇格できる     │
               └─────────────────────────────────────────┘
```

### 種類ではなく、結果の使い方

種類ではなく、結果の使い方でGateにもJudgeにもなる。

| 段階 | 状態 | アクション |
|---|---|---|
| **01** | High confidence + low false positive | → Gate → block automatically |
| **02** | Semantic / subjective / still noisy | → Judge → comment, signal, suggestion |
| **03** | Repeated + calibrated | → promote → to Gate / rule / scenario |

- Judgeはまずコメントと品質シグナルとして扱う
- 安定して検出できるものだけGateに昇格する

---

## AI開発フローへのEvalの適用

### Evalの考えを、AI開発フローに移植する

AIプロダクトの品質保証だけでなく、AIに開発を委任するプロセスにも使える。AIに深く任せるために、Entry / Exit / Evalを設計する。

| 部品 | 役割 | AI開発フローの例 |
|---|---|---|
| **Eval Case** | 評価したい具体ケースを固定する | 失敗したPR、UI崩れ、AI出力ミス |
| **Rubric** | 何を良しとするかを言語化する | Spec, Acceptance Criteria, AI Design System |
| **Grader** | 出力を判定シグナルに変換する | Test, Browser QA, LLM Review |
| **Gate** | 明確に止める判定を担う | typecheck, schema, 必須UI, 4xx/5xx |
| **Judge** | 意味的品質を見る判定を担う | 業務妥当性、UI自然さ、Design Review |
| **Trace** | 判断の根拠を残す | screenshot, video, logs, session URL |
| **Feedback Loop** | 失敗を戻す経路を作る | rule, scenario, fixture, workflow改善 |

### SpecはRubric

Evalの要素は、AIで開発するにも、AIプロダクトを開発するにも必要な考え。AI Software Factoryは、ほぼAIソフトウェア（みたいなもの）。例えば、SpecはAIへの入力であると同時に、Rubricでもある。

```
                    ┌──────────────┐
                    │   spec.md    │
                    └──────┬───────┘
                           │
          ┌────────┬───────┼───────┬────────┐
          ↓        ↓       │       ↓        ↓
    ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
    │ Rubric   │ │Eval Case │ │Constraints│ │Decisions │
    │          │ │          │ │          │ │          │
    │Requireme-│ │Scenario- │ │Non-goals │ │設計判断を│
    │ntsと     │ │sとVerify │ │と制約で  │ │記録し、  │
    │Acceptance│ │で実ブラウ│ │AIに任せな│ │後続の実装│
    │Criteria  │ │ザ上の操作│ │い境界を先│ │とレビュー│
    │で明文化  │ │と期待状態│ │に決める  │ │が同じ前提│
    │          │ │まで落とす│ │          │ │に立てる  │
    └──────────┘ └──────────┘ └──────────┘ └──────────┘
```

---

## Background Coding Workflow

### Own Background Coding Workflow

弊社ではClaude Agent SDK + TypeScriptで、Agentic Engineeringのプロセスを型化したWorkflowを内製（ローカル開発ではCodex/Claude Codeも利用）。

```
1. Issue / Spec
   AIに渡す前に、目的、制約、受け入れ条件を短い仕様として揃える
        ↓
2. Cloud Work
   AIは独立した作業環境で実装、調査、テストを進め、人間の作業をブロックしない
        ↓
3. Review Packet
   差分、判断理由、テスト結果、残課題をまとめ、人間が短時間で判断できる形にする
        ↓
4. Merge / Fix
   合格ならmergeし、不足があればFix Targetとして再委任する
```

**特徴:**
- AIによるdevサーバーの立ち上げ / ブラウザ操作の機能も保持
- PR上で「@xxxx ブラウザQAを実行」を依頼可能
- 他開発者のPRやAI自動生成のPRに対してもブラウザQAを自動実行可能

### 背景

- 開発チームはベース言語が英語で、海外在住メンバーも半数
- AIコーディングをどのように行っているかも見えづらい
- 自分がAIに書かせたコードをどう信頼するか？も難しいが、国や言語を跨いだ、自分以外の開発者がAI生成したコードを信頼する難しさ
- このような背景もあり、「自動PRマージ率30%」をお題目に内製/整備を始めた

### Claude Agent SDK + TypeScriptでAI開発フローをまとめる良さ

コード化すると、プロセスを仕組みに埋め込む。AIの作業がレビュー／評価可能な非同期プロセスになる。

| 利点 | 詳細 |
|---|---|
| **再現性と属人性の排除** | 誰が起動しても同じプロセスが走る。個人のAI開発への熟練度に依存しなくなる |
| **品質保証の組み込み** | ブラウザテスト・証跡スケジュール・動画まで完了した状態でPRが出る。不良specを早期に弾き、Codexクロスモデルレビューアで検証 |
| **計測と改善の基盤** | 全実行のログが取れる。設計判断・インシデント履歴をDBに永続化させるなど、「効いてるかわからない」を解消する土台も組み込みやすい |

### ローカル実行とクラウド実行の違い

**ローカル実行:** AIと一緒に考える場所
**クラウド実行:** AIに仕事を委任し、チームのプロセスとして回す場所

| Before: local pair workflow | After: cloud/background workflow |
|---|---|
| 人間が横にいる | issueやPRから起動する |
| 対話しながら進める | 長時間taskを任せる |
| 状況を見て介入する | parallelに複数案を走らせる |
| 結果は手元に残りがち | 人間はあとで結果を受け取る |
| | diff / logs / tests / browser proof が残る |

**クラウド実行の4パターン:**

| パターン | 説明 |
|---|---|
| **Long-running** | 大きめの調査、修正、検証を任せる |
| **Parallel** | 複数issue、複数案、複数検証を同時に進める |
| **Passive** | 人間は張り付かず、PRやReview Packetで受け取る |
| **Team process** | 誰でも同じ入口から起動し、同じ形式で受け取る |

### 人間が直すほど、ワークフローの失敗は隠れやすい

ポン出し型の方が改善が強制的に回りやすいと考える理由の一つ。

```
Spec/Prompt → AI first output → Human fixes → Final output
     ↓              ↓                ↓
  仕様の抜け     手順の抜け      画面確認の抜け
                                 レビュー観点の不足

人の修正がこれらの失敗を覆い隠す

見えるのは「良い結果」だけ:
  1. 成果物は良くなる
  2. でも workflow の弱点は観測しにくい
```

### Human-in-the-loop / Human-on-the-loop

AIに深く作業を委任するにつれ、「毎回判断」から「ループを設計し、監督」に。

| Human-in-the-loop | Human-on-the-loop |
|---|---|
| AIが提案する → 人間が承認する → 実行する | 人間が設計する：Rubric / Gate / Trace / Escalation / Feedback |
| **control by approval** | **control by loop design** |
| 高リスク、初期運用、基準が未確定の場面では、人間が実行経路の途中に入って止める | 定常運用では、人間が基準と戻し先を設計し、例外だけを拾える状態をつくる |

### Harnessにも、評価して育てる仕組みが必要

- PR単位で実行履歴やフェーズ（実装、QA等）毎の時間の割合を確認可能なダッシュボードを整備（裏側はBraintrustを利用）
- 人間がどの程度介入したか？等も確認
- AI開発フローの改善箇所を見つけるためトレースできると便利（LLM Ops / Evalの考えや仕組みから転用）

**計測指標:**

| 指標 | 説明 |
|---|---|
| 人間介入率 | PRに人間のコメントがあった割合 |
| 平均コメント数 | spec top-pr PRあたりの人間コメント |
| ノーティファイPR | 人間コメントなしでマージされたPR数 |

### ワークフローを作るだけでは足りなかった

- Background Coding Workflowは今でも便利に活用中
- 一方で、最終的にボトルネックと感じたのはAIの成果物を受け入れるプロセス
- AIに深く任せる / SDLCのAutomationにはAIの成果物を受け入れる仕組みの方が重要、コーディング単体は解決されつつある
- 特に力を入れているのは、**Browser Proof**と**AI Design System**
- Background Coding Workflowからの、切り出しを進めている

---

## Browser QAへの投資

### Browser QAの仕組みに投資する理由

ソフトウェア開発サイクルの自動化「AIに深く任せる」が回りやすくなる。失敗したシナリオは、次のAIへの入力 or Caseとして再利用できる。

画面操作からバグを見つけ、ひたすら修正のループがローカル環境でもクラウド環境でも実行できる。

| 利点 | 説明 |
|---|---|
| **画面が成果物である** | ユーザーが評価するのはコードではなく画面なので、ブラウザ上の状態を証拠として残す必要がある |
| **レビュー負荷を下げる** | スクリーンショットや動画があると、レビュアーは差分を読む前に成立状況を把握できる |
| **AIに戻しやすい** | 失敗した画面、ログ、操作手順が揃うと、AIへ具体的なFix Targetを渡せる |
| **Eval化しやすい** | 同じシナリオを繰り返し実行できれば、Browser QAはEval Harnessへ育てられる |

### Browser QAでAI出力まで評価する

Browser QAを、AIプロダクト自体のオンライン評価にも利用。ユーザー操作からAI出力までを、実ブラウザ上のシナリオとして評価する。プロダクトEvalのcaseや観点の判定も合わせて実行可能に。

```
1. Scenario
   ユーザー操作と入力文脈を、評価したい体験として定義する
        ↓
2. Browser Run
   画面操作とAIタスク実行を、実利用に近い流れで走らせる
        ↓
3. Observation
   画面状態、AI出力、ログを同じ評価対象として観測する
        ↓
4. Gate / Judge
   UI成立性とAI出力妥当性を分けて判定する
        ↓
5. Review Packet
   スケショ、動画、出力、判定理由を人間が受け取れる形にする
        ↓
6. Eval Case
   失敗を次の評価ケースに戻し、ハーネスを育てる
```

### Browser Proof: 画面確認もAgentic Workflowに

Browser QA Agentsで、UI変更を証拠付きで受け取る。今は第三世代への移行中。画面ベースでの動作確認をチーム全体の共通Eval / ハーネスに。

| 世代 | 技術 | 特徴と課題 |
|---|---|---|
| **第一世代: Local Skill** | Playwright MCP | AIがローカルブラウザ操作と画面確認を実行。ローカル環境に依存し、チーム運用に載せにくかった |
| **第二世代: Workflow** | Claude Agent TypeScript SDK | Agentic Workflow化。PR上でクラウド実行を可能にしたが、コストや実行効率、シナリオ再利用に課題 |
| **第三世代: Eval Harness** | Browserbaseベース | クラウド実行、録画、cache、シナリオ管理を統合。ブラウザベースでのEval Harnessに |

※ デザインレビューや操作ドキュメント生成等も組み込んでいる途中

### Browserbase

AI agent向けにクラウドブラウザとWeb Data APIを提供し、ログイン・JS・動的UIを含むWebをAPIのように扱えるようにする。

**事例:** Rampのfinance agent事例でもvendor siteやmerchant portalをブラウザで操作・自動化。

**参照:** https://www.browserbase.com/blog/how-ramp-built-its-new-finance-agents-on-browserbase

---

## AI Design System

### AI Design Systemは、UI生成のRubric

デザインシステムは、AIに渡す部品表 + UI判断ガイドライン。

AI CodingやBackground Coding Workflowに投資する中で、Gateを引くのが難しかった / 人によるブレが大きかったのがUI / Design。

| 要素 | 説明 |
|---|---|
| **Components** | 利用できる部品と役割を明確にし、AIが新しいUIを勝手に発明しないようにする |
| **Tokens** | 色、余白、フォント、角丸、影のルールを渡し、見た目のばらつきを抑える |
| **Patterns** | 一覧、詳細、フォーム、空状態、エラー状態の型を示し、画面構成の迷いを減らす |
| **Constraints** | 禁止パターン、アクセシビリティ、レスポンシブ案件を明文化し、受け入れ条件につなげる |

---

## Verifiability（検証可能性）

### Vibe Coding（という名称）の生みの親によるVerifiability

**Verifiableなタスクは、最適化・自動改善の対象にしやすい**

- **Software 1.0:** 指定できることを自動化しやすい
- **Software 2.0:** 検証できることを自動化しやすい

**引用:** https://karpahy.bearblog.dev/verifiability/

### Verifiability（検証可能性）

AIの答えや行動が「正しいかどうか」を、自動的に判定できるか？ Verifiableなタスクは、AIは最適化・自動改善の対象にしやすい。

| Software 1.0（従来） | Software 2.0（AI時代） |
|---|---|
| 予測因子: **Specificability（明示性）** | 予測因子: **Verifiability（検証可能性）** |
| タスクを明確なアルゴリズムとして記述する | 目的を指定し、AIがプログラムを探索する |
| 例: タイピング、簿記 | 例: 自動運転、画像認識 |

### Verifiabilityなタスクの3条件

以下3つの特性を満たせば、自動化されたフィードバックループを回せる。元はAIの学習について。参考にできる点は多々ありそう。

| 条件 | 問い | 説明 |
|---|---|---|
| **Resettable** | 何度でも最初からやり直せるか？ | タスクを繰り返し、初期状態から何度もやり直せること。AIは試行錯誤を繰り返して、フィードバックサイクルを回せる |
| **Efficient** | 短時間で大量の試行ができるか？ | タスクを高速に反復実行できること。膨大な量の練習やサイクルを回せることが最適化の高速化が期待できる |
| **Rewardable** | 結果の良し悪しを自動でスコアリングできる？ | タスクの結果を明確なスコアや基準で自動的に評価できること。AIは何が良い結果かを学習できる |

---

## まとめ

### 「良い出力が出やすい環境と出たものを証明・確認する仕組み」

生成前の制約と、生成後の証拠/レビューを揃えることが、AIに委任する条件。SDLCの自動化を進めるには、このような設計が必要ではないか。

```
1. AI Design System
   生成前に、選べる部品・守る制約・参照できる例を与える
        ↓
2. Browser Agent
   生成後に、実ブラウザで動いていることとAI出力の妥当性を確認する
        ↓
3. Review Packet
   スケショ、動画、ログ、判定理由を人間が判断できる形で受け取る
        ↓
4. Feedback Loop
   失敗をrule、scenario、component、workflowへ展開
```

### まとめ

- AIに深く任せるほど、ボトルネックは「生成」から「受け入れ可能性」へ
- Evalの考えは、AIプロダクトだけでなく、AI開発フローにも適用できる
- 開発側では、Specで入口を抑え、Review Packet / Browser Proofで出口を証明する取り組みに力を入れている
- それによりAIに作業を委任できる環境、ループの設計を目指す
- AIに任せるとは、入力・出力・Evalからなるループを設計すること、受け入れ可能性を設計すること

### 改めて取り組みの中で感じたこと

- Background Coding Workflowによる自動PRマージ率は数十%には到達（ライブラリアップデートや挙動の変更がない自動リファクタリング含む）
- 一番の要因になったのは、AIコーディングではなく、AIブラウザQAやAIレビュー等のテスト／レビュー／確認工程の自動化・AI化
- **重要なのはAIへの委任条件や環境、ループをどう設計するか？**

---

*© 2026 Asterminds株式会社 / AIE2026 Day2 セッション資料より*
