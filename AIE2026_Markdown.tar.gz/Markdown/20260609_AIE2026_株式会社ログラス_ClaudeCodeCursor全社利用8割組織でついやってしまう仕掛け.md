# ClaudeCode/Cursor全社利用 80% — 組織でついやってしまう仕掛け

**AI Engineering Summit Tokyo 2026 Summer**
**2026年06月09日**

株式会社ログラス
社長室 AI Opsチームマネージャー
荒木慎平

Loglass

---

## 自己紹介

**しんちゃん** (X: @shim_surprise)

### 経歴

- 慶應義塾大学 / 大学院 & Leibniz Universität 🇩🇪
- TOTO: ウォシュレット生産本部 エンジニア
- freee: freee会計 プロダクトマネージャー
- **ログラス: 社長室 AI Opsチーム マネージャー**
- **【専門: 組織全体へのAI実装と定着 / AI駆動経営の実装】**

### 社外AI活動

- **Cursor Ambassadors** — 公式アンバサダー
- **書籍（予定）**
- **AIOps Community Tokyo vol.5** — 9/19(土) @Ubieオフィス / 参加無料 / スラッシュコマンドハッカソン / コミュニティ運営

### 好きなこと / 特技

- テニス 🎾（ベンチ 100kg）
- ハンバーガー 🍔
- スマホプラ 🎮 魔卒
- AtCoder 水色
- トナカイの国際運転免許 🎅

---

## 本編

1. 私のしくじり
2. 大事な3つのポイント
3. まとめ：今日から始められること

---

## 今日の想定視聴者

### ツール導入・PoCじゃなくて、しっかり AIを定着させたい方

- 「ツールを導入」フェーズを超えて「ちゃんと浸透させて成果」を出したい方
- 一部の熱心な人/部署だけが使って、全社成果につながらないので、改善したい方
- PoCを本番運用に定着させたい方

> *組織のフェーズや役割によって大きく変わるので、noteもご参照ください*

---

## こんなこと社内で起こってないですか？

### 事例1: ムーブメント・熱量だけで押し切る！

- SNSなどでAI活用の事例をみかける。せや、ツール導入するぞ！全社勉強会やるぞ！
- 1回やって終わり、熱量・勢いが継続しない。有志的に勉強会が始まるが一定期間経つと自然消滅する

### 事例2: AIで今の業務を全自動化しよう！

- 丸ごとなくしたい！効果が測りやすい！
- 「全自動化1000時間削減」なんとなくかっこいい。SNSでも見かける。
- AIに丸投げして構築したけど、むっちゃ時間かかった。出来上がっても、AIのアップデートでうまく動かない or 不要になる

### 事例3: 最新のツール・機能をたくさん紹介するぞ！

- SNSで、最新のアップデートを知る。すごい機能が出てる！いろんなAIサービス、ツール、MCP、スキル、機能を紹介する。
- 結局、業務にどう活かすかわからない…

> **「組織のAI活用」＝「個人の活用 × 人数」** — 本当に？？？

---

## 「個人的」に遊んでいる AI・便利ツール

### AI Coding & Agentic IDE

Cursor / Google Antigravity / Windsurf / Codex / Roo Code (Cline) / Devin / OpenDevin / Factory / Manus / Prism / Amazon Q Developer / Quick Suite / OpenCode / JetBrains / Copilot / CopilotStudio / CodeRabbit

### Generative UI & Full-stack Dev

Bolt.new / Lovable / Replit Agent / v0 / Figma Make / Google Code Wiki / MCP App (Interactive App) / Streamlit

### Automation & Workflow

Google Workflows·Studio / n8n / Make / Zapier / sim ai / Dify / Langflow / Flowise / Mastra / Argos / GAS / clasp / MCP (Model Context Protocol) / CrewAI / MGX / ChatPRD / GitHub Actions / Claude Code GitHub Actions / OpenClaw (moltbot, clawdbot)

### Generative Media

- **Video**: Runway / Hailuo AI / Veo / Vids / HeyGen / Sora / Genie3 / Remotion
- **Image**: Midjourney / Stable Diffusion / Adobe Firefly / Canva AI / Seadream / Flux / Pencil / Stich
- **Audio**: ElevenLabs / Suno / kits / Whisper / Amazon Transcribe / Grok Speech
- **Voice**: superwhisper / aquavoice / Genspark Speakly

### Search & Data Collection (RAG)

Google File Search API / Tavily / Perplexity / Genspark / Murquerry / Felo / Firecrawl / Watercraw / Jina Reader / Graphiti

### LLM Ops & Evaluation

LangChain / LangGraph / LangGraph Studio / LangSmith / Langfuse / Hugging Face / OpenRouter / LM Arena / Design Arena / MagicArena / Ragas / vLLM / Comet / Computer / SQLite

### Developer Tools & Infrastructure

Ghosty with glow and yazi / Jujutsu / Snowflake / GA4

### Knowledge & Productivity

NotebookLM / Obsidian (Clipper) / Mapify / Napkin / Gamma / Page Sidebar / Kiro / Opal / Nano-banana / Notion AI / Slack AI

### LLM & Foundation Models

OpenAI (GPT-4o / o1 / Realtime API / GPT-OSS) / Google Gemini (Pro / CLI / Extension / AI Mode / nano) / Anthropic Claude (Opus / Claude Code / App / Desktop / Cowork / Plugin) / xAI Grok / Cohere / Mistral / Kimi / Nemotron / Qwen / Gemma / Ollama / Meta Llama 3 / DeepSeek / Phi

### Others

Lakera Guard / Microsoft Security Copilot / Snyk / Menlo Security / CrowdStrike Falcon / GitGuardian / Atlas / dia / Arc / commet / Heptabase / agentresistry / Lovart / ailbreak

などなど

---

## 「世の中の情報」を用いた「漠然とした打ち手」 vs 「自分の組織の課題」に沿った「明確な仕掛け」

### ❌ 世の中の情報に振り回される

世の中のAI情報に翻弄され、不安・焦りから漠然とした打ち手を繰り返す。

### ✅ 自分の組織の課題に沿った明確な仕掛け

1. **可視化** — 現実を把握する
2. **Gap（課題）の特定** — 理想とのギャップを明確にする
3. **小さな成功体験** — 理想へ向けて段階的に進む

> **課題を研ぎ澄ませ！**

---

## 本編

1. 私のしくじり
2. **大事な3つのポイント** ←
3. まとめ：今日から始められること

---

## ① 可視化 — まず、徹底的な可視化

現実から理想へのGAPを埋める第一段階。

### AI導入フェーズ別プロジェクト開発プロセス

| フェーズ | Phase 1: AI-Assisted (Active Support) | Phase 2: AI-Enabled (Collaborative / Workflow) |
|----------|--------------------------------------|------------------------------------------------|
| User Research | ✅ | ✅ |
| Model Research | ✅ | ✅ |
| Requirements Definition | ✅ | ✅ |
| ... | ... | ... |

### 利用状況に応じて、適切な対策ができる

| ステージ | AI利用率 |
|----------|---------|
| Early | 51%（10〜20%） |
| 成熟期 | **80%** |

### 例えば — 確認すべき質問

- 利用回数（定量）/ 利用状況（定性）は？
- 部署別だと違いはある？
- 活用している人は誰？
- 何でできているかできていない？
- 誰が協力してくれる？
- CXO、部長、メンバーのレイヤーでの違いは？

---

## ② 課題特定 — やるべき「課題」を1つ特定する

- ユーザーはAIが使いたいのではなく、いい感じに困っていることを解消したいだけ
  - AIで素早くPoCを作り、理想とGAPの言語化を行う
- PoCが定着しないのは、
  - 本番運用を見据えすぎているのかも。一撃では言語化と適切なHowは出てこない
  - とりあえずやってみようで作ってるのかも。**現実の課題に沿ってない可能性あり。**

---

## ツールも「課題」の段階ごとに開放する

### AI活用

① AIに対応指示 → ② 必要データを探索 → ③ 該当データを抽出 → ④ アウトプット出力

- 徹底的にChatGPT、Gemini、NotebookLMなどの「AI活用」を行う

### ナレッジ蓄積

- 「ナレッジ蓄積」をしたくなったらCursor、ClaudeCode、Codexなど

### AIレベルを可視化

レベル1〜8で段階的に可視化。

---

## ③ 成功体験 — その職種にあった、シンプルなユースケースで「自己効用感」を！

1. 1番時間がかかっている or 簡単に効率化できそうな業務を1つ効率化しましょう！
2. 実装も操作もシンプルなもので「1つ」成功体験を！
3. 1つ成功体験が持てれば、自然に浸透します

### 例

**エンジニア:**
AIレビュー自動化、rules/skills展開、mdじゃなくてhtml/drawio、仕様書Github管理

**Biz:**
メール・議事録、業界分析、入力・アラート、AIマネージャーレビュー、AIロープレ

> *(お客様の業界分析：3日の開発で年間1000時間の業務削減 → 事業数値目標の大幅達成も)*

---

## 本編

1. 私のしくじり
2. 大事な3つのポイント
3. **まとめ：今日から始められること** ←

---

## 今日から何を始めれば良いか？

### 「徹底的に」可視化する

- 自分・チームがどれくらいAIを使っているか知る
- 何ができて、何ができないのかを把握する
- 他の人に説明できること/できないことを整理する

### 「課題」を特定する

- 理想を決める
- 課題を洗い出す
- 優先度をつける

### 「小さな」成功体験を積み上げる

- 1個のAIを使い込む
- 新しいAIを1つだけ5分触ってみる
- 簡単な事例1つを周りに広める

---

## よく聞かれる質問

### CursorとClaudeCodeの使い分けは？

- **Cursor**: UIが使いやすい + モデル切り替えできる。ビジネス職は使いやすい
- **ClaudeCode**: Cursor慣れた + AI活用とナレッジ蓄積が一定できてきた人向け

### AI活用がちゃんとできているとは？

- 他の人/チームに教えられる
- 機能だけでなく、どう業務に落とし込めば良いか説明できる

### AI初心者は何から始めれば良いですか？

- ChatGPTを徹底的に
- 慣れてきたら聞いたことあるツールから
  - ChatGPT/Claude → Codex/ClaudeCodeなど
- 音声入力でタイピングを減らそう

---

**Loglass**

> 良い景気を作ろう。
