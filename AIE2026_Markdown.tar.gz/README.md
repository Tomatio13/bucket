# AI Engineering Summit Tokyo 2026

![logo](assets/logo.svg)

この README は、`AI Engineering Summit Tokyo 2026` の登壇メモを後から辿りやすくするための入口です。

## 📖 読み方

| 目的 | まず読む | 内容 |
| --- | --- | --- |
| 全体像を掴む | [AIEngineeringSummitTokyo2026サマリー.md](./AIEngineeringSummitTokyo2026サマリー.md) | イベント全体の論点、カテゴリ、施策整理 |
| どの登壇を読むか決める | [AIEngineeringSummitTokyo2026サマリー.md](./AIEngineeringSummitTokyo2026サマリー.md) | 登壇比較表、社内活用の読み分け |
| 当日の流れを確認する | [AIEngineeringSummitTokyo2026タイムテーブル要約.md](./AIEngineeringSummitTokyo2026タイムテーブル要約.md) | Day1 / Day2 の抜粋タイムテーブル |
| 自社施策と比較する | [AIEngineeringSummitTokyo2026自社チェックリスト.md](./AIEngineeringSummitTokyo2026自社チェックリスト.md) | 比較用チェックリスト |


## 📌まず押さえること

- 全体テーマは、`AIで速く作る` から `AI前提で組織・工程・統制を再設計する` への移行。
- 論点は大きく `組織定着` `開発フロー再設計` `品質保証/Eval` `統制と安全` `実行基盤` `プロダクト実装` に分かれる。
- 強い事例は、単体ツール導入より `可視化` `知識集約` `ガードレール` `評価ループ` `権限制御` をセットで持っています。

## 🛫 最短ルート

1. [AI Engineering Summit Tokyo 2026 サマリー.md](./AI%20Engineering%20Summit%20Tokyo%202026%20サマリー.md) の `施策を3層で見る` を読む。
2. `登壇比較表` で、自社が近い登壇を見つける。
3. `自社チェックリスト` で、現状施策との差分を書く。
4. 必要になったら [AI Engineering Summit Tokyo 2026 タイムテーブル要約.md](./AI%20Engineering%20Summit%20Tokyo%202026%20タイムテーブル要約.md) で元登壇を探す。
