# Repository Guidelines

This repository is an early-stage knowledge-extraction project. Keep changes small, document intent, and favor clarity over cleverness.

## Project Structure & Module Organization
- `README.md`: Project goals, scope, and the planned workflow for extracting knowledge from meeting recordings.
- New modules should live under `src/` (e.g., `src/prompts/`, `src/pipelines/`) and tests under `tests/`.
- Example data or fixtures should go under `data/` (e.g., `data/recordings/`, `data/expected/`).

## Build, Test, and Development Commands
No build or test commands are defined yet.
- When you introduce a toolchain, add commands to `README.md` and mirror them here.
- Example conventions to adopt:
  - `npm run dev`: run a local dev server or CLI.
  - `npm test`: run the automated test suite.

## Coding Style & Naming Conventions
- Prefer simple, readable code with short functions and explicit names.
- Use consistent indentation (2 spaces for JS/TS, 4 spaces for Python) once a language is chosen.
- Name prompt files with clear intent, e.g., `prompts/knowledge_extraction_v1.md`.
- Add lint/format tools when code is introduced (e.g., `eslint`, `ruff`, `prettier`) and document exact configs.

## Testing Guidelines
- Add tests alongside new extraction logic; focus on behavior (input → expected output).
- Name tests after the scenario, e.g., `tests/test_prompt_parsing.py`.
- If fixtures are used, store them under `data/` with a short README in that folder.

## Commit & Pull Request Guidelines
This repository is not yet a Git repository, so no commit history exists.
- When Git is initialized, use Conventional Commits (`feat:`, `fix:`, `docs:`).
- PRs should include: a brief summary, the problem statement, and sample inputs/outputs.

## Security & Configuration Tips
- Never hardcode API keys; use environment variables and document them in `README.md`.
- Treat meeting recordings and extracted knowledge as sensitive data; avoid committing raw transcripts.

## Agent-Specific Instructions
- Keep the contributor guide within 200–400 words and update it as the structure evolves.
