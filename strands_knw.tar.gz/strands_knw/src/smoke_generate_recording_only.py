import argparse
import json

from pydantic import BaseModel, Field

from agent_utils import build_agent, load_env
from schemas import KnowledgeItem, Persona


class RecordingOnly(BaseModel):
    recording_markdown: str = Field(description="擬似レコーディング結果（Markdown）")
    personas: list[Persona] = Field(description="登場人物ペルソナ一覧")
    knowledge_items: list[KnowledgeItem] = Field(description="正解ナレッジ一覧")


def build_prompt(input_markdown: str) -> str:
    return f"""\
あなたはシステム開発の会議レコーディングを擬似的に生成するアシスタントです。
以下のMarkdownを入力として、擬似レコーディング結果、登場人物のペルソナ、正解ナレッジを作成してください。

要件:
- 出力はMarkdownで、会話形式（話者名 + 発話）にする
- 形式は必ず箇条書きで統一する（例: "- [00:02] **山田**: 〜"）
- 各発話には分:秒のタイムスタンプを付与する（例: 00:02）
- 10〜15分程度の会議を想定し、開始は00:00、終了は10:00〜15:00になるようにする
- 会議の目的、課題、意思決定、未決事項が含まれる
- 人物は3〜4名程度、役割が偏らないように
 - ペルソナは名前・役割・背景を簡潔にまとめる
 - 正解ナレッジは工程別・領域別の観点を含める

ナレッジの定義：
 以下をナレッジと定義し、会話の中であたかも話者しか知らない/他のメンバが初めて聞くような
 会話を入れてください。
 - 属人的: 特定の個人が経験を通じて身につけている情報

入力Markdown:
{input_markdown}
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate pseudo recording only.")
    parser.add_argument("input", help="Input markdown file path")
    parser.add_argument(
        "--out-recording",
        default="outputs/pseudo_recording.md",
        help="Output recording markdown path",
    )
    parser.add_argument(
        "--out-personas",
        default="outputs/personas.json",
        help="Output personas JSON path",
    )
    parser.add_argument(
        "--out-knowledge",
        default="outputs/knowledge_items.json",
        help="Output knowledge items JSON path",
    )
    args = parser.parse_args()

    input_markdown = open(args.input, "r", encoding="utf-8").read()
    config = load_env()
    agent = build_agent(config)

    result = agent(
        build_prompt(input_markdown),
        structured_output_model=RecordingOnly,
    ).structured_output

    with open(args.out_recording, "w", encoding="utf-8") as f:
        f.write(result.recording_markdown.strip() + "\n")

    with open(args.out_personas, "w", encoding="utf-8") as f:
        f.write(
            json.dumps([persona.model_dump() for persona in result.personas], ensure_ascii=False, indent=2)
            + "\n"
        )

    print(f"Wrote: {args.out_recording}")
    print(f"Wrote: {args.out_personas}")

    with open(args.out_knowledge, "w", encoding="utf-8") as f:
        f.write(
            json.dumps([item.model_dump() for item in result.knowledge_items], ensure_ascii=False, indent=2) + "\n"
        )

    print(f"Wrote: {args.out_knowledge}")


if __name__ == "__main__":
    main()
