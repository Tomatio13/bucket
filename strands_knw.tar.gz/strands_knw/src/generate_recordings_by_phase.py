import argparse
import json
import re
from pathlib import Path

from agent_utils import build_agent, load_env
from schemas import RecordingPack

ORDERED_PHASES = [
    "要件定義",
    "基本設計",
    "詳細設計",
    "実装",
    "単体試験",
    "結合試験",
    "総合試験",
    "運用準備",
]


def build_prompt(input_markdown: str, phase: str) -> str:
    return f"""\
あなたはシステム開発の会議レコーディングを擬似的に生成するアシスタントです。
以下のMarkdownを入力として、擬似レコーディング結果、登場人物ペルソナ、正解ナレッジを作成してください。

要件:
- 擬似レコーディング結果はMarkdownで、会話形式（話者名 + 発話）にする
- 形式は必ず箇条書きで統一する（例: "- [00:02] **山田**: 〜"）
- 各発話には分:秒のタイムスタンプを付与する（例: 00:02）
- 10〜15分程度の会議を想定し、開始は00:00、終了は10:00〜15:00になるようにする
- 会議の目的、課題、意思決定、未決事項が含まれる
- 人物は3〜4名程度、役割が偏らないように
- 正解ナレッジは工程別・領域別の観点を含める

工程: {phase}

入力Markdown:
{input_markdown}
"""


def remove_meeting_purpose_section(lines: list[str]) -> list[str]:
    result: list[str] = []
    in_section = False
    for line in lines:
        if line.strip().startswith("## "):
            if line.strip() == "## 会議目的":
                in_section = True
                continue
            in_section = False
        if not in_section:
            result.append(line)
    return result


def extract_phase_line(input_markdown: str) -> str | None:
    for line in input_markdown.splitlines():
        if line.strip().startswith("- 対象工程:"):
            return line.split(":", 1)[1].strip()
    return None


def expand_phases(raw: str | None) -> list[str]:
    if not raw:
        return ORDERED_PHASES[:]

    normalized = raw.replace(" ", "")
    if "〜" in normalized:
        start, end = normalized.split("〜", 1)
        if start in ORDERED_PHASES and end in ORDERED_PHASES:
            start_idx = ORDERED_PHASES.index(start)
            end_idx = ORDERED_PHASES.index(end)
            if start_idx <= end_idx:
                return ORDERED_PHASES[start_idx : end_idx + 1]

    parts = re.split(r"[、,/・]", normalized)
    phases = [p for p in parts if p]
    return phases or ORDERED_PHASES[:]


def build_meeting_purpose(phase: str) -> list[str]:
    agenda_map = {
        "要件定義": "要件定義の範囲と優先度のレビュー",
        "基本設計": "基本設計書のレビューと設計方針の合意",
        "詳細設計": "詳細設計書のレビューと未決事項の整理",
        "実装": "実装方針・影響範囲の確認",
        "単体試験": "単体試験項目のレビュー",
        "結合試験": "結合試験計画・項目のレビュー",
        "総合試験": "総合試験計画・受入観点のレビュー",
        "運用準備": "運用準備の体制と手順のレビュー",
    }
    decision_map = {
        "要件定義": "要件の優先順位と範囲確定",
        "基本設計": "主要な設計方針と非機能要件の基準",
        "詳細設計": "詳細設計の修正方針と未決事項の期限",
        "実装": "実装スケジュールとレビュー観点",
        "単体試験": "試験観点の確定と担当割当",
        "結合試験": "試験範囲と実施順序の確定",
        "総合試験": "受入基準と実施体制の確定",
        "運用準備": "運用移行の役割分担と手順確定",
    }
    open_map = {
        "要件定義": "未確定のステークホルダー要望の整理",
        "基本設計": "外部連携方式の最終確認",
        "詳細設計": "性能・例外処理の詳細詰め",
        "実装": "既存資産の流用可否",
        "単体試験": "自動化範囲と環境制約",
        "結合試験": "結合試験環境の準備状況",
        "総合試験": "負荷試験の条件と実施時期",
        "運用準備": "監視項目と障害対応フロー",
    }

    agenda = agenda_map.get(phase, f"{phase}のレビュー")
    decision = decision_map.get(phase, f"{phase}の合意事項の確定")
    open_item = open_map.get(phase, f"{phase}で残す未決事項の整理")
    return [
        f"- 議題: {agenda}",
        f"- 期待する決定事項: {decision}",
        f"- 未決事項として残したい点: {open_item}",
    ]


def build_phase_input(original_markdown: str, phase: str) -> str:
    lines = remove_meeting_purpose_section(original_markdown.splitlines())
    meeting_lines = ["## 会議目的"] + build_meeting_purpose(phase)
    if lines and lines[-1].strip() != "":
        lines.append("")
    return "\n".join(lines + [""] + meeting_lines) + "\n"


def write_outputs(out_dir: Path, result: RecordingPack) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    recording_path = out_dir / "pseudo_recording.md"
    personas_path = out_dir / "personas.json"
    knowledge_path = out_dir / "knowledge_items.json"

    recording_path.write_text(result.recording_markdown.strip() + "\n", encoding="utf-8")
    personas_path.write_text(
        json.dumps([persona.model_dump() for persona in result.personas], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    knowledge_path.write_text(
        json.dumps([item.model_dump() for item in result.knowledge_items], ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate pseudo recordings for each phase.")
    parser.add_argument("input", type=Path, help="Input markdown file path")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs/phases"),
        help="Output directory for each phase",
    )
    args = parser.parse_args()

    original_markdown = args.input.read_text(encoding="utf-8")
    phases = expand_phases(extract_phase_line(original_markdown))

    config = load_env()
    agent = build_agent(config)

    for idx, phase in enumerate(phases, start=1):
        phase_input = build_phase_input(original_markdown, phase)
        result = agent(
            build_prompt(phase_input, phase),
            structured_output_model=RecordingPack,
        ).structured_output

        out_dir = args.out_dir / f"phase_{idx:02d}"
        write_outputs(out_dir, result)
        (out_dir / "input.md").write_text(phase_input, encoding="utf-8")

        print(f"Wrote: {out_dir}")


if __name__ == "__main__":
    main()
