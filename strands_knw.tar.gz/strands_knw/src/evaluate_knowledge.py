import argparse
import json
from pathlib import Path

from agent_utils import build_agent, load_env
from schemas import EvaluationReport


def build_prompt(ground_truth: list[dict], extracted: list[dict]) -> str:
    return f"""\
以下の2つのナレッジ一覧を比較し、抽出結果の品質を評価してください。

評価観点:
- 工程ごとの網羅性
- 正確性（余計なナレッジの混入）
- 重要度の高い情報の取りこぼし

出力要件:
- overall_score は0〜100の整数
- phase_scores は工程ごとのスコア（整数）
- missing_items は正解にあって抽出にない項目
- extra_items は抽出にあって正解にない項目
- key_gaps は改善ポイントの箇条書き

正解ナレッジ:
{json.dumps(ground_truth, ensure_ascii=False, indent=2)}

抽出ナレッジ:
{json.dumps(extracted, ensure_ascii=False, indent=2)}
"""


def render_markdown(report: EvaluationReport) -> str:
    lines = [
        "# 評価レポート",
        "",
        f"- 総合スコア: {report.overall_score}",
        "",
        "## 工程別スコア",
    ]
    for phase, score in report.phase_scores.items():
        lines.append(f"- {phase}: {score}")

    lines.extend(["", "## 欠落ナレッジ"])
    if report.missing_items:
        for item in report.missing_items:
            lines.append(f"- [{item.category}] {item.summary}")
            lines.append(f"  - evidence: {item.evidence}")
    else:
        lines.append("- なし")

    lines.extend(["", "## 過剰/誤検出ナレッジ"])
    if report.extra_items:
        for item in report.extra_items:
            lines.append(f"- [{item.category}] {item.summary}")
            lines.append(f"  - evidence: {item.evidence}")
    else:
        lines.append("- なし")

    lines.extend(["", "## 改善ポイント"])
    if report.key_gaps:
        for gap in report.key_gaps:
            lines.append(f"- {gap}")
    else:
        lines.append("- なし")

    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate extracted knowledge quality.")
    parser.add_argument("ground_truth", type=Path, help="Ground truth knowledge JSON")
    parser.add_argument("extracted", type=Path, help="Extracted knowledge JSON")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs"),
        help="Output directory",
    )
    args = parser.parse_args()

    ground_truth = json.loads(args.ground_truth.read_text(encoding="utf-8"))
    extracted = json.loads(args.extracted.read_text(encoding="utf-8"))

    config = load_env()
    agent = build_agent(config)

    report = agent(
        build_prompt(ground_truth, extracted),
        structured_output_model=EvaluationReport,
    ).structured_output

    args.out_dir.mkdir(parents=True, exist_ok=True)
    output_json = args.out_dir / "evaluation_report.json"
    output_md = args.out_dir / "evaluation_report.md"

    output_json.write_text(
        json.dumps(report.model_dump(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    output_md.write_text(render_markdown(report), encoding="utf-8")

    print(f"Wrote: {output_json}")
    print(f"Wrote: {output_md}")


if __name__ == "__main__":
    main()
