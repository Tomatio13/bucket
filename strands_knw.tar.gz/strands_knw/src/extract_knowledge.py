import argparse
import json
from pathlib import Path

from agent_utils import build_agent, load_env
from schemas import KnowledgeExtraction


def build_prompt(recording_markdown: str) -> str:
    return f"""\
以下の擬似レコーディング（Markdown）から、工程別・領域別のナレッジを抽出してください。

要件:
- ナレッジは工程や領域ごとに分類する
- summary は簡潔に、evidence は録音内の根拠となる発話を含める
- 形式は構造化出力の KnowledgeExtraction に合わせる

擬似レコーディング:
{recording_markdown}
"""


def render_markdown(items: list[dict]) -> str:
    lines = ["# 抽出ナレッジ", ""]
    for item in items:
        lines.append(f"- [{item['category']}] {item['summary']}")
        lines.append(f"  - evidence: {item['evidence']}")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract knowledge from pseudo recordings.")
    parser.add_argument("input", type=Path, help="Pseudo recording markdown path")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs"),
        help="Output directory",
    )
    args = parser.parse_args()

    recording_markdown = args.input.read_text(encoding="utf-8")
    config = load_env()
    agent = build_agent(config)

    result = agent(
        build_prompt(recording_markdown),
        structured_output_model=KnowledgeExtraction,
    ).structured_output

    args.out_dir.mkdir(parents=True, exist_ok=True)
    output_json = args.out_dir / "extracted_knowledge.json"
    output_md = args.out_dir / "extracted_knowledge.md"

    items = [item.model_dump() for item in result.knowledge_items]
    output_json.write_text(json.dumps(items, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    output_md.write_text(render_markdown(items), encoding="utf-8")

    print(f"Wrote: {output_json}")
    print(f"Wrote: {output_md}")


if __name__ == "__main__":
    main()
