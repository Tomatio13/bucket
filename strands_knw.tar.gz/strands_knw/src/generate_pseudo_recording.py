import argparse
import json
import re
from pathlib import Path

from agent_utils import build_agent, load_env
from schemas import RecordingPack


def build_prompt(input_markdown: str) -> str:
    return f"""\
あなたはシステム開発の会議レコーディングを擬似的に生成するアシスタントです。
以下のMarkdownを入力として、擬似レコーディング結果、登場人物ペルソナ、正解ナレッジを作成してください。

要件:
- 擬似レコーディング結果はMarkdownで、会話形式（話者名 + 発話）にする
- 擬似レコーディングは最低10発話以上にする
- 形式は必ず箇条書きで統一する（例: "- [00:02] **山田**: 〜"）
- 1回の会議は10〜15分程度とし、開始は00:00、終了は10:00〜15:00になるようにする
- 各発話には分:秒のタイムスタンプを付与する（例: 00:02）
- 会議の目的、課題、意思決定、未決事項が含まれる
- 人物は3〜4名程度、役割が偏らないように
- 正解ナレッジは工程別・領域別の観点を含める
- 工程の例: 要件定義、基本設計、詳細設計、実装、単体試験、結合試験、総合試験、運用準備

入力Markdown:
{input_markdown}
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate pseudo recording using Strands Agents.")
    parser.add_argument("input", type=Path, help="Input markdown file path")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("outputs"),
        help="Output directory",
    )
    args = parser.parse_args()

    input_markdown = args.input.read_text(encoding="utf-8")
    config = load_env()
    agent = build_agent(config)
    print(input_markdown)

    result = agent(
        build_prompt(input_markdown),
        structured_output_model=RecordingPack,
    ).structured_output

    utterance_count = 0
    timestamps: list[int] = []
    timestamp_pattern = re.compile(r"^- \[(\d{2}):(\d{2})\] ")
    for line in result.recording_markdown.splitlines():
        stripped = line.strip()
        match = timestamp_pattern.match(stripped)
        if match:
            minutes = int(match.group(1))
            seconds = int(match.group(2))
            timestamps.append(minutes * 60 + seconds)
            utterance_count += 1
    if utterance_count < 10:
        raise RuntimeError(f"Insufficient recording utterances: {utterance_count}")

    if not timestamps:
        raise RuntimeError("No timestamps found in recording output.")

    start_ts = min(timestamps)
    end_ts = max(timestamps)
    duration_seconds = end_ts - start_ts
    if duration_seconds < 10 * 60 or duration_seconds > 15 * 60:
        raise RuntimeError(
            f"Recording duration out of range: {duration_seconds} seconds"
        )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    recording_path = args.out_dir / "pseudo_recording.md"
    personas_path = args.out_dir / "personas.json"
    knowledge_path = args.out_dir / "knowledge_items.json"

    recording_path.write_text(result.recording_markdown.strip() + "\n", encoding="utf-8")
    personas_path.write_text(
        json.dumps([persona.model_dump() for persona in result.personas], ensure_ascii=False, indent=2)
        + "\n",
        encoding="utf-8",
    )
    knowledge_path.write_text(
        json.dumps([item.model_dump() for item in result.knowledge_items], ensure_ascii=False, indent=2)
        + "\n",
        encoding="utf-8",
    )

    print(f"Wrote: {recording_path}")
    print(f"Wrote: {personas_path}")
    print(f"Wrote: {knowledge_path}")


if __name__ == "__main__":
    main()
