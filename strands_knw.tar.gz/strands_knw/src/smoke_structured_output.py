import argparse

from pydantic import BaseModel, Field

from agent_utils import build_agent, load_env


class SimpleOutput(BaseModel):
    name: str = Field(description="Name of the person")
    age: int = Field(description="Age in years")


def main() -> None:
    parser = argparse.ArgumentParser(description="Smoke test for structured output.")
    parser.add_argument(
        "--prompt",
        default="Taro is 28 years old.",
        help="Input prompt for the model",
    )
    args = parser.parse_args()

    config = load_env()
    agent = build_agent(config)

    result = agent(
        args.prompt,
        structured_output_model=SimpleOutput,
    ).structured_output

    print(result.model_dump_json(indent=2))


if __name__ == "__main__":
    main()
