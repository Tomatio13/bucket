from pydantic import BaseModel, Field


class Persona(BaseModel):
    name: str = Field(description="人物名")
    role: str = Field(description="役割・職種")
    background: str = Field(description="専門性や立場の短い説明")


class KnowledgeItem(BaseModel):
    category: str = Field(description="工程や領域の区分")
    summary: str = Field(description="抽出されたナレッジの要約")
    evidence: str = Field(description="擬似レコーディング内の根拠")


class RecordingPack(BaseModel):
    recording_markdown: str = Field(description="擬似レコーディング結果（Markdown）")
    personas: list[Persona] = Field(description="登場人物ペルソナ一覧")
    knowledge_items: list[KnowledgeItem] = Field(description="正解ナレッジ一覧")


class KnowledgeExtraction(BaseModel):
    knowledge_items: list[KnowledgeItem] = Field(description="抽出されたナレッジ一覧")


class EvaluationReport(BaseModel):
    overall_score: int = Field(description="0-100の総合スコア")
    phase_scores: dict[str, int] = Field(description="工程別のスコア")
    missing_items: list[KnowledgeItem] = Field(description="不足しているナレッジ")
    extra_items: list[KnowledgeItem] = Field(description="誤検出や過剰なナレッジ")
    key_gaps: list[str] = Field(description="弱点や改善ポイントの要約")
