
## やりたいこと
システム開発ではノウハウ・ナレッジなどドキュメント化されずに属人化している知識が多々ある。
そこで、会議のレコーディング結果からLLMでナレッジを抽出して溜めていきたい。

## はじめの一歩

レコーディング情報からナレッジを抽出するプロンプトを作る。

## 使い方

### セットアップ
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

`.env` に OpenAI 互換APIの設定を記載する。
```
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL_ID=gpt-4o-mini
OPENAI_TEMPERATURE=0.4
OPENAI_MAX_TOKENS=1800
```

### 入力テンプレート
入力は Markdown で作成する。テンプレートは `templates/recording_input_template.md` を参照。

### 実行手順
1. 擬似レコーディング生成（Markdown/JSON出力）
```bash
python src/generate_pseudo_recording.py path/to/input.md --out-dir outputs
```
- `outputs/pseudo_recording.md`
- `outputs/personas.json`
- `outputs/knowledge_items.json`

2. ナレッジ抽出
```bash
python src/extract_knowledge.py outputs/pseudo_recording.md --out-dir outputs
```
- `outputs/extracted_knowledge.json`
- `outputs/extracted_knowledge.md`

3. 抽出結果の評価
```bash
python src/evaluate_knowledge.py outputs/knowledge_items.json outputs/extracted_knowledge.json --out-dir outputs
```
- `outputs/evaluation_report.json`
- `outputs/evaluation_report.md`

## 作りたい流れ

1. システム開発の要件定義から総合試験までの各工程の生産物レビューや、
各種の打ち合わせの擬似レコーディング結果を作りたい。

インプット情報：
　- 簡単なシステム概要や利用予定の言語

生成されてほしい物：
　- 擬似レコーディング結果
  - 擬似レコーディング結果に記載されている登場人物のペルソナ
　- 擬似レコーディング結果に含まれているナレッジ

  これは、作成したプロンプトから正しくナレッジが抽出されるか試験を行い、
　改善点を抽出できるようにしておく必要があるので、
　試験データとして利用する

2. 擬似レコーディング結果に対して、作成したナレッジ抽出プロンプトを適用して、
　ナレッジ抽出を行う

3. 抽出されたナレッジ出力結果と正解ナレッジと比較して、どの工程のどういうナレッジ抽出が弱いのか
　分析し、改善プロンプトする

## 想定されるシステム開発

プロンプトを利用するのは、公共システムや携帯キャリア会社等の大規模システムを開発しており、
ウォターフォール開発するSIerである。少なくとも開発要員は20名以上所属する
