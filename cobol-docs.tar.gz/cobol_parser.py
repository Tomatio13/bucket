from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Iterable


class Division(str, Enum):
    NONE = "NONE"
    IDENTIFICATION = "IDENTIFICATION"
    ENVIRONMENT = "ENVIRONMENT"
    DATA = "DATA"
    PROCEDURE = "PROCEDURE"


class SqlType(str, Enum):
    NONE = "NONE"
    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    CREATE = "CREATE"


@dataclass
class FileDefinition:
    logical_name: str
    physical_name: str


@dataclass
class Operation:
    kind: str
    target: str
    detail: str = ""
    conditions: str = ""


@dataclass
class CalledMethod:
    name: str
    module_flg: bool
    conditions: str
    method_list_index: int = -1

    @classmethod
    def from_conditions(
        cls, name: str, module_flg: bool, conditions: Iterable[str]
    ) -> "CalledMethod":
        normalized = " かつ ".join(f"【{condition}】" for condition in conditions)
        return cls(name=name, module_flg=module_flg, conditions=normalized)


@dataclass
class Method:
    method_name_p: str
    method_name_l: str
    start_index: int
    end_index: int = -1
    checkpoint_list: list[str] = field(default_factory=list)
    called_method_list: list[CalledMethod] = field(default_factory=list)
    operation_list: list[Operation] = field(default_factory=list)
    called_flg: bool = False

    def detect_check_point(self, word: str) -> bool:
        return self.method_name_p.replace("-PROC", "") in word

    def dedupe_called_methods(self) -> None:
        seen: set[str] = set()
        deduped: list[CalledMethod] = []
        for called_method in self.called_method_list:
            if called_method.name in seen:
                continue
            seen.add(called_method.name)
            deduped.append(called_method)
        self.called_method_list = deduped


@dataclass
class SqlInfo:
    value: str
    type: SqlType
    used_method_name: str
    cursor_name: str = ""

    def get_db_list(self) -> list[str]:
        patterns = (
            r"\bFROM\s+([A-Z0-9_\-\.]+)",
            r"\bJOIN\s+([A-Z0-9_\-\.]+)",
            r"\bINSERT\s+INTO\s+([A-Z0-9_\-\.]+)",
            r"\bUPDATE\s+([A-Z0-9_\-\.]+)",
            r"\bDELETE\s+FROM\s+([A-Z0-9_\-\.]+)",
            r"\bCREATE\s+TABLE\s+([A-Z0-9_\-\.]+)",
        )
        db_names: set[str] = set()
        normalized = self.value.upper()
        for pattern in patterns:
            db_names.update(re.findall(pattern, normalized))
        return sorted(db_names)


@dataclass
class CobolAnalysisResult:
    file_path: str
    copy_list: dict[str, str]
    file_definition_list: list[FileDefinition]
    called_module_list: list[str]
    method_list: list[Method]
    sql_info_list: list[SqlInfo]
    cursor_list: list[SqlInfo]

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, *, ensure_ascii: bool = False, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=ensure_ascii, indent=indent)

    def to_markdown(self) -> str:
        lines: list[str] = [
            "# COBOL詳細設計書",
            "",
            "## 1. プログラム概要",
            "",
            f"- 対象ファイル: `{self.file_path}`",
            f"- セクション数: {len(self.method_list)}",
            f"- 外部呼出モジュール数: {len(self.called_module_list)}",
            f"- COPY句数: {len(self.copy_list)}",
            f"- 入出力ファイル数: {len(self.file_definition_list)}",
            f"- SQL文数: {len(self.sql_info_list)}",
            f"- カーソル数: {len(self.cursor_list)}",
            "",
            "## 2. 使用COPY句一覧",
            "",
        ]

        if self.copy_list:
            lines.extend(
                [
                    "| COPY名 | コメント |",
                    "| --- | --- |",
                ]
            )
            for copy_name, comment in sorted(self.copy_list.items()):
                lines.append(
                    f"| `{copy_name}` | {self._markdown_text(comment, fallback='要確認')} |"
                )
        else:
            lines.append("- 該当なし")

        lines.extend(["", "## 3. 入出力ファイル一覧", ""])
        if self.file_definition_list:
            lines.extend(
                [
                    "| 論理名 | 物理名 |",
                    "| --- | --- |",
                ]
            )
            for definition in self.file_definition_list:
                lines.append(
                    f"| `{definition.logical_name}` | `{definition.physical_name}` |"
                )
        else:
            lines.append("- 該当なし")

        lines.extend(["", "## 4. 外部呼出一覧", ""])
        if self.called_module_list:
            for module_name in self.called_module_list:
                lines.append(f"- `{module_name}`")
        else:
            lines.append("- 該当なし")

        lines.extend(["", "## 5. セクション一覧", ""])
        lines.extend(
            [
                "| セクション名 | 説明 | 開始行 | 終了行 | 到達可否 |",
                "| --- | --- | ---: | ---: | --- |",
            ]
        )
        for method in self.method_list:
            lines.append(
                "| `{name}` | {desc} | {start} | {end} | {called} |".format(
                    name=method.method_name_p,
                    desc=self._markdown_text(method.method_name_l, fallback="要確認"),
                    start=method.start_index,
                    end=method.end_index if method.end_index >= 0 else "要確認",
                    called="到達可" if method.called_flg else "未到達",
                )
            )

        lines.extend(["", "## 6. セクション詳細", ""])
        for index, method in enumerate(self.method_list, start=1):
            lines.extend(self._build_method_markdown(index, method))

        lines.extend(["", "## 7. SQL一覧", ""])
        if self.sql_info_list:
            lines.extend(
                [
                    "| 種別 | 利用セクション | 対象DB | SQL |",
                    "| --- | --- | --- | --- |",
                ]
            )
            for sql_info in self.sql_info_list:
                db_list = ", ".join(f"`{db}`" for db in sql_info.get_db_list()) or "要確認"
                lines.append(
                    f"| {sql_info.type.value} | `{sql_info.used_method_name}` | {db_list} | `{self._inline_code(sql_info.value)}` |"
                )
        else:
            lines.append("- 該当なし")

        lines.extend(["", "## 8. カーソル一覧", ""])
        if self.cursor_list:
            lines.extend(
                [
                    "| カーソル名 | 利用セクション | 対象DB | SQL |",
                    "| --- | --- | --- | --- |",
                ]
            )
            for cursor in self.cursor_list:
                db_list = ", ".join(f"`{db}`" for db in cursor.get_db_list()) or "要確認"
                used_method = cursor.used_method_name or "要確認"
                lines.append(
                    f"| `{cursor.cursor_name}` | `{used_method}` | {db_list} | `{self._inline_code(cursor.value)}` |"
                )
        else:
            lines.append("- 該当なし")

        lines.extend(
            [
                "",
                "## 9. LLM利用時の注意",
                "",
                "- 本設計書は静的解析結果をもとに生成しています。",
                "- JSONに存在しない業務仕様や項目意味は補完していません。",
                "- コメントや命令列から断定できない内容は `要確認` としています。",
            ]
        )

        return "\n".join(lines)

    def _build_method_markdown(self, index: int, method: Method) -> list[str]:
        lines = [
            f"### 6.{index} `{method.method_name_p}`",
            "",
            f"- 説明: {self._markdown_text(method.method_name_l, fallback='要確認')}",
            f"- 開始行: {method.start_index}",
            f"- 終了行: {method.end_index if method.end_index >= 0 else '要確認'}",
            f"- 到達可否: {'到達可' if method.called_flg else '未到達'}",
        ]

        if method.checkpoint_list:
            checkpoints = ", ".join(f"`{checkpoint}`" for checkpoint in method.checkpoint_list)
            lines.append(f"- チェックポイント: {checkpoints}")
        else:
            lines.append("- チェックポイント: 該当なし")

        lines.append("- 呼出先:")
        if method.called_method_list:
            for called_method in method.called_method_list:
                kind = "外部モジュール" if called_method.module_flg else "内部セクション"
                condition = called_method.conditions or "条件なし"
                lines.append(
                    f"  - `{called_method.name}` ({kind}, 条件: {condition})"
                )
        else:
            lines.append("  - 該当なし")

        lines.append("- 主要命令:")
        if method.operation_list:
            for operation in method.operation_list:
                summary = f"{operation.kind} {operation.target}".strip()
                if operation.detail:
                    summary += f" ({operation.detail})"
                if operation.conditions:
                    summary += f" [条件: {operation.conditions}]"
                lines.append(f"  - {summary}")
        else:
            lines.append("  - 該当なし")

        lines.append("")
        return lines

    @staticmethod
    def _markdown_text(value: str, *, fallback: str) -> str:
        cleaned = value.strip().strip("*").strip()
        return cleaned if cleaned else fallback

    @staticmethod
    def _inline_code(value: str) -> str:
        return value.replace("`", "'").strip()


class CobolParser:
    regex_identification = re.compile(
        r"(IDENTIFICATION|PROGRAM-ID|AUTHOR|DATE-WRITTEN|DATE-COMPILED)"
    )
    regex_environment = re.compile(
        r"(ENVIRONMENT|CONFIGURATION|SOURCE-COMPUTER|OBJECT-COMPUTER|INPUT-OUTPUT|FILE-CONTROL)"
    )
    regex_data = re.compile(r"(DATA|FILE|WORKING-STORAGE|REPORT|SCREEN)")

    def __init__(self, encoding: str = "cp932") -> None:
        self.encoding = encoding

    def parse_file(self, file_path: str | Path) -> CobolAnalysisResult:
        path = Path(file_path)
        lines = path.read_text(encoding=self.encoding).splitlines()
        return self.parse_lines(lines, file_path=str(path))

    def parse_lines(
        self, lines: list[str], *, file_path: str = "<memory>"
    ) -> CobolAnalysisResult:
        method_list: list[Method] = []
        copy_list: dict[str, str] = {}
        file_definition_list: list[FileDefinition] = []
        called_module_list: list[str] = []
        sql_info_list: list[SqlInfo] = []
        cursor_list: list[SqlInfo] = []

        division = Division.NONE
        method_index = -1
        in_method_area = False
        in_if_condition_define_area = False
        then_add_flg = False
        when_condition_add_flg = False
        if_condition_txt = ""
        evaluate_condition_txt = ""
        when_txt = ""
        conditions: list[str] = []
        in_sql_area = False
        sql = ""
        sql_type = SqlType.NONE
        cursor_name = ""
        pending_operation: Operation | None = None

        for file_index, line in enumerate(lines, start=1):
            fmt_line = self.format_line(line, except_com_flg=False)
            line_has_period = fmt_line.endswith(".")
            if not in_sql_area:
                fmt_line = fmt_line.replace(".", "")
            arr_word = fmt_line.split(" ") if fmt_line else [""]

            if division != Division.PROCEDURE:
                changed = self.check_division_changed(arr_word)
                division = changed if changed != Division.NONE else division

            if not self.check_excluded_words(arr_word, division):
                continue

            if division in (
                Division.NONE,
                Division.IDENTIFICATION,
            ):
                continue

            if division == Division.ENVIRONMENT:
                file_definition = self.parse_file_definition(arr_word)
                if file_definition and file_definition not in file_definition_list:
                    file_definition_list.append(file_definition)
                continue

            if division == Division.DATA:
                if arr_word[0] == "COPY":
                    copy_key = self.get_array_word(arr_word, 1)
                    comment = self.get_comment(lines, file_index - 2)
                    if copy_key and copy_key not in copy_list:
                        copy_list[copy_key] = comment

                if " ".join(arr_word) == "EXEC SQL":
                    in_sql_area = True
                    sql = ""
                    sql_type = SqlType.NONE
                    cursor_name = ""
                    continue

                if in_sql_area:
                    in_sql_area, sql, sql_type, cursor_name = self.add_sql_list(
                        division=division,
                        arr_word=arr_word,
                        used_method_name="",
                        sql=sql,
                        sql_type=sql_type,
                        sql_list=cursor_list,
                        cursor_name=cursor_name,
                    )
                continue

            if arr_word[-1] == "SECTION":
                method_index += 1
                method_name_l = self.get_comment(lines, file_index - 3)
                method_list.append(
                    Method(
                        method_name_p=arr_word[0],
                        method_name_l=method_name_l,
                        start_index=file_index,
                    )
                )
                in_method_area = True
                conditions.clear()
                continue

            if not in_method_area:
                continue

            latest_method = method_list[-1]
            if pending_operation is not None and self.should_extend_operation(arr_word):
                pending_operation.target = (
                    f"{pending_operation.target} {' '.join(arr_word).strip()}".strip()
                )
                if line_has_period:
                    pending_operation = None
                continue

            if not in_sql_area and latest_method.detect_check_point(arr_word[0]):
                latest_method.checkpoint_list.append(arr_word[0])
                continue

            if (
                len(arr_word) >= 2
                and arr_word[0] == "PERFORM"
                and arr_word[1] != "VARYING"
            ) or arr_word[0] == "CALL":
                module_flg = arr_word[0] == "CALL"
                name = self.get_array_word(arr_word, 1).replace("'", "").replace('"', "")
                if module_flg and name:
                    called_module_list.append(name)
                latest_method.operation_list.append(
                    Operation(
                        kind="CALL" if module_flg else "PERFORM",
                        target=name,
                        conditions=" / ".join(conditions),
                    )
                )
                latest_method.called_method_list.append(
                    CalledMethod.from_conditions(name, module_flg, conditions)
                )
                continue

            if len(arr_word) >= 3 and f"{arr_word[0]} {arr_word[1]}" == "GO TO":
                latest_method.operation_list.append(
                    Operation(
                        kind="GO TO",
                        target=arr_word[2].replace("'", ""),
                        conditions=" / ".join(conditions),
                    )
                )
                latest_method.called_method_list.append(
                    CalledMethod.from_conditions(
                        arr_word[2].replace("'", ""), False, conditions
                    )
                )
                continue

            if arr_word[0] in {"EXIT", "GOBACK"}:
                latest_method.operation_list.append(Operation(kind=arr_word[0], target=""))
                latest_method.dedupe_called_methods()
                latest_method.end_index = file_index
                in_method_area = False
                continue

            if " ".join(arr_word) == "EXEC SQL":
                in_sql_area = True
                sql = ""
                sql_type = SqlType.NONE
                cursor_name = ""
                continue

            if in_sql_area:
                sql_target = cursor_list if cursor_name else sql_info_list
                in_sql_area, sql, sql_type, cursor_name = self.add_sql_list(
                    division=division,
                    arr_word=arr_word,
                    used_method_name=latest_method.method_name_p,
                    sql=sql,
                    sql_type=sql_type,
                    sql_list=sql_target,
                    cursor_name=cursor_name,
                )
                if len(arr_word) > 1 and arr_word[0] == "FETCH":
                    for cursor in cursor_list:
                        if cursor.cursor_name == arr_word[1]:
                            cursor.used_method_name = latest_method.method_name_p
                continue

            operation_added = False
            operation = self.parse_operation(arr_word, conditions)
            if operation is not None:
                latest_method.operation_list.append(operation)
                operation_added = True
                if operation.kind in {"OPEN", "CLOSE"} and not line_has_period:
                    pending_operation = operation
                else:
                    pending_operation = None

            if arr_word[0] == "IF":
                if in_if_condition_define_area and not then_add_flg:
                    conditions.append(if_condition_txt.replace("IF", "").strip())
                in_if_condition_define_area = True
                then_add_flg = False
                if_condition_txt = ""

            if (
                in_if_condition_define_area
                and "THEN" not in arr_word
                and "ELSE" not in arr_word
                and "CONTINUE" not in arr_word
            ):
                if_condition_txt += f" {' '.join(arr_word)}"

            if "THEN" in arr_word:
                in_if_condition_define_area = False
                if_condition_txt += f" {' '.join(arr_word)}"
                conditions.append(
                    if_condition_txt.replace(" THEN", "").replace("IF", "").strip()
                )
                then_add_flg = True
                continue
            if in_if_condition_define_area and not then_add_flg and "CONTINUE" in arr_word:
                in_if_condition_define_area = False
                conditions.append(if_condition_txt.replace("IF", "").strip())
                then_add_flg = True
                continue
            if in_if_condition_define_area and not then_add_flg and "ELSE" in arr_word:
                in_if_condition_define_area = False
                conditions.append(if_condition_txt.replace("IF", "").strip() + " 以外")
                then_add_flg = True
                continue
            if "ELSE" in arr_word and conditions:
                conditions[-1] = conditions[-1] + " 以外"
                continue

            if "END-IF" in arr_word:
                if in_if_condition_define_area and not then_add_flg:
                    if_condition_txt = ""
                    in_if_condition_define_area = False
                    then_add_flg = True
                    continue
                if conditions:
                    conditions.pop()
                continue

            if in_if_condition_define_area:
                continue

            if arr_word[0] == "EVALUATE":
                evaluate_condition_txt = "[" + " ".join(arr_word).replace("EVALUATE ", "") + "]"
                when_condition_add_flg = False
                continue

            if "WHEN" in arr_word:
                when_txt += (
                    ""
                    if "OTHER" in arr_word
                    else "," + " ".join(arr_word).replace("WHEN", "")
                )
                when_txt = when_txt.strip(",").strip()

                previous_line = ""
                if file_index >= 2:
                    previous_line = self.format_line(lines[file_index - 2], except_com_flg=False)
                previous_when = previous_line if self.left(previous_line, 4) == "WHEN" else ""

                if when_condition_add_flg and conditions:
                    conditions.pop()

                when_condition_txt = (
                    f"[{' '.join(arr_word)}]"
                    if not previous_when
                    else f"[{previous_when}] または [{' '.join(arr_word)}]"
                )
                other_condition_txt = f"[{when_txt}] 以外"
                if "OTHER" in when_condition_txt:
                    conditions.append(f"{evaluate_condition_txt} = {other_condition_txt}")
                else:
                    conditions.append(
                        f"{evaluate_condition_txt} = {when_condition_txt.replace('WHEN ', '')}"
                    )
                when_condition_add_flg = True
                continue

            if arr_word[0].startswith("END-EVALUATE"):
                if conditions:
                    conditions.pop()
                when_txt = ""
                continue

            if arr_word[0] and not operation_added:
                pending_operation = None

        if not method_list:
            raise ValueError("ファイル内に関数が一つもありません。")

        self.mark_called_methods(method_list)

        return CobolAnalysisResult(
            file_path=file_path,
            copy_list=copy_list,
            file_definition_list=file_definition_list,
            called_module_list=sorted(set(called_module_list)),
            method_list=method_list,
            sql_info_list=sql_info_list,
            cursor_list=cursor_list,
        )

    def mark_called_methods(self, method_list: list[Method]) -> None:
        for index, method1 in enumerate(method_list):
            if index == 0:
                method1.called_flg = True
            for other_index, method2 in enumerate(method_list):
                if index == other_index:
                    continue
                for called_method in method2.called_method_list:
                    if method1.method_name_p == called_method.name:
                        method1.called_flg = True
                        called_method.method_list_index = index

        called_by_uncalled: list[Method] = []
        for method in method_list:
            if method.called_flg or not method.called_method_list:
                continue
            for called_method in method.called_method_list:
                if called_method.module_flg or called_method.method_list_index < 0:
                    continue
                called_by_uncalled.append(method_list[called_method.method_list_index])

        for target in called_by_uncalled:
            if target.method_name_p == method_list[0].method_name_p:
                continue
            target.called_flg = False
            target_index = method_list.index(target)
            for method in method_list:
                if method is target:
                    continue
                for called_method in method.called_method_list:
                    if (
                        target.method_name_p == called_method.name
                        and method.called_flg
                    ):
                        target.called_flg = True
                        break
                if target.called_flg:
                    break

    def format_line(self, line: str, except_com_flg: bool) -> str:
        start = 8 if except_com_flg else 7
        formatted = self.mid(line, start, 73 - start)
        formatted = re.sub(r"\s{2,}", " ", formatted.strip())
        if except_com_flg:
            index = formatted.find("A.")
            if index < 0:
                index = formatted.find("D.")
            if index >= 0:
                formatted = self.left(formatted, index)
        return self.replace_reserved_word(formatted)

    def check_division_changed(self, arr_word: list[str]) -> Division:
        if len(arr_word) < 2 or arr_word[1].replace(".", "") != "DIVISION":
            return Division.NONE
        mapping = {
            "IDENTIFICATION": Division.IDENTIFICATION,
            "ENVIRONMENT": Division.ENVIRONMENT,
            "DATA": Division.DATA,
            "PROCEDURE": Division.PROCEDURE,
        }
        return mapping.get(arr_word[0], Division.NONE)

    def replace_reserved_word(self, line: str) -> str:
        replacements = {"ZERO": "0", "SPACE": "''", "ALSO": "と"}
        words = line.split(" ") if line else []
        return " ".join(replacements.get(word, word) for word in words)

    def parse_file_definition(self, arr_word: list[str]) -> FileDefinition | None:
        if len(arr_word) < 4 or arr_word[0] != "SELECT" or arr_word[2] != "ASSIGN":
            return None
        return FileDefinition(logical_name=arr_word[1], physical_name=arr_word[3])

    def parse_operation(
        self, arr_word: list[str], conditions: list[str]
    ) -> Operation | None:
        if not arr_word or not arr_word[0]:
            return None

        keyword = arr_word[0]
        normalized_conditions = " / ".join(conditions)

        if keyword in {"OPEN", "CLOSE", "READ", "WRITE", "INITIALIZE"}:
            target = " ".join(arr_word[1:]).strip()
            return Operation(
                kind=keyword,
                target=target or "要確認",
                conditions=normalized_conditions,
            )

        if keyword in {"MOVE", "COMPUTE"}:
            detail = " ".join(arr_word[1:]).strip()
            target = self.extract_primary_target(keyword, arr_word)
            return Operation(
                kind=keyword,
                target=target,
                detail=detail,
                conditions=normalized_conditions,
            )

        return None

    def extract_primary_target(self, keyword: str, arr_word: list[str]) -> str:
        if keyword == "MOVE" and "TO" in arr_word:
            index = arr_word.index("TO")
            return " ".join(arr_word[index + 1 :]).strip() or "要確認"
        if keyword == "COMPUTE" and len(arr_word) > 1:
            return arr_word[1]
        return "要確認"

    def should_extend_operation(self, arr_word: list[str]) -> bool:
        if not arr_word or not arr_word[0]:
            return False
        reserved_keywords = {
            "IF",
            "ELSE",
            "THEN",
            "END-IF",
            "EVALUATE",
            "WHEN",
            "END-EVALUATE",
            "EXEC",
            "CALL",
            "PERFORM",
            "GO",
            "EXIT",
            "GOBACK",
            "OPEN",
            "CLOSE",
            "READ",
            "WRITE",
            "MOVE",
            "COMPUTE",
            "INITIALIZE",
        }
        return arr_word[0] not in reserved_keywords

    def check_excluded_words(self, arr_word: list[str], division: Division) -> bool:
        check_text = arr_word[0].replace(".", "")
        if not check_text or self.left(check_text, 1) == "*":
            return False
        if division == Division.IDENTIFICATION:
            return not self.regex_identification.search(check_text)
        if division == Division.ENVIRONMENT:
            return not self.regex_environment.search(check_text)
        if division == Division.DATA:
            return not self.regex_data.search(check_text)
        if division == Division.PROCEDURE:
            return check_text != "DISPLAY"
        return True

    def get_comment(self, lines: list[str], zero_based_index: int) -> str:
        if zero_based_index < 0 or zero_based_index >= len(lines):
            return ""
        comment_line = lines[zero_based_index]
        if self.mid(comment_line, 7, 1) == "*":
            return self.format_line(comment_line, except_com_flg=True)
        return ""

    def add_sql_list(
        self,
        *,
        division: Division,
        arr_word: list[str],
        used_method_name: str,
        sql: str,
        sql_type: SqlType,
        sql_list: list[SqlInfo],
        cursor_name: str,
    ) -> tuple[bool, str, SqlType, str]:
        if (
            division in {Division.DATA, Division.PROCEDURE}
            and len(arr_word) > 2
            and arr_word[0] == "DECLARE"
            and arr_word[2] == "CURSOR"
        ):
            cursor_name = arr_word[1]

        sql_type = self.string_to_sql_type(arr_word[0], sql_type)

        if arr_word[0].replace(".", "") == "END-EXEC":
            if sql.strip():
                sql_list.append(
                    SqlInfo(
                        value=sql.strip(),
                        type=sql_type,
                        used_method_name=used_method_name,
                        cursor_name=cursor_name,
                    )
                )
            return False, "", SqlType.NONE, ""

        sql += "".join(f"{value} " for value in arr_word)
        return True, sql, sql_type, cursor_name

    def string_to_sql_type(self, value: str, sql_type: SqlType) -> SqlType:
        if sql_type != SqlType.NONE:
            return sql_type
        mapping = {
            "SELECT": SqlType.SELECT,
            "INSERT": SqlType.INSERT,
            "UPDATE": SqlType.UPDATE,
            "DELETE": SqlType.DELETE,
            "CREATE": SqlType.CREATE,
        }
        return mapping.get(value, sql_type)

    @staticmethod
    def get_array_word(value: list[str], index: int) -> str:
        return value[index] if index < len(value) else ""

    @staticmethod
    def mid(text: str, start: int, length: int | None = None) -> str:
        if start <= 0:
            raise ValueError("start must be >= 1")
        if text is None or len(text) < start:
            return ""
        offset = start - 1
        if length is None:
            return text[offset:]
        if length < 0:
            return ""
        return text[offset : offset + length]

    @staticmethod
    def left(text: str, length: int) -> str:
        if length < 0:
            raise ValueError("length must be >= 0")
        if text is None:
            return ""
        return text[:length]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="COBOLソースを解析してJSONまたはMarkdownを出力します。"
    )
    parser.add_argument("file", help="解析対象のCOBOLソース")
    parser.add_argument(
        "--encoding",
        default="cp932",
        help="入力エンコーディング。既定値は cp932。",
    )
    parser.add_argument(
        "--format",
        choices=("json", "markdown"),
        default="json",
        help="出力形式。既定値は json。",
    )
    args = parser.parse_args()

    result = CobolParser(encoding=args.encoding).parse_file(args.file)
    if args.format == "markdown":
        print(result.to_markdown())
    else:
        print(result.to_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
