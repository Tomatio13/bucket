from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


SYSTEM_PROMPT = """あなたはCOBOL保守案件の詳細設計書を作成するシステムアナリストです。
必ず日本語で出力してください。
与えられた解析結果だけを根拠に記述してください。
情報が不足する箇所は推測せず、「要確認」と明記してください。
出力はMarkdownで、読みやすい見出し・表・箇条書きを使ってください。
同じ情報の繰り返しは避けてください。
JSONやMarkdownの生データをそのまま貼り付けず、設計書として自然な文に整形してください。

特に重要なルール:
- COBOL命令をそのまま列挙しない
- `MOVE A TO B` のような記述は「AをBへ設定する」「BにAを格納する」のような日本語に言い換える
- `READ` `WRITE` `OPEN` `CLOSE` `CALL` `PERFORM` `COMPUTE` `EVALUATE` `IF` なども、設計書として自然な日本語に変換する
- 出力は「コード説明」ではなく「処理仕様説明」にする
- 必要に応じて「入力チェックを行う」「顧客情報を取得する」「正常データを出力する」などの業務的な粒度にまとめる
- ただし、解析結果から断定できない業務意図は補わず、「解析結果上は〜する」と表現する
"""


SECTION_PROMPT_TEMPLATE = """以下はCOBOL解析結果から抽出した設計材料です。
この情報のみを使って、詳細設計書の一部として自然なMarkdownを作成してください。

対象セクション:
{section_name}

記述ルール:
- 推測禁止
- 不明点は「要確認」
- 業務的な意図が断定できない場合は「解析結果上は〜」と表現
- セクション名に対応する内容だけを書く
- 可能なら表を使う
- COBOL命令名をそのまま箇条書きしない
- 命令列は日本語の処理内容に変換する
- 例えば `MOVE WS-A TO WS-B` は「WS-Aの値をWS-Bに設定する」といった設計書向け表現にする
- 例えば `READ FILE-A` は「入力ファイル FILE-A を読み込む」と表現する
- 条件分岐は「〜の場合」「〜以外の場合」と日本語で書く
- セクション詳細では、可能なら以下の順で整理する
  1. 処理概要
  2. 入力・参照情報
  3. 主な処理内容
  4. 出力・更新内容
  5. エラー時の動作
- 「主な処理内容」はコードの逐語的説明ではなく、処理手順として自然な日本語でまとめる

設計材料:
```{payload_format}
{payload}
```
"""


@dataclass
class SectionTask:
    key: str
    title: str
    payload: str
    payload_format: str
    heading_level: int = 2
    generate_content: bool = True


class OpenAICompatibleClient:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        api_key: str | None,
        timeout: int = 120,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def generate_markdown(self, section_name: str, payload: str, payload_format: str) -> str:
        prompt = SECTION_PROMPT_TEMPLATE.format(
            section_name=section_name,
            payload=payload,
            payload_format=payload_format,
        )
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,
        }
        request = urllib.request.Request(
            url=f"{self.base_url}/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers=self._build_headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"API request failed: {exc.code} {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"API request failed: {exc.reason}") from exc

        return self._extract_content(payload).strip()

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    @staticmethod
    def _extract_content(payload: dict[str, Any]) -> str:
        choices = payload.get("choices")
        if not choices:
            raise RuntimeError("API response does not contain choices.")
        message = choices[0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    parts.append(item.get("text", ""))
            if parts:
                return "\n".join(parts)
        raise RuntimeError("API response content format is not supported.")


def load_input(path: Path, input_format: str) -> tuple[str, str]:
    text = path.read_text(encoding="utf-8")
    if input_format == "auto":
        suffix = path.suffix.lower()
        if suffix == ".json":
            input_format = "json"
        elif suffix in {".md", ".markdown"}:
            input_format = "markdown"
        else:
            raise ValueError("input format could not be inferred. use --input-format.")
    return text, input_format


def build_section_tasks(source_text: str, input_format: str) -> list[SectionTask]:
    if input_format == "json":
        return build_section_tasks_from_json(source_text)
    if input_format == "markdown":
        return build_section_tasks_from_markdown(source_text)
    raise ValueError(f"unsupported input format: {input_format}")


def build_section_tasks_from_json(source_text: str) -> list[SectionTask]:
    data = json.loads(source_text)
    tasks: list[SectionTask] = []

    overview_payload = {
        "file_path": data.get("file_path"),
        "copy_list": data.get("copy_list", {}),
        "file_definition_list": data.get("file_definition_list", []),
        "called_module_list": data.get("called_module_list", []),
        "method_count": len(data.get("method_list", [])),
        "sql_count": len(data.get("sql_info_list", [])),
        "cursor_count": len(data.get("cursor_list", [])),
    }
    tasks.append(
        SectionTask(
            key="overview",
            title="プログラム概要",
            payload=json.dumps(overview_payload, ensure_ascii=False, indent=2),
            payload_format="json",
        )
    )

    structure_payload = {
        "file_definition_list": data.get("file_definition_list", []),
        "copy_list": data.get("copy_list", {}),
        "called_module_list": data.get("called_module_list", []),
    }
    tasks.append(
        SectionTask(
            key="structure",
            title="外部仕様・入出力",
            payload=json.dumps(structure_payload, ensure_ascii=False, indent=2),
            payload_format="json",
        )
    )

    sql_info_list = data.get("sql_info_list", [])
    cursor_list = data.get("cursor_list", [])
    for index, method in enumerate(data.get("method_list", []), start=1):
        related_sql = [
            sql_info for sql_info in sql_info_list if sql_info.get("used_method_name") == method.get("method_name_p")
        ]
        related_cursor = [
            cursor for cursor in cursor_list if cursor.get("used_method_name") == method.get("method_name_p")
        ]
        method_payload = {
            "method": method,
            "related_sql": related_sql,
            "related_cursor": related_cursor,
        }
        tasks.append(
            SectionTask(
                key=f"method_{index:02d}_{method.get('method_name_p', 'unknown')}",
                title=f"セクション詳細: {method.get('method_name_p', 'UNKNOWN')}",
                payload=json.dumps(method_payload, ensure_ascii=False, indent=2),
                payload_format="json",
            )
        )

    db_payload = {
        "sql_info_list": sql_info_list,
        "cursor_list": cursor_list,
    }
    tasks.append(
        SectionTask(
            key="database",
            title="DB・SQL仕様",
            payload=json.dumps(db_payload, ensure_ascii=False, indent=2),
            payload_format="json",
        )
    )
    return tasks


def build_section_tasks_from_markdown(source_text: str) -> list[SectionTask]:
    lines = source_text.splitlines()
    tasks: list[SectionTask] = []
    split_level = infer_markdown_split_level(lines)
    top_sections = extract_markdown_sections(lines, split_level)

    for section in top_sections:
        title = section["title"]
        payload = section["payload"]
        if is_section_details_title(title):
            tasks.append(
                SectionTask(
                    key=slugify(title),
                    title=title,
                    payload="",
                    payload_format="markdown",
                    heading_level=split_level,
                    generate_content=False,
                )
            )
            child_sections = extract_markdown_sections(payload.splitlines(), split_level + 1)
            for child in child_sections:
                tasks.append(
                    SectionTask(
                        key=slugify(child["title"]),
                        title=child["title"],
                        payload=child["payload"],
                        payload_format="markdown",
                        heading_level=split_level + 1,
                    )
                )
            continue

        tasks.append(
            SectionTask(
                key=slugify(title),
                title=title,
                payload=payload,
                payload_format="markdown",
                heading_level=split_level,
            )
        )

    if not tasks:
        tasks.append(
            SectionTask(
                key="document",
                title="詳細設計書全体",
                payload=source_text.strip(),
                payload_format="markdown",
                heading_level=split_level,
            )
        )
    return tasks


def infer_markdown_split_level(lines: list[str]) -> int:
    for line in lines:
        match = re.match(r"^(#{1,6})\s+.+$", line)
        if not match:
            continue
        level = len(match.group(1))
        if level < 6:
            # 文書タイトルの 1 段下を章見出しとして扱う。
            return level + 1
    return 2


def extract_markdown_sections(lines: list[str], heading_level: int) -> list[dict[str, str]]:
    sections: list[dict[str, str]] = []
    current_title: str | None = None
    current_lines: list[str] = []
    heading_pattern = re.compile(r"^(#{1,6})\s+(.+)$")

    for line in lines:
        match = heading_pattern.match(line)
        if match and len(match.group(1)) == heading_level:
            if current_title is not None:
                sections.append(
                    {
                        "title": current_title,
                        "payload": "\n".join(current_lines).strip(),
                    }
                )
            current_title = match.group(2).strip()
            current_lines = []
            continue
        if current_title is not None:
            current_lines.append(line)

    if current_title is not None:
        sections.append(
            {
                "title": current_title,
                "payload": "\n".join(current_lines).strip(),
            }
        )

    return sections


def is_section_details_title(title: str) -> bool:
    return normalize_heading_title(title) == "セクション詳細"


def slugify(text: str) -> str:
    normalized = re.sub(r"[^\w\u3040-\u30ff\u3400-\u9fff-]+", "_", text.strip())
    return normalized.strip("_").lower() or "section"


def assemble_document(title: str, generated_sections: list[tuple[SectionTask, str]]) -> str:
    lines = [
        f"# {title}",
        "",
        "## 目次",
        "",
    ]
    toc_index = 0
    inside_section_details = False
    for task, _ in generated_sections:
        if task.heading_level == 2:
            toc_index += 1
            lines.append(f"{toc_index}. {task.title}")
            inside_section_details = is_section_details_title(task.title)
            continue
        if inside_section_details:
            lines.append(f"   - {task.title}")

    lines.extend(["", "---", ""])
    for task, content in generated_sections:
        lines.append(f"{'#' * task.heading_level} {task.title}")
        lines.append("")
        if task.generate_content:
            lines.append(normalize_generated_section_content(content, task.title))
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def normalize_generated_section_content(content: str, title: str) -> str:
    lines = content.strip().splitlines()
    if not lines:
        return ""

    while lines and not lines[0].strip():
        lines.pop(0)

    if not lines:
        return ""

    while lines and is_heading_line_for_title(lines[0].strip(), title):
        lines.pop(0)
        while lines and not lines[0].strip():
            lines.pop(0)

    return "\n".join(lines).strip()


def is_heading_line_for_title(line: str, title: str) -> bool:
    match = re.match(r"^#{1,6}\s+(.+?)\s*$", line)
    if not match:
        return False
    heading_title = normalize_heading_title(match.group(1))
    normalized_title = normalize_heading_title(title)
    return (
        heading_title == normalized_title
        or heading_title.startswith(normalized_title)
        or normalized_title.startswith(heading_title)
    )


def normalize_heading_title(text: str) -> str:
    normalized = re.sub(r"`", "", text).strip().lower()
    normalized = re.sub(r"^(\d+(?:\.\d+)*)\s*[.)]?\s*", "", normalized)
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized


def write_section_cache(cache_dir: Path, task: SectionTask, content: str) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    section_path = cache_dir / f"{task.key}.md"
    section_path.write_text(content, encoding="utf-8")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="COBOL解析JSON/MarkdownをOpenAI互換APIで詳細設計書に変換します。"
    )
    parser.add_argument("input", help="入力ファイル。JSONまたはMarkdown。")
    parser.add_argument(
        "--input-format",
        choices=("auto", "json", "markdown"),
        default="auto",
        help="入力形式。既定値は auto。",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="生成する詳細設計書Markdownの出力先。",
    )
    parser.add_argument(
        "--title",
        default="COBOL詳細設計書",
        help="出力Markdownのタイトル。",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("OPENAI_BASE_URL", "http://localhost:8000/v1"),
        help="OpenAI互換APIのベースURL。環境変数 OPENAI_BASE_URL でも指定可能。",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
        help="使用モデル名。環境変数 OPENAI_MODEL でも指定可能。",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("OPENAI_API_KEY"),
        help="APIキー。環境変数 OPENAI_API_KEY でも指定可能。",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="APIタイムアウト秒。既定値は 120。",
    )
    parser.add_argument(
        "--cache-dir",
        help="各セクションの生成結果を保存するディレクトリ。",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    input_path = Path(args.input)
    output_path = Path(args.output)

    source_text, input_format = load_input(input_path, args.input_format)
    tasks = build_section_tasks(source_text, input_format)
    client = OpenAICompatibleClient(
        base_url=args.base_url,
        model=args.model,
        api_key=args.api_key,
        timeout=args.timeout,
    )

    generated_sections: list[tuple[SectionTask, str]] = []
    cache_dir = Path(args.cache_dir) if args.cache_dir else None

    for index, task in enumerate(tasks, start=1):
        if not task.generate_content:
            generated_sections.append((task, ""))
            continue

        print(f"[{index}/{len(tasks)}] generating: {task.title}", file=sys.stderr)
        content = client.generate_markdown(task.title, task.payload, task.payload_format)
        generated_sections.append((task, content))
        if cache_dir is not None:
            write_section_cache(cache_dir, task, content)

    final_document = assemble_document(args.title, generated_sections)
    output_path.write_text(final_document, encoding="utf-8")
    print(f"written: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
