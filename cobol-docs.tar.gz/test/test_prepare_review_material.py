from __future__ import annotations

import unittest
from pathlib import Path
import sys

from design_doc_generator import SectionTask


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = PROJECT_ROOT / "skills" / "cobol-review-skill" / "scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from prepare_review_material import filter_tasks, render_review_packet, render_section_list, validate_filters


class PrepareReviewMaterialTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tasks = [
            SectionTask(
                key="overview",
                title="プログラム概要",
                payload='{"file_path": "sample.cbl"}',
                payload_format="json",
            ),
            SectionTask(
                key="method_01_MAIN",
                title="セクション詳細: MAIN",
                payload='{"method": {"method_name_p": "MAIN"}}',
                payload_format="json",
            ),
            SectionTask(
                key="database",
                title="DB・SQL仕様",
                payload='{"sql_info_list": []}',
                payload_format="json",
            ),
        ]
        self.review_points_path = (
            PROJECT_ROOT / "skills" / "cobol-review-skill" / "references" / "review_checkpoints.md"
        )

    def test_filter_tasks_by_key(self) -> None:
        filtered = filter_tasks(self.tasks, ["database"], [])
        self.assertEqual(["database"], [task.key for task in filtered])

    def test_filter_tasks_by_title_keywords(self) -> None:
        filtered = filter_tasks(self.tasks, [], ["セクション詳細", "MAIN"])
        self.assertEqual(["method_01_MAIN"], [task.key for task in filtered])

    def test_validate_filters_raises_for_unknown_key(self) -> None:
        with self.assertRaisesRegex(ValueError, "存在しない section key"):
            validate_filters(self.tasks, self.tasks, ["missing"])

    def test_render_section_list_includes_header_and_sections(self) -> None:
        rendered = render_section_list(self.tasks)
        self.assertIn("key\ttitle\tformat\tgenerate_content", rendered)
        self.assertIn("overview\tプログラム概要\tjson\tTrue", rendered)

    def test_render_review_packet_includes_review_points_and_payload(self) -> None:
        rendered = render_review_packet(
            PROJECT_ROOT / "sample_json" / "dummy.json",
            "json",
            self.review_points_path,
            self.tasks[:1],
        )
        self.assertIn("# COBOL Review Packet", rendered)
        self.assertIn("## Review Checkpoints", rendered)
        self.assertIn("## Selected Section 1", rendered)
        self.assertIn('{"file_path": "sample.cbl"}', rendered)


if __name__ == "__main__":
    unittest.main()
