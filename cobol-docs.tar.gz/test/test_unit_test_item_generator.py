import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from design_doc_generator import SectionTask
from unit_test_item_generator import (
    assemble_test_items_document,
    build_test_item_tasks,
    sanitize_free_text_line,
    sanitize_generated_content,
    strip_outer_code_fence,
    has_unsupported_specifics,
    parse_toc_structure,
    read_section_cache,
    slugify,
)


class UnitTestItemGeneratorTest(unittest.TestCase):
    def test_parse_toc_structure_extracts_top_and_child_titles(self) -> None:
        source = """# COBOL詳細設計書

## 1. 概要

## 目次

1. 1. プログラム概要
2. 5. セクション一覧
3. 6. セクション詳細
   - 6.1 `00-MAIN`
   - 6.2 `10-INITIALIZE`
4. 7. SQL一覧

---
"""
        toc = parse_toc_structure(source.splitlines())

        self.assertEqual(
            toc.top_titles,
            ["1. プログラム概要", "5. セクション一覧", "6. セクション詳細", "7. SQL一覧"],
        )
        self.assertEqual(toc.section_detail_titles, ["6.1 `00-MAIN`", "6.2 `10-INITIALIZE`"])

    def test_build_test_item_tasks_groups_internal_headings_under_top_sections(self) -> None:
        source = """# COBOL詳細設計書

## 目次

1. 1. プログラム概要
2. 5. セクション一覧
3. 6. セクション詳細
   - 6.1 `00-MAIN`

---

## 1. プログラム概要

## 1. 処理概要

概要本文

## 5. セクション一覧

## 1. 00-MAIN

一覧本文

## 6. セクション詳細

### 6.1 `00-MAIN`

## 1. 処理概要
詳細本文
"""

        tasks = build_test_item_tasks(source, "markdown")

        self.assertEqual(
            [(task.title, task.heading_level, task.generate_content) for task in tasks],
            [
                ("1. プログラム概要", 2, True),
                ("5. セクション一覧", 2, True),
                ("6. セクション詳細", 2, False),
                ("6.1 `00-MAIN`", 3, True),
            ],
        )
        self.assertIn("## 1. 処理概要", tasks[0].payload)
        self.assertIn("## 1. 00-MAIN", tasks[1].payload)
        self.assertEqual(tasks[3].payload, "## 1. 処理概要\n詳細本文")

    def test_build_test_item_tasks_rejects_non_markdown_input(self) -> None:
        with self.assertRaises(ValueError):
            build_test_item_tasks("{}", "json")

    def test_assemble_test_items_document_renders_parent_placeholder(self) -> None:
        generated_sections = [
            (SectionTask("overview", "1. 概要", "payload", "markdown"), "- 方針\n"),
            (
                SectionTask(
                    "details",
                    "6. セクション詳細",
                    "",
                    "markdown",
                    heading_level=2,
                    generate_content=False,
                ),
                "",
            ),
            (
                SectionTask(
                    "main",
                    "6.1 `00-MAIN`",
                    "payload",
                    "markdown",
                    heading_level=3,
                ),
                "### 6.1 `00-MAIN`\n\n| 項目 |\n| --- |\n| 1 |\n",
            ),
        ]

        document = assemble_test_items_document("単体試験項目一覧", generated_sections)

        self.assertIn("# 単体試験項目一覧", document)
        self.assertIn("2. 6. セクション詳細", document)
        self.assertIn("## 6. セクション詳細", document)
        self.assertIn("- この章は配下セクションの試験項目を参照してください。", document)
        self.assertIn("### 6.1 `00-MAIN`", document)
        self.assertIn("| 項目 |", document)

    def test_read_section_cache_returns_none_for_missing_or_empty_file(self) -> None:
        task = SectionTask("overview", "1. 概要", "payload", "markdown")
        with TemporaryDirectory() as temp_dir:
            cache_dir = Path(temp_dir)
            self.assertIsNone(read_section_cache(cache_dir, task))
            (cache_dir / "overview.md").write_text("", encoding="utf-8")
            self.assertIsNone(read_section_cache(cache_dir, task))

    def test_read_section_cache_returns_cached_content(self) -> None:
        task = SectionTask("overview", "1. 概要", "payload", "markdown")
        with TemporaryDirectory() as temp_dir:
            cache_dir = Path(temp_dir)
            (cache_dir / "overview.md").write_text("cached body\n", encoding="utf-8")
            self.assertEqual(read_section_cache(cache_dir, task), "cached body")

    def test_slugify_normalizes_section_title(self) -> None:
        self.assertEqual(slugify("6.24 `94-WRITE-ABEND-REPORT`"), "6_24_94-write-abend-report")

    def test_has_unsupported_specifics_detects_unbacked_examples(self) -> None:
        payload = "## 処理概要\n要確認"
        generated = "| 1 | 観点 | 不正データまたはNULL | エラーメッセージが表示されるか | 要確認 |"
        self.assertTrue(has_unsupported_specifics(payload, generated))

    def test_has_unsupported_specifics_allows_payload_backed_literals(self) -> None:
        payload = "エラーメッセージが「INPUT FILE OPEN ERROR」になる。"
        generated = "| 1 | 観点 | 入力ファイルオープン失敗 | エラーメッセージが設定される | エラーメッセージが「INPUT FILE OPEN ERROR」になる |"
        self.assertFalse(has_unsupported_specifics(payload, generated))

    def test_strip_outer_code_fence_removes_markdown_fence(self) -> None:
        content = "```markdown\n### 試験方針\n- a\n```"
        self.assertEqual(strip_outer_code_fence(content), "### 試験方針\n- a")

    def test_sanitize_generated_content_rewrites_unsupported_table_row(self) -> None:
        payload = "## 処理概要\n要確認"
        content = "| 1 | 観点 | 不正データまたはNULL | エラーメッセージが表示されるか | 要確認 |\n"
        sanitized = sanitize_generated_content(payload, content)
        self.assertEqual(
            sanitized,
            "| 1 | 観点 | 要確認 | 設計書記載内容に基づき確認 | 要確認 |",
        )

    def test_sanitize_free_text_line_rewrites_unbacked_literals_and_codes(self) -> None:
        payload = "支店コードは要確認。"
        line = "- 支店コードに基づくフラグ設定: '0001' の場合に有効な値を設定する。"
        self.assertEqual(
            sanitize_free_text_line(payload, line),
            "- 支店コードに基づくフラグ設定: 要確認 の場合に要確認値を設定する。",
        )


if __name__ == "__main__":
    unittest.main()
