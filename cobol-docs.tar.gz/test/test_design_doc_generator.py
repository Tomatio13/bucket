import unittest

from design_doc_generator import (
    SectionTask,
    assemble_document,
    build_section_tasks_from_markdown,
    is_section_details_title,
    infer_markdown_split_level,
    normalize_generated_section_content,
)


class DesignDocGeneratorTest(unittest.TestCase):
    def test_markdown_input_keeps_section_details_per_subsection(self) -> None:
        source = """# COBOL詳細設計書

## 1. プログラム概要

概要本文

## 6. セクション詳細

### 6.1 `00-MAIN`

詳細本文
"""
        tasks = build_section_tasks_from_markdown(source)

        self.assertEqual(
            [(task.title, task.heading_level, task.generate_content) for task in tasks],
            [
                ("1. プログラム概要", 2, True),
                ("6. セクション詳細", 2, False),
                ("6.1 `00-MAIN`", 3, True),
            ],
        )
        self.assertEqual(tasks[2].payload, "詳細本文")

    def test_infer_markdown_split_level_uses_level_below_document_title(self) -> None:
        lines = [
            "# Title",
            "",
            "## Section",
            "",
            "### Detail",
        ]

        self.assertEqual(infer_markdown_split_level(lines), 2)

    def test_normalize_generated_section_content_removes_duplicate_heading_variants(self) -> None:
        content = """# 6.1 `00-MAIN` セクション詳細設計書

## 1. 処理概要
本文
"""

        normalized = normalize_generated_section_content(content, "6.1 `00-MAIN`")

        self.assertEqual(normalized, "## 1. 処理概要\n本文")

    def test_assemble_document_renders_section_details_as_parent_and_children(self) -> None:
        generated_sections = [
            (SectionTask("overview", "1. プログラム概要", "概要", "markdown"), "概要本文"),
            (
                SectionTask("details", "6. セクション詳細", "", "markdown", heading_level=2, generate_content=False),
                "",
            ),
            (
                SectionTask("main", "6.1 `00-MAIN`", "payload", "markdown", heading_level=3),
                "## 処理概要\n本文",
            ),
        ]

        document = assemble_document("COBOL詳細設計書", generated_sections)

        self.assertIn("2. 6. セクション詳細", document)
        self.assertIn("   - 6.1 `00-MAIN`", document)
        self.assertIn("## 6. セクション詳細", document)
        self.assertIn("### 6.1 `00-MAIN`", document)
        self.assertTrue(is_section_details_title("6. セクション詳細"))


if __name__ == "__main__":
    unittest.main()
