from __future__ import annotations

import unittest
from pathlib import Path

from design_doc_generator import SectionTask
from cobol_review_generator import (
    assemble_review_document,
    filter_tasks,
    load_review_checkpoints,
    render_section_list,
    select_review_points,
    strip_outer_code_fence,
    validate_filtered_tasks,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class CobolReviewGeneratorTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tasks = [
            SectionTask(
                key="overview",
                title="プログラム概要",
                payload='{"file_path": "sample.cbl"}',
                payload_format="json",
            ),
            SectionTask(
                key="method_01_MAIN",
                title="セクション詳細: MAIN",
                payload='{"method": {"method_name_p": "MAIN"}}',
                payload_format="json",
            ),
            SectionTask(
                key="database",
                title="DB・SQL仕様",
                payload='{"sql_info_list": []}',
                payload_format="json",
            ),
        ]
        self.checkpoints = load_review_checkpoints(PROJECT_ROOT / "docs" / "cobol_review_checkpoints.md")

    def test_filter_tasks_by_key(self) -> None:
        filtered = filter_tasks(self.tasks, ["database"], [])
        self.assertEqual(["database"], [task.key for task in filtered])

    def test_filter_tasks_by_title_keywords(self) -> None:
        filtered = filter_tasks(self.tasks, [], ["セクション詳細", "MAIN"])
        self.assertEqual(["method_01_MAIN"], [task.key for task in filtered])

    def test_validate_filtered_tasks_rejects_unknown_key(self) -> None:
        with self.assertRaisesRegex(ValueError, "存在しない section key"):
            validate_filtered_tasks(self.tasks, self.tasks, ["missing"])

    def test_render_section_list_includes_header(self) -> None:
        rendered = render_section_list(self.tasks)
        self.assertIn("key\ttitle\tformat\tgenerate_content", rendered)

    def test_select_review_points_chooses_section_specific_content(self) -> None:
        review_points = select_review_points(self.tasks[2], self.checkpoints)
        self.assertIn("## 共通観点", review_points)
        self.assertIn("## DB・SQL仕様", review_points)
        self.assertIn("## レビュー結果の書き方", review_points)
        self.assertNotIn("## 外部仕様・入出力", review_points)

    def test_assemble_review_document_includes_section_key_comment(self) -> None:
        rendered = assemble_review_document(
            "COBOLコードレビュー",
            [(self.tasks[0], "## プログラム概要\n\n問題なし。")],
        )
        self.assertIn("# COBOLコードレビュー", rendered)
        self.assertIn("<!-- section-key: overview -->", rendered)

    def test_strip_outer_code_fence_removes_fence(self) -> None:
        self.assertEqual("hello", strip_outer_code_fence("```markdown\nhello\n```"))


if __name__ == "__main__":
    unittest.main()
