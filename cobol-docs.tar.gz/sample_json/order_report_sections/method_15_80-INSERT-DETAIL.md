# 80-INSERT-DETAIL セクション詳細設計書

## 1. 処理概要
このセクションは、受注詳細情報をデータベースに挿入する処理を担当します。具体的には、受注日、受注番号、顧客ID、商品ID、支店コード、受注数量、合計金額を含むレコードを `SALES_ORDER_DETAIL` テーブルに追加します。

## 2. 入力・参照情報
以下の情報が処理に使用されます。

| 変数名               | 説明                     |
|----------------------|--------------------------|
| WS-ORDER-DATE        | 受注日                   |
| WS-ORDER-NO          | 受注番号                 |
| HV-CUSTOMER-ID       | 顧客ID                   |
| HV-PRODUCT-ID        | 商品ID                   |
| WS-BRANCH-CODE       | 支店コード               |
| WS-ORDER-QTY         | 受注数量                 |
| WS-TOTAL-AMOUNT      | 合計金額                 |

## 3. 主な処理内容
1. 受注日を `WS-ORDER-DATE` から `HV-ORDER-DATE` に設定します。
2. 受注番号を `WS-ORDER-NO` から `HV-ORDER-NO` に設定します。
3. 合計金額を `WS-TOTAL-AMOUNT` から `HV-TOTAL-AMOUNT` に設定します。
4. エラーフラグを `WS-YES` に設定し、エラーコードを `'DB30001'` に設定します。
5. エラーメッセージを `'DETAIL INSERT FAILED'` に設定します。
6. 処理を終了します。

## 4. 出力・更新内容
- `SALES_ORDER_DETAIL` テーブルに新しいレコードを挿入します。挿入される内容は以下の通りです。

| カラム名       | 値                          |
|----------------|-----------------------------|
| ORDER_DATE     | :HV-ORDER-DATE              |
| ORDER_NO       | :HV-ORDER-NO                |
| CUSTOMER_ID    | :HV-CUSTOMER-ID             |
| PRODUCT_ID     | :HV-PRODUCT-ID              |
| BRANCH_CODE     | :WS-BRANCH-CODE             |
| ORDER_QTY      | :WS-ORDER-QTY               |
| TOTAL_AMOUNT    | :HV-TOTAL-AMOUNT            |
| UPDATE_TS      | CURRENT TIMESTAMP            |

## 5. エラー時の動作
処理中にエラーが発生した場合、エラーフラグが設定され、エラーコードとエラーメッセージがそれぞれ設定されます。具体的なエラー処理の流れは要確認です。