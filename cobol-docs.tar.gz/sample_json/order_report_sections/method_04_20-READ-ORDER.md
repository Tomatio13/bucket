# セクション詳細: 20-READ-ORDER

## 1. 処理概要
このセクションは、注文データを入力ファイルから読み込み、各フィールドに格納する処理を行います。処理が完了した後は、次の処理へ移行します。

## 2. 入力・参照情報
- **入力ファイル**: ORD-IN-FILE
- **入力データフィールド**:
  - IN-ORDER-DATE
  - IN-ORDER-NO
  - IN-CUSTOMER-ID
  - IN-PRODUCT-ID
  - IN-BRANCH-CODE
  - IN-ORDER-QTY
  - IN-TRACE-ID

## 3. 主な処理内容
1. 注文データを入力ファイルから読み込みます。
2. 読み込んだデータを以下のワークストレージに格納します。
   - IN-ORDER-DATEの値をWS-ORDER-DATEに設定します。
   - IN-ORDER-NOの値をWS-ORDER-NOに設定します。
   - IN-CUSTOMER-IDの値をWS-CUSTOMER-IDに設定します。
   - IN-PRODUCT-IDの値をWS-PRODUCT-IDに設定します。
   - IN-BRANCH-CODEの値をWS-BRANCH-CODEに設定します。
   - IN-ORDER-QTYの値をWS-ORDER-QTYに設定します。
   - IN-TRACE-IDの値をWS-TRACE-IDに設定します。
3. 処理が正常に完了した場合、フラグWS-END-FLGに「はい」を設定します。
4. 次の処理へ移行します。

## 4. 出力・更新内容
- 各ワークストレージに設定された値は、後続の処理で使用されます。
- WS-END-FLGが「はい」に設定されることで、処理の完了を示します。

## 5. エラー時の動作
- エラー処理に関する具体的な情報は解析結果に含まれていないため、要確認です。