# Repository Guidelines

## Project Structure & Module Organization
This repository provides two standalone Python entrypoints at the root:

- `cobol_parser.py`: parses COBOL source and emits JSON or Markdown summaries.
- `design_doc_generator.py`: turns parser output into sectioned Japanese design documents through an OpenAI-compatible API.

Tests live in `test/`, with `test_design_doc_generator.py` covering document assembly and Markdown splitting logic. Use `test/order_report_batch_sample.cbl` as the primary local sample input. Generated examples are stored under `sample_json/` and `sample_markdown/` for reference outputs only.

## Build, Test, and Development Commands
This project currently uses the Python standard library only, so no install step is required.

- `python cobol_parser.py test/order_report_batch_sample.cbl --format json`
  Parses sample COBOL and prints JSON.
- `python cobol_parser.py test/order_report_batch_sample.cbl --format markdown`
  Produces a Markdown draft from the same source.
- `python design_doc_generator.py /tmp/order_report.json --input-format json --output /tmp/order_report_design.md`
  Generates a design document from parser output.
- `python -m unittest discover -s test -v`
  Runs the full test suite.

## Coding Style & Naming Conventions
Follow existing Python style in the repository:

- Use 4-space indentation and type hints on public functions and dataclass fields.
- Prefer `snake_case` for functions, variables, and file names.
- Use `PascalCase` for dataclasses and enums such as `SectionTask` and `SqlInfo`.
- Keep modules focused; root scripts already act as the main application boundary.
- Write comments only when they explain intent, not syntax.

No formatter or linter is configured yet. Keep changes consistent with the current codebase and avoid introducing unnecessary dependencies.

## Testing Guidelines
Add `unittest` test cases in `test/test_*.py`. Name test methods as `test_<behavior>`. Cover behavior, edge cases, and regression risks, especially around Markdown section parsing, JSON shape handling, and API response normalization.

## Commit & Pull Request Guidelines
Git history currently starts from `Initial commit`, while repository-wide instructions require Conventional Commits. Use messages like `feat: add markdown section cache` or `fix: normalize duplicate headings`.

For pull requests, include:

- a short summary of the user-visible change,
- test evidence (`python -m unittest discover -s test -v`),
- sample input/output paths when behavior changes,
- linked issue or rationale if no issue exists.

## Security & Configuration Tips
Do not hardcode API keys. Use `OPENAI_BASE_URL`, `OPENAI_MODEL`, and `OPENAI_API_KEY` when running `design_doc_generator.py`. Treat `sample_json/` and `sample_markdown/` as generated artifacts and regenerate them when parser or prompt behavior changes.
