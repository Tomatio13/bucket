from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from design_doc_generator import (
    SectionTask,
    load_input,
    normalize_generated_section_content,
    write_section_cache,
)


SYSTEM_PROMPT = """あなたはCOBOL保守案件の単体試験設計を行う品質保証担当者です。
必ず日本語で出力してください。
入力として渡された設計書の記述だけを根拠に、単体試験項目一覧をMarkdownで作成してください。
推測は禁止です。不足情報は「要確認」と記載してください。
目的は、対象セクションに対して設計書記載内容を漏れなく確認できる試験観点を整理することです。
設計書に明記されていない入力値、エラー内容、表示メッセージ、更新項目、分岐条件を補完してはいけません。
"""

VALIDATION_SYSTEM_PROMPT = """あなたは単体試験項目一覧のレビュアーです。
必ず日本語で出力してください。
設計書に存在しない具体値、条件、メッセージ、入力例、エラー内容を削除または「要確認」に置き換えてください。
設計書に根拠がある記述だけを残してください。
見出し構造とMarkdown表は可能な限り維持してください。
"""


SECTION_PROMPT_TEMPLATE = """以下はCOBOL詳細設計書の一部です。
このセクションだけを根拠に、単体試験項目一覧をMarkdownで作成してください。

対象セクション:
{section_name}

作成ルール:
- このセクションの記述を網羅できる試験項目を列挙する
- 条件分岐、正常系、異常系、境界値、更新処理、出力内容、エラー時動作が読み取れる場合は漏れなく含める
- 設計書に書かれていない値や業務ルールは作らない
- 「100%カバレッジ」は、このセクションの設計記述を網羅する観点で整理する
- 同じ観点の重複は避ける
- 可能なら表形式で整理する
- 先頭にセクション見出しを重複出力しない
- 以下の列を基本とする: `試験項目ID`, `観点`, `事前条件・入力`, `確認内容`, `期待結果`
- 設計書に具体値がない場合、`不正データ` `NULL` `初期メッセージ` `エラーメッセージ表示` のような具体例を勝手に書かない
- 情報不足の場合は、`要確認` を用いた最小限の試験項目だけを書く

出力形式:
- まず短い「試験方針」箇条書きを書く
- 続けて試験項目一覧のMarkdown表を書く
- 試験項目が作れない場合でも、理由を明記して空にはしない

設計書抜粋:
```{payload_format}
{payload}
```
"""

VALIDATION_PROMPT_TEMPLATE = """以下の2つを比較し、単体試験項目一覧を設計書準拠に修正してください。

対象セクション:
{section_name}

修正ルール:
- 設計書にない具体値、固定メッセージ、入力例、NULL、不正データ、存在しないIDなどの補完を削除する
- 根拠がない箇所は「要確認」に置き換える
- 既に設計書に明記されている内容は残す
- Markdownの見出しと表形式は維持する
- 先頭にセクション見出しを重複出力しない
- 試験項目数は必要以上に増やさない

設計書:
```{payload_format}
{payload}
```

生成済み単体試験項目一覧:
```markdown
{generated_content}
```
"""

SUSPICIOUS_TERMS = (
    "NULL",
    "不正データ",
    "初期メッセージ",
    "エラーメッセージが表示される",
    "エラーメッセージを表示",
    "ダミー変数",
    "存在しない",
    "有効な",
    "無効な",
)

SUSPICIOUS_LITERAL_PATTERN = re.compile(r"(?:'[^']{1,80}'|\"[^\"]{1,80}\"|「[^」]{1,80}」)")
SUSPICIOUS_NUMERIC_CODE_PATTERN = re.compile(r"\b\d{3,}\b")


@dataclass
class TocStructure:
    top_titles: list[str]
    section_detail_titles: list[str]


class OpenAICompatibleClient:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        api_key: str | None,
        timeout: int = 120,
        debug_dir: Path | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.debug_dir = debug_dir

    def generate_test_items(
        self, section_name: str, payload: str, payload_format: str
    ) -> str:
        prompt = SECTION_PROMPT_TEMPLATE.format(
            section_name=section_name,
            payload=payload,
            payload_format=payload_format,
        )
        return self._post_markdown(prompt, SYSTEM_PROMPT, section_name, payload, payload_format)

    def revise_test_items(
        self,
        section_name: str,
        payload: str,
        payload_format: str,
        generated_content: str,
    ) -> str:
        prompt = VALIDATION_PROMPT_TEMPLATE.format(
            section_name=section_name,
            payload=payload,
            payload_format=payload_format,
            generated_content=generated_content,
        )
        return self._post_markdown(
            prompt,
            VALIDATION_SYSTEM_PROMPT,
            f"{section_name}_validation",
            payload,
            payload_format,
        )

    def _post_markdown(
        self,
        prompt: str,
        system_prompt: str,
        section_name: str,
        payload: str,
        payload_format: str,
    ) -> str:
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.0,
        }
        request_body = json.dumps(
            body,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
        request = urllib.request.Request(
            url=f"{self.base_url}/chat/completions",
            data=request_body,
            headers=self._build_headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                response_payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            self._write_debug_dump(
                section_name=section_name,
                payload=payload,
                payload_format=payload_format,
                request_body=request_body,
                error_detail=f"HTTP {exc.code}\n{detail}",
            )
            raise RuntimeError(f"API request failed: {exc.code} {detail}") from exc
        except urllib.error.URLError as exc:
            self._write_debug_dump(
                section_name=section_name,
                payload=payload,
                payload_format=payload_format,
                request_body=request_body,
                error_detail=f"URL error: {exc.reason}",
            )
            raise RuntimeError(f"API request failed: {exc.reason}") from exc

        return strip_outer_code_fence(self._extract_content(response_payload).strip())

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    @staticmethod
    def _extract_content(payload: dict[str, Any]) -> str:
        choices = payload.get("choices")
        if not choices:
            raise RuntimeError("API response does not contain choices.")
        message = choices[0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    parts.append(item.get("text", ""))
            if parts:
                return "\n".join(parts)
        raise RuntimeError("API response content format is not supported.")

    def _write_debug_dump(
        self,
        *,
        section_name: str,
        payload: str,
        payload_format: str,
        request_body: bytes,
        error_detail: str,
    ) -> None:
        if self.debug_dir is None:
            return
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        debug_base = self.debug_dir / slugify(section_name)
        metadata = {
            "section_name": section_name,
            "payload_format": payload_format,
            "request_bytes": len(request_body),
            "error_detail": error_detail,
        }
        (debug_base.with_suffix(".request.json")).write_bytes(request_body)
        (debug_base.with_suffix(".payload.md")).write_text(payload, encoding="utf-8")
        (debug_base.with_suffix(".meta.json")).write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def build_test_item_tasks(source_text: str, input_format: str) -> list[SectionTask]:
    if input_format != "markdown":
        raise ValueError("unit test item generator supports markdown input only.")

    lines = source_text.splitlines()
    toc = parse_toc_structure(lines)
    if not toc.top_titles:
        raise ValueError("table of contents could not be parsed from markdown input.")

    tasks: list[SectionTask] = []
    top_heading_positions = find_heading_positions(lines, toc.top_titles, level=2)

    for index, title in enumerate(toc.top_titles):
        start = top_heading_positions[title] + 1
        end = len(lines)
        if index + 1 < len(toc.top_titles):
            end = top_heading_positions[toc.top_titles[index + 1]]
        payload_lines = lines[start:end]

        if title == "6. セクション詳細":
            tasks.append(
                SectionTask(
                    key="6_セクション詳細",
                    title=title,
                    payload="",
                    payload_format="markdown",
                    heading_level=2,
                    generate_content=False,
                )
            )
            child_positions = find_heading_positions(
                payload_lines,
                toc.section_detail_titles,
                level=3,
            )
            for child_index, child_title in enumerate(toc.section_detail_titles):
                child_start = child_positions[child_title] + 1
                child_end = len(payload_lines)
                if child_index + 1 < len(toc.section_detail_titles):
                    child_end = child_positions[toc.section_detail_titles[child_index + 1]]
                child_payload = "\n".join(payload_lines[child_start:child_end]).strip()
                tasks.append(
                    SectionTask(
                        key=slugify(child_title),
                        title=child_title,
                        payload=child_payload,
                        payload_format="markdown",
                        heading_level=3,
                    )
                )
            continue

        payload = "\n".join(payload_lines).strip()
        tasks.append(
            SectionTask(
                key=slugify(title),
                title=title,
                payload=payload,
                payload_format="markdown",
                heading_level=2,
            )
        )

    return tasks


def parse_toc_structure(lines: list[str]) -> TocStructure:
    toc_start = find_heading_index(lines, "目次", level=2)
    if toc_start is None:
        return TocStructure(top_titles=[], section_detail_titles=[])

    top_titles: list[str] = []
    section_detail_titles: list[str] = []
    inside_section_details = False

    for line in lines[toc_start + 1 :]:
        stripped = line.strip()
        if stripped == "---":
            break
        top_match = re.match(r"^\d+\.\s+(.+)$", stripped)
        if top_match:
            title = top_match.group(1).strip()
            top_titles.append(title)
            inside_section_details = title == "6. セクション詳細"
            continue
        if inside_section_details:
            child_match = re.match(r"^-\s+(.+)$", stripped)
            if child_match:
                section_detail_titles.append(child_match.group(1).strip())

    filtered_titles = [title for title in top_titles if title != "目次"]
    return TocStructure(
        top_titles=filtered_titles,
        section_detail_titles=section_detail_titles,
    )


def find_heading_index(lines: list[str], title: str, level: int) -> int | None:
    heading = f"{'#' * level} {title}"
    for index, line in enumerate(lines):
        if line.strip() == heading:
            return index
    return None


def find_heading_positions(lines: list[str], titles: list[str], level: int) -> dict[str, int]:
    positions: dict[str, int] = {}
    pending = set(titles)
    heading_pattern = re.compile(rf"^{'#' * level}\s+(.+?)\s*$")

    for index, line in enumerate(lines):
        match = heading_pattern.match(line.strip())
        if not match:
            continue
        title = match.group(1).strip()
        if title in pending:
            positions[title] = index
            pending.remove(title)
            if not pending:
                break

    if pending:
        missing = ", ".join(sorted(pending))
        raise ValueError(f"expected headings not found: {missing}")
    return positions


def slugify(text: str) -> str:
    normalized = re.sub(r"[^\w\u3040-\u30ff\u3400-\u9fff-]+", "_", text.strip())
    return normalized.strip("_").lower() or "section"


def has_unsupported_specifics(payload: str, generated_content: str) -> bool:
    for term in SUSPICIOUS_TERMS:
        if term in generated_content and term not in payload:
            return True

    quoted_literals = SUSPICIOUS_LITERAL_PATTERN.findall(generated_content)
    for literal in quoted_literals:
        inner = literal[1:-1]
        if literal not in payload and inner not in payload and "要確認" not in literal:
            return True

    uppercase_literals = re.findall(r"\b[A-Z][A-Z0-9_-]{4,}\b", generated_content)
    for literal in uppercase_literals:
        if literal not in payload:
            return True

    numeric_codes = SUSPICIOUS_NUMERIC_CODE_PATTERN.findall(generated_content)
    for code in numeric_codes:
        if code not in payload:
            return True

    return False


def strip_outer_code_fence(content: str) -> str:
    stripped = content.strip()
    match = re.match(r"^```[a-zA-Z0-9_-]*\n(.*)\n```$", stripped, re.DOTALL)
    if match:
        return match.group(1).strip()
    return stripped


def sanitize_generated_content(payload: str, content: str) -> str:
    sanitized_lines: list[str] = []
    for line in strip_outer_code_fence(content).splitlines():
        if not line.lstrip().startswith("|"):
            sanitized_lines.append(sanitize_free_text_line(payload, line))
            continue
        stripped = line.strip()
        if "---" in stripped or "試験項目ID" in stripped:
            sanitized_lines.append(line)
            continue
        if not has_unsupported_specifics(payload, line):
            sanitized_lines.append(line)
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        if len(cells) >= 5:
            cells[2] = "要確認"
            cells[3] = "設計書記載内容に基づき確認"
            cells[4] = "要確認"
            sanitized_lines.append("| " + " | ".join(cells) + " |")
            continue
        sanitized_lines.append("要確認")
    return "\n".join(sanitized_lines).strip()


def sanitize_free_text_line(payload: str, line: str) -> str:
    sanitized = line
    for literal in SUSPICIOUS_LITERAL_PATTERN.findall(sanitized):
        inner = literal[1:-1]
        if literal not in payload and inner not in payload:
            sanitized = sanitized.replace(literal, "要確認")

    for code in sorted(set(SUSPICIOUS_NUMERIC_CODE_PATTERN.findall(sanitized)), key=len, reverse=True):
        if code not in payload:
            sanitized = re.sub(rf"\b{re.escape(code)}\b", "要確認", sanitized)

    for term in SUSPICIOUS_TERMS:
        if term in sanitized and term not in payload:
            sanitized = sanitized.replace(term, "要確認")

    return sanitized


def ground_generated_content(
    client: OpenAICompatibleClient,
    task: SectionTask,
    content: str,
    *,
    max_passes: int = 2,
) -> str:
    grounded = sanitize_generated_content(task.payload, content)
    for _ in range(max_passes):
        if not has_unsupported_specifics(task.payload, grounded):
            return grounded
        grounded = client.revise_test_items(
            task.title,
            task.payload,
            task.payload_format,
            grounded,
        )
        grounded = sanitize_generated_content(task.payload, grounded)
    return grounded


def assemble_test_items_document(
    title: str, generated_sections: list[tuple[SectionTask, str]]
) -> str:
    lines = [
        f"# {title}",
        "",
        "## 目次",
        "",
    ]

    toc_index = 0
    for task, _ in generated_sections:
        if task.heading_level == 2:
            toc_index += 1
            lines.append(f"{toc_index}. {task.title}")

    lines.extend(["", "---", ""])
    for task, content in generated_sections:
        lines.append(f"{'#' * task.heading_level} {task.title}")
        lines.append("")
        if task.generate_content:
            lines.append(normalize_generated_section_content(content, task.title))
        else:
            lines.append("- この章は配下セクションの試験項目を参照してください。")
        lines.append("")

    return "\n".join(lines).strip() + "\n"


def read_section_cache(cache_dir: Path, task: SectionTask) -> str | None:
    section_path = cache_dir / f"{task.key}.md"
    if not section_path.exists():
        return None
    content = section_path.read_text(encoding="utf-8").strip()
    return content or None


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="詳細設計書MarkdownをOpenAI互換APIで単体試験項目一覧に変換します。"
    )
    parser.add_argument("input", help="入力Markdownファイル。")
    parser.add_argument(
        "--input-format",
        choices=("auto", "markdown"),
        default="auto",
        help="入力形式。既定値は auto。",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="生成する単体試験項目一覧Markdownの出力先。",
    )
    parser.add_argument(
        "--title",
        default="単体試験項目一覧",
        help="出力Markdownのタイトル。",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("OPENAI_BASE_URL", "http://localhost:8000/v1"),
        help="OpenAI互換APIのベースURL。環境変数 OPENAI_BASE_URL でも指定可能。",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
        help="使用モデル名。環境変数 OPENAI_MODEL でも指定可能。",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("OPENAI_API_KEY"),
        help="APIキー。環境変数 OPENAI_API_KEY でも指定可能。",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="APIタイムアウト秒。既定値は 120。",
    )
    parser.add_argument(
        "--cache-dir",
        help="各セクションの生成結果を保存するディレクトリ。",
    )
    parser.add_argument(
        "--debug-dir",
        help="API失敗時のリクエスト/入力を保存するディレクトリ。",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    input_path = Path(args.input)
    output_path = Path(args.output)

    source_text, input_format = load_input(input_path, args.input_format)
    tasks = build_test_item_tasks(source_text, input_format)
    cache_dir = Path(args.cache_dir) if args.cache_dir else None
    debug_dir = Path(args.debug_dir) if args.debug_dir else None
    if debug_dir is None and cache_dir is not None:
        debug_dir = cache_dir / "_debug"
    client = OpenAICompatibleClient(
        base_url=args.base_url,
        model=args.model,
        api_key=args.api_key,
        timeout=args.timeout,
        debug_dir=debug_dir,
    )

    generated_sections: list[tuple[SectionTask, str]] = []

    for index, task in enumerate(tasks, start=1):
        if not task.generate_content:
            generated_sections.append((task, ""))
            continue

        if cache_dir is not None:
            cached_content = read_section_cache(cache_dir, task)
            if cached_content is not None:
                print(f"[{index}/{len(tasks)}] cached: {task.title}", file=sys.stderr)
                content = sanitize_generated_content(task.payload, cached_content)
                if has_unsupported_specifics(task.payload, content) or content != cached_content:
                    print(f"[{index}/{len(tasks)}] revising cached: {task.title}", file=sys.stderr)
                    content = ground_generated_content(client, task, content)
                    write_section_cache(cache_dir, task, content)
                generated_sections.append((task, content))
                continue

        print(f"[{index}/{len(tasks)}] generating: {task.title}", file=sys.stderr)
        try:
            content = sanitize_generated_content(
                task.payload,
                client.generate_test_items(task.title, task.payload, task.payload_format),
            )
            if has_unsupported_specifics(task.payload, content):
                print(f"[{index}/{len(tasks)}] revising: {task.title}", file=sys.stderr)
                content = ground_generated_content(client, task, content)
        except RuntimeError:
            if generated_sections:
                partial_output_path = output_path.with_suffix(".partial.md")
                partial_document = assemble_test_items_document(args.title, generated_sections)
                partial_output_path.write_text(partial_document, encoding="utf-8")
                print(f"partial written: {partial_output_path}", file=sys.stderr)
            raise
        generated_sections.append((task, content))
        if cache_dir is not None:
            write_section_cache(cache_dir, task, content)

    final_document = assemble_test_items_document(args.title, generated_sections)
    output_path.write_text(final_document, encoding="utf-8")
    print(f"written: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
