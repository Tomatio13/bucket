from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from design_doc_generator import SectionTask, build_section_tasks, load_input


SYSTEM_PROMPT = """あなたはCOBOL保守案件のコードレビュアーです。
必ず日本語で出力してください。
与えられた解析結果だけを根拠にレビューしてください。
情報が不足する箇所は推測せず、「要確認」と明記してください。
指摘がある場合は重大度順に並べてください。
各指摘には、何が問題か・なぜ問題か・どのような影響があるかを含めてください。
指摘がない場合でも、その旨と残る確認事項を簡潔に書いてください。
"""


SECTION_REVIEW_PROMPT_TEMPLATE = """以下は COBOL 解析結果から抽出したレビュー対象です。
レビュー観点に従って、この対象だけをレビューしてください。

対象セクション:
{section_name}

レビュー観点:
{review_points}

レビュー対象:
```{payload_format}
{payload}
```

出力ルール:
- Markdown で出力する
- 先頭に `## {section_name}` の見出しを置く
- その直後に短い要約を書く
- 指摘があれば `1. 2. 3.` の番号付きで重大度順に並べる
- 各指摘は以下の形式に近づける
  - `[High]` などの重大度
  - 問題点
  - 根拠
  - 影響
  - 対応案または確認ポイント
- 推測で断定しない
- COBOL命令の逐語説明ではなく、保守・品質・欠落観点のレビューにする
"""


@dataclass
class ReviewCheckpointSet:
    title: str
    content: str


class OpenAICompatibleClient:
    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        api_key: str | None,
        timeout: int = 120,
        debug_dir: Path | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.debug_dir = debug_dir

    def generate_review(
        self,
        section_name: str,
        payload: str,
        payload_format: str,
        review_points: str,
    ) -> str:
        prompt = SECTION_REVIEW_PROMPT_TEMPLATE.format(
            section_name=section_name,
            payload=payload,
            payload_format=payload_format,
            review_points=review_points,
        )
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.0,
        }
        request_body = json.dumps(
            body,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
        request = urllib.request.Request(
            url=f"{self.base_url}/chat/completions",
            data=request_body,
            headers=self._build_headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                response_payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            self._write_debug_dump(
                section_name=section_name,
                payload=payload,
                payload_format=payload_format,
                request_body=request_body,
                error_detail=f"HTTP {exc.code}\n{detail}",
            )
            raise RuntimeError(f"API request failed: {exc.code} {detail}") from exc
        except urllib.error.URLError as exc:
            self._write_debug_dump(
                section_name=section_name,
                payload=payload,
                payload_format=payload_format,
                request_body=request_body,
                error_detail=f"URL error: {exc.reason}",
            )
            raise RuntimeError(f"API request failed: {exc.reason}") from exc

        return strip_outer_code_fence(self._extract_content(response_payload).strip())

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    @staticmethod
    def _extract_content(payload: dict[str, Any]) -> str:
        choices = payload.get("choices")
        if not choices:
            raise RuntimeError("API response does not contain choices.")
        message = choices[0].get("message", {})
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    parts.append(item.get("text", ""))
            if parts:
                return "\n".join(parts)
        raise RuntimeError("API response content format is not supported.")

    def _write_debug_dump(
        self,
        *,
        section_name: str,
        payload: str,
        payload_format: str,
        request_body: bytes,
        error_detail: str,
    ) -> None:
        if self.debug_dir is None:
            return
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        debug_base = self.debug_dir / slugify(section_name)
        metadata = {
            "section_name": section_name,
            "payload_format": payload_format,
            "request_bytes": len(request_body),
            "error_detail": error_detail,
        }
        (debug_base.with_suffix(".request.json")).write_bytes(request_body)
        (debug_base.with_suffix(".payload.md")).write_text(payload, encoding="utf-8")
        (debug_base.with_suffix(".meta.json")).write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def slugify(value: str) -> str:
    sanitized = "".join(ch.lower() if ch.isalnum() else "-" for ch in value.strip())
    while "--" in sanitized:
        sanitized = sanitized.replace("--", "-")
    return sanitized.strip("-") or "section"


def strip_outer_code_fence(text: str) -> str:
    lines = text.strip().splitlines()
    if len(lines) >= 2 and lines[0].startswith("```") and lines[-1].startswith("```"):
        return "\n".join(lines[1:-1]).strip()
    return text.strip()


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="COBOL解析JSON/MarkdownをOpenAI互換APIでコードレビュー結果に変換します。"
    )
    parser.add_argument("input", help="入力ファイル。JSONまたはMarkdown。")
    parser.add_argument(
        "--input-format",
        choices=("auto", "json", "markdown"),
        default="auto",
        help="入力形式。既定値は auto。",
    )
    parser.add_argument(
        "--output",
        help="生成するレビューMarkdownの出力先。",
    )
    parser.add_argument(
        "--title",
        default="COBOLコードレビュー",
        help="出力Markdownのタイトル。",
    )
    parser.add_argument(
        "--section-key",
        action="append",
        default=[],
        help="レビュー対象に含める section key。複数回指定可能。",
    )
    parser.add_argument(
        "--title-contains",
        action="append",
        default=[],
        help="レビュー対象タイトルの部分一致条件。複数回指定可能。",
    )
    parser.add_argument(
        "--list-sections",
        action="store_true",
        help="レビュー可能なセクション一覧を表示して終了します。",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("OPENAI_BASE_URL", "http://localhost:8000/v1"),
        help="OpenAI互換APIのベースURL。環境変数 OPENAI_BASE_URL でも指定可能。",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
        help="使用モデル名。環境変数 OPENAI_MODEL でも指定可能。",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("OPENAI_API_KEY"),
        help="APIキー。環境変数 OPENAI_API_KEY でも指定可能。",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="APIタイムアウト秒。既定値は 120。",
    )
    parser.add_argument(
        "--review-points",
        default="docs/cobol_review_checkpoints.md",
        help="レビュー観点Markdownのパス。",
    )
    parser.add_argument(
        "--cache-dir",
        help="各セクションのレビュー結果を保存するディレクトリ。",
    )
    parser.add_argument(
        "--debug-dir",
        help="API失敗時のリクエスト/入力を保存するディレクトリ。",
    )
    return parser.parse_args(argv)


def filter_tasks(
    tasks: list[SectionTask],
    section_keys: list[str],
    title_keywords: list[str],
) -> list[SectionTask]:
    requested_keys = {key for key in section_keys if key}
    requested_titles = [keyword for keyword in title_keywords if keyword]
    if not requested_keys and not requested_titles:
        return tasks

    filtered: list[SectionTask] = []
    for task in tasks:
        if task.key in requested_keys:
            filtered.append(task)
            continue
        if requested_titles and all(keyword in task.title for keyword in requested_titles):
            filtered.append(task)
    return filtered


def validate_filtered_tasks(
    tasks: list[SectionTask],
    filtered_tasks: list[SectionTask],
    section_keys: list[str],
) -> None:
    task_keys = {task.key for task in tasks}
    unknown_keys = sorted({key for key in section_keys if key and key not in task_keys})
    if unknown_keys:
        raise ValueError(f"存在しない section key が指定されました: {', '.join(unknown_keys)}")
    if not filtered_tasks:
        raise ValueError("条件に一致するセクションが見つかりません。--list-sections で候補を確認してください。")


def render_section_list(tasks: list[SectionTask]) -> str:
    lines = ["key\ttitle\tformat\tgenerate_content"]
    for task in tasks:
        lines.append(f"{task.key}\t{task.title}\t{task.payload_format}\t{task.generate_content}")
    return "\n".join(lines) + "\n"


def load_review_checkpoints(path: Path) -> list[ReviewCheckpointSet]:
    text = path.read_text(encoding="utf-8").strip()
    sections: list[ReviewCheckpointSet] = []
    current_title: str | None = None
    current_lines: list[str] = []
    for line in text.splitlines():
        if line.startswith("## "):
            if current_title is not None:
                sections.append(ReviewCheckpointSet(current_title, "\n".join(current_lines).strip()))
            current_title = line[3:].strip()
            current_lines = [line]
            continue
        if current_title is None:
            continue
        current_lines.append(line)
    if current_title is not None:
        sections.append(ReviewCheckpointSet(current_title, "\n".join(current_lines).strip()))
    return sections


def select_review_points(task: SectionTask, checkpoints: list[ReviewCheckpointSet]) -> str:
    wanted_titles = ["共通観点"]
    if task.title == "プログラム概要":
        wanted_titles.append("プログラム概要")
    elif task.title == "外部仕様・入出力":
        wanted_titles.append("外部仕様・入出力")
    elif task.title == "DB・SQL仕様":
        wanted_titles.append("DB・SQL仕様")
    elif "セクション詳細" in task.title:
        wanted_titles.append("セクション詳細")
    else:
        wanted_titles.extend(section.title for section in checkpoints if section.title != "レビュー結果の書き方")

    wanted_titles.append("レビュー結果の書き方")
    selected = [section.content for section in checkpoints if section.title in wanted_titles]
    return "\n\n".join(selected).strip()


def assemble_review_document(title: str, reviews: list[tuple[SectionTask, str]]) -> str:
    lines = [f"# {title}"]
    for task, review in reviews:
        lines.extend(
            [
                "",
                f"<!-- section-key: {task.key} -->",
                review.strip() if review.strip() else f"## {task.title}\n\nレビュー結果を取得できませんでした。",
            ]
        )
    return "\n".join(lines).strip() + "\n"


def write_section_cache(cache_dir: Path, task: SectionTask, content: str) -> None:
    cache_dir.mkdir(parents=True, exist_ok=True)
    section_path = cache_dir / f"{task.key}.md"
    section_path.write_text(content, encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    input_path = Path(args.input)
    review_points_path = Path(args.review_points)

    source_text, input_format = load_input(input_path, args.input_format)
    tasks = build_section_tasks(source_text, input_format)

    if args.list_sections:
        sys.stdout.write(render_section_list(tasks))
        return 0

    filtered_tasks = filter_tasks(tasks, args.section_key, args.title_contains)
    validate_filtered_tasks(tasks, filtered_tasks, args.section_key)
    checkpoints = load_review_checkpoints(review_points_path)
    if not args.output:
        raise ValueError("--output は --list-sections を使わない場合に必須です。")
    output_path = Path(args.output)

    client = OpenAICompatibleClient(
        base_url=args.base_url,
        model=args.model,
        api_key=args.api_key,
        timeout=args.timeout,
        debug_dir=Path(args.debug_dir) if args.debug_dir else None,
    )

    generated_reviews: list[tuple[SectionTask, str]] = []
    cache_dir = Path(args.cache_dir) if args.cache_dir else None

    for index, task in enumerate(filtered_tasks, start=1):
        print(f"[{index}/{len(filtered_tasks)}] reviewing: {task.title}", file=sys.stderr)
        review_points = select_review_points(task, checkpoints)
        content = client.generate_review(task.title, task.payload, task.payload_format, review_points)
        generated_reviews.append((task, content))
        if cache_dir is not None:
            write_section_cache(cache_dir, task, content)

    final_document = assemble_review_document(args.title, generated_reviews)
    output_path.write_text(final_document, encoding="utf-8")
    print(f"written: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
