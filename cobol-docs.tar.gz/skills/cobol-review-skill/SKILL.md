---
name: cobol-review-skill
description: COBOLソースのコードレビューを、`cobol_parser.py` のJSON/Markdown出力を使って段階的に進めるスキル。COBOLレビュー、保守観点レビュー、改修影響確認、処理単位の確認、ローカルLLM向けに小さく分割してレビューしたい依頼では必ず使う。ユーザーが COBOL ソース、`cobol_parser.py`、JSON化、Markdown化、設計書化、セクション単位レビュー、レビュー観点、観点別チェック を示したときにも使う。
---

# COBOL Review Skill

`cobol_parser.py` で COBOL を中間成果物へ変換し、必要ならセクション単位まで絞り込んでレビューする。
大きな入力をそのまま LLM に渡さず、まず構造化してから対象を狭める。

## 目的

- COBOLソースをそのまま読むより先に、JSONまたはMarkdownへ変換して構造を把握する
- ローカルLLMでも扱えるように、レビュー対象を章単位・段落単位へ小さく分割する
- レビュー観点を別ファイルから読み込み、観点漏れを防ぐ
- 指摘はコードレビューの形式で返す

## 使うファイル

- パーサ: `cobol_parser.py`
- 分割ロジックの参照元: `design_doc_generator.py`
- レビュー入力準備スクリプト: `scripts/prepare_review_material.py`
- レビュー観点: `references/review_checkpoints.md`

## 基本フロー

1. 入力が COBOL ソースなら、まず `cobol_parser.py` で JSON か Markdown に変換する。
2. `scripts/prepare_review_material.py --list-sections` でレビュー可能な分割単位を確認する。
3. 入力が大きい、またはユーザーが特定箇所だけ見たい場合は、`--section-key` または `--title-contains` で対象を絞る。
4. `references/review_checkpoints.md` から今回の対象に合う観点を選ぶ。
5. 選択したセクションだけを根拠にレビューする。
6. 指摘があれば重大度順に並べ、根拠となる section key / title / 入力内容を明示する。

## 実行手順

### 1. COBOL を中間成果物へ変換する

JSONにする例:

```bash
python3 cobol_parser.py test/order_report_batch_sample.cbl --format json > /tmp/order_report.json
```

Markdownにする例:

```bash
python3 cobol_parser.py test/order_report_batch_sample.cbl --format markdown > /tmp/order_report.md
```

レビュー対象の切り分けが必要なら、原則として JSON を優先する。`design_doc_generator.py` と同じ粒度で `overview` `structure` `method_xx_*` `database` に分けやすいため。

### 2. セクション一覧を確認する

```bash
python3 skills/cobol-review-skill/scripts/prepare_review_material.py /tmp/order_report.json --list-sections
```

### 3. 必要な箇所だけ抽出する

特定メソッドだけ見る例:

```bash
python3 skills/cobol-review-skill/scripts/prepare_review_material.py \
  /tmp/order_report.json \
  --section-key method_02_MAIN-LOOP \
  --output /tmp/review_packet.md
```

タイトルの部分一致で絞る例:

```bash
python3 skills/cobol-review-skill/scripts/prepare_review_material.py \
  /tmp/order_report.md \
  --title-contains セクション詳細 \
  --title-contains MAIN \
  --output /tmp/review_packet.md
```

### 4. レビュー観点を読む

`references/review_checkpoints.md` を読み、対象に関係する章だけ使う。

- 全体構造を見るとき: `共通観点`
- ファイルI/OやCOPY句を見るとき: `外部仕様・入出力`
- 段落処理を見るとき: `セクション詳細`
- SQLやカーソルを見るとき: `DB・SQL仕様`

### 5. レビューする

レビューでは次を守る。

- Findings first で返す
- 重大度順に並べる
- 推測で断定しない
- COBOL原文だけでなく、JSON/Markdown中間成果物も根拠として使う
- 範囲外の話は広げない

## 出力ルール

レビュー結果は以下の形を優先する。

```markdown
1. [severity] 指摘の要約
根拠: <section key or title>
理由: <何が問題か>
影響: <想定される不具合、保守リスク、確認漏れ>

2. ...
```

指摘がない場合も、その旨を明記し、残るリスクを短く添える。

## 判断ルール

- 入力が大きいときは、いきなり全文レビューしない
- 対象レビュー箇所が曖昧なときは、まず `--list-sections` を使う
- ローカルLLMや小さいコンテキスト前提なら、1回のレビュー対象は 1〜3 セクションを目安にする
- メソッド単位レビューと DB 仕様レビューは分けてよい
- JSONとMarkdownのどちらも使える場合、構造把握は JSON、自然文の確認は Markdown を優先する

## 補足

`scripts/prepare_review_material.py` は `design_doc_generator.py` のセクション分割ロジックを再利用している。設計書生成と同じ粒度でレビュー対象を切れるため、後工程との整合を崩しにくい。
