from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from design_doc_generator import SectionTask, build_section_tasks, load_input


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="COBOLレビュー用に parser 出力をセクション単位へ整理します。"
    )
    parser.add_argument("input", help="cobol_parser.py が出力した JSON または Markdown ファイル。")
    parser.add_argument(
        "--input-format",
        choices=("auto", "json", "markdown"),
        default="auto",
        help="入力形式。既定値は auto。",
    )
    parser.add_argument(
        "--list-sections",
        action="store_true",
        help="レビュー可能なセクション一覧だけを表示します。",
    )
    parser.add_argument(
        "--section-key",
        action="append",
        default=[],
        help="抽出する section key。複数回指定可能。",
    )
    parser.add_argument(
        "--title-contains",
        action="append",
        default=[],
        help="タイトル部分一致で抽出する文字列。複数回指定可能。",
    )
    parser.add_argument(
        "--output",
        help="レビュー用 Markdown の出力先。未指定時は標準出力へ出します。",
    )
    parser.add_argument(
        "--review-points",
        default=str(Path(__file__).resolve().parent.parent / "references" / "review_checkpoints.md"),
        help="レビュー観点 Markdown のパス。",
    )
    return parser.parse_args(argv)


def filter_tasks(
    tasks: list[SectionTask],
    section_keys: Iterable[str],
    title_keywords: Iterable[str],
) -> list[SectionTask]:
    requested_keys = {key for key in section_keys if key}
    requested_titles = [keyword for keyword in title_keywords if keyword]
    if not requested_keys and not requested_titles:
        return tasks

    filtered: list[SectionTask] = []
    for task in tasks:
        if task.key in requested_keys:
            filtered.append(task)
            continue
        if requested_titles and all(keyword in task.title for keyword in requested_titles):
            filtered.append(task)
    return filtered


def validate_filters(
    tasks: list[SectionTask],
    filtered_tasks: list[SectionTask],
    section_keys: Iterable[str],
) -> None:
    task_keys = {task.key for task in tasks}
    unknown_keys = sorted({key for key in section_keys if key and key not in task_keys})
    if unknown_keys:
        raise ValueError(f"存在しない section key が指定されました: {', '.join(unknown_keys)}")

    if not filtered_tasks:
        raise ValueError("条件に一致するセクションが見つかりません。--list-sections で候補を確認してください。")


def render_section_list(tasks: list[SectionTask]) -> str:
    lines = ["key\ttitle\tformat\tgenerate_content"]
    for task in tasks:
        lines.append(f"{task.key}\t{task.title}\t{task.payload_format}\t{task.generate_content}")
    return "\n".join(lines)


def render_review_packet(
    input_path: Path,
    input_format: str,
    review_points_path: Path,
    tasks: list[SectionTask],
) -> str:
    review_points = review_points_path.read_text(encoding="utf-8").strip()
    lines = [
        "# COBOL Review Packet",
        "",
        "## Source",
        f"- input_path: {input_path}",
        f"- input_format: {input_format}",
        f"- selected_section_count: {len(tasks)}",
        "",
        "## Review Procedure",
        "1. Read the review checkpoints and pick only the relevant items.",
        "2. Review the selected sections without expanding the scope unnecessarily.",
        "3. Return findings first, ordered by severity.",
        "",
        "## Review Checkpoints",
        review_points,
    ]

    for index, task in enumerate(tasks, start=1):
        lines.extend(
            [
                "",
                f"## Selected Section {index}",
                f"- key: {task.key}",
                f"- title: {task.title}",
                f"- payload_format: {task.payload_format}",
                f"- heading_level: {task.heading_level}",
                f"- generate_content: {task.generate_content}",
                "",
                f"```{task.payload_format}",
                task.payload.strip(),
                "```",
            ]
        )

    return "\n".join(lines).strip() + "\n"


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    input_path = Path(args.input)
    review_points_path = Path(args.review_points)

    source_text, input_format = load_input(input_path, args.input_format)
    tasks = build_section_tasks(source_text, input_format)

    if args.list_sections:
        output_text = render_section_list(tasks)
    else:
        filtered_tasks = filter_tasks(tasks, args.section_key, args.title_contains)
        validate_filters(tasks, filtered_tasks, args.section_key)
        output_text = render_review_packet(input_path, input_format, review_points_path, filtered_tasks)

    if args.output:
        Path(args.output).write_text(output_text, encoding="utf-8")
    else:
        sys.stdout.write(output_text)
        if not output_text.endswith("\n"):
            sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
