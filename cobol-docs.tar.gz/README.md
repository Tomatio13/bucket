# COBOL Docs Toolkit

COBOL ソースを静的解析し、詳細設計書と単体試験項目一覧を生成するための Python ツール群です。  
標準ライブラリのみで動作し、OpenAI 互換 API を利用する設計書生成系ツールも含みます。

## 構成

- `cobol_parser.py`
  - COBOL ソースを解析し、JSON または Markdown の中間成果物を生成します。
- `design_doc_generator.py`
  - 解析結果をセクション単位で OpenAI 互換 API に渡し、詳細設計書 Markdown を生成します。
- `unit_test_item_generator.py`
  - 詳細設計書をセクション単位で処理し、単体試験項目一覧 Markdown を生成します。
- `test/`
  - `unittest` ベースのテストとサンプル COBOL ファイルを格納します。
- `sample_json/`, `sample_markdown/`
  - サンプル入力・生成結果の保管場所です。
- `docs/`
  - 各 Python スクリプトの設計書です。

## 前提環境

- Python 3.10 以上推奨
- 追加ライブラリ不要
- `design_doc_generator.py` と `unit_test_item_generator.py` は OpenAI 互換 API が必要

環境変数:

```bash
export OPENAI_BASE_URL=http://localhost:8000/v1
export OPENAI_MODEL=gpt-4.1-mini
export OPENAI_API_KEY=dummy
```

## 使い方

### 1. COBOL を解析して JSON を生成

```bash
python3 cobol_parser.py test/order_report_batch_sample.cbl --format json > /tmp/order_report.json
```

### 2. 詳細設計書を生成

```bash
python3 design_doc_generator.py /tmp/order_report.json \
  --input-format json \
  --output /tmp/order_report_design.md \
  --cache-dir /tmp/order_report_sections
```

### 3. 単体試験項目一覧を生成

```bash
python3 unit_test_item_generator.py /tmp/order_report_design.md \
  --input-format markdown \
  --output /tmp/order_report_test_items.md \
  --cache-dir /tmp/order_report_test_sections
```

## 主な出力

- 解析結果 JSON
  - `file_path`, `copy_list`, `file_definition_list`, `called_module_list`, `method_list`, `sql_info_list`, `cursor_list`
- 詳細設計書 Markdown
  - 章見出しごとに生成し、`セクション詳細` は子セクション単位で展開
- 単体試験項目一覧 Markdown
  - 設計書の章構造に合わせて生成し、不足情報は `要確認` として保持

## テスト

全テスト:

```bash
python3 -m unittest discover -s test -v
```

構文確認:

```bash
python3 -m compileall cobol_parser.py design_doc_generator.py unit_test_item_generator.py
```

## 設計書

- [COBOL Parser 設計書](docs/cobol_parser_design.md)
- [Design Doc Generator 設計書](docs/design_doc_generator_design.md)
- [Unit Test Item Generator 設計書](docs/unit_test_item_generator_design.md)

## 注意点

- 解析は静的解析ベースです。業務仕様を完全復元するものではありません。
- LLM 出力はモデル品質に依存します。不足情報は `要確認` として扱う前提です。
- 単体試験項目生成は保守的に寄せていますが、最終的なプロジェクト固有ルールの反映は別途調整が必要です。
