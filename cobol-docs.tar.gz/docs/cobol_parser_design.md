# cobol_parser.py 設計書

## 1. 目的

`cobol_parser.py` は COBOL ソースを静的解析し、後続処理で使いやすい構造化データを生成するためのエントリポイントです。  
出力形式は JSON または Markdown で、詳細設計書生成や単体試験項目生成の前段を担います。

## 2. 責務

- COBOL ソースの行整形
- Division 判定
- COPY 句、ファイル定義、外部呼出、セクション一覧の抽出
- セクションごとの操作列、呼出関係、チェックポイントの抽出
- SQL 文とカーソル定義の抽出
- 解析結果の JSON / Markdown 変換

## 3. 主な構成

- `CobolParser`
  - 実際の解析処理を担当する中核クラス
- `CobolAnalysisResult`
  - 解析結果の保持と出力変換を担当
- `Method`, `CalledMethod`, `Operation`, `SqlInfo`, `FileDefinition`
  - 解析結果を構造化するデータクラス
- `Division`, `SqlType`
  - COBOL の大分類、SQL 種別を表す列挙型

## 4. 処理フロー

1. CLI 引数で対象ファイル、文字コード、出力形式を受け取る
2. `CobolParser.parse_file()` でファイルを読み込む
3. 各行を正規化し、Division 遷移や予約語を考慮しながら解析する
4. セクション、呼出先、主要操作、SQL、カーソルを蓄積する
5. `mark_called_methods()` で到達可否をマーキングする
6. `CobolAnalysisResult` にまとめ、JSON または Markdown として出力する

## 5. 入出力

### 入力

- COBOL ソースファイル
- `--encoding`
- `--format=json|markdown`

### 出力

- JSON
  - 後続ツール向けの構造化データ
- Markdown
  - 人が読める解析ドラフト

## 6. 主要な設計判断

- 標準ライブラリのみで構成し、実行環境依存を減らしている
- 解析対象を主要構文中心に絞り、完全な COBOL パーサではなく業務ドキュメント生成向けの抽出器として設計している
- Markdown 出力は後続の LLM 処理で扱いやすい章構成にしている

## 7. 制約

- 静的解析のため、実行時条件や外部 COPY の完全解決は行わない
- COBOL 全構文を網羅しているわけではない
- コメント品質や命名規則に依存して `要確認` が増減する
