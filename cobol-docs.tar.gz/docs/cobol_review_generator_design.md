# cobol_review_generator.py 設計書

## 1. 目的

`cobol_review_generator.py` は `cobol_parser.py` の出力を受け取り、OpenAI 互換 API を使って COBOL コードレビュー結果の Markdown を生成するツールです。  
大きな入力をそのまま一括レビューせず、`design_doc_generator.py` と同じセクション粒度で分割し、ローカルLLMでも扱いやすいサイズでレビューします。

## 2. 責務

- 入力形式の判定
- JSON / Markdown の入力分解
- セクション別レビュー対象の抽出
- レビュー観点ファイルの読込と対象別選択
- OpenAI 互換 API 呼び出し
- セクション別レビュー結果の結合
- 必要に応じたセクション別キャッシュ保存

## 3. 主な構成

- `OpenAICompatibleClient`
  - Chat Completions API 呼び出しを担当
- `filter_tasks()`
  - section key やタイトル条件でレビュー対象を絞り込む
- `load_review_checkpoints()`
  - レビュー観点 Markdown を章ごとに読み込む
- `select_review_points()`
  - 対象セクションに応じて使う観点を選ぶ
- `assemble_review_document()`
  - セクション別レビュー結果を最終 Markdown に再構成する

## 4. 処理フロー

1. 入力ファイルを読み込む
2. `--input-format` または拡張子から形式を決定する
3. `design_doc_generator.py` と同じ分割ロジックで `SectionTask` 配列を作る
4. 必要なら `--section-key` `--title-contains` で対象を絞る
5. レビュー観点ファイルから対象別の観点を選ぶ
6. 各セクションを OpenAI 互換 API に送る
7. 必要に応じて `cache-dir` にセクション別レビュー結果を保存する
8. 最終レビュー Markdown として出力する

## 5. セクション分割方針

`design_doc_generator.py` の `build_section_tasks()` をそのまま再利用する。

- JSON 入力
  - `プログラム概要`
  - `外部仕様・入出力`
  - 各 `セクション詳細`
  - `DB・SQL仕様`
- Markdown 入力
  - 文書タイトル直下の章見出し単位
  - `セクション詳細` 章のみ子見出し単位で分割

## 6. レビュー方針

- 指摘は重大度順
- 推測禁止
- 不足情報は `要確認`
- COBOL 命令の逐語説明ではなく、欠落・不整合・保守リスクを中心にレビューする
- レビュー観点は別ファイル `docs/cobol_review_checkpoints.md` で管理する
