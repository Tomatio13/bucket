# unit_test_item_generator.py 設計書

## 1. 目的

`unit_test_item_generator.py` は詳細設計書 Markdown を入力とし、OpenAI 互換 API を使って単体試験項目一覧 Markdown を生成するツールです。  
プロジェクト固有の試験観点に合わせて調整しやすいよう、セクション単位の処理とキャッシュ再利用を前提にしています。

## 2. 責務

- 詳細設計書の目次解析
- トップ章と `セクション詳細` 配下の子セクション分割
- OpenAI 互換 API による試験項目生成
- 生成済み内容の再校正
- 具体値や補完表現のサニタイズ
- キャッシュ再利用とデバッグダンプ出力

## 3. 主な構成

- `TocStructure`
  - 目次から抽出した章構成情報
- `OpenAICompatibleClient`
  - 試験項目生成と再校正 API 呼び出しを担当
- `build_test_item_tasks()`
  - 目次ベースで `SectionTask` を組み立てる
- `ground_generated_content()`
  - LLM 出力を再校正し、根拠の薄い具体化を減らす
- `sanitize_generated_content()`
  - 表行や自由文から unsupported な具体値を `要確認` に寄せる
- `read_section_cache()`
  - 既存生成結果を再利用する

## 4. 処理フロー

1. 詳細設計書 Markdown を読み込む
2. `## 目次` を解析して章一覧と `セクション詳細` の子セクション一覧を取得する
3. 各章を `SectionTask` に変換する
4. `cache-dir` に既存成果物があれば再利用する
5. 必要なセクションだけ OpenAI 互換 API に送る
6. 生成結果に対して再校正とローカルサニタイズを実施する
7. 最終的な単体試験項目一覧 Markdown を出力する

## 5. 品質制御

- 設計書にない `NULL`、`不正データ`、固定コード値、引用句を警戒対象にしている
- API 失敗時は request body / payload / metadata を `debug-dir` に保存できる
- 途中失敗しても `.partial.md` を出力して、途中成果物を失わないようにしている

## 6. キャッシュ方針

- `cache-dir/<task.key>.md` にセクション単位で保存
- 再実行時は cache を優先利用
- ただし内容に unsupported な具体化がある場合は再校正を行う

## 7. 制約

- 汎用ヒューリスティックだけでは、プロジェクト固有ルールまでは完全に反映できない
- 設計書自体に具体値が含まれている場合、どこまで残すかは案件ルールで調整が必要
- 最終品質は設計書品質と、プロジェクト側で定義する試験ポリシーに強く依存する
