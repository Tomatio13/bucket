# design_doc_generator.py 設計書

## 1. 目的

`design_doc_generator.py` は `cobol_parser.py` の出力を受け取り、OpenAI 互換 API を使って日本語の詳細設計書 Markdown を生成するツールです。  
入力全体を一括で送るのではなく、章単位またはセクション単位で分割して生成することで、制御しやすい出力を目指します。

## 2. 責務

- 入力形式の判定
- JSON / Markdown の入力分解
- 章ごとの生成タスク化
- OpenAI 互換 API 呼び出し
- 生成結果の結合
- セクション別キャッシュ保存

## 3. 主な構成

- `SectionTask`
  - 1 章または 1 セクション分の生成単位
- `OpenAICompatibleClient`
  - Chat Completions API 呼び出しを担当
- `build_section_tasks_from_json()`
  - 解析 JSON から章構成を組み立てる
- `build_section_tasks_from_markdown()`
  - Markdown 見出しから生成単位を抽出する
- `assemble_document()`
  - 生成済みセクションを最終 Markdown に再構成する

## 4. 処理フロー

1. 入力ファイルを読み込む
2. `--input-format` または拡張子から形式を決定する
3. 入力内容を `SectionTask` の配列へ変換する
4. 各タスクを OpenAI 互換 API に送信する
5. 必要に応じて `cache-dir` にセクション結果を保存する
6. 最終設計書を章構成付き Markdown として出力する

## 5. セクション分割方針

### JSON 入力

- `プログラム概要`
- `外部仕様・入出力`
- 各 `セクション詳細`
- `DB・SQL仕様`

### Markdown 入力

- 文書タイトル直下の章見出し単位で処理
- `セクション詳細` 章のみ、配下の `###` セクションを個別タスクとして扱う

## 6. プロンプト方針

- 日本語出力
- 推測禁止
- 不足情報は `要確認`
- COBOL 命令の逐語説明ではなく、設計書として自然な説明へ変換

## 7. 制約

- 入力情報にない業務仕様は生成しない前提
- API モデル品質に応じて文体や粒度は変動する
- Markdown 入力の見出し品質に依存して分割精度が変わる
