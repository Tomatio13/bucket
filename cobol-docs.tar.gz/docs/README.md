# Docs Index

このディレクトリには、各スクリプトの設計情報とレビュー観点を格納します。

## 一覧

- [cobol_parser_design.md](./cobol_parser_design.md)
  - `cobol_parser.py` の責務、解析対象、出力構造
- [design_doc_generator_design.md](./design_doc_generator_design.md)
  - `design_doc_generator.py` の分割方針、設計書生成フロー
- [cobol_review_generator_design.md](./cobol_review_generator_design.md)
  - `cobol_review_generator.py` のレビュー生成フロー、セクション抽出方針
- [cobol_review_checkpoints.md](./cobol_review_checkpoints.md)
  - COBOL レビュー時に使う観点集
- [unit_test_item_generator_design.md](./unit_test_item_generator_design.md)
  - `unit_test_item_generator.py` の試験項目生成フロー

## レビュー関連の参照順

コードレビュー機能を把握するときは、次の順で読むと追いやすいです。

1. `cobol_review_generator_design.md`
2. `cobol_review_checkpoints.md`
3. `design_doc_generator_design.md`

`cobol_review_generator.py` は `design_doc_generator.py` のセクション分割ロジックを再利用しているため、レビュー粒度の背景は設計書生成側の設計情報も合わせて確認してください。
